-- Drop the caregiver-only table we just created (it's empty)
DROP TABLE IF EXISTS public.caregiver_medications;

-- Create unified medications table that works for both seniors and caregivers
CREATE TABLE public.medications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  senior_id UUID NOT NULL,
  owner_id UUID NOT NULL,
  created_by_role TEXT NOT NULL CHECK (created_by_role IN ('senior', 'caregiver')),
  name TEXT NOT NULL,
  time TEXT NOT NULL,
  dosage TEXT,
  notes TEXT,
  completed BOOLEAN NOT NULL DEFAULT false,
  completed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.medications ENABLE ROW LEVEL SECURITY;

-- Seniors can view their own medications (created by themselves or their caregiver)
CREATE POLICY "Seniors can view their medications"
  ON public.medications FOR SELECT
  USING (senior_id = auth.uid());

-- Seniors can create their own medications
CREATE POLICY "Seniors can create their own medications"
  ON public.medications FOR INSERT
  WITH CHECK (
    auth.uid() = owner_id AND 
    auth.uid() = senior_id AND 
    created_by_role = 'senior'
  );

-- Seniors can update their own medications (mark as completed)
CREATE POLICY "Seniors can update their medications"
  ON public.medications FOR UPDATE
  USING (senior_id = auth.uid());

-- Seniors can delete their own medications (only ones they created)
CREATE POLICY "Seniors can delete their own medications"
  ON public.medications FOR DELETE
  USING (senior_id = auth.uid() AND created_by_role = 'senior');

-- Caregivers can view their seniors' medications
CREATE POLICY "Caregivers can view their seniors medications"
  ON public.medications FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM caregiver_seniors
      WHERE caregiver_seniors.caregiver_id = auth.uid()
      AND caregiver_seniors.senior_id = medications.senior_id
    )
  );

-- Caregivers can create medications for their seniors
CREATE POLICY "Caregivers can create medications for their seniors"
  ON public.medications FOR INSERT
  WITH CHECK (
    auth.uid() = owner_id AND
    created_by_role = 'caregiver' AND
    EXISTS (
      SELECT 1 FROM caregiver_seniors
      WHERE caregiver_seniors.caregiver_id = auth.uid()
      AND caregiver_seniors.senior_id = medications.senior_id
    )
  );

-- Caregivers can update their seniors' medications (mark as completed)
CREATE POLICY "Caregivers can update their seniors medications"
  ON public.medications FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM caregiver_seniors
      WHERE caregiver_seniors.caregiver_id = auth.uid()
      AND caregiver_seniors.senior_id = medications.senior_id
    )
  );

-- Caregivers can delete medications they created
CREATE POLICY "Caregivers can delete their medications"
  ON public.medications FOR DELETE
  USING (owner_id = auth.uid() AND created_by_role = 'caregiver');

-- Deny anonymous access
CREATE POLICY "deny_anon_access_medications"
  ON public.medications FOR ALL
  USING (false);

-- Add updated_at trigger
CREATE TRIGGER update_medications_updated_at
  BEFORE UPDATE ON public.medications
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();