import { useState, useMemo } from "react";
import { LucideIcon, ChevronUp, ChevronDown } from "lucide-react";

export interface CaregiverNavItem {
  value: string;
  label: string;
  icon: LucideIcon;
}

interface CaregiverBottomNavProps {
  items: CaregiverNavItem[];
  active: string;
  onChange: (value: string) => void;
}

const PRIORITY_VALUES = ["overview", "health", "trackers"];

/** Compact fixed mobile bottom navigation for caregivers. */
export const CaregiverBottomNav = ({ items, active, onChange }: CaregiverBottomNavProps) => {
  const [expanded, setExpanded] = useState(false);

  const itemMap = useMemo(() => {
    const map = new Map<string, CaregiverNavItem>();
    items.forEach((item) => map.set(item.value, item));
    return map;
  }, [items]);

  const collapsedItems = useMemo(() => {
    const seen = new Set<string>();
    const result: CaregiverNavItem[] = [];

    const add = (value: string) => {
      const item = itemMap.get(value);
      if (item && !seen.has(value)) {
        seen.add(value);
        result.push(item);
      }
    };

    PRIORITY_VALUES.forEach(add);
    add(active);
    for (const item of items) {
      if (result.length >= 3) break;
      add(item.value);
    }
    return result;
  }, [itemMap, items, active]);

  const renderTile = (item: CaregiverNavItem) => {
    const Icon = item.icon;
    const isActive = active === item.value;
    return (
      <button
        key={item.value}
        type="button"
        aria-current={isActive ? "page" : undefined}
        onClick={() => {
          onChange(item.value);
          setExpanded(false);
          window.scrollTo({ top: 0, behavior: "smooth" });
        }}
        className={`w-full min-h-[52px] flex flex-col items-center justify-center gap-0.5 rounded-xl border px-1 py-1.5 transition-all active:scale-95 ${
          isActive
            ? "bg-primary/10 text-primary border-primary/30 font-semibold shadow-sm"
            : "bg-muted/40 text-muted-foreground border-border"
        }`}
      >
        <Icon className="w-5 h-5" />
        <span className="text-[10px] leading-tight text-center font-medium truncate w-full">
          {item.label}
        </span>
      </button>
    );
  };

  return (
    <nav
      aria-label="Caregiver sections"
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 border-t border-border bg-card/95 backdrop-blur-md px-2 pt-2 pb-4"
    >
      {!expanded ? (
        <ul className="grid grid-cols-4 gap-1.5">
          {collapsedItems.map((item) => (
            <li key={item.value}>{renderTile(item)}</li>
          ))}
          <li>
            <button
              type="button"
              aria-label="Show all sections"
              onClick={() => setExpanded(true)}
              className="w-full min-h-[52px] flex flex-col items-center justify-center gap-0.5 rounded-xl border px-1 py-1.5 bg-muted/70 text-muted-foreground border-border transition-all active:scale-95"
            >
              <ChevronUp className="w-5 h-5" />
              <span className="text-[10px] leading-tight font-medium">All</span>
            </button>
          </li>
        </ul>
      ) : (
        <div>
          <div className="flex items-center justify-center mb-1.5">
            <button
              type="button"
              onClick={() => setExpanded(false)}
              className="flex items-center gap-1 text-[11px] font-medium text-muted-foreground px-3 py-1 rounded-full bg-muted/70 border border-border active:scale-95"
            >
              <ChevronDown className="w-3.5 h-3.5" />
              Hide
            </button>
          </div>
          <ul className="grid grid-cols-4 gap-1.5">
            {items.map((item) => (
              <li key={item.value}>{renderTile(item)}</li>
            ))}
          </ul>
        </div>
      )}
    </nav>
  );
};

export default CaregiverBottomNav;
