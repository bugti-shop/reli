import { useCallback, useEffect, useMemo, useState } from "react";
import { Activity, Clock3, Heart, HeartPulse, Phone, Pill } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface SeniorDetails {
  full_name: string | null;
  age: number | null;
  address: string | null;
  emergency_contacts: { name?: string; relationship?: string; phone?: string }[];
}

interface DashboardHealthSummaryProps {
  seniorId: string;
  variant?: "full" | "reference";
}

interface VitalSummary {
  reading_type: string;
  systolic: number | null;
  diastolic: number | null;
  bpm: number | null;
  recorded_at: string;
}

interface MedicationSummary {
  id: string;
  name: string;
  time: string;
  completed: boolean;
}

const formatReadingTime = (value?: string) => {
  if (!value) return "No reading yet";
  return `Recorded ${new Date(value).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}`;
};

const formatReferenceReadingTime = (value?: string) => {
  if (!value) return "No reading yet";
  return new Date(value).toLocaleString([], {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
};

type ReadingStatus = { label: string; tone: "good" | "watch" } | null;

const bloodPressureStatus = (systolic?: number | null, diastolic?: number | null): ReadingStatus => {
  if (!systolic || !diastolic) return null;
  if (systolic < 90 || diastolic < 60) return { label: "Low", tone: "watch" };
  if (systolic > 129 || diastolic > 84) return { label: "High", tone: "watch" };
  return { label: "Good", tone: "good" };
};

const heartRateStatus = (bpm?: number | null): ReadingStatus => {
  if (!bpm) return null;
  if (bpm < 60) return { label: "Low", tone: "watch" };
  if (bpm > 100) return { label: "High", tone: "watch" };
  return { label: "Good", tone: "good" };
};

const StatusBadge = ({ status, className = "" }: { status: ReadingStatus; className?: string }) => {
  if (!status) return null;
  return (
    <span
      className={`inline-flex shrink-0 items-center rounded-full px-1.5 py-[1px] text-[8px] font-bold uppercase leading-none md:px-2.5 md:py-0.5 md:text-xs ${
        status.tone === "good"
          ? "bg-dashboard-mint text-dashboard-blue-deep"
          : "bg-destructive text-destructive-foreground"
      } ${className}`}
    >
      {status.label}
    </span>
  );
};

const formatMedicationTime = (value: string) => {
  const [hours, minutes] = value.split(":").map(Number);
  if (!Number.isFinite(hours) || !Number.isFinite(minutes)) return value;
  const date = new Date();
  date.setHours(hours, minutes, 0, 0);
  return date.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
};

export const DashboardHealthSummary = ({ seniorId, variant = "full" }: DashboardHealthSummaryProps) => {
  const [vitals, setVitals] = useState<VitalSummary[]>([]);
  const [medications, setMedications] = useState<MedicationSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [details, setDetails] = useState<SeniorDetails | null>(null);

  useEffect(() => {
    let active = true;
    supabase
      .from("profiles")
      .select("full_name, age, address, emergency_contacts")
      .eq("id", seniorId)
      .maybeSingle()
      .then(({ data }) => {
        if (!active || !data) return;
        setDetails({
          full_name: data.full_name,
          age: data.age,
          address: data.address,
          emergency_contacts: Array.isArray(data.emergency_contacts)
            ? (data.emergency_contacts as SeniorDetails["emergency_contacts"])
            : [],
        });
      });
    return () => {
      active = false;
    };
  }, [seniorId]);

  const loadSummary = useCallback(async () => {
    const [{ data: readings, error: readingsError }, { data: meds, error: medicationsError }] = await Promise.all([
      supabase
        .from("vital_readings")
        .select("reading_type, systolic, diastolic, bpm, recorded_at")
        .eq("senior_id", seniorId)
        .in("reading_type", ["blood_pressure", "heart_rate"])
        .is("deleted_at", null)
        .order("recorded_at", { ascending: false })
        .limit(20),
      supabase
        .from("medications")
        .select("id, name, time, completed")
        .eq("senior_id", seniorId)
        .order("time", { ascending: true }),
    ]);

    if (readingsError) console.error("Error loading latest dashboard readings:", readingsError);
    if (medicationsError) console.error("Error loading dashboard medications:", medicationsError);
    setVitals(readings || []);
    setMedications(meds || []);
    setLoading(false);
  }, [seniorId]);

  useEffect(() => {
    loadSummary();

    const channel = supabase
      .channel(`dashboard-health-summary-${seniorId}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "vital_readings", filter: `senior_id=eq.${seniorId}` },
        loadSummary,
      )
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "medications", filter: `senior_id=eq.${seniorId}` },
        loadSummary,
      )
      .subscribe();

    // Safety net so the header still refreshes if the live connection drops.
    const interval = window.setInterval(loadSummary, 60000);
    const onVisible = () => {
      if (document.visibilityState === "visible") loadSummary();
    };
    document.addEventListener("visibilitychange", onVisible);
    window.addEventListener("focus", loadSummary);

    return () => {
      supabase.removeChannel(channel);
      window.clearInterval(interval);
      document.removeEventListener("visibilitychange", onVisible);
      window.removeEventListener("focus", loadSummary);
    };
  }, [loadSummary, seniorId]);

  const latestBloodPressure = vitals.find((reading) => reading.reading_type === "blood_pressure");
  const latestHeartRate = vitals.find((reading) => reading.reading_type === "heart_rate");
  const completedCount = medications.filter((medication) => medication.completed).length;

  const nextMedication = useMemo(() => {
    const untaken = medications.filter((medication) => !medication.completed);
    if (!untaken.length) return null;
    const now = new Date();
    const currentMinutes = now.getHours() * 60 + now.getMinutes();
    return untaken.find((medication) => {
      const [hours, minutes] = medication.time.split(":").map(Number);
      return Number.isFinite(hours) && Number.isFinite(minutes) && hours * 60 + minutes >= currentMinutes;
    }) || untaken[0];
  }, [medications]);

  const completionPercent = medications.length ? Math.round((completedCount / medications.length) * 100) : 0;
  const tileClass = "min-h-28 rounded-lg border border-primary-foreground/20 bg-primary-foreground/10 p-3 backdrop-blur-md transition-colors hover:bg-primary-foreground/15 md:min-h-36 md:p-4";

  if (variant === "reference") {
    return (
      <section aria-label="Latest health readings" className="grid grid-cols-2 gap-1.5 md:grid-cols-4 md:gap-4">
        <div className="flex min-h-[3.25rem] items-center gap-1.5 rounded-2xl border border-primary-foreground/20 bg-dashboard-blue-deep/55 py-1.5 pl-1.5 pr-2 text-primary-foreground shadow-sm backdrop-blur-md md:min-h-24 md:gap-3 md:p-5">
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-destructive/85 md:h-14 md:w-14">
            <Activity className="!h-[1.35rem] !w-[1.35rem] md:!h-8 md:!w-8" strokeWidth={2.6} aria-hidden="true" />
          </span>
          <div className="min-w-0">
            <p className="text-[9px] font-bold uppercase leading-tight text-primary-foreground/90 md:text-sm">Recent BP</p>
            <p className="mt-0.5 flex flex-wrap items-center gap-1 whitespace-nowrap text-xl font-bold leading-none md:mt-1 md:gap-2 md:text-3xl">
              {latestBloodPressure?.systolic && latestBloodPressure.diastolic
                ? `${latestBloodPressure.systolic}/${latestBloodPressure.diastolic}`
                : loading ? "…" : "—"}
              <StatusBadge status={bloodPressureStatus(latestBloodPressure?.systolic, latestBloodPressure?.diastolic)} />
            </p>
            <p className="mt-1.5 truncate text-[8px] font-medium text-primary-foreground/80 md:mt-2 md:text-xs">{formatReferenceReadingTime(latestBloodPressure?.recorded_at)}</p>
          </div>
        </div>
        <div className="flex min-h-[3.25rem] items-center gap-1.5 rounded-2xl border border-primary-foreground/20 bg-dashboard-blue-deep/55 py-1.5 pl-1.5 pr-2 text-primary-foreground shadow-sm backdrop-blur-md md:min-h-24 md:gap-3 md:p-5">
          <span className="flex h-8 w-8 shrink-0 items-center justify-center text-destructive md:h-14 md:w-14">
            <Heart className="!h-7 !w-7 fill-current md:!h-11 md:!w-11" strokeWidth={1.5} aria-hidden="true" />
          </span>
          <div className="min-w-0">
            <p className="text-[9px] font-bold uppercase leading-tight text-primary-foreground/90 md:text-sm">Recent heart rate</p>
            <p className="mt-0.5 flex flex-wrap items-center gap-1 whitespace-nowrap text-xl font-bold leading-none md:mt-1 md:gap-2 md:text-3xl">
              {latestHeartRate?.bpm ? `${latestHeartRate.bpm} bpm` : loading ? "…" : "—"}
              <StatusBadge status={heartRateStatus(latestHeartRate?.bpm)} />
            </p>
            <p className="mt-1.5 truncate text-[8px] font-medium text-primary-foreground/80 md:mt-2 md:text-xs">{formatReferenceReadingTime(latestHeartRate?.recorded_at)}</p>
          </div>
        </div>
        <div className="flex min-h-[4.5rem] items-center gap-1.5 rounded-2xl border border-primary-foreground/20 bg-dashboard-blue-deep/55 p-1.5 text-primary-foreground shadow-sm backdrop-blur-md md:min-h-32 md:gap-3 md:p-5">
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-secondary/85 md:h-14 md:w-14">
            <Pill className="!h-[1.35rem] !w-[1.35rem] md:!h-8 md:!w-8" strokeWidth={2.2} aria-hidden="true" />
          </span>
          <div className="min-w-0">
            <p className="text-[9px] font-bold uppercase leading-tight text-primary-foreground/90 md:text-sm">Meds taken</p>
            <p className="mt-0.5 whitespace-nowrap text-xl font-bold leading-none md:mt-1 md:text-3xl">
              {loading ? "…" : medications.length ? `${completedCount}/${medications.length}` : "—"}
            </p>
            <p className="mt-1.5 truncate text-[8px] font-medium text-primary-foreground/80 md:mt-2 md:text-xs">
              {medications.length ? `${completionPercent}% complete today` : "No medications added"}
            </p>
          </div>
        </div>
        <div className="flex min-h-[4.5rem] items-center gap-1.5 rounded-2xl border border-primary-foreground/20 bg-dashboard-blue-deep/55 p-1.5 text-primary-foreground shadow-sm backdrop-blur-md md:min-h-32 md:gap-3 md:p-5">
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-accent/45 md:h-14 md:w-14">
            <Clock3 className="!h-[1.35rem] !w-[1.35rem] md:!h-8 md:!w-8" strokeWidth={2.2} aria-hidden="true" />
          </span>
          <div className="min-w-0">
            <p className="text-[9px] font-bold uppercase leading-tight text-primary-foreground/90 md:text-sm">Next medication</p>
            <p className="mt-0.5 truncate text-base font-bold leading-none md:mt-1 md:text-2xl">
              {loading ? "…" : nextMedication?.name || (medications.length ? "All taken today" : "Nothing scheduled")}
            </p>
            <p className="mt-1.5 truncate text-[8px] font-medium text-primary-foreground/80 md:mt-2 md:text-xs">
              {nextMedication ? formatMedicationTime(nextMedication.time) : " "}
            </p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section aria-label="Latest health readings" className="grid grid-cols-2 gap-2 md:gap-3 lg:grid-cols-5">
      <div className={tileClass}>
        <div className="mb-2 flex items-start justify-between gap-1 md:mb-4 md:gap-2">
          <p className="text-xs font-semibold uppercase text-primary-foreground/80 md:text-sm">Recent BP</p>
          <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-destructive/25 md:h-9 md:w-9">
            <HeartPulse className="h-4 w-4 text-primary-foreground md:h-5 md:w-5" aria-hidden="true" />
          </span>
        </div>
        <p className="flex flex-wrap items-center gap-2 text-2xl font-bold text-primary-foreground md:text-3xl">
          {latestBloodPressure?.systolic && latestBloodPressure.diastolic
            ? `${latestBloodPressure.systolic}/${latestBloodPressure.diastolic}`
            : loading ? "…" : "—"}
          <StatusBadge status={bloodPressureStatus(latestBloodPressure?.systolic, latestBloodPressure?.diastolic)} />
        </p>
        <p className="mt-1 text-xs text-primary-foreground/70 md:mt-2 md:text-sm">{formatReadingTime(latestBloodPressure?.recorded_at)}</p>
      </div>

      <div className={tileClass}>
        <div className="mb-2 flex items-start justify-between gap-1 md:mb-4 md:gap-2">
          <p className="text-xs font-semibold uppercase text-primary-foreground/80 md:text-sm">Recent heart rate</p>
          <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-accent/25 md:h-9 md:w-9">
            <Activity className="h-4 w-4 text-primary-foreground md:h-5 md:w-5" aria-hidden="true" />
          </span>
        </div>
        <p className="flex flex-wrap items-center gap-2 text-2xl font-bold text-primary-foreground md:text-3xl">
          {latestHeartRate?.bpm ? `${latestHeartRate.bpm} bpm` : loading ? "…" : "—"}
          <StatusBadge status={heartRateStatus(latestHeartRate?.bpm)} />
        </p>
        <p className="mt-1 text-xs text-primary-foreground/70 md:mt-2 md:text-sm">{formatReadingTime(latestHeartRate?.recorded_at)}</p>
      </div>

      <div className={tileClass}>
        <div className="mb-2 flex items-start justify-between gap-1 md:mb-4 md:gap-2">
          <p className="text-xs font-semibold uppercase text-primary-foreground/80 md:text-sm">Meds taken</p>
          <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-secondary/25 md:h-9 md:w-9">
            <Pill className="h-4 w-4 text-primary-foreground md:h-5 md:w-5" aria-hidden="true" />
          </span>
        </div>
        <div className="flex items-end gap-3">
          <p className="text-2xl font-bold text-primary-foreground md:text-3xl">
            {loading ? "…" : medications.length ? `${completedCount}/${medications.length}` : "—"}
          </p>
          {medications.length > 0 && (
            <progress className="mb-2 h-2 min-w-0 flex-1 accent-accent" max="100" value={completionPercent} aria-label={`${completionPercent}% complete`} />
          )}
        </div>
        <p className="mt-1 text-xs text-primary-foreground/70 md:mt-2 md:text-sm">
          {medications.length ? `${completionPercent}% complete today` : "No medications added"}
        </p>
      </div>

      <div className="min-h-28 rounded-lg border border-accent/40 bg-accent/15 p-3 backdrop-blur-md transition-colors hover:bg-accent/20 md:min-h-36 md:p-4">
        <div className="mb-2 flex items-start justify-between gap-1 md:mb-4 md:gap-2">
          <p className="text-xs font-semibold uppercase text-primary-foreground/80 md:text-sm">Next medication</p>
          <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-accent/25 md:h-9 md:w-9">
            <Clock3 className="h-4 w-4 text-primary-foreground md:h-5 md:w-5" aria-hidden="true" />
          </span>
        </div>
        <p className="truncate text-lg font-bold text-primary-foreground md:text-xl">
          {loading ? "Loading…" : nextMedication?.name || (medications.length ? "All taken today" : "Nothing scheduled")}
        </p>
        {nextMedication && (
          <p className="mt-1 text-sm font-semibold text-primary-foreground/85 md:mt-2 md:text-base">{formatMedicationTime(nextMedication.time)}</p>
        )}
      </div>

      <div className={`col-span-2 lg:col-span-1 ${tileClass}`}>
        <div className="mb-2 flex items-start justify-between gap-1 md:mb-4 md:gap-2">
          <p className="text-xs font-semibold uppercase text-primary-foreground/80 md:text-sm">Details &amp; emergency</p>
          <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-primary-foreground/20 md:h-9 md:w-9">
            <Phone className="h-4 w-4 text-primary-foreground md:h-5 md:w-5" aria-hidden="true" />
          </span>
        </div>
        <p className="text-base font-bold text-primary-foreground md:text-lg">
          {details?.age != null ? `Age ${details.age}` : "Age not set"}
        </p>
        {details?.address && (
          <p className="mt-1 truncate text-xs text-primary-foreground/80 md:text-sm">{details.address}</p>
        )}
        {details?.emergency_contacts?.length ? (
          <p className="mt-1 text-xs text-primary-foreground/80 md:mt-2 md:text-sm">
            {details.emergency_contacts[0].name || "Contact"}
            {details.emergency_contacts[0].phone ? ` · ${details.emergency_contacts[0].phone}` : ""}
            {details.emergency_contacts.length > 1 ? ` +${details.emergency_contacts.length - 1} more` : ""}
          </p>
        ) : (
          <p className="mt-1 text-xs text-primary-foreground/70 md:mt-2 md:text-sm">No emergency contact yet</p>
        )}
      </div>
    </section>
  );
};