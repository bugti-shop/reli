import { useEffect, useState } from "react";
import { Check, HeartHandshake, Loader2, ShieldCheck, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import {
  buyStorePackage, loadStorePackages, restoreStorePurchases, storePurchasesAvailable, type StorePackage,
} from "@/lib/purchases";
import { nativePlatform } from "@/lib/native";

const PREMIUM_FEATURES = [
  "Unlimited health, tracker, journal, and daily care history",
  "Custom reminders and trackers for your family's routines",
  "AI-powered trends and care insights",
  "Family sharing, reports, and coordinated caregiver access",
  "One membership for the senior and connected caregivers",
];

/** Premium purchase inside the phone app, through Apple / Google billing. */
export const StorePlans = ({ userId, onActive }: { userId: string | null; onActive: () => Promise<void> | void }) => {
  const { toast } = useToast();
  const [pkgs, setPkgs] = useState<StorePackage[] | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const store = nativePlatform() === "ios" ? "App Store" : "Google Play";

  useEffect(() => {
    if (!userId || !storePurchasesAvailable()) { setPkgs([]); return; }
    loadStorePackages(userId).then(setPkgs).catch(() => setPkgs([]));
  }, [userId]);

  const done = async (active: boolean) => {
    if (active) {
      toast({ title: "You're Premium!", description: "Confirming with your account…" });
      // The store notifies our backend; poll briefly until the plan flips.
      for (let i = 0; i < 6; i++) { await onActive(); await new Promise((r) => setTimeout(r, 2500)); }
    }
  };

  const buy = async (p: StorePackage) => {
    if (!userId) return;
    setBusy(p.id);
    try { await done(await buyStorePackage(userId, p)); }
    catch (e: any) {
      if (!e?.userCancelled) toast({ title: "Purchase not completed", description: "No charge was made.", variant: "destructive" });
    } finally { setBusy(null); }
  };

  const restore = async () => {
    if (!userId) return;
    setBusy("restore");
    try {
      const active = await restoreStorePurchases(userId);
      if (!active) toast({ title: "No active subscription found" });
      await done(active);
    } catch { toast({ title: "Could not restore purchases", variant: "destructive" }); }
    finally { setBusy(null); }
  };

  if (pkgs === null) return <div className="flex justify-center py-10"><Loader2 className="h-6 w-6 animate-spin" /></div>;

  if (pkgs.length === 0) {
    return (
      <Card className="border-primary/20 p-6 text-center shadow-gentle">
        <ShieldCheck className="mx-auto mb-3 h-8 w-8 text-primary" />
        <p className="font-semibold text-foreground">Reli Premium is being prepared</p>
        <p className="mt-1 text-sm text-muted-foreground">
          The monthly plan will appear here when your store account finishes loading it.
        </p>
        <Button variant="ghost" className="mt-3" onClick={restore} disabled={busy !== null}>
          {busy === "restore" && <Loader2 className="h-4 w-4 animate-spin" />}Restore purchases
        </Button>
      </Card>
    );
  }

  const monthly = pkgs[0];

  return (
    <Card className="mx-auto max-w-md overflow-hidden border-primary/25 shadow-gentle">
      <div className="bg-primary px-6 py-7 text-primary-foreground">
        <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary-foreground/15">
          <HeartHandshake className="h-6 w-6" />
        </div>
        <div className="flex items-center gap-2 text-sm font-semibold">
          <Sparkles className="h-4 w-4" /> Premium family care
        </div>
        <h2 className="mt-2 text-3xl font-bold">Reli Premium</h2>
        <p className="mt-2 text-sm leading-6 text-primary-foreground/85">
          More history, smarter insights, and shared tools for confident family caregiving.
        </p>
      </div>
      <div className="p-6">
        <div className="mb-6 flex items-end gap-2 border-b border-border pb-5">
          <span className="text-4xl font-bold">{monthly.price || "$34.99"}</span>
          <span className="pb-1 text-muted-foreground">/ month</span>
        </div>
        <ul className="space-y-3">
          {PREMIUM_FEATURES.map((feature) => (
            <li key={feature} className="flex items-start gap-3 text-sm leading-5">
              <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-accent/50">
                <Check className="h-3.5 w-3.5 text-accent-foreground" />
              </span>
              <span>{feature}</span>
            </li>
          ))}
        </ul>
        <Button className="mt-7 h-12 w-full text-base" onClick={() => buy(monthly)} disabled={busy !== null}>
          {busy === monthly.id && <Loader2 className="h-4 w-4 animate-spin" />}
          Start Reli Premium
        </Button>
        <p className="mt-3 text-center text-xs text-muted-foreground">Monthly subscription · Cancel anytime</p>
        <Button variant="ghost" className="mt-2 w-full" onClick={restore} disabled={busy !== null}>
          {busy === "restore" && <Loader2 className="h-4 w-4 animate-spin" />}Restore purchases
        </Button>
        <p className="mt-3 text-center text-xs leading-5 text-muted-foreground">
          Payment is charged to your {store} account. This subscription renews automatically each month unless
          cancelled at least 24 hours before the current period ends. Manage or cancel in your {store} settings.{" "}
          <a href="/terms-of-service" className="underline underline-offset-2">Terms</a> ·{" "}
          <a href="/privacy-policy" className="underline underline-offset-2">Privacy</a>
        </p>
      </div>
    </Card>
  );
};
