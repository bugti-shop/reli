package com.reli.care;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    public static final String EXTRA_SOS = "reli_sos";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SosMessagingService.ensureChannel(this);
        applySosWindow(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        applySosWindow(intent);
    }

    /** Only an SOS full-screen intent may show Reli over the lock screen. */
    private void applySosWindow(Intent intent) {
        boolean sos = intent != null && intent.getBooleanExtra(EXTRA_SOS, false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(sos);
            setTurnScreenOn(sos);
        } else if (sos) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        }
    }
}
