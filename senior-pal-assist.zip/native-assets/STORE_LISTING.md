# Reli: Family Caregiver App — Google Play listing

## App title
Reli: Family Caregiver App

## Short description
Coordinate medications, health, reminders and daily care with your family.

## Long description
Reli helps families coordinate care for aging parents, older adults, and loved ones who need everyday support. Seniors and authorized caregivers stay connected through one clear, easy-to-use care companion designed for shared routines, timely updates, and greater peace of mind.

Create medication schedules, appointments, and custom reminders so important tasks are easier to remember. Caregivers can use a dedicated dashboard to review upcoming actions, recent updates, medication status, and the information their family needs to coordinate care.

Track health readings and daily activity, including blood pressure, heart rate, glucose, weight, water intake, medication completion, and other care routines. Reli organizes this information into accessible histories and reports that families can review together and discuss with healthcare professionals.

Capture symptoms, mood, sleep, meals, activities, and observations in the shared care journal. Record meaningful memories and photos with Life Stories, helping families preserve personal history and stay connected beyond day-to-day care tasks.

Reli also supports family sharing, caregiver messages, care reminders, notifications, emergency SOS alerts, and live location sharing during an active SOS. Access is limited to the senior and their authorized caregivers, helping families coordinate support while respecting personal information.

Key features include:
• Medication schedules, completion tracking, and reminders
• Appointment and custom care reminders
• Dedicated caregiver dashboard and daily status view
• Health readings and activity history
• Care journal and pattern summaries
• Life Stories, memories, and private photo sharing
• Family caregiver sharing and care coordination
• Messages, alerts, and real-time notifications
• Emergency SOS and live location sharing during an active alert
• Shared reports for family and care discussions

Reli does not provide medical advice, diagnosis, or treatment. Always consult a qualified healthcare professional before making medical or medication decisions. Emergency SOS notifications support family coordination and are not a replacement for local emergency services.