-- Create medication schedules table for caregivers to manage senior medications
CREATE TABLE public.caregiver_medications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  caregiver_id UUID NOT NULL,
  senior_id UUID NOT NULL,
  name TEXT NOT NULL,
  time TEXT NOT NULL,
  dosage TEXT,
  notes TEXT,
  completed BOOLEAN NOT NULL DEFAULT false,
  completed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.caregiver_medications ENABLE ROW LEVEL SECURITY;

-- Caregivers can manage medications for their seniors
CREATE POLICY "Caregivers can view their seniors medications"
  ON public.caregiver_medications FOR SELECT
  USING (caregiver_id = auth.uid());

CREATE POLICY "Caregivers can create medications for their seniors"
  ON public.caregiver_medications FOR INSERT
  WITH CHECK (
    caregiver_id = auth.uid() AND
    EXISTS (
      SELECT 1 FROM caregiver_seniors
      WHERE caregiver_seniors.caregiver_id = auth.uid()
      AND caregiver_seniors.senior_id = caregiver_medications.senior_id
    )
  );

CREATE POLICY "Caregivers can update their seniors medications"
  ON public.caregiver_medications FOR UPDATE
  USING (caregiver_id = auth.uid());

CREATE POLICY "Caregivers can delete their seniors medications"
  ON public.caregiver_medications FOR DELETE
  USING (caregiver_id = auth.uid());

-- Deny anonymous access
CREATE POLICY "deny_anon_access_caregiver_medications"
  ON public.caregiver_medications FOR ALL
  USING (false);

-- Add updated_at trigger
CREATE TRIGGER update_caregiver_medications_updated_at
  BEFORE UPDATE ON public.caregiver_medications
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();