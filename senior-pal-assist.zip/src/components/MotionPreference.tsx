import { useEffect, useState } from "react";
import { Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

const STORAGE_KEY = "reli-reduce-motion";

const apply = (reduce: boolean) => {
  document.documentElement.classList.toggle("reduce-motion", reduce);
};

/** Small control letting people turn off animations across the app. */
export const MotionPreference = () => {
  const [reduce, setReduce] = useState(() => localStorage.getItem(STORAGE_KEY) === "true");

  useEffect(() => {
    apply(reduce);
    localStorage.setItem(STORAGE_KEY, String(reduce));
  }, [reduce]);

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="sm" aria-label="Motion settings" className="min-h-[44px]">
          <Sparkles className="w-4 h-4 md:mr-1.5" />
          <span className="hidden md:inline">Motion</span>
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-64" align="end">
        <div className="flex items-center justify-between gap-3">
          <Label htmlFor="reduce-motion" className="text-sm">Reduce motion</Label>
          <Switch id="reduce-motion" checked={reduce} onCheckedChange={setReduce} />
        </div>
        <p className="text-xs text-muted-foreground mt-2">
          Turns off pulsing and sliding animations for a calmer screen.
        </p>
      </PopoverContent>
    </Popover>
  );
};

export default MotionPreference;
