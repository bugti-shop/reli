import { useEffect, useMemo, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { usePlan } from "@/hooks/use-plan";
import { useToast } from "@/hooks/use-toast";
import { Sparkles, LineChart as LineChartIcon, Loader2 } from "lucide-react";
import { format, parseISO, subDays } from "date-fns";
import {
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

interface HealthInsightsProps {
  userId: string;
  seniorId: string;
  seniorName?: string;
}

interface Point {
  date: string;
  label: string;
  systolic?: number;
  diastolic?: number;
  bpm?: number;
  doses?: number;
}

const FREE_DAYS = 30;

export const HealthInsights = ({ userId, seniorId, seniorName }: HealthInsightsProps) => {
  const { toast } = useToast();
  const { plan, isPremium } = usePlan(userId);
  const [bpData, setBpData] = useState<Point[]>([]);
  const [hrData, setHrData] = useState<Point[]>([]);
  const [doseData, setDoseData] = useState<Point[]>([]);
  const [insight, setInsight] = useState<string | null>(null);
  const [loadingInsight, setLoadingInsight] = useState(false);

  const days = isPremium ? 365 : FREE_DAYS;

  useEffect(() => {
    if (!plan) return;
    const load = async () => {
      const cutoff = subDays(new Date(), days).toISOString();

      const [{ data: readings, error: rErr }, { data: doses, error: dErr }] = await Promise.all([
        supabase
          .from("vital_readings")
          .select("reading_type, systolic, diastolic, bpm, recorded_at")
          .eq("senior_id", seniorId)
          .is("deleted_at", null)
          .gte("recorded_at", cutoff)
          .order("recorded_at", { ascending: true })
          .limit(1000),
        supabase
          .from("medication_doses")
          .select("taken_at")
          .eq("senior_id", seniorId)
          .is("deleted_at", null)
          .gte("taken_at", cutoff)
          .order("taken_at", { ascending: true })
          .limit(2000),
      ]);

      if (rErr) console.error("Error loading readings:", rErr);
      if (dErr) console.error("Error loading doses:", dErr);

      const toPoint = (iso: string) => ({ date: iso, label: format(parseISO(iso), "MMM d") });

      setBpData(
        (readings || [])
          .filter((r) => r.reading_type === "blood_pressure")
          .map((r) => ({ ...toPoint(r.recorded_at), systolic: r.systolic ?? undefined, diastolic: r.diastolic ?? undefined })),
      );
      setHrData(
        (readings || [])
          .filter((r) => r.reading_type === "heart_rate")
          .map((r) => ({ ...toPoint(r.recorded_at), bpm: r.bpm ?? undefined })),
      );

      const byDay = new Map<string, number>();
      (doses || []).forEach((d) => {
        const key = format(parseISO(d.taken_at), "MMM d");
        byDay.set(key, (byDay.get(key) || 0) + 1);
      });
      setDoseData(Array.from(byDay.entries()).map(([label, count]) => ({ date: label, label, doses: count })));
    };
    load();
  }, [seniorId, plan, days]);

  const hasData = bpData.length > 0 || hrData.length > 0 || doseData.length > 0;

  const averages = useMemo(() => {
    const avg = (nums: number[]) => (nums.length ? Math.round(nums.reduce((a, b) => a + b, 0) / nums.length) : null);
    return {
      systolic: avg(bpData.map((p) => p.systolic!).filter(Boolean)),
      diastolic: avg(bpData.map((p) => p.diastolic!).filter(Boolean)),
      bpm: avg(hrData.map((p) => p.bpm!).filter(Boolean)),
      doses: doseData.reduce((a, p) => a + (p.doses || 0), 0),
    };
  }, [bpData, hrData, doseData]);

  const runAnalysis = async () => {
    setLoadingInsight(true);
    setInsight(null);
    const { data, error } = await supabase.functions.invoke("analyze-health-trends", {
      body: { seniorId, days },
    });
    setLoadingInsight(false);

    if (error) {
      console.error("analyze-health-trends failed:", error);
      toast({
        title: "Could not analyze right now",
        description: "Please try again in a moment.",
        variant: "destructive",
      });
      return;
    }
    setInsight((data as { insight?: string })?.insight || "No insight was generated.");
  };

  return (
    <Card className="p-6 border-2">
      <div className="flex items-center justify-between gap-3 mb-4 flex-wrap">
        <h2 className="text-2xl font-semibold flex items-center gap-2">
          <LineChartIcon className="w-6 h-6 text-primary" />
          Trends &amp; Insights
          {seniorName ? ` — ${seniorName}` : ""}
        </h2>
        <Button onClick={runAnalysis} disabled={loadingInsight || !hasData} className="gap-2">
          {loadingInsight ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
          {loadingInsight ? "Analyzing…" : "Analyze trends"}
        </Button>
      </div>

      <p className="text-sm text-muted-foreground mb-4">
        {isPremium ? "Premium: charting the last 12 months." : `Free plan: charting the last ${FREE_DAYS} days.`}
      </p>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
        <div className="p-3 rounded-lg bg-muted/40 border">
          <p className="text-xs text-muted-foreground">Avg. blood pressure</p>
          <p className="text-xl font-bold">
            {averages.systolic && averages.diastolic ? `${averages.systolic}/${averages.diastolic}` : "—"}
          </p>
        </div>
        <div className="p-3 rounded-lg bg-muted/40 border">
          <p className="text-xs text-muted-foreground">Avg. heart rate</p>
          <p className="text-xl font-bold">{averages.bpm ? `${averages.bpm} bpm` : "—"}</p>
        </div>
        <div className="p-3 rounded-lg bg-muted/40 border">
          <p className="text-xs text-muted-foreground">Readings logged</p>
          <p className="text-xl font-bold">{bpData.length + hrData.length}</p>
        </div>
        <div className="p-3 rounded-lg bg-muted/40 border">
          <p className="text-xs text-muted-foreground">Doses taken</p>
          <p className="text-xl font-bold">{averages.doses}</p>
        </div>
      </div>

      {!hasData ? (
        <p className="text-muted-foreground text-base text-center py-8">
          No readings or doses recorded yet. Once a few are logged, charts and insights appear here.
        </p>
      ) : (
        <Tabs defaultValue="bp">
          <TabsList className="mb-3 flex-wrap h-auto">
            <TabsTrigger value="bp">Blood Pressure</TabsTrigger>
            <TabsTrigger value="hr">Heart Rate</TabsTrigger>
            <TabsTrigger value="meds">Doses per Day</TabsTrigger>
          </TabsList>

          <TabsContent value="bp">
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={bpData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="label" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} domain={[40, 200]} />
                  <Tooltip
                    contentStyle={{
                      background: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: 8,
                      color: "hsl(var(--foreground))",
                    }}
                  />
                  <Legend />
                  <Line type="monotone" dataKey="systolic" name="Top (systolic)" stroke="hsl(var(--primary))" strokeWidth={2} />
                  <Line type="monotone" dataKey="diastolic" name="Bottom (diastolic)" stroke="hsl(var(--destructive))" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>

          <TabsContent value="hr">
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={hrData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="label" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} domain={[40, 160]} />
                  <Tooltip
                    contentStyle={{
                      background: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: 8,
                      color: "hsl(var(--foreground))",
                    }}
                  />
                  <Line type="monotone" dataKey="bpm" name="Beats per minute" stroke="hsl(var(--primary))" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>

          <TabsContent value="meds">
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={doseData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="label" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} allowDecimals={false} />
                  <Tooltip
                    contentStyle={{
                      background: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: 8,
                      color: "hsl(var(--foreground))",
                    }}
                  />
                  <Line type="monotone" dataKey="doses" name="Doses taken" stroke="hsl(var(--primary))" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>
        </Tabs>
      )}

      {insight && (
        <div className="mt-5 p-4 rounded-lg border-2 border-primary/30 bg-primary/5">
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="w-5 h-5 text-primary" />
            <h3 className="text-lg font-semibold">What the numbers suggest</h3>
            <Badge className="bg-primary text-primary-foreground">AI</Badge>
          </div>
          <div className="text-base whitespace-pre-wrap leading-relaxed text-foreground/90">
            {insight.replace(/^#+\s*/gm, "")}
          </div>
          <p className="text-xs text-muted-foreground mt-3">
            This is a general summary of recorded numbers, not medical advice. Always talk to a doctor about health
            decisions.
          </p>
        </div>
      )}
    </Card>
  );
};

export default HealthInsights;
