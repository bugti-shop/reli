import * as React from 'npm:react@18.3.1'
import {
  Body,
  Container,
  Head,
  Heading,
  Html,
  Preview,
  Section,
  Text,
} from 'npm:@react-email/components@0.0.22'
import type { TemplateEntry } from './registry.ts'

interface Props {
  senderName?: string
  senderEmail?: string
  message?: string
}

const Email = ({
  senderName = 'Someone',
  senderEmail = '',
  message = '',
}: Props) => (
  <Html lang="en" dir="ltr">
    <Head />
    <Preview>New contact form message from {senderName}</Preview>
    <Body style={main}>
      <Container style={container}>
        <Heading style={h1}>New contact form submission</Heading>
        <Text style={text}>
          <strong>Name:</strong> {senderName}
        </Text>
        <Text style={text}>
          <strong>Email:</strong> {senderEmail}
        </Text>
        <Section style={quote}>
          <Text style={quoteText}>{message}</Text>
        </Section>
        <Text style={footer}>
          Reply directly to this email to respond to {senderName}.
        </Text>
      </Container>
    </Body>
  </Html>
)

export const template = {
  component: Email,
  subject: (data: Record<string, any>) =>
    `New Contact Form Submission from ${data.senderName || 'a visitor'}`,
  displayName: 'Contact form notification',
  to: 'info@reli.care',
  previewData: {
    senderName: 'Jane Doe',
    senderEmail: 'jane@example.com',
    message: 'Hi, I have a question about Premium plans for my family.',
  },
} satisfies TemplateEntry

const main = { backgroundColor: '#ffffff', fontFamily: 'Arial, sans-serif' }
const container = { padding: '20px 25px' }
const h1 = {
  fontSize: '22px',
  fontWeight: 'bold' as const,
  color: 'hsl(24, 20%, 15%)',
  margin: '0 0 20px',
}
const text = {
  fontSize: '16px',
  color: 'hsl(24, 15%, 35%)',
  lineHeight: '1.6',
  margin: '0 0 12px',
}
const quote = {
  backgroundColor: 'hsl(206, 55%, 96%)',
  borderLeft: '4px solid hsl(206, 55%, 38%)',
  borderRadius: '10px',
  padding: '14px 18px',
  margin: '12px 0 20px',
}
const quoteText = {
  fontSize: '16px',
  color: 'hsl(24, 20%, 15%)',
  lineHeight: '1.6',
  margin: '0',
  whiteSpace: 'pre-wrap' as const,
}
const footer = { fontSize: '12px', color: '#999999', margin: '30px 0 0' }
