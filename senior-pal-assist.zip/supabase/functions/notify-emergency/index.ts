import { createClient } from 'npm:@supabase/supabase-js@2'
import { sendTemplateEmail } from '../_shared/transactional-email-templates/send-email.ts'
import { resolveEmailRecipient, resolveSmsRecipient } from '../_shared/notify-recipient.ts'
import { sendSms, toE164 } from '../_shared/send-sms.ts'
import { sendPushToUser } from '../_shared/send-push.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  })

const OPEN = ['active', 'partially_acknowledged', 'acknowledged']
const MAX_ATTEMPTS = 6
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms))

/**
 * SOS dispatcher. Every call is keyed by the SOS event id, so repeats never
 * create new events or re-ring caregivers who were already reached.
 *  - action "alarm": ring every linked caregiver who has not been reached yet
 *    (also used as the retry path for offline devices).
 *  - action "cancel": tell every caregiver the SOS was cancelled/resolved so
 *    their alarm stops.
 */
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })

  try {
    const authHeader = req.headers.get('Authorization') ?? ''
    const userClient = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, {
      global: { headers: { Authorization: authHeader } },
    })
    const { data: userData } = await userClient.auth.getUser()
    const user = userData?.user
    if (!user) return json({ error: 'Unauthorized' }, 401)

    const body = await req.json().catch(() => ({}))
    const alertId = typeof body?.alertId === 'string' ? body.alertId : ''
    const action = body?.action === 'cancel' ? 'cancel' : 'alarm'
    if (!/^[0-9a-f-]{36}$/i.test(alertId)) return json({ error: 'Invalid alertId' }, 400)

    const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!)

    const { data: alert } = await admin
      .from('emergency_alerts')
      .select('id, senior_id, message, created_at, status, latitude, longitude, accuracy_m, cancelled_by')
      .eq('id', alertId)
      .maybeSingle()
    if (!alert) return json({ error: 'Alert not found' }, 404)

    const [{ data: senior }, { data: links }, { data: acks }] = await Promise.all([
      admin.from('profiles').select('full_name').eq('id', alert.senior_id).maybeSingle(),
      admin.from('caregiver_seniors').select('caregiver_id').eq('senior_id', alert.senior_id),
      admin.from('sos_acknowledgements').select('caregiver_id').eq('alert_id', alert.id),
    ])
    const caregiverIds = (links || []).map((l: any) => l.caregiver_id as string)
    const isSenior = alert.senior_id === user.id
    if (!isSenior && !caregiverIds.includes(user.id)) return json({ error: 'Forbidden' }, 403)

    const seniorLabel = senior?.full_name || 'Someone in your care'

    // ---------- Cancellation / resolution ----------
    if (action === 'cancel') {
      if (OPEN.includes(alert.status)) return json({ error: 'SOS is still open' }, 409)
      let notified = 0
      const verb = alert.status === 'cancelled' ? 'cancelled' : 'resolved'
      for (const cid of caregiverIds) {
        if (cid === user.id) continue
        const { data: existing } = await admin
          .from('sos_deliveries')
          .select('id, status')
          .eq('alert_id', alert.id)
          .eq('caregiver_id', cid)
          .eq('kind', 'cancel')
          .maybeSingle()
        if (existing?.status === 'delivered') continue
        const reached = await sendPushToUser(admin, cid, 'notify_emergency', {
          title: `SOS ${verb} — ${seniorLabel}`,
          body: alert.status === 'cancelled' ? `${seniorLabel} cancelled the SOS. The alarm has stopped.` : 'The emergency was marked resolved.',
          path: '/caregiver',
          type: 'sos_cancel',
          data: { alert_id: alert.id, status: alert.status },
          collapseKey: `sos-${alert.id}`,
        }).catch(() => 0)
        await admin.from('sos_deliveries').upsert(
          {
            alert_id: alert.id,
            caregiver_id: cid,
            kind: 'cancel',
            attempts: 1,
            status: reached > 0 ? 'delivered' : 'no_device',
            devices_reached: reached,
            last_attempt_at: new Date().toISOString(),
            delivered_at: reached > 0 ? new Date().toISOString() : null,
          },
          { onConflict: 'alert_id,caregiver_id,kind' },
        )
        if (reached > 0) notified++
      }
      return json({ notified })
    }

    // ---------- Alarm (first send + retries) ----------
    if (!isSenior) return json({ error: 'Only the senior can send the alarm' }, 403)
    if (!OPEN.includes(alert.status)) return json({ skipped: 'closed' })

    const acked = new Set((acks || []).map((a: any) => a.caregiver_id))
    const sentAt = new Date(alert.created_at).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })
    const results: Record<string, string> = {}
    let pushed = 0, texted = 0, emailed = 0

    await Promise.all(
      caregiverIds.map(async (cid) => {
        if (acked.has(cid)) return (results[cid] = 'acknowledged')

        const { data: row } = await admin
          .from('sos_deliveries')
          .select('id, attempts, status')
          .eq('alert_id', alert.id)
          .eq('caregiver_id', cid)
          .eq('kind', 'alarm')
          .maybeSingle()
        if (row?.status === 'delivered') return (results[cid] = 'delivered')
        if ((row?.attempts ?? 0) >= MAX_ATTEMPTS) return (results[cid] = row?.status ?? 'failed')
        const firstContact = !row

        // Immediate push with short in-call retries for transient errors.
        let reached = 0
        let attempts = row?.attempts ?? 0
        for (let i = 0; i < 2 && reached === 0 && attempts < MAX_ATTEMPTS; i++) {
          attempts++
          reached = await sendPushToUser(admin, cid, 'notify_emergency', {
            title: `🚨 SOS — ${seniorLabel} needs help`,
            body: `Emergency SOS at ${sentAt}. Tap to see location and respond.`,
            path: `/caregiver?sos=${alert.id}`,
            urgent: true,
            data: { alert_id: alert.id, senior_id: alert.senior_id },
            collapseKey: `sos-${alert.id}`,
          }).catch(() => 0)
          if (reached === 0 && i === 0) await sleep(1500)
        }
        pushed += reached

        // Email + text only once per caregiver per SOS event (backup channels).
        if (firstContact) {
          const smsTo = await resolveSmsRecipient(admin, cid, 'notify_emergency').catch(() => null)
          const phone = toE164(smsTo?.phone)
          if (phone) {
            const r = await sendSms(phone, `Reli EMERGENCY SOS: ${seniorLabel} needs help (${sentAt}). Open Reli now to respond.`).catch(() => ({ sent: false }))
            if (r.sent) texted++
          }
          const recipient = await resolveEmailRecipient(admin, cid, 'notify_emergency').catch(() => null)
          if (recipient) {
            const r = await sendTemplateEmail('emergency-alert', recipient.email, {
              templateData: { recipientName: recipient.name?.split(' ')[0] ?? undefined, seniorName: seniorLabel, sentAt },
              idempotencyKey: `emergency-alert-${alert.id}-${cid}`,
            }).catch(() => ({ sent: false }))
            if (r.sent) emailed++
          }
        }

        const status = reached > 0 ? 'delivered' : 'retrying'
        await admin.from('sos_deliveries').upsert(
          {
            alert_id: alert.id,
            caregiver_id: cid,
            kind: 'alarm',
            attempts,
            status: attempts >= MAX_ATTEMPTS && reached === 0 ? 'failed' : status,
            devices_reached: reached,
            last_attempt_at: new Date().toISOString(),
            delivered_at: reached > 0 ? new Date().toISOString() : null,
            last_error: reached > 0 ? null : 'No registered phone reached',
          },
          { onConflict: 'alert_id,caregiver_id,kind' },
        )
        results[cid] = status
      }),
    )

    const pending = Object.values(results).filter((s) => s === 'retrying').length
    return json({ pushed, texted, emailed, pending, caregivers: caregiverIds.length })
  } catch (error) {
    console.error('notify-emergency error', error)
    return json({ error: 'Failed to send alerts' }, 500)
  }
})
