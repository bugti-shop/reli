import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Settings, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface FeatureSettingsProps {
  seniorId: string;
  seniorName: string;
  caregiverId: string;
}

interface Settings {
  show_trivia: boolean;
  show_medication_tracker: boolean;
  show_activity_tracker: boolean;
  show_life_story: boolean;
  show_ai_companion: boolean;
  show_doctor_report: boolean;
}

const defaultSettings: Settings = {
  show_trivia: true,
  show_medication_tracker: true,
  show_activity_tracker: true,
  show_life_story: true,
  show_ai_companion: true,
  show_doctor_report: true,
};

const featureLabels: Record<keyof Settings, string> = {
  show_trivia: "Daily Trivia",
  show_medication_tracker: "Medication Tracker",
  show_activity_tracker: "Activity Tracker",
  show_life_story: "Life Story Prompts",
  show_ai_companion: "AI Companion Chat",
  show_doctor_report: "Doctor Report",
};

export const FeatureSettings = ({ seniorId, seniorName, caregiverId }: FeatureSettingsProps) => {
  const [settings, setSettings] = useState<Settings>(defaultSettings);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchSettings();
  }, [seniorId, caregiverId]);

  const fetchSettings = async () => {
    setIsLoading(true);
    const { data, error } = await supabase
      .from("senior_feature_settings")
      .select("*")
      .eq("senior_id", seniorId)
      .eq("caregiver_id", caregiverId)
      .maybeSingle();

    if (error) {
      console.error("Error fetching settings:", error);
    } else if (data) {
      setSettings({
        show_trivia: data.show_trivia,
        show_medication_tracker: data.show_medication_tracker,
        show_activity_tracker: data.show_activity_tracker,
        show_life_story: data.show_life_story,
        show_ai_companion: data.show_ai_companion,
        show_doctor_report: data.show_doctor_report,
      });
    }
    setIsLoading(false);
  };

  const updateSetting = async (key: keyof Settings, value: boolean) => {
    setIsSaving(true);
    const newSettings = { ...settings, [key]: value };
    setSettings(newSettings);

    // Check if settings exist
    const { data: existing } = await supabase
      .from("senior_feature_settings")
      .select("id")
      .eq("senior_id", seniorId)
      .eq("caregiver_id", caregiverId)
      .maybeSingle();

    let error;
    if (existing) {
      // Update existing
      const result = await supabase
        .from("senior_feature_settings")
        .update(newSettings)
        .eq("senior_id", seniorId)
        .eq("caregiver_id", caregiverId);
      error = result.error;
    } else {
      // Create new
      const result = await supabase
        .from("senior_feature_settings")
        .insert({
          senior_id: seniorId,
          caregiver_id: caregiverId,
          ...newSettings,
        });
      error = result.error;
    }

    if (error) {
      console.error("Error saving settings:", error);
      toast({
        title: "Error",
        description: "Could not save settings. Please try again.",
        variant: "destructive",
      });
      // Revert on error
      setSettings(settings);
    } else {
      toast({
        title: "Settings updated",
        description: `${featureLabels[key]} is now ${value ? "visible" : "hidden"} for ${seniorName}.`,
      });
    }
    setIsSaving(false);
  };

  if (isLoading) {
    return (
      <Card className="p-6 bg-card/90 backdrop-blur border-2">
        <div className="flex items-center justify-center py-8">
          <Loader2 className="w-6 h-6 animate-spin text-primary" />
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-6 bg-card/90 backdrop-blur border-2">
      <CardHeader className="px-0 pt-0">
        <CardTitle className="text-2xl font-semibold flex items-center gap-2">
          <Settings className="w-6 h-6 text-primary" />
          Feature Settings for {seniorName}
        </CardTitle>
        <p className="text-muted-foreground">
          Toggle features on or off for this senior's dashboard
        </p>
      </CardHeader>
      <CardContent className="px-0 pb-0">
        <div className="grid gap-4 sm:grid-cols-2">
          {(Object.keys(featureLabels) as Array<keyof Settings>).map((key) => (
            <div
              key={key}
              className="flex items-center justify-between p-4 rounded-lg bg-secondary/20 hover:bg-secondary/30 transition-colors"
            >
              <Label htmlFor={key} className="text-lg cursor-pointer flex-1">
                {featureLabels[key]}
              </Label>
              <Switch
                id={key}
                checked={settings[key]}
                onCheckedChange={(checked) => updateSetting(key, checked)}
                disabled={isSaving}
              />
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};
