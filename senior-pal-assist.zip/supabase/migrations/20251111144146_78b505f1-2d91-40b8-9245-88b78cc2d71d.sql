-- Allow caregivers to search for senior profiles by email when adding them to their care list
CREATE POLICY "Caregivers can search for seniors by email"
  ON public.profiles FOR SELECT
  USING (
    role = 'senior' AND 
    (
      auth.uid() = id OR
      EXISTS (
        SELECT 1 FROM public.profiles AS caregiver_profile
        WHERE caregiver_profile.id = auth.uid() AND caregiver_profile.role = 'caregiver'
      )
    )
  );