import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors'
import { createClient } from 'npm:@supabase/supabase-js@2'
import { z } from 'npm:zod@3'

const Body = z.object({
  senior_id: z.string().uuid(),
  email: z.string().trim().toLowerCase().email().max(255),
  redirect_to: z.string().url().max(500).optional(),
})

const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), { status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  try {
    const url = Deno.env.get('SUPABASE_URL')!
    const userClient = createClient(url, Deno.env.get('SUPABASE_ANON_KEY')!, {
      global: { headers: { Authorization: req.headers.get('Authorization') ?? '' } },
    })
    const { data: { user } } = await userClient.auth.getUser()
    if (!user) return json({ error: 'NOT_AUTHENTICATED' }, 401)

    const parsed = Body.safeParse(await req.json())
    if (!parsed.success) return json({ error: 'INVALID_INPUT' }, 400)
    const { senior_id, email } = parsed.data

    const admin = createClient(url, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!)
    const { data: link } = await admin.from('caregiver_seniors').select('id')
      .eq('caregiver_id', user.id).eq('senior_id', senior_id).maybeSingle()
    if (!link) return json({ error: 'NOT_LINKED' }, 403)

    const { data: senior } = await admin.from('profiles').select('managed').eq('id', senior_id).maybeSingle()
    if (!senior?.managed) return json({ error: 'ALREADY_HAS_ACCOUNT' }, 400)

    const { data: taken } = await admin.from('profiles').select('id').ilike('email', email).maybeSingle()
    if (taken) return json({ error: 'EMAIL_IN_USE' }, 400)

    const { error: uErr } = await admin.auth.admin.updateUserById(senior_id, { email, email_confirm: true })
    if (uErr) { console.error(uErr); return json({ error: 'EMAIL_IN_USE' }, 400) }
    await admin.from('profiles').update({ email, managed: false }).eq('id', senior_id)

    // Send "set your password" email via the normal recovery flow (branded templates).
    const anon = createClient(url, Deno.env.get('SUPABASE_ANON_KEY')!)
    const redirectTo = parsed.data.redirect_to && /^https:\/\/([a-z0-9-]+\.)*(reli\.care|lovable\.app)(\/|$)/i.test(parsed.data.redirect_to)
      ? parsed.data.redirect_to : 'https://reli.care/reset-password'
    const { error: rErr } = await anon.auth.resetPasswordForEmail(email, { redirectTo })
    if (rErr) console.error('recovery email failed', rErr)

    return json({ ok: true, email_sent: !rErr })
  } catch (e) {
    console.error(e)
    return json({ error: 'SERVER_ERROR' }, 500)
  }
})
