package com.reli.care;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.capacitorjs.plugins.pushnotifications.MessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Map;

/**
 * Wraps the Capacitor push service. SOS alarms arrive as data-only FCM
 * messages so this runs even when Reli is in the background: it posts a
 * max-importance alarm notification with a full-screen intent (Android shows
 * the full-screen SOS over the lock screen when the user allowed it).
 * "sos_cancel" dismisses the ringing alarm. Everything else falls through
 * to the normal Capacitor handling.
 */
public class SosMessagingService extends MessagingService {
    public static final String CHANNEL_ID = "sos_alarm";

    @Override
    public void onMessageReceived(RemoteMessage message) {
        Map<String, String> data = message.getData();
        String type = data.get("type");
        String alertId = data.get("alert_id");
        if ("sos".equals(type) && alertId != null) {
            showAlarm(this, alertId, data.get("title"), data.get("body"));
        } else if ("sos_cancel".equals(type) && alertId != null) {
            NotificationManagerCompat.from(this).cancel(notificationId(alertId));
            showInfo(this, alertId, data.get("title"), data.get("body"));
        }
        // Always forward so the web layer (if running) updates as well.
        super.onMessageReceived(message);
    }

    static int notificationId(String alertId) {
        return ("sos:" + alertId).hashCode();
    }

    static void ensureChannel(Context ctx) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager nm = ctx.getSystemService(NotificationManager.class);
        if (nm.getNotificationChannel(CHANNEL_ID) != null) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "SOS Emergency Alarm", NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("Rings loudly when a senior you care for presses SOS");
        ch.enableVibration(true);
        ch.setVibrationPattern(new long[]{0, 800, 400, 800, 400, 800});
        ch.setLockscreenVisibility(NotificationCompat.VISIBILITY_PUBLIC);
        ch.setBypassDnd(true); // honoured only if the user allows DND override
        Uri sound = Uri.parse("android.resource://" + ctx.getPackageName() + "/raw/sos_alarm");
        ch.setSound(sound, new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build());
        nm.createNotificationChannel(ch);
    }

    private static PendingIntent openIntent(Context ctx, String alertId, boolean sos) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("reli://app/caregiver?sos=" + Uri.encode(alertId)), ctx, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        if (sos) intent.putExtra(MainActivity.EXTRA_SOS, true);
        return PendingIntent.getActivity(ctx, notificationId(alertId) + (sos ? 0 : 1), intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void showAlarm(Context ctx, String alertId, String title, String body) {
        ensureChannel(ctx);
        PendingIntent pi = openIntent(ctx, alertId, true);
        NotificationCompat.Builder b = new NotificationCompat.Builder(ctx, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_stat_reli_heart)
                .setContentTitle(title != null ? title : "Senior Emergency SOS")
                .setContentText(body != null ? body : "A senior you care for pressed SOS")
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .setFullScreenIntent(pi, true);
        try {
            NotificationManagerCompat.from(ctx).notify(notificationId(alertId), b.build());
        } catch (SecurityException ignored) {
            // POST_NOTIFICATIONS not granted; the in-app alarm, SMS and email remain.
        }
    }

    static void showInfo(Context ctx, String alertId, String title, String body) {
        ensureChannel(ctx);
        NotificationCompat.Builder b = new NotificationCompat.Builder(ctx, "default")
                .setSmallIcon(R.drawable.ic_stat_reli_heart)
                .setContentTitle(title != null ? title : "SOS cancelled")
                .setContentText(body != null ? body : "The emergency was cancelled")
                .setAutoCancel(true)
                .setContentIntent(openIntent(ctx, alertId, false));
        try {
            NotificationManagerCompat.from(ctx).notify(notificationId(alertId) + 1, b.build());
        } catch (SecurityException ignored) { }
    }
}
