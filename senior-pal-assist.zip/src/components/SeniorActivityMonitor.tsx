import { useCallback, useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  Activity, AlertTriangle, Bell, CheckCircle2, Clock, HeartPulse, Loader2, MapPin, Pill, ShieldAlert, XCircle,
} from "lucide-react";

interface LogRow {
  id: string;
  activity_type: string;
  activity_description: string;
  feature: string;
  status: string;
  metadata: Record<string, unknown>;
  actor_role: string | null;
  occurred_at: string;
}

interface ActionItem {
  key: string;
  kind: "medication" | "reminder";
  title: string;
  detail?: string;
  at: Date;
  status: "completed" | "pending" | "missed" | "upcoming";
}

const PAGE = 25;
const MISSED_AFTER_MIN = 60;

const FEATURES: { value: string; label: string }[] = [
  { value: "all", label: "All" },
  { value: "medication", label: "Medication" },
  { value: "health", label: "Health" },
  { value: "emergency", label: "SOS" },
  { value: "reminders", label: "Reminders" },
  { value: "journal", label: "Journal" },
  { value: "trackers", label: "Trackers" },
  { value: "messages", label: "Messages" },
  { value: "account", label: "Sign in/out" },
];

const statusStyle: Record<string, string> = {
  completed: "bg-dashboard-mint text-foreground",
  pending: "bg-dashboard-sky text-foreground",
  upcoming: "bg-muted text-foreground",
  missed: "bg-destructive text-destructive-foreground",
  skipped: "bg-dashboard-blush text-foreground",
  cancelled: "bg-muted text-muted-foreground",
  info: "bg-muted text-foreground",
};

const parseTime = (t: string, base = new Date()) => {
  const m = t.trim().match(/^(\d{1,2}):(\d{2})\s*(AM|PM)?$/i);
  if (!m) return null;
  let h = Number(m[1]);
  const ap = m[3]?.toUpperCase();
  if (ap === "PM" && h < 12) h += 12;
  if (ap === "AM" && h === 12) h = 0;
  const d = new Date(base);
  d.setHours(h, Number(m[2]), 0, 0);
  return d;
};

const fmtTime = (d: Date | string) => new Date(d).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
const fmtFull = (d: Date | string) =>
  new Date(d).toLocaleString([], { weekday: "short", month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
const ago = (d: string) => {
  const m = Math.round((Date.now() - new Date(d).getTime()) / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m} min ago`;
  if (m < 1440) return `${Math.round(m / 60)} h ago`;
  return `${Math.round(m / 1440)} d ago`;
};

const featureIcon = (f: string) =>
  f === "medication" ? Pill : f === "health" ? HeartPulse : f === "emergency" ? ShieldAlert : f === "reminders" ? Bell : Activity;

const metaLabel = (k: string) => k.replace(/_/g, " ").replace(/^\w/, (c) => c.toUpperCase());

/** Caregiver view of one senior: live status, today's full action list, and complete activity history. */
export const SeniorActivityMonitor = ({ seniorId, seniorName }: { seniorId: string; seniorName: string }) => {
  const [actions, setActions] = useState<ActionItem[]>([]);
  const [logs, setLogs] = useState<LogRow[]>([]);
  const [hasMore, setHasMore] = useState(false);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [filter, setFilter] = useState("all");
  const [sos, setSos] = useState<{ id: string; status: string; created_at: string } | null>(null);
  const [lastLocation, setLastLocation] = useState<{ lat: number; lng: number; accuracy: number | null; at: string } | null>(null);
  const [detail, setDetail] = useState<LogRow | null>(null);
  const [showAllActions, setShowAllActions] = useState(false);
  const [now, setNow] = useState(() => new Date());

  const loadToday = useCallback(async () => {
    const start = new Date(); start.setHours(0, 0, 0, 0);
    const end = new Date(start); end.setDate(end.getDate() + 1);
    const [meds, doses, reminders, alert, loc] = await Promise.all([
      supabase.from("medications").select("id, name, time, dosage, days_of_week").eq("senior_id", seniorId),
      supabase.from("medication_doses").select("medication_id, medication_name, scheduled_time, taken_at").eq("senior_id", seniorId).is("deleted_at", null).gte("taken_at", start.toISOString()).lt("taken_at", end.toISOString()),
      supabase.from("senior_reminders").select("id, message, reminder_time, completed").eq("senior_id", seniorId).gte("reminder_time", start.toISOString()).lt("reminder_time", end.toISOString()),
      supabase.from("emergency_alerts").select("id, status, created_at").eq("senior_id", seniorId).in("status", ["active", "partially_acknowledged", "acknowledged"]).order("created_at", { ascending: false }).limit(1).maybeSingle(),
      supabase.from("emergency_alerts").select("latitude, longitude, accuracy_m, location_captured_at").eq("senior_id", seniorId).not("latitude", "is", null).order("location_captured_at", { ascending: false }).limit(1).maybeSingle(),
    ]);
    const today = start.getDay();
    const t = new Date();
    const items: ActionItem[] = [];
    for (const m of meds.data || []) {
      if (Array.isArray(m.days_of_week) && m.days_of_week.length && !m.days_of_week.includes(today)) continue;
      const at = parseTime(m.time) ?? start;
      const taken = (doses.data || []).find((d) => d.medication_id === m.id && (!d.scheduled_time || d.scheduled_time === m.time));
      const status: ActionItem["status"] = taken ? "completed" : t.getTime() - at.getTime() > MISSED_AFTER_MIN * 60000 ? "missed" : at <= t ? "pending" : "upcoming";
      items.push({ key: `m:${m.id}`, kind: "medication", title: m.name + (m.dosage ? ` ${m.dosage}` : ""), detail: taken ? `Taken at ${fmtTime(taken.taken_at)}` : `Scheduled ${m.time}`, at, status });
    }
    for (const r of reminders.data || []) {
      const at = new Date(r.reminder_time);
      const status: ActionItem["status"] = r.completed ? "completed" : t.getTime() - at.getTime() > MISSED_AFTER_MIN * 60000 ? "missed" : at <= t ? "pending" : "upcoming";
      items.push({ key: `r:${r.id}`, kind: "reminder", title: r.message, detail: `Due ${fmtTime(at)}`, at, status });
    }
    items.sort((a, b) => a.at.getTime() - b.at.getTime());
    setActions(items);
    setSos(alert.data ?? null);
    setLastLocation(loc.data?.latitude != null ? { lat: loc.data.latitude, lng: loc.data.longitude!, accuracy: loc.data.accuracy_m, at: loc.data.location_captured_at! } : null);
  }, [seniorId]);

  const loadLogs = useCallback(async (before?: string) => {
    let q = supabase.from("senior_activity_log").select("id, activity_type, activity_description, feature, status, metadata, actor_role, occurred_at").eq("senior_id", seniorId).order("occurred_at", { ascending: false }).limit(PAGE);
    if (filter !== "all") q = q.eq("feature", filter);
    if (before) q = q.lt("occurred_at", before);
    const { data } = await q;
    const rows = (data || []) as unknown as LogRow[];
    setHasMore(rows.length === PAGE);
    setLogs((prev) => (before ? [...prev, ...rows] : rows));
  }, [seniorId, filter]);

  useEffect(() => {
    setLoading(true);
    Promise.all([loadToday(), loadLogs()]).finally(() => setLoading(false));
  }, [loadToday, loadLogs]);

  // Live: new activity appears immediately; statuses re-evaluate every minute.
  useEffect(() => {
    const ch = supabase
      .channel(`activity-${seniorId}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "senior_activity_log", filter: `senior_id=eq.${seniorId}` }, (p) => {
        const row = p.new as LogRow;
        if (filter === "all" || row.feature === filter) setLogs((prev) => (prev.some((l) => l.id === row.id) ? prev : [row, ...prev]));
        loadToday();
      })
      .subscribe();
    const timer = window.setInterval(() => { setNow(new Date()); loadToday(); }, 60000);
    return () => { supabase.removeChannel(ch); window.clearInterval(timer); };
  }, [seniorId, filter, loadToday]);

  const counts = useMemo(() => {
    const c = { completed: 0, pending: 0, missed: 0, upcoming: 0 };
    actions.forEach((a) => c[a.status]++);
    return c;
  }, [actions]);
  const meds = actions.filter((a) => a.kind === "medication");
  const medsTaken = meds.filter((a) => a.status === "completed").length;
  const remindersPending = actions.filter((a) => a.kind === "reminder" && (a.status === "pending" || a.status === "upcoming")).length;
  const missed = actions.filter((a) => a.status === "missed");
  const lastActivity = logs[0];
  const visibleActions = showAllActions ? actions : actions.slice(0, 8);

  if (loading) return <Card className="flex justify-center p-6"><Loader2 className="h-6 w-6 animate-spin" /></Card>;

  return (
    <div className="space-y-3" aria-live="polite">
      {/* STATUS */}
      <Card className="border p-4 shadow-sm">
        <div className="mb-3 flex flex-wrap items-baseline justify-between gap-2">
          <h3 className="text-xl font-bold">Status</h3>
          <span className="text-xs text-muted-foreground">Updated {fmtTime(now)}</span>
        </div>
        {sos && (
          <div className="mb-3 flex items-start gap-3 rounded-xl bg-destructive p-3 text-destructive-foreground">
            <ShieldAlert className="mt-0.5 h-6 w-6 shrink-0" />
            <div><p className="font-bold">SOS active</p><p className="text-sm">Sent {fmtFull(sos.created_at)} · {sos.status.replace("_", " ")}</p></div>
          </div>
        )}
        <dl className="grid grid-cols-2 gap-2 text-sm sm:grid-cols-4">
          <div className="rounded-xl bg-dashboard-mint p-3"><dt className="text-xs font-medium">Medications today</dt><dd className="text-2xl font-bold">{medsTaken}/{meds.length}</dd><dd className="text-xs">taken</dd></div>
          <div className="rounded-xl bg-dashboard-sky p-3"><dt className="text-xs font-medium">Pending reminders</dt><dd className="text-2xl font-bold">{remindersPending}</dd></div>
          <div className={`rounded-xl p-3 ${missed.length ? "bg-destructive text-destructive-foreground" : "bg-muted"}`}><dt className="text-xs font-medium">Missed today</dt><dd className="text-2xl font-bold">{missed.length}</dd></div>
          <div className="rounded-xl bg-muted p-3"><dt className="text-xs font-medium">Completed today</dt><dd className="text-2xl font-bold">{counts.completed}</dd></div>
        </dl>
        <ul className="mt-3 space-y-2 text-sm">
          <li className="flex items-start gap-2"><Clock className="mt-0.5 h-4 w-4 shrink-0 text-primary" /><span><strong>Last activity:</strong> {lastActivity ? `${lastActivity.activity_type} · ${ago(lastActivity.occurred_at)} (${fmtFull(lastActivity.occurred_at)})` : "Nothing recorded yet"}</span></li>
          <li className="flex items-start gap-2"><MapPin className="mt-0.5 h-4 w-4 shrink-0 text-primary" /><span><strong>Last shared location:</strong> {lastLocation ? <>{fmtFull(lastLocation.at)}{lastLocation.accuracy != null && ` · ±${Math.round(lastLocation.accuracy)} m`} · <a className="underline" href={`https://www.openstreetmap.org/?mlat=${lastLocation.lat}&mlon=${lastLocation.lng}#map=17/${lastLocation.lat}/${lastLocation.lng}`} target="_blank" rel="noreferrer">Open map</a></> : "Only shared during an SOS — none yet"}</span></li>
        </ul>
        {missed.length > 0 && (
          <div className="mt-3 rounded-xl border border-destructive/40 p-3 text-sm">
            <p className="mb-1 flex items-center gap-2 font-bold text-destructive"><AlertTriangle className="h-4 w-4" />Needs attention</p>
            <ul className="list-disc space-y-1 pl-5">{missed.map((m) => <li key={m.key}>{m.kind === "medication" ? "Missed medication" : "Missed reminder"}: {m.title} ({m.detail})</li>)}</ul>
          </div>
        )}
      </Card>

      {/* TODAY'S ACTIONS */}
      <Card className="border p-4 shadow-sm">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <h3 className="text-xl font-bold">Today's Actions</h3>
          <div className="flex flex-wrap gap-1 text-xs">
            <Badge className={statusStyle.completed}>{counts.completed} done</Badge>
            <Badge className={statusStyle.pending}>{counts.pending} due now</Badge>
            <Badge className={statusStyle.upcoming}>{counts.upcoming} upcoming</Badge>
            <Badge className={statusStyle.missed}>{counts.missed} missed</Badge>
          </div>
        </div>
        {actions.length === 0 ? <p className="text-sm text-muted-foreground">No medications or reminders scheduled for {seniorName} today.</p> : (
          <ol className="space-y-2">
            {visibleActions.map((a) => {
              const Icon = a.status === "completed" ? CheckCircle2 : a.status === "missed" ? XCircle : a.kind === "medication" ? Pill : Bell;
              return (
                <li key={a.key} className="flex items-start gap-3 rounded-xl bg-muted/40 p-3">
                  <Icon className={`mt-0.5 h-5 w-5 shrink-0 ${a.status === "missed" ? "text-destructive" : "text-primary"}`} />
                  <div className="min-w-0 flex-1">
                    <p className="break-words font-semibold leading-snug">{a.title}</p>
                    <p className="text-xs text-muted-foreground">{a.kind === "medication" ? "Medication" : "Reminder"} · {a.detail}</p>
                  </div>
                  <Badge className={`shrink-0 capitalize ${statusStyle[a.status]}`}>{a.status === "pending" ? "due now" : a.status}</Badge>
                </li>
              );
            })}
          </ol>
        )}
        {actions.length > 8 && <Button variant="ghost" className="mt-2 w-full" onClick={() => setShowAllActions((v) => !v)}>{showAllActions ? "Show fewer" : `Show all ${actions.length} actions`}</Button>}
      </Card>

      {/* ACTIVITY HISTORY */}
      <Card className="border p-4 shadow-sm">
        <h3 className="mb-3 text-xl font-bold">Activity History</h3>
        <div className="-mx-1 mb-3 flex gap-1 overflow-x-auto px-1 pb-1" role="tablist" aria-label="Filter activities">
          {FEATURES.map((f) => (
            <Button key={f.value} size="sm" variant={filter === f.value ? "default" : "outline"} className="shrink-0 rounded-full" onClick={() => setFilter(f.value)} aria-pressed={filter === f.value}>{f.label}</Button>
          ))}
        </div>
        {logs.length === 0 ? <p className="text-sm text-muted-foreground">No activity recorded yet.</p> : (
          <ol className="max-h-[32rem] space-y-2 overflow-y-auto pr-1">
            {logs.map((log) => {
              const Icon = featureIcon(log.feature);
              return (
                <li key={log.id} className="rounded-xl border p-3">
                  <div className="flex items-start gap-3">
                    <Icon className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <p className="font-semibold">{log.activity_type}</p>
                        <Badge className={`capitalize ${statusStyle[log.status] ?? statusStyle.info}`}>{log.status}</Badge>
                      </div>
                      {log.activity_description && <p className="mt-1 whitespace-pre-wrap break-words text-sm">{log.activity_description}</p>}
                      <p className="mt-1 text-xs text-muted-foreground">{fmtFull(log.occurred_at)} · {metaLabel(log.feature)}{log.actor_role && log.actor_role !== "senior" ? " · by caregiver" : ""}</p>
                    </div>
                  </div>
                  <Button variant="link" size="sm" className="h-auto px-8 py-1" onClick={() => setDetail(log)}>View details</Button>
                </li>
              );
            })}
          </ol>
        )}
        {hasMore && (
          <Button variant="outline" className="mt-3 w-full" disabled={loadingMore} onClick={async () => { setLoadingMore(true); await loadLogs(logs[logs.length - 1]?.occurred_at); setLoadingMore(false); }}>
            {loadingMore && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Load older activity
          </Button>
        )}
      </Card>

      <Dialog open={!!detail} onOpenChange={(o) => !o && setDetail(null)}>
        <DialogContent className="max-h-[85vh] overflow-y-auto">
          {detail && <>
            <DialogHeader>
              <DialogTitle>{detail.activity_type}</DialogTitle>
              <DialogDescription>{fmtFull(detail.occurred_at)}</DialogDescription>
            </DialogHeader>
            <dl className="space-y-2 text-sm">
              <div><dt className="font-semibold">What happened</dt><dd className="whitespace-pre-wrap break-words">{detail.activity_description || "—"}</dd></div>
              <div><dt className="font-semibold">Feature</dt><dd>{metaLabel(detail.feature)}</dd></div>
              <div><dt className="font-semibold">Status</dt><dd className="capitalize">{detail.status}</dd></div>
              <div><dt className="font-semibold">Done by</dt><dd className="capitalize">{detail.actor_role ?? "senior"}</dd></div>
              {Object.entries(detail.metadata || {}).filter(([, v]) => v !== null && v !== "" && !(Array.isArray(v) && !v.length)).map(([k, v]) => (
                <div key={k}><dt className="font-semibold">{metaLabel(k)}</dt><dd className="break-words">{Array.isArray(v) ? v.join(", ") : typeof v === "object" ? JSON.stringify(v) : String(v)}</dd></div>
              ))}
            </dl>
          </>}
        </DialogContent>
      </Dialog>
    </div>
  );
};
