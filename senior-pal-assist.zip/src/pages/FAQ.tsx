import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { ArrowLeft, HelpCircle } from "lucide-react";
import Header from "@/components/Header";
import Newsletter from "@/components/Newsletter";

const FAQ = () => {
  const navigate = useNavigate();

  const faqs = [
    {
      question: "What is Reli?",
      answer: "Reli is an AI-powered companion app designed to help seniors live more independently while keeping caregivers connected. It provides friendly reminders, engaging conversations, daily trivia, medication tracking, and much more - all through an easy-to-use interface."
    },
    {
      question: "Who is Reli designed for?",
      answer: "Reli is designed for seniors who want to maintain their independence while staying connected with loved ones. It's also perfect for caregivers - whether family members or professional caregivers - who want to stay informed about their loved one's daily activities and wellbeing."
    },
    {
      question: "How do I get started with Reli?",
      answer: "Getting started is easy! Simply click 'Try Reli' on our homepage, create an account by choosing whether you're a senior or caregiver, and you're ready to go. Seniors can start using the dashboard immediately, while caregivers can add seniors to their care list using the senior's email address."
    },
    {
      question: "Is Reli free to use?",
      answer: "We offer a free tier that includes essential features to help you get started. Premium features may be available in the future to provide even more value to our users."
    },
    {
      question: "How does the caregiver connection work?",
      answer: "Caregivers can add seniors to their care list using the senior's registered email address. Once connected, caregivers can view activity reports, send messages and reminders, read life story entries, and customize which features are visible to their senior."
    },
    {
      question: "What kind of reminders can caregivers send?",
      answer: "Caregivers can send both regular messages and scheduled reminders. Reminders can include medication times, appointment notifications, daily tasks, or any other important information. Seniors receive these in real-time with clear notifications."
    },
    {
      question: "What is the Life Story feature?",
      answer: "The Life Story feature provides daily prompts that encourage seniors to share memories and experiences. These responses are saved and can be viewed by connected caregivers, helping preserve precious memories and providing meaningful conversation starters during visits."
    },
    {
      question: "How does the AI Companion work?",
      answer: "The AI Companion is a friendly chat assistant that's always available to talk. It can help with questions, provide companionship, engage in meaningful conversations, and offer support throughout the day. It's designed to be warm, patient, and easy to interact with."
    },
    {
      question: "Is my data secure?",
      answer: "Yes! We take privacy and security seriously. All data is encrypted and stored securely. We never share personal information with third parties. You can read more in our Privacy Policy."
    },
    {
      question: "Can I use Reli on my tablet or phone?",
      answer: "Yes! Reli is designed to work on any device with a web browser - including tablets, phones, and computers. The interface automatically adjusts to fit your screen size for the best experience."
    },
    {
      question: "What if I need help or have more questions?",
      answer: "We're here to help! You can reach out through our Contact page anytime. Our team is dedicated to ensuring you have the best experience with Reli."
    },
    {
      question: "Can caregivers customize what features seniors see?",
      answer: "Yes! Caregivers can toggle various features on or off for each senior in their care. This includes the AI Companion, Daily Trivia, Medication Tracker, Activity Tracker, Life Story prompts, and Doctor Report generation."
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/20 to-background">
      <Header />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Button
          variant="ghost"
          onClick={() => navigate(-1)}
          className="mb-6"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>

        <div className="text-center mb-12">
          <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6">
            <HelpCircle className="w-10 h-10 text-primary" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Frequently Asked Questions
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Find answers to common questions about Reli and how it can help you or your loved ones.
          </p>
        </div>

        <Card className="p-6 md:p-8 bg-card/80 backdrop-blur border-2">
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`}>
                <AccordionTrigger className="text-left text-lg font-medium hover:text-primary">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground text-base leading-relaxed">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </Card>

        <Card className="mt-8 p-8 bg-gradient-to-r from-primary/10 to-accent/10 border-2 text-center">
          <h2 className="text-2xl font-semibold mb-3">Still have questions?</h2>
          <p className="text-muted-foreground mb-6">
            We're here to help! Reach out to our team and we'll get back to you as soon as possible.
          </p>
          <Button onClick={() => navigate("/contact")} size="lg">
            Contact Us
          </Button>
        </Card>
      </main>

      <Newsletter />
    </div>
  );
};

export default FAQ;
