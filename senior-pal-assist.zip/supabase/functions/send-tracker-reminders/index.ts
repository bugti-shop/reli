// Scheduled sender for medication + tracker reminders.
// Runs on a cron every minute so reminder push/emails/texts go out on time even
// when nobody has the app open. Each reminder time matches exactly one run window,
// and email idempotency keys prevent duplicates on retries.
import { createClient } from 'npm:@supabase/supabase-js@2'
import { sendTemplateEmail } from '../_shared/transactional-email-templates/send-email.ts'
import { resolveEmailRecipient, resolveSmsRecipient } from '../_shared/notify-recipient.ts'
import { sendSms, toE164 } from '../_shared/send-sms.ts'
import { sendPushToUser } from '../_shared/send-push.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-cron-key',
}

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  })

// The job runs every minute so reminders land on time.
const WINDOW_MINUTES = 1
const DEFAULT_TZ = 'America/New_York'

const ALL_DAYS = [0, 1, 2, 3, 4, 5, 6]
const WEEKDAY_INDEX: Record<string, number> = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 }

interface DueItem {
  key: string
  time: string // HH:MM local
  title: string
  detail: string
  days: number[] // 0 = Sunday, in the senior's local timezone
  at?: number // one-time reminders (appointments/caregiver reminders), epoch ms
}

const localParts = (tz: string, at = new Date()) => {
  const fmt = new Intl.DateTimeFormat('en-CA', {
    timeZone: tz,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    weekday: 'short',
    hour12: false,
  })
  const parts: Record<string, string> = {}
  for (const p of fmt.formatToParts(at)) parts[p.type] = p.value
  const hour = Number(parts.hour === '24' ? '0' : parts.hour)
  return {
    date: `${parts.year}-${parts.month}-${parts.day}`,
    minutes: hour * 60 + Number(parts.minute),
    weekday: WEEKDAY_INDEX[parts.weekday] ?? new Date(at).getUTCDay(),
  }
}

// Accepts both 24-hour ("08:00") and 12-hour ("8:00 AM") stored times.
const toMinutes = (t: string) => {
  const raw = String(t).trim()
  const match = raw.match(/^(\d{1,2}):(\d{2})\s*(am|pm)?/i)
  if (!match) return NaN
  let hours = Number(match[1])
  const minutes = Number(match[2])
  const meridiem = match[3]?.toLowerCase()
  if (meridiem === 'pm' && hours < 12) hours += 12
  if (meridiem === 'am' && hours === 12) hours = 0
  return hours * 60 + minutes
}

const isDue = (reminderTime: string, nowMinutes: number) => {
  const target = toMinutes(reminderTime)
  if (!Number.isFinite(target)) return false
  const diff = (nowMinutes - target + 1440) % 1440
  return diff < WINDOW_MINUTES
}

const labelFor = (kind: string, label?: string | null) => {
  if (label) return label
  if (kind === 'blood_pressure') return 'blood pressure'
  if (kind === 'heart_rate') return 'heart rate'
  return 'medication'
}

async function notifyUser(admin: any, userId: string, item: DueItem, localDate: string, seniorName?: string | null) {
  const suffix = seniorName ? ` for ${seniorName}` : ''
  const title = `${item.title}${suffix}`

  try {
    await sendPushToUser(admin, userId, 'notify_reminders', {
      title,
      body: `${item.detail || 'Your Reli reminder'} (${item.time})`,
      path: '/dashboard',
    })
  } catch (e) {
    console.error('reminder push failed', userId, e)
  }


  const smsTo = await resolveSmsRecipient(admin, userId, 'notify_reminders')
  const phone = toE164(smsTo?.phone)
  if (phone) {
    try {
      await sendSms(phone, `Reli — ${title}${item.detail ? `: ${item.detail}` : ''} (${item.time})`)
    } catch (e) {
      console.error('reminder text failed', userId, e)
    }
  }

  const recipient = await resolveEmailRecipient(admin, userId, 'notify_reminders')
  if (!recipient) return false

  const result = await sendTemplateEmail('reminder-alert', recipient.email, {
    templateData: {
      recipientName: recipient.name?.split(' ')[0] ?? undefined,
      title,
      detail: item.detail || undefined,
      time: item.time,
    },
    idempotencyKey: `reminder-${userId}-${item.key}-${localDate}-${item.time}`,
  })
  return Boolean((result as any)?.sent)
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })

  const expected = Deno.env.get('DAILY_SUMMARY_CRON_KEY')
  if (!expected || req.headers.get('x-cron-key') !== expected) {
    return json({ error: 'Unauthorized' }, 401)
  }

  const admin = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
  )

  try {
    const nowMs = Date.now()
    const [{ data: meds }, { data: reminders }, { data: oneTime }] = await Promise.all([
      admin.from('medications').select('id, senior_id, name, time, dosage, completed, days_of_week'),
      admin
        .from('tracker_reminders')
        .select('id, senior_id, kind, label, time, enabled, days_of_week')
        .eq('enabled', true),
      admin
        .from('caregiver_messages')
        .select('id, senior_id, message, reminder_time')
        .eq('is_reminder', true)
        .gte('reminder_time', new Date(nowMs - 60_000).toISOString())
        .lte('reminder_time', new Date(nowMs + 1_000).toISOString()),
    ])

    // Collect candidate items per senior.
    const bySenior = new Map<string, DueItem[]>()
    const push = (seniorId: string, item: DueItem) => {
      const list = bySenior.get(seniorId) ?? []
      list.push(item)
      bySenior.set(seniorId, list)
    }

    // Group medications that share the same time and days into a single
    // reminder so one email/push/text covers all pills due together.
    const medGroups = new Map<string, DueItem & { seniorId: string }>()
    for (const m of meds ?? []) {
      if (!m.time || m.completed) continue
      const time = String(m.time).slice(0, 5)
      const days = (m.days_of_week as number[]) ?? ALL_DAYS
      const gKey = `medgroup-${m.senior_id}-${time}-${[...days].sort((a, b) => a - b).join('')}`
      const label = `${m.name}${m.dosage ? ` — ${m.dosage}` : ''}`
      const existing = medGroups.get(gKey)
      if (existing) {
        existing.detail += `, ${label}`
        existing.title = 'Time for medications'
      } else {
        medGroups.set(gKey, {
          key: gKey,
          time,
          title: 'Time for medication',
          detail: label,
          days,
          seniorId: m.senior_id,
        })
      }
    }
    for (const g of medGroups.values()) {
      push(g.seniorId, { key: g.key, time: g.time, title: g.title, detail: g.detail, days: g.days })
    }

    for (const r of reminders ?? []) {
      const kindLabel = labelFor(r.kind, r.label)
      push(r.senior_id, {
        key: `rem-${r.id}`,
        time: String(r.time).slice(0, 5),
        title:
          r.kind === 'custom'
            ? 'Reminder'
            : r.kind === 'medication'
              ? 'Medication reminder'
              : 'Time to take a reading',
        detail: r.kind === 'custom' ? kindLabel : `Please record ${kindLabel}.`,
        days: (r.days_of_week as number[]) ?? ALL_DAYS,
      })
    }

    for (const m of oneTime ?? []) {
      const at = new Date(m.reminder_time).getTime()
      push(m.senior_id, {
        key: `msg-${m.id}`,
        time: new Date(at).toISOString().slice(11, 16),
        title: 'Reminder',
        detail: String(m.message ?? '').slice(0, 300),
        days: [],
        at,
      })
    }

    let sent = 0
    let due = 0

    for (const [seniorId, items] of bySenior) {
      const [{ data: prefs }, { data: seniorProfile }, { data: links }] = await Promise.all([
        admin
          .from('notification_preferences')
          .select('daily_summary_timezone')
          .eq('user_id', seniorId)
          .maybeSingle(),
        admin.from('profiles').select('full_name').eq('id', seniorId).maybeSingle(),
        admin.from('caregiver_seniors').select('caregiver_id').eq('senior_id', seniorId),
      ])

      const tz = prefs?.daily_summary_timezone || DEFAULT_TZ
      const { date, minutes, weekday } = localParts(tz)
      const dueItems = items.filter((i) =>
        i.at !== undefined
          ? nowMs - i.at >= 0 && nowMs - i.at < 60_000
          : isDue(i.time, minutes) && (i.days.length === 0 || i.days.includes(weekday)),
      )
      if (dueItems.length === 0) continue
      due += dueItems.length

      const caregiverIds = (links ?? []).map((l: any) => l.caregiver_id)

      for (const item of dueItems) {
        try {
          if (await notifyUser(admin, seniorId, item, date)) sent++
        } catch (e) {
          console.error('reminder notify failed for senior', seniorId, e)
        }
        for (const caregiverId of caregiverIds) {
          try {
            if (await notifyUser(admin, caregiverId, item, date, seniorProfile?.full_name)) sent++
          } catch (e) {
            console.error('reminder notify failed for caregiver', caregiverId, e)
          }
        }
      }
    }

    return json({ ok: true, due, sent })
  } catch (error) {
    console.error('send-tracker-reminders error', error)
    return json({ error: 'Failed to send reminders' }, 500)
  }
})
