import { supabase } from "@/integrations/supabase/client";
import { brokeredPreviewStorage } from "@/integrations/supabase/previewAuthStorage";

const getAuthStorageKey = () => {
  try {
    const projectRef = new URL(import.meta.env.VITE_SUPABASE_URL).hostname.split(".")[0];
    return projectRef ? `sb-${projectRef}-auth-token` : null;
  } catch {
    return null;
  }
};

export const logoutAndRedirect = async () => {
  const storageKey = getAuthStorageKey();

  // Clear the local session first and synchronously so the redirect is instant.
  if (storageKey) {
    try {
      window.localStorage.removeItem(storageKey);
    } catch {
      // Ignore storage access failures; the sign-out calls below still run.
    }
    try {
      // An empty value is a logout tombstone for the shared preview-session broker.
      Promise.resolve(brokeredPreviewStorage()?.setItem(storageKey, "")).catch(() => {});
    } catch {
      // The preview broker is optional.
    }
  }

  // Fire and forget: a revoked server session can hang or reject, and waiting on it
  // is what made logout feel slow.
  void supabase.auth.signOut({ scope: "local" }).catch(() => {});

  // A hard navigation discards any stale in-memory auth state before opening sign-in.
  window.location.replace("/auth");
};
