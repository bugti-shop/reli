CREATE OR REPLACE FUNCTION public.cancel_circle_invite(_invite_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  inv public.circle_invites;
  me uuid := auth.uid();
BEGIN
  IF me IS NULL THEN RAISE EXCEPTION 'Please sign in first'; END IF;

  SELECT * INTO inv
  FROM public.circle_invites
  WHERE id = _invite_id
  FOR UPDATE;

  IF inv.id IS NULL THEN RAISE EXCEPTION 'Invitation not found'; END IF;
  IF NOT (
    inv.senior_id = me OR EXISTS (
      SELECT 1 FROM public.caregiver_seniors cs
      WHERE cs.senior_id = inv.senior_id AND cs.caregiver_id = me
    )
  ) THEN RAISE EXCEPTION 'You cannot manage this Family Circle'; END IF;
  IF inv.approved_at IS NOT NULL OR inv.used_at IS NOT NULL THEN
    RAISE EXCEPTION 'Accepted invitations cannot be cancelled';
  END IF;

  DELETE FROM public.circle_invites WHERE id = inv.id;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.cancel_circle_invite(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.cancel_circle_invite(uuid) TO authenticated;