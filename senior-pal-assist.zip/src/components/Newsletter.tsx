import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { CheckCircle2, Mail } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

const Newsletter = () => {
  const [email, setEmail] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const { toast } = useToast();

  const EMAIL_REGEX = /^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)+$/;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const trimmed = email.trim();
    if (!EMAIL_REGEX.test(trimmed)) {
      toast({
        title: "Invalid email",
        description: "Please enter a valid email address, like name@example.com.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);

    const { data, error } = await supabase.functions.invoke("newsletter-subscribe", {
      body: { email: trimmed },
    });

    if (error) {
      let message = "Something went wrong. Please try again.";
      try {
        const body = await (error as { context?: Response }).context?.json();
        if (body?.error) message = body.error;
      } catch {
        // fall back to generic message
      }
      toast({
        title: message === "already_subscribed" ? "Already subscribed" : "Error",
        description:
          message === "already_subscribed"
            ? "This email is already subscribed to our newsletter."
            : message,
        variant: message === "already_subscribed" ? "default" : "destructive",
      });
    } else if (data?.success) {
      toast({
        title: "Subscribed!",
        description: "Thank you for subscribing! Check your inbox for a welcome email from us.",
      });
      setEmail("");
      setIsSubscribed(true);
    }

    setIsSubmitting(false);
  };

  return (
    <section className="w-full bg-background px-5 py-14 sm:py-20">
      <div className="max-w-2xl mx-auto text-center">
        <div className="flex justify-center mb-4">
          <div className="rounded-full bg-primary/10 p-3">
            <Mail className="h-6 w-6 text-primary" />
          </div>
        </div>
        <h3 className="font-landing-serif text-3xl font-bold text-landing-navy mb-2 sm:text-4xl">
          Stay Updated
        </h3>
        <p className="text-muted-foreground mb-6">
          Subscribe to our newsletter for updates on new features and functionalities.
        </p>
        {isSubscribed ? (
          <div className="max-w-md mx-auto rounded-lg border border-primary/30 bg-card p-5">
            <CheckCircle2 className="h-8 w-8 text-primary mx-auto mb-2" aria-hidden="true" />
            <p className="text-lg font-semibold text-foreground">Thank you for subscribing!</p>
            <p className="text-muted-foreground mt-1">
              A welcome email is on its way — check your inbox.
            </p>
            <Button variant="ghost" className="mt-3" onClick={() => setIsSubscribed(false)}>
              Add another email
            </Button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="mx-auto flex max-w-md flex-col gap-3 sm:flex-row">
            <Input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="h-12 flex-1 rounded-full bg-card px-5"
              disabled={isSubmitting}
            />
            <Button type="submit" disabled={isSubmitting} className="h-12 rounded-full px-7">
              {isSubmitting ? "Subscribing..." : "Subscribe"}
            </Button>
          </form>
        )}
      </div>
    </section>
  );
};

export default Newsletter;
