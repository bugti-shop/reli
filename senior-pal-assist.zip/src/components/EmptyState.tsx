import { LucideIcon } from "lucide-react";
import { Card } from "@/components/ui/card";

interface EmptyStateProps {
  icon: LucideIcon;
  title: string;
  description?: string;
  action?: React.ReactNode;
  className?: string;
}

/** Friendly placeholder shown when a list or tracker has no entries yet. */
export const EmptyState = ({ icon: Icon, title, description, action, className = "" }: EmptyStateProps) => (
  <Card className={`p-8 border text-center ${className}`}>
    <div className="w-16 h-16 rounded-full bg-secondary/60 flex items-center justify-center mx-auto mb-4">
      <Icon className="w-8 h-8 text-primary" />
    </div>
    <p className="text-lg font-semibold text-foreground">{title}</p>
    {description && <p className="text-sm text-muted-foreground mt-1 max-w-md mx-auto">{description}</p>}
    {action && <div className="mt-4 flex justify-center">{action}</div>}
  </Card>
);

export default EmptyState;
