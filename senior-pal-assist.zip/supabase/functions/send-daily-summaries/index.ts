import { createClient } from 'npm:@supabase/supabase-js@2'
import { sendTemplateEmail } from '../_shared/transactional-email-templates/send-email.ts'
import { resolveEmailRecipient, resolveSmsRecipient } from '../_shared/notify-recipient.ts'
import { sendSms, toE164 } from '../_shared/send-sms.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-cron-key',
}

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  })

interface PersonSummary {
  name?: string
  medsTaken: number
  medsTotal: number
  bloodPressure?: string
  heartRate?: string
  log?: string
  journal?: string
}

const localParts = (tz: string, at = new Date()) => {
  const fmt = new Intl.DateTimeFormat('en-CA', {
    timeZone: tz,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    hour12: false,
  })
  const parts: Record<string, string> = {}
  for (const p of fmt.formatToParts(at)) parts[p.type] = p.value
  return {
    date: `${parts.year}-${parts.month}-${parts.day}`,
    hour: Number(parts.hour === '24' ? '0' : parts.hour),
  }
}

const dateLabelFor = (tz: string, isoDate: string) =>
  new Intl.DateTimeFormat('en-US', {
    timeZone: tz,
    weekday: 'long',
    month: 'long',
    day: 'numeric',
  }).format(new Date(`${isoDate}T12:00:00Z`))

const timeLabel = (tz: string, iso: string | null) =>
  iso
    ? new Intl.DateTimeFormat('en-US', {
        timeZone: tz,
        hour: 'numeric',
        minute: '2-digit',
      }).format(new Date(iso))
    : ''

async function buildSummaryFor(
  admin: any,
  userId: string,
  tz: string,
  localDate: string
): Promise<PersonSummary[]> {
  const { data: profile } = await admin
    .from('profiles')
    .select('role, full_name')
    .eq('id', userId)
    .maybeSingle()

  let seniorIds: string[] = []
  if (profile?.role === 'caregiver') {
    const { data: links } = await admin
      .from('caregiver_seniors')
      .select('senior_id')
      .eq('caregiver_id', userId)
    seniorIds = (links ?? []).map((l: any) => l.senior_id)
  } else {
    seniorIds = [userId]
  }
  if (seniorIds.length === 0) return []

  // Local-day window in UTC (approximate at the day's edges by 1h in DST shifts).
  const dayStart = new Date(`${localDate}T00:00:00Z`)
  const offsetMs =
    new Date(dayStart.toLocaleString('en-US', { timeZone: 'UTC' })).getTime() -
    new Date(dayStart.toLocaleString('en-US', { timeZone: tz })).getTime()
  const startIso = new Date(dayStart.getTime() + offsetMs).toISOString()
  const endIso = new Date(dayStart.getTime() + offsetMs + 86400000).toISOString()

  const summaries: PersonSummary[] = []

  for (const seniorId of seniorIds) {
    const [
      { data: seniorProfile },
      { count: medsTotal },
      { count: medsTaken },
      { data: bp },
      { data: hr },
      { data: log },
      { data: journal },
    ] = await Promise.all([
      admin.from('profiles').select('full_name').eq('id', seniorId).maybeSingle(),
      admin.from('medications').select('id', { count: 'exact', head: true }).eq('senior_id', seniorId),
      admin
        .from('medication_doses')
        .select('id', { count: 'exact', head: true })
        .eq('senior_id', seniorId)
        .is('deleted_at', null)
        .gte('taken_at', startIso)
        .lt('taken_at', endIso),
      admin
        .from('vital_readings')
        .select('systolic, diastolic, recorded_at')
        .eq('senior_id', seniorId)
        .eq('reading_type', 'blood_pressure')
        .is('deleted_at', null)
        .gte('recorded_at', startIso)
        .lt('recorded_at', endIso)
        .order('recorded_at', { ascending: false })
        .limit(1),
      admin
        .from('vital_readings')
        .select('bpm, recorded_at')
        .eq('senior_id', seniorId)
        .eq('reading_type', 'heart_rate')
        .is('deleted_at', null)
        .gte('recorded_at', startIso)
        .lt('recorded_at', endIso)
        .order('recorded_at', { ascending: false })
        .limit(1),
      admin
        .from('caregiver_daily_logs')
        .select('mood, ate_well, slept_well, had_fall, confusion_noted, notes')
        .eq('senior_id', seniorId)
        .eq('log_date', localDate)
        .order('updated_at', { ascending: false })
        .limit(1),
      admin
        .from('journal_entries')
        .select('title')
        .eq('senior_id', seniorId)
        .eq('entry_date', localDate)
        .limit(1),
    ])

    const bpRow = bp?.[0]
    const hrRow = hr?.[0]
    const logRow = log?.[0]

    const logBits: string[] = []
    if (logRow?.mood) logBits.push(`mood ${logRow.mood}`)
    if (logRow?.ate_well) logBits.push('ate well')
    if (logRow?.slept_well) logBits.push('slept well')
    if (logRow?.had_fall) logBits.push('a fall was noted')
    if (logRow?.confusion_noted) logBits.push('confusion was noted')
    if (logRow?.notes) logBits.push(String(logRow.notes).slice(0, 200))

    summaries.push({
      name: seniorProfile?.full_name || (seniorIds.length > 1 ? 'Your senior' : undefined),
      medsTotal: medsTotal ?? 0,
      medsTaken: medsTaken ?? 0,
      bloodPressure: bpRow
        ? `${bpRow.systolic}/${bpRow.diastolic}${
            timeLabel(tz, bpRow.recorded_at) ? ` at ${timeLabel(tz, bpRow.recorded_at)}` : ''
          }`
        : undefined,
      heartRate: hrRow
        ? `${hrRow.bpm} bpm${
            timeLabel(tz, hrRow.recorded_at) ? ` at ${timeLabel(tz, hrRow.recorded_at)}` : ''
          }`
        : undefined,
      log: logBits.length ? logBits.join(', ') : undefined,
      journal: journal?.[0] ? journal[0].title || 'An entry was written' : undefined,
    })
  }

  return summaries
}

async function sendFor(admin: any, userId: string, tz: string, localDate: string) {
  const people = await buildSummaryFor(admin, userId, tz, localDate)
  const dateLabel = dateLabelFor(tz, localDate)

  let texted = false
  const smsTo = await resolveSmsRecipient(admin, userId, 'notify_daily_summary')
  const phone = toE164(smsTo?.phone)
  if (phone) {
    const lines = people.map((p) => {
      const bits = [`${p.medsTaken}/${p.medsTotal} meds`]
      if (p.bloodPressure) bits.push(`BP ${p.bloodPressure.split(' at ')[0]}`)
      if (p.heartRate) bits.push(p.heartRate.split(' at ')[0])
      return `${p.name ? `${p.name}: ` : ''}${bits.join(', ')}`
    })
    try {
      const result = await sendSms(
        phone,
        `Reli daily summary (${dateLabel}) — ${lines.join(' | ') || 'nothing recorded today'}`
      )
      texted = result.sent
    } catch (e) {
      console.error('daily summary text failed', e)
    }
  }

  const recipient = await resolveEmailRecipient(admin, userId, 'notify_daily_summary')
  if (!recipient) return { sent: false, texted, reason: 'email_off' }

  const result = await sendTemplateEmail('daily-summary', recipient.email, {
    templateData: {
      recipientName: recipient.name?.split(' ')[0] ?? undefined,
      dateLabel,
      people,
    },
    idempotencyKey: `daily-summary-${userId}-${localDate}`,
  })
  return { ...result, texted }
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })

  const admin = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
  )

  try {
    const cronKey = req.headers.get('x-cron-key')
    const expected = Deno.env.get('DAILY_SUMMARY_CRON_KEY')

    // Scheduled run: send to everyone whose chosen local time is the current hour.
    if (expected && cronKey === expected) {
      const { data: rows } = await admin
        .from('notification_preferences')
        .select('user_id, daily_summary_time, daily_summary_timezone, notify_daily_summary, email_enabled, sms_enabled')

      let sent = 0
      for (const row of rows ?? []) {
        if (row.notify_daily_summary === false) continue
        if (row.email_enabled === false && row.sms_enabled !== true) continue
        const tz = row.daily_summary_timezone || 'America/New_York'
        const wantedHour = Number(String(row.daily_summary_time || '19:00').slice(0, 2))
        const { date, hour } = localParts(tz)
        if (hour !== wantedHour) continue
        try {
          const result = await sendFor(admin, row.user_id, tz, date)
          if ((result as any).sent) sent++
        } catch (e) {
          console.error('daily summary failed for user', row.user_id, e)
        }
      }
      return json({ scheduled: true, sent })
    }

    // Manual "send me one now" from a signed-in user.
    const authHeader = req.headers.get('Authorization') ?? ''
    const userClient = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_ANON_KEY')!,
      { global: { headers: { Authorization: authHeader } } }
    )
    const { data: userData } = await userClient.auth.getUser()
    const user = userData?.user
    if (!user) return json({ error: 'Unauthorized' }, 401)

    const { data: prefs } = await admin
      .from('notification_preferences')
      .select('daily_summary_timezone')
      .eq('user_id', user.id)
      .maybeSingle()
    const tz = prefs?.daily_summary_timezone || 'America/New_York'
    const { date } = localParts(tz)
    const result = await sendFor(admin, user.id, tz, date)
    return json(result)
  } catch (error) {
    console.error('send-daily-summaries error', error)
    return json({ error: 'Failed to send daily summary' }, 500)
  }
})
