
-- Drop the overly restrictive UPDATE policies
DROP POLICY "Caregivers can update their trackers" ON public.custom_trackers;
DROP POLICY "Seniors can update their own trackers" ON public.custom_trackers;

-- Caregivers can update any tracker for their seniors
CREATE POLICY "Caregivers can update their seniors trackers"
ON public.custom_trackers
FOR UPDATE
USING (
  EXISTS (
    SELECT 1 FROM caregiver_seniors
    WHERE caregiver_seniors.caregiver_id = auth.uid()
    AND caregiver_seniors.senior_id = custom_trackers.senior_id
  )
);

-- Seniors can update any tracker visible to them
CREATE POLICY "Seniors can update visible trackers"
ON public.custom_trackers
FOR UPDATE
USING (
  senior_id = auth.uid()
  AND (created_by_role = 'senior' OR shared_with_senior = true)
);
