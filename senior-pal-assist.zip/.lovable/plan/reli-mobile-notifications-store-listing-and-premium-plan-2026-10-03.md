# Reli mobile notifications, store listing, and Premium plan

## Goal
Finish the app-side iPhone push setup, prepare a single $34.99 monthly in-app subscription, redesign the mobile paywall, and provide final Google Play listing copy for **Reli: Family Caregiver App**.

## 1. Firebase and iPhone notifications
- Link the existing Firebase Cloud Messaging connection to this project so the backend can send real pushes.
- Keep the APNs `.p8` key in Firebase only; never add it to source control or Codemagic.
- Verify the iOS app uses bundle ID `com.reli.care`, includes Push Notifications/background notification support, registers the FCM token, and stores it against the signed-in Reli user.
- Ensure regular notifications open the correct Reli screen and SOS notifications retain the high-priority/critical payload and bundled alarm sound.
- Keep Critical Alerts honest: the entitlement will only be enabled after Apple approves it. Before approval, iPhone notifications work normally but cannot override Silent/Focus.
- Make Codemagic fail clearly when the iOS Firebase config is missing instead of producing a notification-disabled release.

### Current blocker
The Firebase connection exists, but Lovable reports that the current project owner does not have permission to link it. The owner must grant this project/user access to **Flowist's Firebase Cloud Messaging** in Workspace connector settings. Once access is available, the connection can be linked and backend notification delivery can be tested.

## 2. One mobile Premium subscription
- Define one shared store product ID for Apple and Google: `com.reli.care.monthly`.
- Keep one RevenueCat entitlement: `premium`, with one current monthly package/offering.
- Filter the app’s store packages so only this product can appear; no annual or second mobile plan.
- Price shown in the paywall: **$34.99/month**, monthly recurring, automatically renewing until cancelled.
- Preserve purchase restoration, account-linked entitlement syncing, and platform subscription management.
- Add a safe product-ID check to the RevenueCat webhook so unrelated store products cannot activate Reli Premium.

## 3. Clean mobile paywall
- Replace the generic package row with a focused Reli Premium screen:
  - Title: **Reli Premium**
  - Short family-care subtitle
  - Clear **$34.99 / month** pricing
  - Premium feature list covering unlimited care history, custom reminders and trackers, AI insights, family sharing, and shared access for the senior and caregivers
  - One prominent subscribe button
  - Restore Purchases, Terms, Privacy, and auto-renewal/cancellation disclosure
- Use the existing Reli colors, typography, buttons, and card styling; keep it compact and readable on small phones.
- Keep the existing web Stripe plan behavior unchanged unless store configuration requires a shared entitlement update.

## 4. Google Play listing copy
Use the following final English copy:

**App title**  
Reli: Family Caregiver App

**Short description**  
Coordinate medications, health, reminders and daily care with your family.

**Long description**  
Reli helps families coordinate care for aging parents, older adults, and loved ones who need everyday support. Seniors and authorized caregivers stay connected through one clear, easy-to-use care companion designed for shared routines, timely updates, and greater peace of mind.

Create medication schedules, appointments, and custom reminders so important tasks are easier to remember. Caregivers can use a dedicated dashboard to review upcoming actions, recent updates, medication status, and the information their family needs to coordinate care.

Track health readings and daily activity, including blood pressure, heart rate, glucose, weight, water intake, medication completion, and other care routines. Reli organizes this information into accessible histories and reports that families can review together and discuss with healthcare professionals.

Capture symptoms, mood, sleep, meals, activities, and observations in the shared care journal. Record meaningful memories and photos with Life Stories, helping families preserve personal history and stay connected beyond day-to-day care tasks.

Reli also supports family sharing, caregiver messages, care reminders, notifications, emergency SOS alerts, and live location sharing during an active SOS. Access is limited to the senior and their authorized caregivers, helping families coordinate support while respecting personal information.

Key features include:
• Medication schedules, completion tracking, and reminders
• Appointment and custom care reminders
• Dedicated caregiver dashboard and daily status view
• Health readings and activity history
• Care journal and pattern summaries
• Life Stories, memories, and private photo sharing
• Family caregiver sharing and care coordination
• Messages, alerts, and real-time notifications
• Emergency SOS and live location sharing during an active alert
• Shared reports for family and care discussions

Reli does not provide medical advice, diagnosis, or treatment. Always consult a qualified healthcare professional before making medical or medication decisions. Emergency SOS notifications support family coordination and are not a replacement for local emergency services.

## 5. Store-side setup that cannot be created from source code
- In App Store Connect, create an auto-renewable monthly subscription with product ID `com.reli.care.monthly` and price tier equivalent to USD $34.99.
- In Google Play Console, create a monthly auto-renewing subscription with the same product ID and USD $34.99 base-plan price.
- In RevenueCat, connect both store products to entitlement `premium`, add the monthly package to the current offering, configure the public SDK keys in Codemagic, and configure the existing secure webhook.
- Store prices remain authoritative and localized; the app’s visible $34.99 copy is the requested US reference price.

## 6. Verification
- Run the project’s TypeScript check and inspect the automatic preview build result.
- Verify the paywall at a phone viewport, including loading, unavailable, purchase-in-progress, cancellation, and restore states.
- Run Capacitor sync checks for iOS and confirm Firebase/RevenueCat native packages remain present.
- After Firebase access and store products are configured, perform the real-device test through TestFlight: permission prompt, token registration, normal push while foreground/background, notification tap navigation, and SOS delivery.
- A true signed iOS archive and real APNs delivery require Codemagic/TestFlight plus the external Firebase and Apple configuration; local web preview cannot prove them.
