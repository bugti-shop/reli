import type { ComponentType } from 'npm:react@18.3.1'

export interface TemplateEntry {
  component: ComponentType<any>
  subject: string | ((data: Record<string, any>) => string)
  displayName?: string
  previewData?: Record<string, any>
  /** Fixed recipient — overrides caller-provided recipientEmail when set. */
  to?: string
}

import { template as caregiverMessage } from './caregiver-message.tsx'
import { template as emergencyAlert } from './emergency-alert.tsx'
import { template as reminderAlert } from './reminder-alert.tsx'
import { template as dailySummary } from './daily-summary.tsx'
import { template as contactNotification } from './contact-notification.tsx'
import { template as contactConfirmation } from './contact-confirmation.tsx'
import { template as newsletterWelcome } from './newsletter-welcome.tsx'
import { template as familyCircleInvite } from './family-circle-invite.tsx'
import { template as accountDeletionCode } from './account-deletion-code.tsx'

/**
 * Template registry — maps template names to their React Email components.
 */
export const TEMPLATES: Record<string, TemplateEntry> = {
  'caregiver-message': caregiverMessage,
  'emergency-alert': emergencyAlert,
  'reminder-alert': reminderAlert,
  'daily-summary': dailySummary,
  'contact-notification': contactNotification,
  'contact-confirmation': contactConfirmation,
  'newsletter-welcome': newsletterWelcome,
  'family-circle-invite': familyCircleInvite,
  'account-deletion-code': accountDeletionCode,
}
