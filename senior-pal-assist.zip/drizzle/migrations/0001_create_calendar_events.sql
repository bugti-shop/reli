CREATE TABLE public.calendar_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  senior_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  owner_id uuid NOT NULL,
  created_by_role text NOT NULL DEFAULT 'caregiver',
  title text NOT NULL,
  event_date date NOT NULL,
  event_time text,
  event_type text NOT NULL DEFAULT 'appointment',
  notes text,
  completed boolean NOT NULL DEFAULT false,
  completed_at timestamp with time zone,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

CREATE INDEX idx_calendar_events_senior_date ON public.calendar_events (senior_id, event_date);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.calendar_events TO authenticated;
GRANT ALL ON public.calendar_events TO service_role;

ALTER TABLE public.calendar_events ENABLE ROW LEVEL SECURITY;

-- Seniors see only their own events
CREATE POLICY "senior_select_own_calendar_events"
  ON public.calendar_events FOR SELECT
  USING (auth.uid() = senior_id);

CREATE POLICY "senior_insert_own_calendar_events"
  ON public.calendar_events FOR INSERT
  WITH CHECK (auth.uid() = senior_id);

CREATE POLICY "senior_update_own_calendar_events"
  ON public.calendar_events FOR UPDATE
  USING (auth.uid() = senior_id)
  WITH CHECK (auth.uid() = senior_id);

CREATE POLICY "senior_delete_own_calendar_events"
  ON public.calendar_events FOR DELETE
  USING (auth.uid() = senior_id);

-- Caregivers see and manage events of seniors linked to them
CREATE POLICY "caregiver_select_linked_calendar_events"
  ON public.calendar_events FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM public.caregiver_seniors cs
    WHERE cs.caregiver_id = auth.uid() AND cs.senior_id = calendar_events.senior_id
  ));

CREATE POLICY "caregiver_insert_linked_calendar_events"
  ON public.calendar_events FOR INSERT
  WITH CHECK (EXISTS (
    SELECT 1 FROM public.caregiver_seniors cs
    WHERE cs.caregiver_id = auth.uid() AND cs.senior_id = calendar_events.senior_id
  ));

CREATE POLICY "caregiver_update_linked_calendar_events"
  ON public.calendar_events FOR UPDATE
  USING (EXISTS (
    SELECT 1 FROM public.caregiver_seniors cs
    WHERE cs.caregiver_id = auth.uid() AND cs.senior_id = calendar_events.senior_id
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM public.caregiver_seniors cs
    WHERE cs.caregiver_id = auth.uid() AND cs.senior_id = calendar_events.senior_id
  ));

CREATE POLICY "caregiver_delete_linked_calendar_events"
  ON public.calendar_events FOR DELETE
  USING (EXISTS (
    SELECT 1 FROM public.caregiver_seniors cs
    WHERE cs.caregiver_id = auth.uid() AND cs.senior_id = calendar_events.senior_id
  ));

-- Updated_at maintenance
CREATE TRIGGER trg_calendar_events_updated
  BEFORE UPDATE ON public.calendar_events
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

-- Senior activity capture (same model as other data tables)
CREATE OR REPLACE FUNCTION public.trg_calendar_event_activity()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  n jsonb := CASE WHEN TG_OP = 'DELETE' THEN to_jsonb(OLD) ELSE to_jsonb(NEW) END;
  o jsonb := CASE WHEN TG_OP = 'UPDATE' THEN to_jsonb(OLD) ELSE NULL END;
  sid uuid := (n->>'senior_id')::uuid;
  actor uuid := COALESCE(auth.uid(), sid);
  eid text := TG_TABLE_NAME || ':' || TG_OP || ':' || (n->>'id') || ':' || extract(epoch from clock_timestamp())::text;
  when_text text := COALESCE(n->>'event_time', '') ; 
  descr text := (n->>'title') || COALESCE(' — ' || (n->>'event_date'), '') || CASE WHEN when_text <> '' THEN ' at ' || when_text ELSE '' END;
BEGIN
  IF TG_OP = 'INSERT' THEN
    PERFORM record_senior_activity(sid, eid, 'Calendar entry added', descr, 'calendar', 'info',
      jsonb_build_object('title', n->>'title', 'date', n->>'event_date', 'time', n->>'event_time', 'type', n->>'event_type', 'by_role', n->>'created_by_role'), actor);
  ELSIF TG_OP = 'UPDATE' AND (o->>'completed') IS DISTINCT FROM (n->>'completed') THEN
    PERFORM record_senior_activity(sid, eid, CASE WHEN (n->>'completed')::boolean THEN 'Calendar entry completed' ELSE 'Calendar entry reopened' END, descr, 'calendar',
      CASE WHEN (n->>'completed')::boolean THEN 'completed' ELSE 'pending' END,
      jsonb_build_object('title', n->>'title', 'date', n->>'event_date', 'time', n->>'event_time'), actor);
  ELSIF TG_OP = 'UPDATE' THEN
    PERFORM record_senior_activity(sid, eid, 'Calendar entry updated', descr, 'calendar', 'info',
      jsonb_build_object('title', n->>'title', 'date', n->>'event_date', 'time', n->>'event_time', 'type', n->>'event_type'), actor);
  ELSE
    PERFORM record_senior_activity(sid, eid, 'Calendar entry deleted', descr, 'calendar', 'cancelled',
      jsonb_build_object('title', n->>'title', 'date', n->>'event_date', 'time', n->>'event_time'), actor);
  END IF;
  RETURN NULL;
EXCEPTION WHEN OTHERS THEN
  RAISE LOG 'calendar event activity capture failed: %', SQLERRM;
  RETURN NULL;
END $$;

REVOKE EXECUTE ON FUNCTION public.trg_calendar_event_activity() FROM PUBLIC, anon, authenticated;

CREATE TRIGGER trg_calendar_events_activity
  AFTER INSERT OR UPDATE OR DELETE ON public.calendar_events
  FOR EACH ROW EXECUTE FUNCTION public.trg_calendar_event_activity();
