-- Drop and recreate the handle_new_user function with input validation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  validated_full_name TEXT;
  validated_role app_role;
BEGIN
  -- Validate and sanitize full_name (max 100 chars, trim whitespace)
  validated_full_name := NULLIF(TRIM(SUBSTRING(COALESCE(NEW.raw_user_meta_data->>'full_name', '')::TEXT, 1, 100)), '');
  
  -- Validate role - only allow 'senior' or 'caregiver', default to 'senior'
  BEGIN
    validated_role := COALESCE((NEW.raw_user_meta_data->>'role')::app_role, 'senior');
  EXCEPTION
    WHEN invalid_text_representation THEN
      validated_role := 'senior';
  END;
  
  -- Log profile creation for audit purposes
  RAISE LOG 'Creating profile for user %: full_name=%, role=%', NEW.id, validated_full_name, validated_role;
  
  INSERT INTO public.profiles (id, email, full_name, role)
  VALUES (
    NEW.id,
    NEW.email,
    validated_full_name,
    validated_role
  );
  
  RETURN NEW;
END;
$$;