import { useCallback, useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Inbox, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface SeniorMessage {
  id: string;
  message: string;
  read: boolean;
  created_at: string;
}

interface CaregiverInboxProps {
  caregiverId: string;
  seniorId: string;
  seniorName: string;
}

export const CaregiverInbox = ({ caregiverId, seniorId, seniorName }: CaregiverInboxProps) => {
  const [messages, setMessages] = useState<SeniorMessage[]>([]);
  const { toast } = useToast();

  const fetchMessages = useCallback(async () => {
    const { data, error } = await supabase
      .from("caregiver_messages")
      .select("id, message, read, created_at")
      .eq("caregiver_id", caregiverId)
      .eq("senior_id", seniorId)
      .eq("sender_role", "senior")
      .order("created_at", { ascending: false })
      .limit(50);
    if (error) {
      console.error("Error fetching senior messages:", error);
      return;
    }
    setMessages(data || []);
  }, [caregiverId, seniorId]);

  useEffect(() => {
    fetchMessages();
    const channel = supabase
      .channel(`senior-messages-${seniorId}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "caregiver_messages",
          filter: `caregiver_id=eq.${caregiverId}`,
        },
        (payload) => {
          const row = payload.new as { sender_role?: string; senior_id?: string } | null;
          fetchMessages();
          if (payload.eventType === "INSERT" && row?.sender_role === "senior" && row?.senior_id === seniorId) {
            toast({
              title: `New message from ${seniorName}`,
              description: "Check your inbox to read it.",
            });
          }
        }
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [caregiverId, seniorId, seniorName, fetchMessages, toast]);

  const markAsRead = async (id: string) => {
    setMessages((current) => current.map((m) => (m.id === id ? { ...m, read: true } : m)));
    const { error } = await supabase.from("caregiver_messages").update({ read: true }).eq("id", id);
    if (error) console.error("Error marking message read:", error);
  };

  const deleteMessage = async (id: string) => {
    setMessages((current) => current.filter((m) => m.id !== id));
    const { error } = await supabase.from("caregiver_messages").delete().eq("id", id);
    if (error) {
      console.error("Error deleting message:", error);
      toast({ title: "Could not delete message", variant: "destructive" });
      fetchMessages();
    }
  };

  const unread = messages.filter((m) => !m.read).length;

  return (
    <Card className="p-5 border">
      <h3 className="text-base font-semibold text-foreground mb-3 flex items-center gap-2">
        <Inbox className="w-4 h-4 text-primary" /> Messages from {seniorName}
        {unread > 0 && (
          <span className="bg-destructive text-destructive-foreground px-2 py-0.5 rounded-full text-xs font-bold">
            {unread} new
          </span>
        )}
      </h3>
      {messages.length === 0 ? (
        <p className="text-sm text-muted-foreground">
          No messages yet. When {seniorName} sends you a message, it appears here.
        </p>
      ) : (
        <div className="space-y-2 max-h-[320px] overflow-y-auto">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`p-3 rounded-lg border ${msg.read ? "bg-muted/30" : "bg-primary/5 border-primary/30"}`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-sm text-foreground break-words">{msg.message}</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {new Date(msg.created_at).toLocaleString()}
                  </p>
                </div>
                <div className="flex items-center gap-1 flex-shrink-0">
                  {!msg.read && (
                    <Button variant="outline" size="sm" className="text-xs" onClick={() => markAsRead(msg.id)}>
                      Mark Read
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="icon"
                    aria-label="Delete message"
                    onClick={() => deleteMessage(msg.id)}
                  >
                    <Trash2 className="w-4 h-4 text-destructive" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </Card>
  );
};
