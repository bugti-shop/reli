export interface PaidPlan {
  id: string;
  name: string;
  monthlyPriceId: string;
  annualPriceId: string;
  monthlyProductId: string;
  annualProductId: string;
  monthlyAmount: number; // dollars
  annualAmount: number; // dollars
  blurb: string;
  features: string[];
  /** Not purchasable yet — shown as "Coming soon". */
  comingSoon?: boolean;
}

/** Seniors a caregiver can manage on the free plan. Premium is unlimited. */
export const FREE_SENIOR_LIMIT = 2;

/** Caregivers a senior can have on the free plan. Premium is unlimited. */
export const FREE_CAREGIVER_LIMIT = 2;

export const PAID_PLANS: PaidPlan[] = [
  {
    id: "premium",
    name: "Premium",
    monthlyPriceId: "price_1UG2sBFAPtKh08jGFK6PK1r2",
    annualPriceId: "price_1UG2thFAPtKh08jGv0AmuiFi",
    monthlyProductId: "prod_VGa2TZxenqsAvd",
    annualProductId: "prod_VGa3caIZmDeTuH",
    monthlyAmount: 34.99,
    annualAmount: 356.9,
    blurb: "Full history and smart tools for one family.",
    features: [
      "Unlimited tracker, journal & daily log history",
      "Unlimited seniors per caregiver",
      "Custom trackers",
      "Custom reminders",
      "AI trends & insights",
      "Covers the senior and their caregivers",
    ],
  },
  {
    id: "premium_plus",
    name: "Premium Plus",
    monthlyPriceId: "price_1UG2u8FAPtKh08jG1ENPhumb",
    annualPriceId: "price_1UG2ujFAPtKh08jG3YJmn4yz",
    monthlyProductId: "prod_VGa4X6nKpeFHrj",
    annualProductId: "prod_VGa4v4i27Gjouq",
    monthlyAmount: 64.99,
    annualAmount: 662.9,
    blurb: "Everything in Premium, built for larger care teams.",
    comingSoon: true,
    features: [
      "Everything in Premium",
      "Best for families with several caregivers",
      "Priority support",
    ],
  },
];

export const ALL_PRODUCT_IDS = PAID_PLANS.flatMap((p) => [
  p.monthlyProductId,
  p.annualProductId,
]);
