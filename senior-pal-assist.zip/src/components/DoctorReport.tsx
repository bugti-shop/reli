import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { FileText, Plus, Trash2, Printer, Mail, MessageSquare } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Question {
  id: string;
  text: string;
}

interface Medication {
  id: string;
  name: string;
  dosage: string;
  frequency: string;
  time: string;
  taken: boolean;
}

interface Activity {
  id: string;
  name: string;
  time: string;
  completed: boolean;
}

const DoctorReport = () => {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [newQuestion, setNewQuestion] = useState("");
  const [additionalNotes, setAdditionalNotes] = useState("");
  const { toast } = useToast();

  useEffect(() => {
    const saved = localStorage.getItem("doctorQuestions");
    if (saved) {
      setQuestions(JSON.parse(saved));
    }
    const notes = localStorage.getItem("doctorNotes");
    if (notes) {
      setAdditionalNotes(notes);
    }
  }, []);

  const addQuestion = () => {
    if (!newQuestion.trim()) return;

    const question: Question = {
      id: Date.now().toString(),
      text: newQuestion.trim(),
    };

    const updated = [...questions, question];
    setQuestions(updated);
    localStorage.setItem("doctorQuestions", JSON.stringify(updated));
    setNewQuestion("");
    
    toast({
      title: "Question Added",
      description: "Your question has been saved to the report.",
    });
  };

  const removeQuestion = (id: string) => {
    const updated = questions.filter((q) => q.id !== id);
    setQuestions(updated);
    localStorage.setItem("doctorQuestions", JSON.stringify(updated));
  };

  const saveNotes = () => {
    localStorage.setItem("doctorNotes", additionalNotes);
    toast({
      title: "Notes Saved",
      description: "Your notes have been saved.",
    });
  };

  // HTML escape function to prevent XSS attacks
  const escapeHtml = (text: string): string => {
    const htmlEntities: Record<string, string> = {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;',
    };
    return text.replace(/[&<>"']/g, (char) => htmlEntities[char] || char);
  };

  const generateReport = () => {
    const medications: Medication[] = JSON.parse(
      localStorage.getItem("medications") || "[]"
    );
    const activities: Activity[] = JSON.parse(
      localStorage.getItem("activities") || "[]"
    );

    const printWindow = window.open("", "_blank");
    if (!printWindow) return;

    const reportHTML = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Doctor Visit Report - ${new Date().toLocaleDateString()}</title>
          <style>
            body {
              font-family: Arial, sans-serif;
              padding: 40px;
              max-width: 800px;
              margin: 0 auto;
            }
            h1 {
              color: #333;
              border-bottom: 2px solid #666;
              padding-bottom: 10px;
            }
            h2 {
              color: #555;
              margin-top: 30px;
              border-bottom: 1px solid #999;
              padding-bottom: 5px;
            }
            .section {
              margin: 20px 0;
            }
            .item {
              margin: 10px 0;
              padding: 10px;
              background: #f5f5f5;
              border-radius: 5px;
            }
            .question {
              margin: 8px 0;
              padding: 8px;
              background: #fff3cd;
              border-left: 4px solid #ffc107;
            }
            .medication {
              display: grid;
              grid-template-columns: 2fr 1fr 1fr;
              gap: 10px;
            }
            .footer {
              margin-top: 40px;
              padding-top: 20px;
              border-top: 1px solid #999;
              font-size: 12px;
              color: #666;
            }
            @media print {
              body { padding: 20px; }
            }
          </style>
        </head>
        <body>
          <h1>Doctor Visit Report</h1>
          <p><strong>Date:</strong> ${new Date().toLocaleDateString()}</p>
          
          <div class="section">
            <h2>Questions for Doctor</h2>
            ${questions.length > 0 
              ? questions.map((q, i) => `<div class="question">${i + 1}. ${escapeHtml(q.text)}</div>`).join("")
              : "<p>No questions recorded.</p>"
            }
          </div>

          ${additionalNotes ? `
            <div class="section">
              <h2>Additional Notes</h2>
              <div class="item">${escapeHtml(additionalNotes).replace(/\n/g, "<br>")}</div>
            </div>
          ` : ""}

          <div class="section">
            <h2>Current Medications</h2>
            ${medications.length > 0
              ? medications.map(m => `
                <div class="item medication">
                  <div><strong>${escapeHtml(m.name)}</strong></div>
                  <div>${escapeHtml(m.dosage)}</div>
                  <div>${escapeHtml(m.frequency)}</div>
                </div>
              `).join("")
              : "<p>No medications tracked.</p>"
            }
          </div>

          <div class="section">
            <h2>Daily Activities</h2>
            ${activities.length > 0
              ? activities.map(a => `
                <div class="item">
                  <strong>${escapeHtml(a.name)}</strong> - ${escapeHtml(a.time)}
                </div>
              `).join("")
              : "<p>No activities tracked.</p>"
            }
          </div>

          <div class="footer">
            <p>Generated on ${new Date().toLocaleString()}</p>
            <p>This report was created to help facilitate discussion with your healthcare provider.</p>
          </div>
        </body>
      </html>
    `;

    printWindow.document.write(reportHTML);
    printWindow.document.close();
    printWindow.focus();
    
    setTimeout(() => {
      printWindow.print();
    }, 250);

    toast({
      title: "Report Generated",
      description: "Your doctor visit report is ready to print.",
    });
  };

  const buildTextReport = () => {
    const medications: Medication[] = JSON.parse(localStorage.getItem("medications") || "[]");
    const activities: Activity[] = JSON.parse(localStorage.getItem("activities") || "[]");
    const lines: string[] = [`Doctor Visit Report - ${new Date().toLocaleDateString()}`, ""];

    lines.push("Questions for Doctor:");
    lines.push(
      questions.length > 0
        ? questions.map((q, i) => `${i + 1}. ${q.text}`).join("\n")
        : "None recorded."
    );

    if (additionalNotes.trim()) {
      lines.push("", "Additional Notes:", additionalNotes.trim());
    }

    lines.push("", "Current Medications:");
    lines.push(
      medications.length > 0
        ? medications.map((m) => `- ${m.name} ${m.dosage} (${m.frequency})`).join("\n")
        : "None tracked."
    );

    lines.push("", "Daily Activities:");
    lines.push(
      activities.length > 0
        ? activities.map((a) => `- ${a.name} at ${a.time}`).join("\n")
        : "None tracked."
    );

    lines.push("", "Sent from Reli");
    return lines.join("\n");
  };

  const emailReport = () => {
    const subject = `Doctor Visit Report - ${new Date().toLocaleDateString()}`;
    window.location.href = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(buildTextReport())}`;
  };

  const textReport = () => {
    window.location.href = `sms:?&body=${encodeURIComponent(buildTextReport())}`;
  };

  return (
    <Card className="p-6 bg-card/90 backdrop-blur border-2">
      <h2 className="text-2xl font-semibold mb-4 flex items-center gap-2">
        <FileText className="w-6 h-6 text-primary" />
        Doctor Visit Report
      </h2>


      <div className="space-y-6">
        {/* Add Questions */}
        <div>
          <h3 className="text-xl font-medium mb-3">Questions for Your Doctor</h3>
          <div className="flex gap-2 mb-3">
            <Input
              value={newQuestion}
              onChange={(e) => setNewQuestion(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && addQuestion()}
              placeholder="What do you want to ask your doctor?"
              className="text-lg h-12"
            />
            <Button onClick={addQuestion} size="lg">
              <Plus className="w-5 h-5" />
            </Button>
          </div>

          <div className="space-y-2">
            {questions.map((question) => (
              <div
                key={question.id}
                className="flex items-start justify-between p-3 bg-secondary/20 rounded-lg"
              >
                <p className="flex-1 text-lg">{question.text}</p>
                <Button
                  onClick={() => removeQuestion(question.id)}
                  variant="ghost"
                  size="sm"
                >
                  <Trash2 className="w-4 h-4 text-destructive" />
                </Button>
              </div>
            ))}
            {questions.length === 0 && (
              <p className="text-muted-foreground text-center py-4">
                No questions added yet
              </p>
            )}
          </div>
        </div>

        {/* Additional Notes */}
        <div>
          <h3 className="text-xl font-medium mb-3">Additional Notes</h3>
          <Textarea
            value={additionalNotes}
            onChange={(e) => setAdditionalNotes(e.target.value)}
            placeholder="Any symptoms, concerns, or changes you want to discuss..."
            className="min-h-[120px] text-lg mb-2"
          />
          <Button onClick={saveNotes} variant="outline" size="lg">
            Save Notes
          </Button>
        </div>

        {/* Share Report */}
        <div className="grid gap-2 sm:grid-cols-3">
          <Button onClick={generateReport} size="lg" className="w-full">
            <Printer className="w-5 h-5 mr-2" />
            Print
          </Button>
          <Button onClick={emailReport} size="lg" variant="outline" className="w-full">
            <Mail className="w-5 h-5 mr-2" />
            Email
          </Button>
          <Button onClick={textReport} size="lg" variant="outline" className="w-full">
            <MessageSquare className="w-5 h-5 mr-2" />
            Text
          </Button>
        </div>

      </div>
    </Card>
  );
};

export default DoctorReport;
