import { useState, useEffect, useRef } from "react";
import { ShieldAlert, ShieldCheck, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";

interface Interaction {
  medications: string[];
  severity: "major" | "moderate" | "minor";
  description: string;
  advice: string;
  source?: string;
}

interface InteractionResult {
  summary: string;
  interactions: Interaction[];
  fda_sources?: string[];
  unmatched?: string[];
}

const severityVariant = { major: "destructive", moderate: "default", minor: "secondary" } as const;

export const MedicationInteractions = ({ seniorId, medCount }: { seniorId: string; medCount: number }) => {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<InteractionResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const run = async () => {
    setLoading(true); setError(null);
    const { data, error } = await supabase.functions.invoke("check-med-interactions", { body: { senior_id: seniorId } });
    setLoading(false);
    if (error || (data as any)?.error) {
      let msg = (data as any)?.error;
      try { msg = msg || (await (error as any)?.context?.json?.())?.error; } catch { /* ignore */ }
      setError(msg || "Check failed. Please try again.");
      return;
    }
    setResult(data as any);
  };

  const runRef = useRef(run);
  runRef.current = run;

  // Auto-check whenever a new medication is added (and there are at least 2)
  useEffect(() => {
    const onAdded = () => { runRef.current(); };
    window.addEventListener("reli:med-added", onAdded);
    return () => window.removeEventListener("reli:med-added", onAdded);
  }, [medCount, seniorId]);

  return (
    <div className="rounded-xl bg-dashboard-sky/55 p-4 space-y-3">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex min-w-0 items-center gap-3">
          <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
            <ShieldAlert className="h-6 w-6" />
          </span>
          <div className="min-w-0">
            <h3 className="text-base font-bold sm:text-lg">Medication interactions</h3>
            {medCount < 2 && <p className="text-xs text-muted-foreground sm:text-sm">Add one more medication to check</p>}
          </div>
        </div>
        <Button size="sm" variant="outline" className="border-primary bg-card text-primary" onClick={run} disabled={loading || medCount < 2}>
          {loading ? <><Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> Checking…</> : "Check now"}
        </Button>
      </div>
      {error && <p className="text-sm text-destructive">{error}</p>}
      {result && (
        <div className="space-y-3">
          {result.fda_sources && result.fda_sources.length > 0 && (
            <p className="text-xs text-muted-foreground">
              Cross-checked against official FDA drug labels for: {result.fda_sources.join(", ")}
            </p>
          )}
          <p className="text-sm flex items-start gap-2">
            {result.interactions.length === 0 && <ShieldCheck className="w-4 h-4 mt-0.5 text-primary flex-shrink-0" />}
            {result.summary}
          </p>
          {result.interactions.map((it, i) => (
            <div key={i} className="rounded-md border p-3 space-y-1">
              <div className="flex items-center gap-2 flex-wrap">
                <Badge variant={severityVariant[it.severity] ?? "secondary"} className="capitalize">{it.severity}</Badge>
                <span className="font-medium text-sm">{it.medications.join(" + ")}</span>
              </div>
              <p className="text-sm">{it.description}</p>
              <p className="text-sm text-muted-foreground"><span className="font-medium">What to do:</span> {it.advice}</p>
              {it.source && <p className="text-xs text-muted-foreground">Source: {it.source}</p>}
            </div>
          ))}
        </div>
      )}
      {medCount >= 2 && <p className="text-xs text-muted-foreground">
        Only interactions listed on official FDA drug labels are shown; AI rewrites them in plain language. Not medical advice. Always confirm with a doctor or pharmacist before changing any medication.
      </p>}
    </div>
  );
};
