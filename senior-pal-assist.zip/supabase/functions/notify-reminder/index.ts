import { createClient } from 'npm:@supabase/supabase-js@2'
import { sendTemplateEmail } from '../_shared/transactional-email-templates/send-email.ts'
import { resolveEmailRecipient, resolveSmsRecipient } from '../_shared/notify-recipient.ts'
import { sendSms, toE164 } from '../_shared/send-sms.ts'
import { sendPushToUser } from '../_shared/send-push.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  })

const clean = (v: unknown, max: number) =>
  typeof v === 'string' ? v.trim().slice(0, max) : ''

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })

  try {
    const authHeader = req.headers.get('Authorization') ?? ''
    const userClient = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_ANON_KEY')!,
      { global: { headers: { Authorization: authHeader } } }
    )
    const { data: userData } = await userClient.auth.getUser()
    const user = userData?.user
    if (!user) return json({ error: 'Unauthorized' }, 401)

    const body = await req.json().catch(() => ({}))
    const key = clean(body?.key, 100)
    const title = clean(body?.title, 120) || 'Your Reli reminder'
    const detail = clean(body?.detail, 300)
    const time = clean(body?.time, 20)
    if (!key) return json({ error: 'Invalid reminder key' }, 400)

    const admin = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    )

    let pushed = 0
    try {
      pushed = await sendPushToUser(admin, user.id, 'notify_reminders', {
        title,
        body: `${detail || 'Your Reli reminder'}${time ? ` (${time})` : ''}`,
        path: '/dashboard',
      })
    } catch (e) {
      console.error('reminder push failed', e)
    }

    let texted = false
    const smsTo = await resolveSmsRecipient(admin, user.id, 'notify_reminders')
    const phone = toE164(smsTo?.phone)
    if (phone) {
      try {
        const smsResult = await sendSms(
          phone,
          `Reli — ${title}${detail ? `: ${detail}` : ''}${time ? ` (${time})` : ''}`
        )
        texted = smsResult.sent
      } catch (e) {
        console.error('reminder text failed', e)
      }
    }

    const recipient = await resolveEmailRecipient(admin, user.id, 'notify_reminders')
    if (!recipient) return json({ sent: false, texted, pushed, reason: 'email_off' })

    const result = await sendTemplateEmail('reminder-alert', recipient.email, {
      templateData: {
        recipientName: recipient.name?.split(' ')[0] ?? undefined,
        title,
        detail: detail || undefined,
        time: time || undefined,
      },
      idempotencyKey: `reminder-${user.id}-${key}-${new Date().toISOString().slice(0, 10)}`,
    })

    return json({ ...result, texted, pushed })
  } catch (error) {
    console.error('notify-reminder error', error)
    return json({ error: 'Failed to send reminder' }, 500)
  }
})
