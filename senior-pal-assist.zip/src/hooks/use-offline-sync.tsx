import { useCallback, useEffect, useState } from "react";
import {
  QueueItem,
  flushQueue,
  getQueue,
  isOnline,
  subscribeToQueue,
} from "@/lib/offlineQueue";
import { useToast } from "@/hooks/use-toast";

/** Tracks whether the device currently has a connection. */
export const useOnlineStatus = () => {
  const [online, setOnline] = useState(isOnline());

  useEffect(() => {
    const goOnline = () => setOnline(true);
    const goOffline = () => setOnline(false);
    window.addEventListener("online", goOnline);
    window.addEventListener("offline", goOffline);
    return () => {
      window.removeEventListener("online", goOnline);
      window.removeEventListener("offline", goOffline);
    };
  }, []);

  return online;
};

/** Live view of everything saved on this device but not sent yet. */
export const usePendingQueue = (table?: string) => {
  const [items, setItems] = useState<QueueItem[]>(() =>
    table ? getQueue().filter((i) => i.table === table) : getQueue()
  );

  useEffect(() => {
    const read = () =>
      setItems(table ? getQueue().filter((i) => i.table === table) : getQueue());
    read();
    return subscribeToQueue(read);
  }, [table]);

  return items;
};

/**
 * Sends saved-on-device entries as soon as the connection returns.
 * Mount once, high up in the app.
 */
export const useOfflineSync = () => {
  const online = useOnlineStatus();
  const pending = usePendingQueue();
  const [syncing, setSyncing] = useState(false);
  const { toast } = useToast();

  const sync = useCallback(async () => {
    if (!isOnline() || getQueue().length === 0) return;
    setSyncing(true);
    const result = await flushQueue();
    setSyncing(false);

    if (result.synced > 0) {
      toast({
        title: "Back online",
        description: `${result.synced} saved ${
          result.synced === 1 ? "entry" : "entries"
        } uploaded.`,
      });
    }
    if (result.failed > 0) {
      toast({
        title: "Some entries could not be uploaded",
        description: `${result.failed} ${
          result.failed === 1 ? "entry" : "entries"
        } had to be skipped. Please re-enter them.`,
        variant: "destructive",
      });
    }
  }, [toast]);

  useEffect(() => {
    if (online) sync();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [online, pending.length]);

  useEffect(() => {
    const id = window.setInterval(() => {
      if (isOnline() && getQueue().length > 0) sync();
    }, 30000);
    return () => window.clearInterval(id);
  }, [sync]);

  return { online, pendingCount: pending.length, syncing, sync };
};
