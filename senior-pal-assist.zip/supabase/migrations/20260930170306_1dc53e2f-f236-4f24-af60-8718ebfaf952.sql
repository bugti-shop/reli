CREATE OR REPLACE FUNCTION public.cancel_circle_invite(_invite_id uuid)
RETURNS void
LANGUAGE sql
SECURITY INVOKER
SET search_path = public
AS $$
  DELETE FROM public.circle_invites
  WHERE id = _invite_id
    AND approved_at IS NULL
    AND used_at IS NULL;
$$;

REVOKE EXECUTE ON FUNCTION public.cancel_circle_invite(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.cancel_circle_invite(uuid) TO authenticated;