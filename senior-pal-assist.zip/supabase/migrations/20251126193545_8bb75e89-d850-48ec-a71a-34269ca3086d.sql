-- Fix critical RLS policy issues on profiles table

-- 1. Drop the overly permissive policy that exposes all senior profiles
DROP POLICY IF EXISTS "Anyone can view basic senior profiles" ON public.profiles;

-- 2. Drop existing RESTRICTIVE SELECT policies to recreate as PERMISSIVE
DROP POLICY IF EXISTS "Users can view their own profile" ON public.profiles;
DROP POLICY IF EXISTS "Seniors can view their caregivers profiles" ON public.profiles;

-- 3. Create PERMISSIVE policies (OR logic) for proper access control

-- Users can view their own profile
CREATE POLICY "Users can view their own profile" 
ON public.profiles 
FOR SELECT 
TO authenticated
USING (auth.uid() = id);

-- Seniors can view their assigned caregivers' profiles
CREATE POLICY "Seniors can view their caregivers profiles" 
ON public.profiles 
FOR SELECT 
TO authenticated
USING (
  EXISTS (
    SELECT 1
    FROM caregiver_seniors
    WHERE caregiver_seniors.caregiver_id = profiles.id
      AND caregiver_seniors.senior_id = auth.uid()
  )
);

-- Caregivers can view their assigned seniors' profiles
CREATE POLICY "Caregivers can view their seniors profiles" 
ON public.profiles 
FOR SELECT 
TO authenticated
USING (
  EXISTS (
    SELECT 1
    FROM caregiver_seniors
    WHERE caregiver_seniors.senior_id = profiles.id
      AND caregiver_seniors.caregiver_id = auth.uid()
  )
);