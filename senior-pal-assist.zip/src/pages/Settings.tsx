import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Loader2, LogOut } from "lucide-react";
import { logoutAndRedirect } from "@/lib/logout";
import { supabase } from "@/integrations/supabase/client";
import { NotificationSettings } from "@/components/NotificationSettings";
import { PlanSettings } from "@/components/PlanSettings";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { readTimeOverride, setTimeOverride } from "@/components/SeniorLandscapeBackground";
import Header from "@/components/Header";
import { AccountDeletion } from "@/components/AccountDeletion";

const minutesToTimeValue = (minutes: number) =>
  `${String(Math.floor(minutes / 60)).padStart(2, "0")}:${String(Math.floor(minutes % 60)).padStart(2, "0")}`;

const TimeSettings = () => {
  const [value, setValue] = useState(() => {
    const override = readTimeOverride();
    return override === null ? "" : minutesToTimeValue(override);
  });

  const apply = (time: string) => {
    setValue(time);
    if (!time) {
      setTimeOverride(null);
      return;
    }
    const [hours, mins] = time.split(":").map(Number);
    setTimeOverride(hours * 60 + mins);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Time setting</CardTitle>
        <CardDescription>
          Set a time to preview how the blue card's background changes through the day. It updates the
          dashboard background in real time — no reload needed.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="sky-time">Preview time</Label>
          <Input
            id="sky-time"
            type="time"
            value={value}
            onChange={(event) => apply(event.target.value)}
            className="max-w-[200px]"
          />
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline" onClick={() => apply("")} disabled={!value}>
            Use real time
          </Button>
          {value && (
            <p className="text-sm text-muted-foreground">
              Previewing {value} — open the dashboard to see the matching background.
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

const Settings = () => {
  const navigate = useNavigate();
  const [userId, setUserId] = useState<string | null>(null);
  const [userEmail, setUserEmail] = useState("");
  const [role, setRole] = useState<"senior" | "caregiver">("senior");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        navigate("/auth");
        return;
      }
      setUserId(user.id);
      setUserEmail(user.email ?? "");
      const { data: profile } = await supabase
        .from("profiles")
        .select("role")
        .eq("id", user.id)
        .maybeSingle();
      if (profile?.role === "caregiver") setRole("caregiver");
      setLoading(false);
    };
    load();
  }, [navigate]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-8 max-w-2xl">
        <Button
          variant="ghost"
          className="mb-6 -ml-2"
          onClick={() => navigate(role === "caregiver" ? "/caregiver" : "/dashboard")}
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to dashboard
        </Button>

        <h1 className="text-3xl font-bold mb-2">Settings</h1>
        <p className="text-muted-foreground mb-6">
          Manage your plan, alerts and notification preferences.
        </p>

        {userId && (
          <div className="mb-8">
            <AccountDeletion defaultEmail={userEmail} onAccountDeleted={() => navigate("/")} />
          </div>
        )}

        {userId && (
          <Tabs defaultValue="notifications" className="space-y-6">
            <TabsList className="w-full grid grid-cols-3">
              <TabsTrigger value="notifications">Alerts</TabsTrigger>
              <TabsTrigger value="plan">Manage plan</TabsTrigger>
              <TabsTrigger value="time">Time</TabsTrigger>
            </TabsList>
            <TabsContent value="notifications">
              <NotificationSettings userId={userId} role={role} />
            </TabsContent>
            <TabsContent value="plan">
              <PlanSettings userId={userId} />
            </TabsContent>
            <TabsContent value="time">
              <TimeSettings />
            </TabsContent>
          </Tabs>
        )}
        <Button
          variant="outline"
          className="mt-8 w-full min-h-12 text-destructive hover:text-destructive"
          onClick={() => void logoutAndRedirect()}
        >
          <LogOut className="w-5 h-5 mr-2" />
          Log out
        </Button>
      </main>
    </div>
  );
};

export default Settings;
