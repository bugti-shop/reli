import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { ClipboardList, Save, Smile, Frown, Meh, AlertTriangle, Check, CloudOff } from "lucide-react";
import { format } from "date-fns";
import { enqueue, isOnline } from "@/lib/offlineQueue";
import { usePendingQueue } from "@/hooks/use-offline-sync";

interface CaregiverDailyLogProps {
  caregiverId: string;
  seniorId: string;
  seniorName: string;
}

interface DailyLog {
  id?: string;
  mood: string | null;
  had_fall: boolean;
  confusion_noted: boolean;
  ate_well: boolean;
  slept_well: boolean;
  took_medications: boolean;
  notes: string | null;
}

const moodOptions = [
  { value: "happy", label: "Happy", icon: Smile, color: "text-green-500" },
  { value: "neutral", label: "Neutral", icon: Meh, color: "text-yellow-500" },
  { value: "sad", label: "Sad", icon: Frown, color: "text-blue-500" },
  { value: "anxious", label: "Anxious", icon: AlertTriangle, color: "text-orange-500" },
];

export const CaregiverDailyLog = ({ caregiverId, seniorId, seniorName }: CaregiverDailyLogProps) => {
  const [log, setLog] = useState<DailyLog>({
    mood: null,
    had_fall: false,
    confusion_noted: false,
    ate_well: true,
    slept_well: true,
    took_medications: true,
    notes: null,
  });
  const [isLoading, setIsLoading] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const { toast } = useToast();
  const pendingAll = usePendingQueue("caregiver_daily_logs");
  const pending = pendingAll.filter(
    (p) => (p.payload as { senior_id?: string })?.senior_id === seniorId
  );

  useEffect(() => {
    fetchTodaysLog();
  }, [seniorId, caregiverId]);

  const fetchTodaysLog = async () => {
    const today = format(new Date(), "yyyy-MM-dd");
    
    const { data, error } = await supabase
      .from("caregiver_daily_logs")
      .select("*")
      .eq("caregiver_id", caregiverId)
      .eq("senior_id", seniorId)
      .eq("log_date", today)
      .maybeSingle();

    if (error) {
      console.error("Error fetching daily log:", error);
      return;
    }

    if (data) {
      setLog({
        id: data.id,
        mood: data.mood,
        had_fall: data.had_fall,
        confusion_noted: data.confusion_noted,
        ate_well: data.ate_well,
        slept_well: data.slept_well,
        took_medications: data.took_medications,
        notes: data.notes,
      });
      setIsSaved(true);
    }
  };

  const handleSave = async () => {
    setIsLoading(true);
    const today = format(new Date(), "yyyy-MM-dd");

    const logData = {
      caregiver_id: caregiverId,
      senior_id: seniorId,
      log_date: today,
      mood: log.mood,
      had_fall: log.had_fall,
      confusion_noted: log.confusion_noted,
      ate_well: log.ate_well,
      slept_well: log.slept_well,
      took_medications: log.took_medications,
      notes: log.notes,
    };

    if (!isOnline()) {
      enqueue({
        table: "caregiver_daily_logs",
        op: "upsert",
        payload: logData,
        onConflict: "caregiver_id,senior_id,log_date",
        label: `Daily log for ${seniorName}`,
      });
      setIsLoading(false);
      setIsSaved(true);
      toast({
        title: "Saved on this device",
        description: "No internet right now — this log will upload automatically later.",
      });
      return;
    }

    let error;
    
    
    if (log.id) {
      // Update existing log
      const result = await supabase
        .from("caregiver_daily_logs")
        .update(logData)
        .eq("id", log.id);
      error = result.error;
    } else {
      // Insert new log
      const result = await supabase
        .from("caregiver_daily_logs")
        .insert(logData)
        .select()
        .single();
      error = result.error;
      if (result.data) {
        setLog(prev => ({ ...prev, id: result.data.id }));
      }
    }

    setIsLoading(false);

    if (error) {
      toast({
        title: "Error",
        description: "Failed to save daily log. Please try again.",
        variant: "destructive",
      });
      return;
    }

    setIsSaved(true);
    toast({
      title: "Saved",
      description: "Daily log has been saved successfully.",
    });
  };

  const updateLog = (field: keyof DailyLog, value: any) => {
    setLog(prev => ({ ...prev, [field]: value }));
    setIsSaved(false);
  };

  return (
    <Card className="p-6 bg-gradient-to-r from-purple-50/50 to-purple-100/50 dark:from-purple-950/20 dark:to-purple-900/20 border-2">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-semibold flex items-center gap-2">
          <ClipboardList className="w-6 h-6 text-primary" />
          Daily Log - {seniorName}
        </h2>
        <span className="text-sm text-muted-foreground">
          {format(new Date(), "MMMM d, yyyy")}
        </span>
      </div>

      {pending.length > 0 && (
        <div className="mb-4 p-3 rounded-lg border-2 border-dashed bg-muted/30 flex items-center gap-3">
          <CloudOff className="w-5 h-5 text-amber-600 dark:text-amber-400" />
          <p className="text-base">
            {pending.length === 1 ? "A log is" : `${pending.length} logs are`} saved on this
            device and will upload when you're back online.
          </p>
        </div>
      )}

      <div className="space-y-6">
        {/* Mood Selection */}
        <div className="space-y-2">
          <Label className="text-lg">How was their mood today?</Label>
          <Select value={log.mood || ""} onValueChange={(value) => updateLog("mood", value)}>
            <SelectTrigger className="h-12 text-lg">
              <SelectValue placeholder="Select mood..." />
            </SelectTrigger>
            <SelectContent>
              {moodOptions.map((option) => {
                const Icon = option.icon;
                return (
                  <SelectItem key={option.value} value={option.value} className="text-lg py-3">
                    <div className="flex items-center gap-2">
                      <Icon className={`w-5 h-5 ${option.color}`} />
                      {option.label}
                    </div>
                  </SelectItem>
                );
              })}
            </SelectContent>
          </Select>
        </div>

        {/* Yes/No Questions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="flex items-center justify-between p-4 bg-background/50 rounded-lg border">
            <Label className="text-lg cursor-pointer" htmlFor="had_fall">
              Did they have a fall?
            </Label>
            <div className="flex items-center gap-2">
              <span className={`text-sm ${!log.had_fall ? "text-green-600 font-medium" : "text-muted-foreground"}`}>No</span>
              <Switch
                id="had_fall"
                checked={log.had_fall}
                onCheckedChange={(checked) => updateLog("had_fall", checked)}
              />
              <span className={`text-sm ${log.had_fall ? "text-red-600 font-medium" : "text-muted-foreground"}`}>Yes</span>
            </div>
          </div>

          <div className="flex items-center justify-between p-4 bg-background/50 rounded-lg border">
            <Label className="text-lg cursor-pointer" htmlFor="confusion_noted">
              Any confusion noted?
            </Label>
            <div className="flex items-center gap-2">
              <span className={`text-sm ${!log.confusion_noted ? "text-green-600 font-medium" : "text-muted-foreground"}`}>No</span>
              <Switch
                id="confusion_noted"
                checked={log.confusion_noted}
                onCheckedChange={(checked) => updateLog("confusion_noted", checked)}
              />
              <span className={`text-sm ${log.confusion_noted ? "text-red-600 font-medium" : "text-muted-foreground"}`}>Yes</span>
            </div>
          </div>

          <div className="flex items-center justify-between p-4 bg-background/50 rounded-lg border">
            <Label className="text-lg cursor-pointer" htmlFor="ate_well">
              Did they eat well?
            </Label>
            <div className="flex items-center gap-2">
              <span className={`text-sm ${!log.ate_well ? "text-red-600 font-medium" : "text-muted-foreground"}`}>No</span>
              <Switch
                id="ate_well"
                checked={log.ate_well}
                onCheckedChange={(checked) => updateLog("ate_well", checked)}
              />
              <span className={`text-sm ${log.ate_well ? "text-green-600 font-medium" : "text-muted-foreground"}`}>Yes</span>
            </div>
          </div>

          <div className="flex items-center justify-between p-4 bg-background/50 rounded-lg border">
            <Label className="text-lg cursor-pointer" htmlFor="slept_well">
              Did they sleep well?
            </Label>
            <div className="flex items-center gap-2">
              <span className={`text-sm ${!log.slept_well ? "text-red-600 font-medium" : "text-muted-foreground"}`}>No</span>
              <Switch
                id="slept_well"
                checked={log.slept_well}
                onCheckedChange={(checked) => updateLog("slept_well", checked)}
              />
              <span className={`text-sm ${log.slept_well ? "text-green-600 font-medium" : "text-muted-foreground"}`}>Yes</span>
            </div>
          </div>

          <div className="flex items-center justify-between p-4 bg-background/50 rounded-lg border md:col-span-2">
            <Label className="text-lg cursor-pointer" htmlFor="took_medications">
              Did they take their medications?
            </Label>
            <div className="flex items-center gap-2">
              <span className={`text-sm ${!log.took_medications ? "text-red-600 font-medium" : "text-muted-foreground"}`}>No</span>
              <Switch
                id="took_medications"
                checked={log.took_medications}
                onCheckedChange={(checked) => updateLog("took_medications", checked)}
              />
              <span className={`text-sm ${log.took_medications ? "text-green-600 font-medium" : "text-muted-foreground"}`}>Yes</span>
            </div>
          </div>
        </div>

        {/* Notes */}
        <div className="space-y-2">
          <Label className="text-lg" htmlFor="notes">Additional Notes</Label>
          <Textarea
            id="notes"
            value={log.notes || ""}
            onChange={(e) => updateLog("notes", e.target.value)}
            placeholder="Any other observations, concerns, or notes about today..."
            className="min-h-[100px] text-lg"
          />
        </div>

        {/* Save Button */}
        <Button 
          onClick={handleSave} 
          size="lg" 
          className="w-full"
          disabled={isLoading}
        >
          {isLoading ? (
            "Saving..."
          ) : isSaved ? (
            <>
              <Check className="w-5 h-5 mr-2" />
              Saved
            </>
          ) : (
            <>
              <Save className="w-5 h-5 mr-2" />
              Save Daily Log
            </>
          )}
        </Button>
      </div>
    </Card>
  );
};
