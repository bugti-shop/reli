import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors'
import { createClient } from 'npm:@supabase/supabase-js@2'
import { z } from 'npm:zod@3'

const Body = z.object({ senior_id: z.string().uuid() })
const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), { status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })

// Look up the official FDA "Drug Interactions" section for a medication name
// via openFDA. Returns null when no matching label carries interaction text
// (common for OTC products and supplements).
async function fdaLabelExcerpt(rawName: string): Promise<{ product: string; excerpt: string } | null> {
  const term = rawName.toLowerCase().replace(/[^a-z0-9 -]/g, ' ').replace(/\s+/g, ' ').trim()
  if (!term) return null
  // Try the full name first, then just the first word (strips stray dosage text).
  const queries = Array.from(new Set([term, term.split(' ')[0]]))
  for (const q of queries) {
    try {
      const search = `(active_ingredient:"${q}" OR openfda.substance_name:"${q}" OR openfda.brand_name:"${q}")`
      const res = await fetch(`https://api.fda.gov/drug/label.json?search=${encodeURIComponent(search)}&limit=10`)
      if (!res.ok) continue // 404 = no match, 429 = rate limited: fall through quietly
      const data = await res.json()
      const docs: any[] = data.results ?? []
      const scored = docs
        .map((r) => {
          const di = Array.isArray(r.drug_interactions) ? r.drug_interactions.join(' ') : r.drug_interactions
          const text = typeof di === 'string' ? di.trim() : ''
          if (text.length < 120) return null
          const labelNames: string[] = []
            .concat(r.openfda?.generic_name ?? [], r.openfda?.brand_name ?? [], r.openfda?.substance_name ?? [])
            .map((n: string) => String(n).toLowerCase())
          const nameMatch = labelNames.some((n) => n.includes(q)) ? 1 : 0
          return { product: (r.openfda?.generic_name ?? r.openfda?.brand_name ?? ['Unknown'])[0] as string, text, nameMatch }
        })
        .filter(Boolean) as { product: string; text: string; nameMatch: number }[]
      if (!scored.length) continue
      scored.sort((a, b) => b.nameMatch - a.nameMatch || b.text.length - a.text.length)
      return { product: scored[0].product, excerpt: scored[0].text.slice(0, 2200) }
    } catch {
      continue // network hiccup: skip grounding for this medication
    }
  }
  return null
}


// Normalize a freehand name ("Advil", "ibuprofen 81mg", "Tylenol Extra Strength") to its
// active ingredient(s) via NIH RxNorm, so brand/generic/dosage variants resolve to the same drug.
const RX = 'https://rxnav.nlm.nih.gov/REST'
const stripDose = (n: string) => n.toLowerCase()
  .replace(/\([^)]*\)/g, ' ')
  .replace(/\d+(\.\d+)?\s*(mg|mcg|µg|g|iu|ml|units?|%)\b/g, ' ')
  .replace(/\b(tablets?|tabs?|capsules?|caps?|extra strength|er|xr|sr|dr|daily|once|twice)\b/g, ' ')
  .replace(/[^a-z -]/g, ' ').replace(/\s+/g, ' ').trim()
async function ingredientsFor(rxcui: string): Promise<string[]> {
  const r = await (await fetch(`${RX}/rxcui/${rxcui}/related.json?tty=IN+MIN`)).json()
  const names = (r?.relatedGroup?.conceptGroup ?? []).filter((g: any) => g.tty === 'IN')
    .flatMap((g: any) => (g.conceptProperties ?? []).map((p: any) => String(p.name).toLowerCase()))
  if (names.length) return names
  const p = await (await fetch(`${RX}/rxcui/${rxcui}/properties.json`)).json()
  return p?.properties?.tty === 'IN' ? [String(p.properties.name).toLowerCase()] : []
}
async function ingredientNames(rawName: string): Promise<string[]> {
  const cleaned = stripDose(rawName)
  const tries = Array.from(new Set([cleaned, cleaned.split(' ')[0]])).filter(Boolean)
  for (const t of tries) {
    try {
      const a = await (await fetch(`${RX}/approximateTerm.json?term=${encodeURIComponent(t)}&maxEntries=3`)).json()
      const ids: string[] = Array.from(new Set((a?.approximateGroup?.candidate ?? []).map((c: any) => c.rxcui)))
      for (const id of ids) {
        const ins = await ingredientsFor(id)
        if (ins.length) return ins
      }
    } catch { /* try next */ }
  }
  return cleaned ? [cleaned.split(' ')[0]] : []
}

function snippetAround(text: string, term: string): string | null {
  const i = text.toLowerCase().indexOf(term)
  if (i < 0 || term.length < 4) return null
  return text.slice(Math.max(0, i - 350), i + 450).trim()
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  try {
    const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, {
      global: { headers: { Authorization: req.headers.get('Authorization') ?? '' } },
    })
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return json({ error: 'Please sign in.' }, 401)

    const parsed = Body.safeParse(await req.json())
    if (!parsed.success) return json({ error: 'Invalid request.' }, 400)

    // RLS ensures only the senior or linked caregivers can read these.
    const { data: meds, error } = await supabase
      .from('medications').select('name, dosage').eq('senior_id', parsed.data.senior_id)
    if (error) return json({ error: 'Could not load medications.' }, 400)
    const list = (meds ?? []).map((m) => `${m.name}${m.dosage ? ` (${m.dosage})` : ''}`.slice(0, 120))
    if (list.length < 2) return json({ interactions: [], summary: 'Add at least two medications to check for interactions.' })

    const capped = list.slice(0, 12)
    const ingredientLists = await Promise.all(capped.map((n) => ingredientNames(n)))
    const ingredients = ingredientLists.map((l) => l[0] ?? '')
    const fdaResults = await Promise.all(ingredients.map((ing, i) => fdaLabelExcerpt(ing || capped[i])))
    const fdaSections = capped
      .map((name, i) => (fdaResults[i] ? { name, ...fdaResults[i]! } : null))
      .filter(Boolean) as { name: string; product: string; excerpt: string }[]

    // Evidence: a pair counts only when one drug's official FDA label names the other.
    const evidence: { meds: [string, string]; label: string; quote: string }[] = []
    for (let i = 0; i < capped.length; i++) {
      const lab = fdaResults[i]
      if (!lab) continue
      for (let j = 0; j < capped.length; j++) {
        if (i === j) continue
        const quote = ingredientLists[j].map((ing) => snippetAround(lab.excerpt, ing)).find(Boolean) ?? null
        if (ingredientLists[i].some((x) => ingredientLists[j].includes(x))) continue
        const key = [capped[i], capped[j]].sort().join('|')
        if (quote && !evidence.some((e) => [...e.meds].sort().join('|') === key)) {
          evidence.push({ meds: [capped[i], capped[j]], label: capped[i], quote })
        }
      }
    }
    // Same active ingredient listed twice (e.g. "Advil" and "ibuprofen 81mg") = duplicate therapy.
    const duplicates: { medications: string[]; severity: string; description: string; advice: string; source: string }[] = []
    for (let i = 0; i < capped.length; i++) for (let j = i + 1; j < capped.length; j++) {
      const shared = ingredientLists[i].filter((x) => ingredientLists[j].includes(x))
      if (shared.length) duplicates.push({
        medications: [capped[i], capped[j]], severity: 'moderate',
        description: `Both contain the same active ingredient (${shared.join(', ')}), so taking both could mean a double dose.`,
        advice: 'Ask their doctor or pharmacist whether both are meant to be taken.',
        source: 'NIH RxNorm ingredient match',
      })
    }
    const unmatched = capped.filter((_, i) => !fdaResults[i])
    const base = { fda_sources: fdaSections.map((s) => s.name), unmatched, source: 'FDA drug labels (openFDA)' }
    if (!evidence.length) {
      return json({
        ...base,
        interactions: duplicates,
        summary: `${duplicates.length ? 'Some medications share the same active ingredient. ' : ''}No interactions between these medications are listed on their official FDA labels.${unmatched.length ? ` We couldn't find an FDA label for: ${unmatched.join(', ')} — ask a pharmacist about ${unmatched.length > 1 ? 'these' : 'this one'}.` : ''}`,
      })
    }
    const fdaBlock = evidence
      .map((e, k) => `#${k + 1} ${e.meds[0]} + ${e.meds[1]} — from the FDA label of ${e.label}:\n"${e.quote}"`)
      .join('\n\n')

    const res = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: { Authorization: `Bearer ${Deno.env.get('LOVABLE_API_KEY')}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          { role: 'system', content: 'You are a careful clinical pharmacist assistant. You will receive interaction pairs that were found in official FDA drug labels, each with a quote. Rewrite ONLY those pairs in plain language for a family caregiver; do not add any pair that is not listed, and drop a pair if the quote does not actually describe an interaction between them. Use plain, calm language. Do not assume or state any relationship between the user and the person taking the medications — say "their medications", never "your father/mother/family member".\n\nBase severity and description strictly on the quote. Never invent interactions or details not in the quote. Never tell users to stop a medication — advise talking to their doctor or pharmacist.' },
          { role: 'user', content: `FDA-listed pairs:\n\n${fdaBlock}` },
        ],
        tools: [{
          type: 'function',
          function: {
            name: 'report_interactions',
            parameters: {
              type: 'object',
              properties: {
                summary: { type: 'string', description: 'One or two sentence overview. Mention that findings were cross-checked against official FDA drug labels where sections were provided.' },
                interactions: {
                  type: 'array',
                  items: {
                    type: 'object',
                    properties: {
                      medications: { type: 'array', items: { type: 'string' }, description: 'The two medication names copied exactly as written in the pair heading.' },
                      severity: { type: 'string', enum: ['major', 'moderate', 'minor'] },
                      description: { type: 'string' },
                      advice: { type: 'string' },
                    },
                    required: ['medications', 'severity', 'description', 'advice'],
                  },
                },
              },
              required: ['summary', 'interactions'],
            },
          },
        }],
        tool_choice: { type: 'function', function: { name: 'report_interactions' } },
      }),
    })
    if (res.status === 429) return json({ error: 'Too many checks right now — please try again in a minute.' }, 429)
    if (res.status === 402) return json({ error: 'The interaction checker is temporarily unavailable.' }, 402)
    if (!res.ok) { console.error('AI error', res.status, await res.text()); return json({ error: 'Check failed. Please try again.' }, 500) }
    const data = await res.json()
    const args = data.choices?.[0]?.message?.tool_calls?.[0]?.function?.arguments
    const result = args ? JSON.parse(args) : { summary: '', interactions: [] }
    const allowed = new Set(evidence.map((e) => [...e.meds].sort().join('|')))
    const interactions = (result.interactions ?? [])
      .filter((x: any) => Array.isArray(x.medications) && x.medications.length === 2 && allowed.has([...x.medications].sort().join('|')))
      .map((x: any) => ({ ...x, source: `FDA label: ${evidence.find((e) => [...e.meds].sort().join('|') === [...x.medications].sort().join('|'))!.label}` }))
    return json({ ...base, summary: result.summary || 'Interactions found on official FDA labels.', interactions: [...duplicates, ...interactions] })
  } catch (e) {
    console.error(e)
    return json({ error: 'Check failed. Please try again.' }, 500)
  }
})
