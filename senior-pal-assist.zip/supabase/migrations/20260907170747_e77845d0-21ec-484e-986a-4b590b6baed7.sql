REVOKE EXECUTE ON FUNCTION public.handle_updated_at() FROM authenticated, anon;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM authenticated, anon;
REVOKE EXECUTE ON FUNCTION public.validate_tracker_reminder() FROM authenticated, anon;