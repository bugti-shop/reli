# Selected Caregiver Home UI

## Goal
Implement only the uploaded lower-dashboard design on the Caregiver Home screen. Keep the existing blue scenic summary card unchanged.

## Changes
- Restyle the senior selector as two clean pill controls matching the reference.
- Replace the expanded Add Senior form on Home with a compact “Add Senior” row and plus button; tapping it opens the existing fully functional add options.
- Present caregiver access as a compact “Caregiving Network” summary with Accepted, Requested, and Invited counts, while keeping management actions accessible.
- Consolidate messages and reminders into the compact two-column section shown in the reference, linking to the existing inbox and reminder form.
- Reformat today’s activity as a timeline beside working quick actions for Daily Vitals Log, Log Activity, and Call Doctor.
- Preserve the existing five-item bottom navigation and all caregiver-only destinations/features.
- Verify the mobile layout, interactions, and current build state.

## Technical details
- Reuse existing database queries, dialogs, and feature components; this is a presentation-only Home screen change.
- Do not edit `SeniorLandscapeBackground`, `DashboardHealthSummary`, or the scenic card markup/styles.
- Keep detailed network, inbox, and message-management interfaces available through dialogs opened from the compact summaries.
