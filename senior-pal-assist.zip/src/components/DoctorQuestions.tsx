import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  HelpCircle,
  Plus,
  X,
  CheckCircle2,
  Circle,
  Printer,
  Mail,
  MessageSquare,
  Loader2,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface DoctorQuestion {
  id: string;
  question: string;
  asked: boolean;
  created_by_role: string;
  owner_id: string;
  created_at: string;
}

interface DoctorQuestionsProps {
  userId: string;
  userRole: "senior" | "caregiver";
  seniorId: string;
  seniorName?: string;
}

export const DoctorQuestions = ({ userId, userRole, seniorId, seniorName }: DoctorQuestionsProps) => {
  const [questions, setQuestions] = useState<DoctorQuestion[]>([]);
  const [newQuestion, setNewQuestion] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [emailOpen, setEmailOpen] = useState(false);
  const [email, setEmail] = useState("");
  const [sending, setSending] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchQuestions();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [seniorId]);

  const fetchQuestions = async () => {
    setIsLoading(true);
    const { data, error } = await supabase
      .from("doctor_questions")
      .select("*")
      .eq("senior_id", seniorId)
      .order("created_at", { ascending: true });

    if (error) {
      console.error("Error fetching doctor questions:", error);
    } else {
      setQuestions(data || []);
    }
    setIsLoading(false);
  };

  const addQuestion = async () => {
    const text = newQuestion.trim();
    if (!text) return;
    if (text.length > 500) {
      toast({ title: "Too long", description: "Keep questions under 500 characters.", variant: "destructive" });
      return;
    }

    const { error } = await supabase.from("doctor_questions").insert({
      senior_id: seniorId,
      owner_id: userId,
      created_by_role: userRole,
      question: text,
    });

    if (error) {
      toast({ title: "Could not add question", description: error.message, variant: "destructive" });
      return;
    }
    setNewQuestion("");
    fetchQuestions();
  };

  const toggleAsked = async (q: DoctorQuestion) => {
    const { error } = await supabase
      .from("doctor_questions")
      .update({ asked: !q.asked, asked_at: !q.asked ? new Date().toISOString() : null })
      .eq("id", q.id);
    if (error) {
      toast({ title: "Could not update", description: error.message, variant: "destructive" });
      return;
    }
    setQuestions((prev) => prev.map((item) => (item.id === q.id ? { ...item, asked: !q.asked } : item)));
  };

  const removeQuestion = async (id: string) => {
    const { error } = await supabase.from("doctor_questions").delete().eq("id", id);
    if (error) {
      toast({ title: "Could not remove", description: error.message, variant: "destructive" });
      return;
    }
    setQuestions((prev) => prev.filter((q) => q.id !== id));
  };

  const openQuestions = questions.filter((q) => !q.asked);
  const listTitle = seniorName ? `Questions for ${seniorName}'s doctor` : "Questions for the doctor";

  const handlePrint = () => {
    if (questions.length === 0) return;
    const win = window.open("", "_blank", "width=800,height=900");
    if (!win) {
      toast({ title: "Pop-up blocked", description: "Allow pop-ups to print your list.", variant: "destructive" });
      return;
    }
    const rows = questions
      .map(
        (q) =>
          `<li style="margin-bottom:14px;${q.asked ? "color:#6b7280;text-decoration:line-through;" : ""}">${q.question.replace(
            /[<>&]/g,
            (c) => ({ "<": "&lt;", ">": "&gt;", "&": "&amp;" }[c] as string)
          )}</li>`
      )
      .join("");
    win.document.write(`<!DOCTYPE html><html><head><title>${listTitle}</title></head>
      <body style="font-family:Arial,Helvetica,sans-serif;padding:40px;color:#111827">
        <h1 style="font-size:24px;margin-bottom:4px">${listTitle}</h1>
        <p style="color:#6b7280;margin-top:0">${new Date().toLocaleDateString()}</p>
        <ol style="font-size:18px;line-height:1.6">${rows}</ol>
        <p style="color:#9ca3af;font-size:12px;margin-top:40px">Printed from Reli</p>
      </body></html>`);
    win.document.close();
    win.focus();
    win.print();
  };

  const handleText = () => {
    if (questions.length === 0) return;
    const body = `${listTitle}\n\n${questions.map((q, i) => `${i + 1}. ${q.question}`).join("\n")}`;
    window.location.href = `sms:?&body=${encodeURIComponent(body)}`;
  };

  const handleEmail = async () => {
    if (!email.trim()) return;
    setSending(true);
    const { error } = await supabase.functions.invoke("send-doctor-questions", {
      body: {
        to: email.trim(),
        personName: seniorName,
        questions: questions.map((q) => q.question),
      },
    });
    setSending(false);
    if (error) {
      toast({ title: "Could not send email", description: error.message, variant: "destructive" });
      return;
    }
    toast({ title: "Email sent", description: `Your list was sent to ${email.trim()}.` });
    setEmailOpen(false);
    setEmail("");
  };

  return (
    <Card className="p-5 border">
      <div className="flex items-start justify-between gap-3 mb-4 flex-wrap">
        <div className="flex items-center gap-2">
          <HelpCircle className="w-5 h-5 text-primary" />
          <div>
            <h3 className="text-lg font-semibold text-foreground">Questions for the Doctor</h3>
            <p className="text-sm text-muted-foreground">
              {openQuestions.length} to ask{questions.length !== openQuestions.length && ` · ${questions.length - openQuestions.length} answered`}
            </p>
          </div>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button variant="outline" size="sm" className="gap-1.5" onClick={handlePrint} disabled={questions.length === 0}>
            <Printer className="w-4 h-4" /> Print
          </Button>
          <Button variant="outline" size="sm" className="gap-1.5" onClick={() => setEmailOpen(true)} disabled={questions.length === 0}>
            <Mail className="w-4 h-4" /> Email
          </Button>
          <Button variant="outline" size="sm" className="gap-1.5" onClick={handleText} disabled={questions.length === 0}>
            <MessageSquare className="w-4 h-4" /> Text
          </Button>
        </div>
      </div>

      <div className="flex gap-2 mb-4">
        <Input
          value={newQuestion}
          onChange={(e) => setNewQuestion(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") addQuestion();
          }}
          placeholder="Add a question to ask the doctor…"
          maxLength={500}
          aria-label="New question for the doctor"
        />
        <Button onClick={addQuestion} className="gap-1.5 flex-shrink-0">
          <Plus className="w-4 h-4" /> Add
        </Button>
      </div>

      {isLoading ? (
        <p className="text-sm text-muted-foreground">Loading…</p>
      ) : questions.length === 0 ? (
        <p className="text-sm text-muted-foreground py-4 text-center">
          No questions yet. Add anything you want to remember at the next appointment.
        </p>
      ) : (
        <ul className="space-y-2">
          {questions.map((q) => (
            <li key={q.id} className="flex items-start gap-3 p-3 rounded-lg border bg-card">
              <button
                onClick={() => toggleAsked(q)}
                aria-label={q.asked ? "Mark as not yet asked" : "Mark as asked"}
                className="mt-0.5 flex-shrink-0"
              >
                {q.asked ? (
                  <CheckCircle2 className="w-5 h-5 text-primary" />
                ) : (
                  <Circle className="w-5 h-5 text-muted-foreground" />
                )}
              </button>
              <div className="flex-1 min-w-0">
                <p className={`text-base ${q.asked ? "line-through text-muted-foreground" : "text-foreground"}`}>
                  {q.question}
                </p>
                {q.created_by_role !== userRole && (
                  <Badge variant="secondary" className="mt-1 text-xs">
                    Added by {q.created_by_role === "caregiver" ? "caregiver" : seniorName || "senior"}
                  </Badge>
                )}
              </div>
              <button
                onClick={() => removeQuestion(q.id)}
                aria-label="Remove question"
                className="text-muted-foreground hover:text-destructive flex-shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </li>
          ))}
        </ul>
      )}

      <Dialog open={emailOpen} onOpenChange={setEmailOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Email the question list</DialogTitle>
            <DialogDescription>We'll send the full list to this address.</DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <Label htmlFor="dq-email">Email address</Label>
            <Input
              id="dq-email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="name@example.com"
              maxLength={255}
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEmailOpen(false)}>Cancel</Button>
            <Button onClick={handleEmail} disabled={sending || !email.trim()} className="gap-1.5">
              {sending && <Loader2 className="w-4 h-4 animate-spin" />} Send
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
};
