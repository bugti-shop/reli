# Emergency SOS — native iOS & Android setup

The web app, backend, push dispatch, acknowledgement, cancellation and location
logic are complete. These steps are done once, in the native projects created
with `npx cap add ios` / `npx cap add android`.

## 0. Push provider (required)
Connect Firebase Cloud Messaging in Lovable. Without it no phone push is sent
(the in-app alarm, SMS and email still work).

## Android
1. Copy `native-assets/sos_alarm.wav` to `android/app/src/main/res/raw/sos_alarm.wav`.
2. Add `google-services.json` from Firebase to `android/app/`.
3. AndroidManifest.xml permissions:
   - `android.permission.POST_NOTIFICATIONS` (Android 13+, asked by the app)
   - `android.permission.USE_FULL_SCREEN_INTENT` (Android 14+: user must allow
     "Full-screen notifications" in system settings for Reli)
   - `android.permission.ACCESS_FINE_LOCATION` (senior phones)
4. The app creates the `sos_alarm` channel (max importance, alarm sound,
   vibration, lock-screen visible). The user can additionally allow
   "Override Do Not Disturb" for this channel in system settings — Android does
   not allow an app to grant this itself.
5. Optional, for a true full-screen ringing screen while locked: add a native
   FirebaseMessagingService that, for `data.type == "sos"`, posts a
   notification with `setFullScreenIntent(...)` and `CATEGORY_ALARM`.

## iOS
1. Add `sos_alarm.wav` to the Xcode App target (Copy Bundle Resources).
2. Enable Push Notifications + Background Modes → Remote notifications.
3. Upload your APNs key to Firebase.
4. Critical Alerts (ring through Silent / Focus): request the
   `com.apple.developer.usernotifications.critical-alerts` entitlement from
   Apple. Until Apple approves it, iOS delivers the SOS as a time-sensitive
   alert with the alarm sound, which respects the silent switch.
5. iOS never allows third-party apps to open a full-screen screen from a push
   while locked; the lock-screen alert opens the full-screen SOS on tap.
6. Info.plist: `NSLocationWhenInUseUsageDescription` (senior location on SOS).
