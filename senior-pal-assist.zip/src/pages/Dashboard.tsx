import { logActivity as logSeniorActivity, logFeatureOpen } from "@/lib/activity";
import { CarePatternJournal } from "@/components/CarePatternJournal";
import { useState, useEffect, useRef } from "react";
import reliBrand from "@/assets/reli-logo.png";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Lightbulb, Phone, Mic, MicOff, Clock, Sun, Pill, Bell, LogOut, Mail, AlertCircle, Heart, Brain, MessageSquare, Cloud, CloudRain, CloudSnow, CloudFog, CloudLightning, CloudDrizzle, CloudSun, ClipboardList, Activity, FileText, BookOpen, LifeBuoy, Share2, NotebookPen, ChevronRight, Settings, Trash2, Home, UserRound, MoreHorizontal } from "lucide-react";
import { CompanionChat } from "@/components/CompanionChat";
import { SharedMedicationTracker } from "@/components/SharedMedicationTracker";
import { ActivityTracker } from "@/components/ActivityTracker";
import { FontSizeControl } from "@/components/FontSizeControl";
import { EmergencyButton } from "@/components/EmergencyButton";
import { FamilyCircle } from "@/components/FamilyCircle";
import { HomeFamilyCircle } from "@/components/HomeFamilyCircle";
import { HomeCalendar } from "@/components/HomeCalendar";


import { OfflineBanner } from "@/components/OfflineBanner";
import DoctorReport from "@/components/DoctorReport";
import { DailyTrivia } from "@/components/DailyTrivia";
import { QuickMessageDialog } from "@/components/QuickMessageDialog";
import { LifeStoryPrompt } from "@/components/LifeStoryPrompt";
import { Journal } from "@/components/Journal";
import { CustomTracker } from "@/components/CustomTracker";
import { PremiumFeature } from "@/components/PremiumFeature";
import { VitalsTracker } from "@/components/VitalsTracker";
import { QuickReadingTracker } from "@/components/QuickReadingTracker";
import { TrackerReminders } from "@/components/TrackerReminders";
import { TrackerHistory } from "@/components/TrackerHistory";
import { HealthInsights } from "@/components/HealthInsights";
import { useTrackerNotifications } from "@/hooks/use-tracker-notifications";

import { Resources } from "@/components/Resources";
import { SeniorBottomNav, BottomNavItem } from "@/components/SeniorBottomNav";
import { BackToTop } from "@/components/BackToTop";
import { DashboardSkeleton } from "@/components/DashboardSkeleton";
import { EmptyState } from "@/components/EmptyState";
import { MotionPreference } from "@/components/MotionPreference";
import { ShareReport } from "@/components/ShareReport";
import { DashboardHealthSummary } from "@/components/DashboardHealthSummary";
import { SeniorLandscapeBackground } from "@/components/SeniorLandscapeBackground";
import { TrackerSectionTabs, TrackerSection } from "@/components/TrackerSectionTabs";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { supabase } from "@/integrations/supabase/client";
import { User } from "@supabase/supabase-js";
import { useToast } from "@/hooks/use-toast";
import { logoutAndRedirect } from "@/lib/logout";

interface CaregiverMessage {
  id: string;
  message: string;
  is_reminder: boolean;
  reminder_time: string | null;
  read: boolean;
  sender_role?: string | null;
  created_at: string;
  caregiver: {
    full_name: string;
    phone?: string | null;
    email?: string | null;
  } | null;
}

interface Caregiver {
  id: string;
  full_name: string;
  email: string;
  phone?: string | null;
}

interface WeatherData {
  temperature: number;
  description: string;
  icon: "sun" | "cloud-sun" | "cloud" | "fog" | "drizzle" | "rain" | "snow" | "thunderstorm";
}

interface FeatureSettings {
  show_trivia: boolean;
  show_medication_tracker: boolean;
  show_activity_tracker: boolean;
  show_life_story: boolean;
  show_ai_companion: boolean;
  show_doctor_report: boolean;
}

interface SpeechRecognitionLike {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start: () => void;
  stop: () => void;
  onresult: ((event: { results: ArrayLike<{ 0?: { transcript?: string } }> }) => void) | null;
  onerror: (() => void) | null;
  onend: (() => void) | null;
}

const defaultFeatureSettings: FeatureSettings = {
  show_trivia: true,
  show_medication_tracker: true,
  show_activity_tracker: true,
  show_life_story: true,
  show_ai_companion: true,
  show_doctor_report: true,
};

const weatherIcons = {
  "sun": Sun,
  "cloud-sun": CloudSun,
  "cloud": Cloud,
  "fog": CloudFog,
  "drizzle": CloudDrizzle,
  "rain": CloudRain,
  "snow": CloudSnow,
  "thunderstorm": CloudLightning,
};

const getGreetingForHour = (hour: number) => {
  if (hour < 5) return "Good Night";
  if (hour < 12) return "Good Morning";
  if (hour < 17) return "Good Afternoon";
  if (hour < 21) return "Good Evening";
  return "Good Night";
};

const Dashboard = () => {
  const [isListening, setIsListening] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [greeting, setGreeting] = useState("");
  const [user, setUser] = useState<User | null>(null);
  const [messages, setMessages] = useState<CaregiverMessage[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [caregivers, setCaregivers] = useState<Caregiver[]>([]);
  const [triviaOpen, setTriviaOpen] = useState(false);
  const [messageDialogOpen, setMessageDialogOpen] = useState(false);
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [weatherLoading, setWeatherLoading] = useState(true);
  const [featureSettings, setFeatureSettings] = useState<FeatureSettings>(defaultFeatureSettings);
  const [activeTab, setActiveTab] = useState("home");
  const [activeFeature, setActiveFeature] = useState("trackers");
  const [messageToDelete, setMessageToDelete] = useState<string | null>(null);
  const [deletingMessage, setDeletingMessage] = useState(false);
  const [loading, setLoading] = useState(true);
  const speechRecognitionRef = useRef<{ stop: () => void } | null>(null);
  const navigate = useNavigate();
  const { toast } = useToast();
  // Fires medication + reading reminders while the senior is using the app
  useTrackerNotifications(user?.id);

  // ─── All existing hooks & handlers (unchanged) ────────────────────────
  useEffect(() => {
    const weatherData: Record<number, { description: string; icon: WeatherData["icon"] }> = {
      0: { description: "clear skies", icon: "sun" },
      1: { description: "mainly clear", icon: "sun" },
      2: { description: "partly cloudy", icon: "cloud-sun" },
      3: { description: "overcast", icon: "cloud" },
      45: { description: "foggy", icon: "fog" },
      48: { description: "foggy", icon: "fog" },
      51: { description: "light drizzle", icon: "drizzle" },
      53: { description: "drizzle", icon: "drizzle" },
      55: { description: "heavy drizzle", icon: "drizzle" },
      61: { description: "light rain", icon: "rain" },
      63: { description: "rain", icon: "rain" },
      65: { description: "heavy rain", icon: "rain" },
      71: { description: "light snow", icon: "snow" },
      73: { description: "snow", icon: "snow" },
      75: { description: "heavy snow", icon: "snow" },
      80: { description: "rain showers", icon: "rain" },
      81: { description: "rain showers", icon: "rain" },
      82: { description: "heavy rain showers", icon: "rain" },
      95: { description: "thunderstorms", icon: "thunderstorm" },
    };

    const fetchWeather = async (lat: number, lon: number) => {
      try {
        const response = await fetch(
          `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,weather_code&temperature_unit=fahrenheit`
        );
        const data = await response.json();
        const code = data.current.weather_code;
        const info = weatherData[code] || { description: "nice weather", icon: "sun" as const };
        setWeather({
          temperature: Math.round(data.current.temperature_2m),
          description: info.description,
          icon: info.icon
        });
      } catch (error) {
        console.error("Error fetching weather:", error);
      } finally {
        setWeatherLoading(false);
      }
    };

    const getWeatherFromIp = async () => {
      try {
        const locationResponse = await fetch('https://ipapi.co/json/');
        const locationData = await locationResponse.json();
        fetchWeather(locationData.latitude, locationData.longitude);
      } catch (error) {
        console.error("Error getting location:", error);
        fetchWeather(40.7128, -74.006);
      }
    };

    const getLocationAndWeather = () => {
      // Prefer the device's own location (GPS on phones, Wi-Fi/network on computers).
      // Falls back to IP-based location if permission is denied or unavailable.
      if ("geolocation" in navigator) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            fetchWeather(position.coords.latitude, position.coords.longitude);
          },
          (error) => {
            console.log("Geolocation unavailable, using IP fallback:", error.message);
            getWeatherFromIp();
          },
          { timeout: 8000, maximumAge: 30 * 60 * 1000 }
        );
      } else {
        getWeatherFromIp();
      }
    };

    getLocationAndWeather();
  }, []);

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        setUser(session?.user ?? null);
      }
    );

    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      if (!session) {
        navigate("/auth");
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: "instant" });
    const timer = setTimeout(() => {
      window.scrollTo({ top: 0, left: 0, behavior: "instant" });
    }, 100);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      setCurrentTime(now);
      setGreeting(getGreetingForHour(now.getHours()));
    };
    updateClock();
    const timer = setInterval(updateClock, 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (user) {
      logActivity("Dashboard Visit", "User viewed the dashboard");
      Promise.all([
        fetchMessages(),
        fetchCaregivers(),
        fetchUpcomingReminders(),
        fetchFeatureSettings(),
      ]).finally(() => setLoading(false));

      const channel = supabase
        .channel('caregiver-messages')
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'caregiver_messages',
            filter: `senior_id=eq.${user.id}`,
          },
          (payload) => {
            console.log('Message update received:', payload);
            fetchMessages();
            fetchUpcomingReminders();
            const incoming = payload.new as { sender_role?: string };
            if (payload.eventType === 'INSERT' && incoming.sender_role !== 'senior') {
              toast({
                title: "New Message from Caregiver",
                description: "You have a new message. Check your messages above!",
              });
            }
          }
        )
        .subscribe();

      return () => {
        supabase.removeChannel(channel);
      };
    }
  }, [user]);

  const fetchMessages = async () => {
    if (!user) return;
    const { data, error } = await supabase
      .from("caregiver_messages")
      .select(`*, caregiver:profiles!caregiver_id(full_name, phone, email)`)
      .eq("senior_id", user.id)
      .order("created_at", { ascending: false });
    if (error) { console.error("Error fetching messages:", error); return; }
    setMessages(data || []);
    setUnreadCount(data?.filter(m => !m.read && m.sender_role !== 'senior').length || 0);
  };

  const fetchCaregivers = async () => {
    if (!user) return;
    const { data, error } = await supabase
      .from("caregiver_seniors")
      .select("caregiver_id, profiles!caregiver_seniors_caregiver_id_fkey(id, full_name, email, phone)")
      .eq("senior_id", user.id);
    if (error) { console.error("Error fetching caregivers:", error); return; }
    const caregiversList = (data || [])
      .map((item) => item.profiles)
      .filter((profile): profile is NonNullable<typeof profile> => Boolean(profile));
    setCaregivers(caregiversList);
  };

  const fetchFeatureSettings = async () => {
    if (!user) return;
    const { data, error } = await supabase
      .from("senior_feature_settings")
      .select("*")
      .eq("senior_id", user.id);
    if (error) { console.error("Error fetching feature settings:", error); return; }
    if (data && data.length > 0) {
      const mergedSettings: FeatureSettings = {
        show_trivia: data.every(s => s.show_trivia),
        show_medication_tracker: data.every(s => s.show_medication_tracker),
        show_activity_tracker: data.every(s => s.show_activity_tracker),
        show_life_story: data.every(s => s.show_life_story),
        show_ai_companion: data.every(s => s.show_ai_companion),
        show_doctor_report: data.every(s => s.show_doctor_report),
      };
      setFeatureSettings(mergedSettings);
    }
  };

  const markAsRead = async (messageId: string) => {
    const { error } = await supabase
      .from("caregiver_messages")
      .update({ read: true })
      .eq("id", messageId);
    if (error) { console.error("Error marking message as read:", error); return; }
    fetchMessages();
  };

  const deleteMessage = async () => {
    if (!messageToDelete) return;
    setDeletingMessage(true);
    const { error } = await supabase.from("caregiver_messages").delete().eq("id", messageToDelete);
    setDeletingMessage(false);
    if (error) {
      console.error("Error deleting message:", error);
      toast({ title: "Could not delete message", description: "Please try again.", variant: "destructive" });
      return;
    }
    setMessages((current) => current.filter((item) => item.id !== messageToDelete));
    setUnreadCount((current) => {
      const deletedMessage = messages.find((item) => item.id === messageToDelete);
      return deletedMessage && !deletedMessage.read ? Math.max(0, current - 1) : current;
    });
    setMessageToDelete(null);
    toast({ title: "Message deleted" });
  };

  const logActivity = async (activityType: string, description: string) => {
    if (!user) return;
    await logSeniorActivity(activityType, description, { feature: "app" });
  };

  const handleLogout = async () => {
    await logSeniorActivity("Signed out", "Signed out of Reli", { feature: "account" }).catch(() => undefined);
    await logoutAndRedirect();
  };

  const openDashboardSection = (transcript: string) => {
    const command = transcript.toLowerCase();
    const destinations = [
      { words: ["tracker", "trackers", "medication", "medications", "blood pressure", "heart rate"], tab: "trackers", label: "Trackers" },
      { words: ["message", "messages"], tab: "more", label: "Messages" },
      { words: ["home"], tab: "home", label: "Home" },
      { words: ["health", "activity", "doctor"], tab: "health", label: "Health" },
      { words: ["journal", "life story", "story", "companion", "ai companion", "trivia"], tab: "life", label: "My Life" },
      { words: ["more", "share", "report", "resource", "resources", "help", "caregiver", "caregivers", "account", "profile"], tab: "more", label: "More" },
    ];
    const destination = destinations.find((item) => item.words.some((word) => command.includes(word)));

    if (command.includes("setting")) {
      navigate("/settings");
      return;
    }
    if (command.includes("contact")) {
      navigate("/contact");
      return;
    }
    if (!destination) {
      toast({ title: "I didn't recognize that section", description: "Try saying Home, Health, Trackers, My Life, or More." });
      return;
    }

    changeDestination(destination.tab);
    if (command.includes("message")) setActiveFeature("messages");
    else if (command.includes("reminder")) setActiveFeature("reminders");
    else if (command.includes("history") || command.includes("trend")) setActiveFeature("thistory");
    else if (command.includes("custom")) setActiveFeature("custom");
    else if (command.includes("blood pressure") || command.includes("heart rate")) setActiveFeature("vitals");
    else if (command.includes("activity")) setActiveFeature("activity");
    else if (command.includes("doctor")) setActiveFeature("doctor");
    else if (command.includes("life story") || command.includes("story")) setActiveFeature("lifestory");
    else if (command.includes("companion")) setActiveFeature("companion");
    else if (command.includes("trivia")) setActiveFeature("trivia");
    else if (command.includes("share") || command.includes("report")) setActiveFeature("share");
    else if (command.includes("caregiver")) setActiveFeature("caregivers");
    window.scrollTo({ top: 0, left: 0, behavior: "smooth" });
    toast({ title: `Opening ${destination.label}` });
  };

  const handleVoiceToggle = () => {
    if (isListening) {
      speechRecognitionRef.current?.stop();
      setIsListening(false);
      return;
    }

    const recognitionWindow = window as typeof window & {
      SpeechRecognition?: new () => SpeechRecognitionLike;
      webkitSpeechRecognition?: new () => SpeechRecognitionLike;
    };
    const NativeSpeechRecognitionConstructor = recognitionWindow.SpeechRecognition || recognitionWindow.webkitSpeechRecognition;
    if (!NativeSpeechRecognitionConstructor) {
      toast({ title: "Voice navigation isn't available", description: "Please use the tabs to navigate in this browser." });
      return;
    }

    const SpeechRecognitionConstructor = NativeSpeechRecognitionConstructor as unknown as new () => SpeechRecognitionLike;
    const recognition = new SpeechRecognitionConstructor();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = "en-US";
    recognition.onresult = (event) => openDashboardSection(event.results[0]?.[0]?.transcript || "");
    recognition.onerror = () => {
      setIsListening(false);
      toast({ title: "I couldn't hear that", description: "Please tap the microphone and try again." });
    };
    recognition.onend = () => setIsListening(false);
    speechRecognitionRef.current = recognition;
    setIsListening(true);
    recognition.start();
  };

  interface CombinedReminder {
    id: string;
    message: string;
    reminder_time: string;
    source: 'caregiver' | 'senior' | 'daily';
    caregiver_name?: string;
    days?: number[] | null;
  }

  // Turns a repeating "HH:MM" reminder time into the next date/time it happens
  // on one of its chosen days of the week (0 = Sunday).
  const nextOccurrence = (time: string, days?: number[] | null) => {
    const activeDays = days && days.length > 0 ? days : [0, 1, 2, 3, 4, 5, 6];
    const [h, m] = time.slice(0, 5).split(":").map(Number);
    const next = new Date();
    next.setHours(h, m, 0, 0);
    if (next.getTime() < Date.now()) next.setDate(next.getDate() + 1);
    for (let i = 0; i < 7 && !activeDays.includes(next.getDay()); i++) {
      next.setDate(next.getDate() + 1);
    }
    return next.toISOString();
  };

  const describeDays = (days?: number[] | null) => {
    const names = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    const sorted = [...new Set(days || [])].sort((a, b) => a - b);
    if (sorted.length === 0 || sorted.length === 7) return "Every day";
    if (sorted.join(",") === "1,2,3,4,5") return "Weekdays";
    if (sorted.join(",") === "0,6") return "Weekends";
    return sorted.map((d) => names[d]).join(", ");
  };

  const [upcomingReminders, setUpcomingReminders] = useState<CombinedReminder[]>([]);
  const [homeMedicationSummary, setHomeMedicationSummary] = useState({ completed: 0, total: 0 });

  useEffect(() => {
    if (user) {
      fetchUpcomingReminders();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, activeTab]);

  const fetchUpcomingReminders = async () => {
    if (!user) return;
    const now = new Date().toISOString();
    const { data: caregiverReminders, error: caregiverError } = await supabase
      .from("caregiver_messages")
      .select(`id, message, reminder_time, caregiver:profiles!caregiver_id(full_name)`)
      .eq("senior_id", user.id)
      .eq("is_reminder", true)
      .gte("reminder_time", now);
    const { data: seniorReminders, error: seniorError } = await supabase
      .from("senior_reminders")
      .select("id, message, reminder_time")
      .eq("senior_id", user.id)
      .eq("completed", false)
      .gte("reminder_time", now);
    // Daily reminders set under the Trackers tab (and medication times)
    const [{ data: trackerReminders }, { data: meds }] = await Promise.all([
      supabase
        .from("tracker_reminders")
        .select("id, kind, label, time, enabled, days_of_week")
        .eq("senior_id", user.id)
        .eq("enabled", true),
      supabase
        .from("medications")
        .select("id, name, dosage, time, completed, days_of_week")
        .eq("senior_id", user.id),
    ]);
    if (caregiverError) console.error("Error fetching caregiver reminders:", caregiverError);
    if (seniorError) console.error("Error fetching senior reminders:", seniorError);
    const trackerLabel = (kind: string, label: string | null) => {
      if (kind === "custom") return label || "Reminder";
      if (kind === "medication") return label ? `Take ${label}` : "Take your medication";
      if (kind === "blood_pressure") return "Record your blood pressure";
      if (kind === "heart_rate") return "Record your heart rate";
      return label || "Reminder";
    };
    const combined: CombinedReminder[] = [
      ...(caregiverReminders || []).map((r) => ({
        id: r.id, message: r.message, reminder_time: r.reminder_time,
        source: 'caregiver' as const, caregiver_name: r.caregiver?.full_name
      })),
      ...(seniorReminders || []).map((r) => ({
        id: r.id, message: r.message, reminder_time: r.reminder_time,
        source: 'senior' as const
      })),
      ...(trackerReminders || []).map((r) => ({
        id: `tracker-${r.id}`,
        message: trackerLabel(r.kind, r.label),
        reminder_time: nextOccurrence(r.time, r.days_of_week),
        source: 'daily' as const,
        days: r.days_of_week as number[] | null,
      })),
      ...(meds || []).filter((m) => m.time && !m.completed).map((m) => ({
        id: `med-${m.id}`,
        message: `Take ${m.name}${m.dosage ? ` — ${m.dosage}` : ""}`,
        reminder_time: nextOccurrence(m.time, m.days_of_week),
        source: 'daily' as const,
        days: m.days_of_week as number[] | null,
      })),
    ].sort((a, b) => new Date(a.reminder_time).getTime() - new Date(b.reminder_time).getTime());
    setUpcomingReminders(combined);
    setHomeMedicationSummary({
      completed: (meds || []).filter((medication) => medication.completed).length,
      total: (meds || []).length,
    });
  };

  // ─── RENDER ───────────────────────────────────────────────────────────
  const userName = user?.user_metadata?.full_name || "Friend";

  useEffect(() => {
    if (!user) return;
    const labels: Record<string, string> = { trackers: "Health trackers", meds: "Medications", reminders: "Reminders", history: "History", journal: "Journal", resources: "Resources" };
    logFeatureOpen(`feature:${activeFeature}`, labels[activeFeature] ?? activeFeature.replace(/[-_]/g, " "));
  }, [activeFeature, user]);

  const navItems: BottomNavItem[] = [
    { value: "health", label: "Health", icon: Heart },
    { value: "trackers", label: "Trackers", icon: Pill },
    { value: "home", label: "Home", icon: Home },
    { value: "life", label: "My Life", icon: UserRound },
    { value: "more", label: "More", icon: MoreHorizontal },
  ];

  const changeDestination = (destination: string) => {
    setActiveTab(destination);
    logFeatureOpen(destination, { health: "Health", trackers: "Trackers & Medications", home: "Home", life: "My Life", more: "More" }[destination] ?? destination);
    if (destination === "health") setActiveFeature("trackers");
    if (destination === "trackers") setActiveFeature("meds");
    if (destination === "life") setActiveFeature("journal");
    if (destination === "more") setActiveFeature("resources");
  };


  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <DashboardSkeleton />
      </div>
    );
  }

  const sectionButton = (value: string, label: string, Icon: typeof Heart) => (
    <Button
      key={value}
      type="button"
      variant="ghost"
      onClick={() => setActiveFeature(value)}
      aria-pressed={activeFeature === value}
      className={`h-[4.25rem] min-w-0 flex-col gap-1 rounded-xl border px-1 text-[10px] leading-none md:h-[4.75rem] md:text-xs ${
        activeFeature === value
          ? "border-primary/35 bg-card font-semibold text-primary shadow-sm hover:bg-card"
          : "border-border/70 bg-card/65 font-medium text-nav-icon hover:bg-card"
      }`}
    >
      <Icon className="!h-[1.3rem] !w-[1.3rem] md:!h-6 md:!w-6" strokeWidth={1.9} strokeLinecap="round" strokeLinejoin="round" />
      <span className="w-full truncate text-center">{label}</span>
    </Button>
  );

  const screenHeading = (title: string, description: string, Icon: typeof Heart) => (
    <div className="flex items-center gap-2.5 py-1 md:gap-3 md:py-2">
      <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-card text-nav-icon shadow-sm md:h-11 md:w-11">
        <Icon className="h-5 w-5 md:h-6 md:w-6" strokeWidth={1.9} strokeLinecap="round" strokeLinejoin="round" />
      </span>
      <div className="min-w-0">
        <h1 className="text-xl font-bold leading-tight md:text-3xl">{title}</h1>
        <p className="truncate text-[11px] text-muted-foreground md:text-sm">{description}</p>
      </div>
    </div>
  );

  const messagesPanel = (
    <section className="space-y-3 md:space-y-4" aria-labelledby="messages-heading">
      <div className="flex items-center justify-between gap-2">
        <div id="messages-heading">{screenHeading("Messages", "Stay connected with your caregivers.", MessageSquare)}</div>
        <Button onClick={() => setMessageDialogOpen(true)} size="sm" className="h-9 shrink-0 rounded-lg px-3 text-xs md:h-11 md:px-4 md:text-sm">
          <MessageSquare className="!h-4 !w-4 md:!h-5 md:!w-5" /> New
        </Button>
      </div>
      {messages.length === 0 ? (
        <EmptyState icon={Mail} title="No messages yet" description="Messages from your caregivers will appear here." />
      ) : (
        <div className="space-y-2.5 md:space-y-3">
          {messages.map((msg) => (
            <Card key={msg.id} className={`border p-3 md:p-4 ${msg.sender_role === "senior" ? "bg-secondary/40" : msg.read ? "bg-card" : "border-primary/30 bg-primary/5"}`}>
              <div className="flex items-start justify-between gap-3">
                <div className="flex min-w-0 flex-1 gap-3">
                  <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-bold text-primary md:h-11 md:w-11 md:text-base">
                    {msg.sender_role === "senior" ? "You" : (msg.caregiver?.full_name || "C").charAt(0).toUpperCase()}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="font-semibold text-foreground">{msg.sender_role === "senior" ? `You → ${msg.caregiver?.full_name || "Your Caregiver"}` : msg.caregiver?.full_name || "Your Caregiver"}</p>
                      {!msg.read && msg.sender_role !== "senior" && <span className="rounded-full bg-primary px-2 py-0.5 text-xs font-semibold text-primary-foreground">NEW</span>}
                      {msg.is_reminder && <span className="flex items-center gap-1 text-xs font-semibold text-destructive"><AlertCircle className="h-3 w-3" /> Reminder</span>}
                    </div>
                    <p className="mt-1 text-sm text-foreground md:text-base">{msg.message}</p>
                    {msg.is_reminder && msg.reminder_time && <p className="mt-1 flex items-center gap-1 text-sm text-destructive"><Bell className="h-3.5 w-3.5" />{new Date(msg.reminder_time).toLocaleString()}</p>}
                    {msg.sender_role !== "senior" && (msg.caregiver?.phone || msg.caregiver?.email) && (
                      <div className="mt-2 flex flex-wrap gap-3 text-sm">
                        {msg.caregiver?.phone && <a href={`tel:${msg.caregiver.phone.replace(/[^+\d]/g, "")}`} className="flex items-center gap-1 font-medium text-primary"><Phone className="h-4 w-4" />{msg.caregiver.phone}</a>}
                        {msg.caregiver?.email && <a href={`mailto:${msg.caregiver.email}`} className="flex items-center gap-1 break-all font-medium text-primary"><Mail className="h-4 w-4" />{msg.caregiver.email}</a>}
                      </div>
                    )}
                    <p className="mt-2 text-xs text-muted-foreground">{new Date(msg.created_at).toLocaleString()}</p>
                  </div>
                </div>
                <div className="flex shrink-0 flex-col gap-2">
                  {!msg.read && msg.sender_role !== "senior" && <Button onClick={() => markAsRead(msg.id)} variant="outline" size="sm">Read</Button>}
                  <Button onClick={() => setMessageToDelete(msg.id)} variant="ghost" size="icon" className="text-destructive hover:text-destructive" aria-label="Delete message"><Trash2 className="h-4 w-4" /></Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </section>
  );

  return (
    <div className="relative min-h-screen overflow-x-hidden bg-dashboard-cream pb-20 md:pb-24">
      <div>
        <header className="bg-dashboard-cream">
          <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-2.5 md:px-8 md:py-5">
            <div>
              <img src={reliBrand} alt="Reli" className="h-9 w-auto md:h-14" />
              <p className="mt-0.5 text-[10px] font-medium text-muted-foreground md:mt-1 md:text-sm">Care Today. A Brighter Tomorrow.</p>
            </div>
            {user && <EmergencyButton seniorId={user.id} variant="header" />}
          </div>
        </header>

        <main className="mx-auto max-w-6xl px-2.5 pb-3 md:px-8 md:pb-4">
          <OfflineBanner />

          {activeTab === "home" && (
            <div className="space-y-3 md:space-y-5">
              <section className="scenery-readable relative isolate overflow-hidden rounded-[1.65rem] p-2.5 text-primary-foreground shadow-lg md:rounded-[2rem] md:p-8">
                <SeniorLandscapeBackground className="pointer-events-none absolute inset-0 -z-10 h-full w-full" />
                <div className="relative grid gap-1 md:grid-cols-[1fr_auto] md:gap-4">
                  <div>
                    <p className="text-sm font-medium text-primary-foreground/90 md:text-2xl">{greeting},</p>
                    <h1 className="text-2xl font-bold leading-tight text-primary-foreground md:mt-1 md:text-5xl">{userName}</h1>
                    <div className="mt-0.5 flex items-start justify-between gap-3 md:mt-3 md:block">
                      <div>
                        <p className="text-[1.7rem] font-bold leading-tight text-primary-foreground drop-shadow-sm md:text-5xl">{currentTime.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' })}</p>
                        <p className="text-[1.7rem] font-bold leading-tight text-primary-foreground drop-shadow-sm md:mt-1 md:text-5xl">{currentTime.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}</p>
                      </div>
                      {!weatherLoading && weather && (() => {
                        const WeatherIcon = weatherIcons[weather.icon];
                          return <div className="text-right text-primary-foreground md:hidden"><WeatherIcon className="ml-auto h-7 w-7 drop-shadow-sm" /><p className="text-xl font-bold drop-shadow-sm">{weather.temperature}°F</p><p className="text-[10px] font-medium capitalize text-primary-foreground/85">{weather.description}</p></div>;
                      })()}
                    </div>
                  </div>
                  {!weatherLoading && weather && (() => {
                    const WeatherIcon = weatherIcons[weather.icon];
                    return <div className="hidden text-right text-primary-foreground md:block"><WeatherIcon className="ml-auto h-12 w-12 drop-shadow-sm" /><p className="text-3xl font-bold drop-shadow-sm">{weather.temperature}°F</p><p className="font-medium capitalize text-primary-foreground/85">{weather.description}</p></div>;
                  })()}
                </div>

                <div className="relative my-0.5 flex flex-col items-center md:my-7">
                  <Button onClick={handleVoiceToggle} aria-label={isListening ? "Stop listening" : "Tap to speak"} className={`h-[3.25rem] w-[3.25rem] rounded-full shadow-lg md:h-28 md:w-28 ${isListening ? "animate-pulse bg-destructive text-destructive-foreground" : "bg-card text-primary hover:bg-card/90"}`}>
                    {isListening ? <MicOff className="!h-6 !w-6 md:!h-11 md:!w-11" /> : <Mic className="!h-6 !w-6 md:!h-11 md:!w-11" />}
                  </Button>
                  <p className="mt-1 text-[13px] font-semibold md:mt-3 md:text-lg">{isListening ? "Listening…" : "Tap to Speak"}</p>
                  <p className="text-[10px] text-primary-foreground/65 md:text-sm">Talk to Reli anytime</p>
                </div>
                <div className="relative">{user && <DashboardHealthSummary seniorId={user.id} variant="reference" />}</div>
              </section>

              <section className="grid grid-cols-2 gap-3 md:gap-4" aria-label="Quick actions">
                {featureSettings.show_medication_tracker && <Button variant="ghost" onClick={() => { changeDestination("health"); setActiveFeature("trackers"); }} className="h-32 flex-col items-start justify-between rounded-[1.5rem] bg-dashboard-mint p-4 text-left text-foreground hover:bg-dashboard-mint/80 md:h-48 md:rounded-[1.75rem] md:p-5">
                  <span className="flex w-full items-start justify-between"><span className="flex h-11 w-11 items-center justify-center rounded-full bg-accent/35 text-primary md:h-14 md:w-14"><Pill className="h-6 w-6 md:h-8 md:w-8" /></span><ChevronRight className="h-5 w-5 text-primary/60 md:h-7 md:w-7" /></span>
                  <span><span className="block text-lg font-bold md:text-2xl">Medications</span><span className="block text-xs font-normal md:mt-1 md:text-sm">{homeMedicationSummary.completed}/{homeMedicationSummary.total} today</span></span>
                </Button>}
                <Button variant="ghost" onClick={() => { changeDestination("health"); setActiveFeature("reminders"); }} className="h-32 flex-col items-start justify-between rounded-[1.5rem] bg-dashboard-sky p-4 text-left text-foreground hover:bg-dashboard-sky/80 md:h-48 md:rounded-[1.75rem] md:p-5">
                  <span className="flex w-full items-start justify-between"><span className="flex h-11 w-11 items-center justify-center rounded-full bg-primary/10 text-primary md:h-14 md:w-14"><Bell className="h-6 w-6 md:h-8 md:w-8" /></span><ChevronRight className="h-5 w-5 text-primary/60 md:h-7 md:w-7" /></span>
                  <span><span className="block text-lg font-bold md:text-2xl">Reminders</span><span className="block text-xs font-normal md:mt-1 md:text-sm">{upcomingReminders.length} pending</span></span>
                </Button>
                <Button variant="ghost" onClick={() => { changeDestination("more"); setActiveFeature("messages"); }} className="h-32 flex-col items-start justify-between rounded-[1.5rem] bg-dashboard-blush p-4 text-left text-foreground hover:bg-dashboard-blush/80 md:h-48 md:rounded-[1.75rem] md:p-5">
                  <span className="flex w-full items-start justify-between"><span className="flex h-11 w-11 items-center justify-center rounded-full bg-destructive/15 text-destructive md:h-14 md:w-14"><Mail className="h-6 w-6 md:h-8 md:w-8" /></span><ChevronRight className="h-5 w-5 text-destructive/60 md:h-7 md:w-7" /></span>
                  <span><span className="block text-lg font-bold md:text-2xl">Messages</span><span className="block text-xs font-normal md:mt-1 md:text-sm">{unreadCount} new</span></span>
                </Button>
                {featureSettings.show_trivia && <Button variant="ghost" onClick={() => setTriviaOpen(true)} className="h-32 flex-col items-start justify-between rounded-[1.5rem] bg-dashboard-gold p-4 text-left text-foreground hover:bg-dashboard-gold/80 md:h-48 md:rounded-[1.75rem] md:p-5">
                  <span className="flex w-full items-start justify-between"><span className="flex h-11 w-11 items-center justify-center rounded-full bg-dashboard-gold text-primary md:h-14 md:w-14"><Brain className="h-6 w-6 md:h-8 md:w-8" /></span><ChevronRight className="h-5 w-5 text-primary/60 md:h-7 md:w-7" /></span>
                  <span><span className="block text-lg font-bold md:text-2xl">Daily Trivia</span><span className="block whitespace-normal text-xs font-normal md:mt-1 md:text-sm">Keep Your Mind Sharp</span></span>
                </Button>}
              </section>

              <HomeCalendar seniorId={user.id} role="senior" />

              {user && <HomeFamilyCircle seniorId={user.id} />}
            </div>
          )}

          {activeTab === "health" && user && (
            <section className="space-y-3 pt-2 md:space-y-5 md:pt-4">
              {screenHeading("Health", "Medications, readings, reminders and reports.", Heart)}
              <div className="grid grid-cols-5 gap-1.5 md:gap-2">
                {sectionButton("trackers", "Trackers", ClipboardList)}
                {sectionButton("reminders", "Reminders", Bell)}
                {sectionButton("history", "History", Clock)}
                {featureSettings.show_activity_tracker && sectionButton("activity", "Activity", Activity)}
                {featureSettings.show_doctor_report && sectionButton("doctor", "Doctor", FileText)}
              </div>
              {activeFeature === "trackers" && <div className="space-y-4">{featureSettings.show_medication_tracker && <SharedMedicationTracker userId={user.id} userRole="senior" seniorId={user.id} />}<VitalsTracker type="blood_pressure" userId={user.id} userRole="senior" /><VitalsTracker type="heart_rate" userId={user.id} userRole="senior" /><QuickReadingTracker type="glucose" userId={user.id} userRole="senior" /><QuickReadingTracker type="weight" userId={user.id} userRole="senior" /><QuickReadingTracker type="water" userId={user.id} userRole="senior" /><PremiumFeature name="Custom Trackers" description="Track anything you like, your own way." userId={user.id}><CustomTracker userId={user.id} userRole="senior" /></PremiumFeature></div>}
              {activeFeature === "reminders" && <div className="space-y-4"><TrackerReminders userId={user.id} userRole="senior" seniorId={user.id} />{upcomingReminders.length > 0 && <div className="space-y-3"><h2 className="text-xl font-bold">Upcoming Reminders</h2>{upcomingReminders.map((reminder) => <Card key={reminder.id} className="flex items-center gap-3 p-4"><Bell className="h-5 w-5 shrink-0 text-primary" /><div><p className="font-medium">{reminder.message}</p><p className="text-sm text-muted-foreground">{new Date(reminder.reminder_time).toLocaleString()} · {reminder.source === "daily" ? describeDays(reminder.days) : reminder.caregiver_name ? `From ${reminder.caregiver_name}` : "My reminder"}</p></div></Card>)}</div>}</div>}
              {activeFeature === "history" && <div className="space-y-4"><TrackerHistory userId={user.id} userRole="senior" seniorId={user.id} /><PremiumFeature name="Trends & Insights" description="AI-powered charts and insights from your tracker history." userId={user.id}><HealthInsights userId={user.id} seniorId={user.id} /></PremiumFeature></div>}
              {activeFeature === "activity" && featureSettings.show_activity_tracker && <ActivityTracker />}
              {activeFeature === "doctor" && featureSettings.show_doctor_report && <DoctorReport />}
            </section>
          )}

          {activeTab === "trackers" && user && (
            <section className="space-y-3 pt-2 md:space-y-5 md:pt-4">
              <div className="px-1 py-2"><h1 className="text-3xl font-bold leading-tight md:text-5xl">Trackers</h1><p className="mt-1 text-sm text-muted-foreground md:text-lg">Your medications, readings, reminders and history</p></div>
              <TrackerSectionTabs active={activeFeature as TrackerSection} onChange={setActiveFeature} />
              {activeFeature === "meds" && featureSettings.show_medication_tracker && <SharedMedicationTracker userId={user.id} userRole="senior" seniorId={user.id} />}
              {activeFeature === "vitals" && <div className="space-y-4"><VitalsTracker type="blood_pressure" userId={user.id} userRole="senior" /><VitalsTracker type="heart_rate" userId={user.id} userRole="senior" /><QuickReadingTracker type="glucose" userId={user.id} userRole="senior" /><QuickReadingTracker type="weight" userId={user.id} userRole="senior" /><QuickReadingTracker type="water" userId={user.id} userRole="senior" /></div>}
              {activeFeature === "custom" && <PremiumFeature name="Custom Trackers" description="Track anything you like, your own way." userId={user.id}><CustomTracker userId={user.id} userRole="senior" /></PremiumFeature>}
              {activeFeature === "reminders" && <TrackerReminders userId={user.id} userRole="senior" seniorId={user.id} />}
              {activeFeature === "history" && <div className="space-y-4"><TrackerHistory userId={user.id} userRole="senior" seniorId={user.id} /><PremiumFeature name="Trends & Insights" description="AI-powered charts and insights from your tracker history." userId={user.id}><HealthInsights userId={user.id} seniorId={user.id} /></PremiumFeature></div>}
            </section>
          )}


          {activeTab === "life" && user && (
            <section className="space-y-3 pt-2 md:space-y-5 md:pt-4">
              {screenHeading("My Life", "Stories, thoughts and companionship.", UserRound)}
              <div className="grid grid-cols-5 gap-1.5 md:gap-2">
                {sectionButton("journal", "Journal", NotebookPen)}
                {sectionButton("healthjournal", "Health Journal", Lightbulb)}
                {featureSettings.show_life_story && sectionButton("lifestory", "Life Story", BookOpen)}
                {featureSettings.show_ai_companion && sectionButton("companion", "AI Companion", Sun)}
                {featureSettings.show_trivia && sectionButton("trivia", "Trivia", Brain)}
              </div>
              {activeFeature === "journal" && <Journal userId={user.id} />}
              {activeFeature === "healthjournal" && <CarePatternJournal userId={user.id} seniorId={user.id} seniorName="you" self />}
              {activeFeature === "lifestory" && featureSettings.show_life_story && <LifeStoryPrompt />}
              {activeFeature === "companion" && featureSettings.show_ai_companion && <CompanionChat />}
              {activeFeature === "trivia" && featureSettings.show_trivia && <Card className="p-6 text-center"><Brain className="mx-auto h-12 w-12 text-primary" /><h2 className="mt-3 text-2xl font-bold">Daily Trivia</h2><p className="mt-1 text-muted-foreground">Keep your mind sharp with a fresh question.</p><Button onClick={() => setTriviaOpen(true)} className="mt-5 min-h-12">Start Today’s Trivia</Button></Card>}
            </section>
          )}

          {activeTab === "more" && user && (
            <section className="space-y-3 pt-2 md:space-y-5 md:pt-4">
              {screenHeading("More", "Sharing, support and your account.", MoreHorizontal)}
              <div className="grid grid-cols-5 gap-1.5 md:gap-2">
                {sectionButton("resources", "Help", LifeBuoy)}
                {sectionButton("messages", "Messages", Mail)}
                {sectionButton("share", "Share", Share2)}
                {sectionButton("caregivers", "Caregivers", Heart)}
                {sectionButton("account", "Account", Settings)}
              </div>
              {activeFeature === "resources" && <Resources audience="senior" />}
              {activeFeature === "messages" && messagesPanel}
              {activeFeature === "share" && <ShareReport userId={user.id} userRole="senior" seniorId={user.id} />}
              {activeFeature === "caregivers" && <div className="space-y-3">{caregivers.length ? caregivers.map((caregiver) => <Card key={caregiver.id} className="flex items-center gap-3 p-4"><span className="flex h-11 w-11 items-center justify-center rounded-full bg-primary/10 font-bold text-primary">{caregiver.full_name.charAt(0).toUpperCase()}</span><div className="min-w-0 flex-1"><p className="font-semibold">{caregiver.full_name}</p><p className="truncate text-sm text-muted-foreground">{caregiver.email}</p></div>{caregiver.phone && <Button asChild size="icon"><a href={`tel:${caregiver.phone.replace(/[^+\d]/g, "")}`} aria-label={`Call ${caregiver.full_name}`}><Phone className="h-5 w-5" /></a></Button>}</Card>) : <EmptyState icon={Heart} title="No caregivers yet" description="Connected caregivers will appear here." />}</div>}
              {activeFeature === "account" && <div className="grid gap-3 sm:grid-cols-2"><Button variant="outline" className="min-h-16 justify-start" onClick={() => navigate(`/senior-profile/${user.id}`)}><UserRound className="h-5 w-5" />My Profile</Button><Button variant="outline" className="min-h-16 justify-start" onClick={() => navigate("/settings")}><Settings className="h-5 w-5" />Settings & Alerts</Button><Button variant="outline" className="min-h-16 justify-start" onClick={() => navigate("/contact")}><Mail className="h-5 w-5" />Contact Reli</Button><div className="flex min-h-16 items-center justify-between gap-2 rounded-md border bg-background px-4"><FontSizeControl /><MotionPreference /></div><EmergencyButton seniorId={user.id} /><FamilyCircle seniorId={user.id} /><Button variant="outline" className="min-h-12 justify-start text-destructive hover:text-destructive" onClick={handleLogout}><LogOut className="h-5 w-5" />Logout</Button></div>}
            </section>
          )}

          {featureSettings.show_trivia && <DailyTrivia open={triviaOpen} onOpenChange={setTriviaOpen} />}
          <QuickMessageDialog open={messageDialogOpen} onOpenChange={setMessageDialogOpen} caregivers={caregivers} user={user} />
          <AlertDialog open={Boolean(messageToDelete)} onOpenChange={(open) => !open && setMessageToDelete(null)}>
            <AlertDialogContent><AlertDialogHeader><AlertDialogTitle>Delete this message?</AlertDialogTitle><AlertDialogDescription>This permanently removes the message from your list and cannot be undone.</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel disabled={deletingMessage}>Keep message</AlertDialogCancel><AlertDialogAction onClick={(event) => { event.preventDefault(); deleteMessage(); }} disabled={deletingMessage} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">{deletingMessage ? "Deleting…" : "Delete message"}</AlertDialogAction></AlertDialogFooter></AlertDialogContent>
          </AlertDialog>
        </main>
      </div>
      <BackToTop />
      <SeniorBottomNav items={navItems} active={activeTab} onChange={changeDestination} />
    </div>
  );
};

export default Dashboard;
