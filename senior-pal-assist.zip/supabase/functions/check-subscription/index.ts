import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@18.5.0";
import { createClient } from "npm:@supabase/supabase-js@2.57.2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const PAID_PRODUCT_IDS = [
  "prod_VGa2TZxenqsAvd", // Premium monthly
  "prod_VGa3caIZmDeTuH", // Premium annual
  "prod_VGa4X6nKpeFHrj", // Premium Plus monthly
  "prod_VGa4v4i27Gjouq", // Premium Plus annual
];

const logStep = (step: string, details?: unknown) => {
  console.log(`[CHECK-SUBSCRIPTION] ${step}${details ? ` - ${JSON.stringify(details)}` : ""}`);
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseAdmin = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
    { auth: { persistSession: false } }
  );

  try {
    logStep("Function started");

    const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");
    if (!stripeKey) throw new Error("STRIPE_SECRET_KEY is not set");

    const notSignedIn = () =>
      new Response(
        JSON.stringify({ subscribed: false, product_id: null, subscription_end: null, signed_in: false }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 200 }
      );

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      logStep("No session - returning free plan");
      return notSignedIn();
    }

    const token = authHeader.replace("Bearer ", "");
    const { data: userData, error: userError } = await supabaseAdmin.auth.getUser(token);
    const user = userData?.user;
    if (userError || !user?.email) {
      logStep("Invalid or missing session - returning free plan", { message: userError?.message });
      return notSignedIn();
    }
    logStep("User authenticated", { userId: user.id });

    const stripe = new Stripe(stripeKey, { apiVersion: "2025-08-27.basil" });
    const customers = await stripe.customers.list({ email: user.email, limit: 1 });

    let subscribed = false;
    let productId: string | null = null;
    let subscriptionEnd: string | null = null;

    if (customers.data.length > 0) {
      const customerId = customers.data[0].id;
      const subscriptions = await stripe.subscriptions.list({
        customer: customerId,
        status: "active",
        limit: 1,
      });
      if (subscriptions.data.length > 0) {
        const subscription = subscriptions.data[0];
        subscribed = true;
        subscriptionEnd = new Date(subscription.current_period_end * 1000).toISOString();
        productId = subscription.items.data[0].price.product as string;
        logStep("Active subscription found", { productId, subscriptionEnd });
      }
    }

    const isPaid = subscribed && productId !== null && PAID_PRODUCT_IDS.includes(productId);
    const { data: storeActive } = await supabaseAdmin.rpc("has_store_premium", { _user_id: user.id });
    const plan = isPaid || storeActive ? "premium" : "free";

    // Keep profiles.plan in sync so the rest of the app (usePlan) stays accurate.
    const { error: updateError } = await supabaseAdmin
      .from("profiles")
      .update({ plan })
      .eq("id", user.id);
    if (updateError) logStep("Plan sync error", { message: updateError.message });
    else logStep("Plan synced", { plan });

    return new Response(
      JSON.stringify({ subscribed: isPaid || Boolean(storeActive), store: storeActive ? "app_store" : null, product_id: productId, subscription_end: subscriptionEnd }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 200 }
    );
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    logStep("ERROR", { message });
    return new Response(JSON.stringify({ error: message }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});
