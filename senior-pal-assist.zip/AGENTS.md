# Project Architecture Rules

- Life Story photos use the private `life-story-images` bucket and store only object paths in story records, so senior and linked-caregiver access remains policy-controlled.
- Life Story structured categories are configured centrally in `LifeStoryMemories.tsx`, so forms, summaries, sharing, and PDF exports use the same labels and fields.
- Senior dashboard scenery uses eight location-aware compact mobile WebP phases, renders only the current phase, and preloads only the next phase to keep first-open loading fast.
- Family members join via `accept_circle_invite` RPC (single-use 7-day codes in `circle_invites`), reusing `caregiver_seniors` links so all existing access rules and plan limits apply.
- Family Circle emails are sent directly by the authenticated `send-circle-invite` function using the fixed managed-email template; the client supplies only an invite ID and recipient address.
- Emailed Family Circle links open /join/{code}; invitees must sign up or sign in with their own Reli account matching the invited email, then submit a request that a circle caregiver approves before any data is shared.
- Caregiver-managed seniors (no login) are real auth users with placeholder `@managed.reli.care` emails and `profiles.managed=true`, created/claimed via edge functions, so all existing RLS and links are reused; email helpers skip placeholder addresses.
- Senior and caregiver dashboards share the same Reli shell, scenic summary styling, and five-item bottom navigation; each role keeps its own destinations and features.
- Offline-cache service worker removed; public/sw.js is a kill-switch so deploys are never served stale.
- Dashboards are wrapped in RoleGuard, which reads the server-locked profiles.role; RLS + role-immutable trigger enforce it on the backend.
- Pattern journal (caregiver Care tab + senior My Life) stores observations in care_observations and merges medication_doses; local pattern logic lives in src/lib/carePatterns.ts, FDA label matching and AI "Ask" run in the care-pattern-insights function; all wording stays non-causal.

- SOS is one event per senior at a time: created/acked/cancelled only via `trigger_sos`/`acknowledge_sos`/`close_sos` RPCs (idempotent, unique open index), per-caregiver acks in `sos_acknowledgements`, push dedupe/retry in `sos_deliveries` keyed by event id via `notify-emergency`; one global `SosAlarm` overlay, so duplicates never create new alerts.- Native apps (`com.reli.care`) ship the bundled `dist` (no remote server URL); native-only code lives behind `isNativeApp()` in `src/lib/native.ts`, `/` shows the role picker on phones, so the website stays unchanged.
- Android SOS pushes are data-only and handled by `SosMessagingService` (full-screen alarm intent), replacing the Capacitor push service, so alarms ring while backgrounded.
- In-app subscriptions use RevenueCat with the single monthly product `com.reli.care.monthly`; `revenuecat-webhook` accepts only that product, writes `store_entitlements`, and Stripe sync never downgrades an active store subscriber, so one premium entitlement is shared across web and stores.
- Senior activity history is written server-side by the `activity_capture` triggers (data tables) and the `log_my_activity` RPC (app-only events) into `senior_activity_log` with a unique (senior_id, event_id), is read-only for everyone, and is shown by `SeniorActivityMonitor`, so events are real, deduplicated and visible only to the senior and linked caregivers.
- Native builds run on Codemagic from `codemagic.yaml` (build → `cap sync` → sign from Codemagic secrets), so no signing material or Firebase files are committed.
- Native and home-screen branding is generated from the high-resolution, clean-edged, text-free Reli heart masters in `assets/` via `npm run assets:generate`, keeping Android adaptive icons, iOS icons, splash screens, notification marks, and web icons consistent.
