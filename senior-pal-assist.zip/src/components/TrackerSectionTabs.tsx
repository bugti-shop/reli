import { Activity, Bell, ClipboardList, History, Pill } from "lucide-react";
import { Button } from "@/components/ui/button";

export type TrackerSection = "meds" | "vitals" | "reminders" | "history" | "custom";

const items = [
  { value: "meds" as const, label: "Meds", icon: Pill },
  { value: "vitals" as const, label: "Vitals", icon: Activity },
  { value: "reminders" as const, label: "Reminders", icon: Bell },
  { value: "history" as const, label: "History", icon: History },
  { value: "custom" as const, label: "Custom", icon: ClipboardList },
];

interface TrackerSectionTabsProps {
  active: TrackerSection;
  onChange: (value: TrackerSection) => void;
}

export function TrackerSectionTabs({ active, onChange }: TrackerSectionTabsProps) {
  return (
    <nav aria-label="Tracker sections" className="rounded-xl bg-dashboard-sky/70 px-1.5 pt-2 shadow-sm">
      <div className="grid grid-cols-5">
        {items.map(({ value, label, icon: Icon }) => {
          const selected = active === value;
          return (
            <Button
              key={value}
              type="button"
              variant="ghost"
              onClick={() => onChange(value)}
              aria-pressed={selected}
              className={`relative h-[4.4rem] min-w-0 flex-col gap-1 rounded-none px-0.5 text-[10px] hover:bg-transparent sm:text-xs ${
                selected ? "font-bold text-primary" : "font-medium text-muted-foreground"
              }`}
            >
              <Icon className="!h-6 !w-6" strokeWidth={selected ? 2.3 : 1.8} />
              <span className="w-full truncate text-center">{label}</span>
              {selected && <span className="absolute inset-x-2 bottom-0 h-1 rounded-full bg-primary" />}
            </Button>
          );
        })}
      </div>
    </nav>
  );
}