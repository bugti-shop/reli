# One-tap Family Circle invitations and approval

## What will change

- Update the Family Circle email invitation so the recipient can tap one secure link and Reli creates/signs in their family access automatically—no sign-up form or password required.
- Bind each emailed invitation to its recipient address so forwarded or copied links cannot be accepted by another account.
- After the recipient taps the link, create a **Requested** entry only; they will see a waiting-for-approval screen and will not receive access yet.
- Add a Family Circle management section to the caregiver dashboard for the selected senior:
  - **Requested**: name/email, request date, Approve, and Decline.
  - **Accepted**: family member, relationship, accepted date, and Remove access.
  - **Invited**: sent but not yet opened, with expiry and Cancel.
- Refresh the lists immediately after approval, decline, cancellation, or removal, with clear success and error messages.

## Security and access

- Keep invitations single-use and valid for seven days.
- Create passwordless family identities through Reli’s secure email-link flow; the email link proves ownership of the invited address.
- Perform request, approval, decline, and removal through protected server actions that verify the invitation, email address, selected senior, and current caregiver permissions.
- Do not grant health, SOS, or activity access until an authorized caregiver approves the request.
- Preserve existing account-based invite codes and linked caregiver accounts.

## Technical details

- Extend `circle_invites` with the invited email and request/decision timestamps while retaining its existing code and expiry.
- Replace immediate acceptance for emailed invites with a request state; approval creates the existing `caregiver_seniors` link so all current access rules, plan limits, alerts, and dashboard features continue to work.
- Generate the secure one-tap sign-in link inside the invitation sender and place it in the existing Reli-branded email.
- Add protected actions for requesting, approving, declining, cancelling, and removing Family Circle access.
- Add a focused caregiver dashboard component that reads invitation states and accepted members for the currently selected senior.

## Verification

- Send an invitation to an unused email and confirm the recipient reaches the Requested screen without seeing a sign-up form.
- Confirm a different email cannot use the invitation link.
- Approve the request from the caregiver dashboard and verify the recipient then sees the senior and existing shared features.
- Verify Decline, Cancel, Remove, expired-link, reused-link, and free-plan-limit states.
- Check the management list on mobile and desktop and confirm the app builds without errors.
