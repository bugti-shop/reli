# Family Circle + SOS Alarm

## 1. Family members
- A senior (or linked caregiver) can invite family by email or with an invite link/code.
- Family members sign up and join that senior's "circle" with a role: **Family (view only)** or **Caregiver (can edit)**.
- Family can see everything: meds taken, BP/HR, activity, journal (if the senior allows it), Life Story, alerts.
- The senior can see who is in their circle and remove anyone.
- Free plan: 2 people per senior. Premium: unlimited (same rule as today).

## 2. SOS alarm (no form)
- Pressing SOS sends the alert at once: no form, 5-second "Cancel" countdown only, so accidental taps can be stopped.
- Every circle member gets:
  - **Installed Android app:** full-screen ringing alarm (like a clock alarm), loud sound on a loop, vibration, and it rings through silent/Do Not Disturb once the user grants "Override Do Not Disturb" during setup.
  - **Installed iPhone app:** Critical Alert that rings through silent and Do Not Disturb. This needs Apple's approval for the Critical Alerts permission (you apply; it usually takes days to weeks). Until then, a normal time-sensitive notification with sound.
  - **Web / open app:** full-screen red alarm screen with sound on a loop.
  - Email as a backup (already exists), and SMS later if you add a provider.
- Alarm screen shows senior name, time, location (if shared), "I'm on my way" and "Call" buttons. When one person acknowledges, the others see who is responding.
- If nobody acknowledges within 2 minutes, the alert is sent again.

## What you need to provide
1. Firebase project (free): Android `google-services.json`, iOS APNs key, and a Firebase server key for the backend.
2. Apple Developer account + a Critical Alerts entitlement request to Apple.
3. Build the phone app with Capacitor (already configured) through Android Studio / Xcode. Alarms outside the app don't work in the preview.

## 3. Other suggested backend features
- Missed-medication alert to family after 30 minutes
- Abnormal BP/HR alert (e.g. above 160/100)
- "No activity today" check-in alert
- Weekly family wellness email report
- Location sharing at SOS time
- Fall detection (phone sensors, later)
- Appointment calendar with reminders
- Activity audit log (who viewed or changed what)

## Technical details
- New `circle_invites` table (token, email, role, expiry) plus a `relationship`/`access_level` column on `caregiver_seniors`; RLS lets view-only members read but not write.
- `emergency_alerts` gains `location`, `responders` jsonb; realtime subscription drives the in-app alarm screen.
- Edge function `send-sos` sends FCM data messages (Android high-priority channel with `bypassDnd`, full-screen intent) and APNs `interruption-level: critical` payloads; retries after 2 minutes if unacknowledged.
- Capacitor: `@capacitor/push-notifications`, a native Android notification channel + full-screen activity, and the iOS critical-alert entitlement. The `push_tokens` table already exists.
- Build order: Family Circle, then in-app/web alarm, then native push (once Firebase keys are added).
