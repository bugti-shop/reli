import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { HeartHandshake, User } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import reliLogo from "@/assets/reli-logo.png";

/**
 * Phone-app start screen: no marketing, just pick a role. Signed-in users
 * go straight to the dashboard their account is locked to.
 */
const NativeStart = () => {
  const navigate = useNavigate();
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    (async () => {
      const { data } = await supabase.auth.getSession();
      const user = data.session?.user;
      if (user) {
        const { data: profile } = await supabase.from("profiles").select("role").eq("id", user.id).maybeSingle();
        if (profile?.role === "caregiver") return navigate("/caregiver", { replace: true });
        if (profile?.role === "senior") return navigate("/dashboard", { replace: true });
      }
      setChecking(false);
    })();
  }, [navigate]);

  if (checking) {
    return <div className="min-h-screen bg-background" aria-busy="true" />;
  }

  return (
    <main className="min-h-screen bg-background flex flex-col px-6 pt-[max(3rem,env(safe-area-inset-top))] pb-[max(2rem,env(safe-area-inset-bottom))]">
      <div className="flex flex-col items-center text-center mt-6 mb-10">
        <img src={reliLogo} alt="Reli" className="h-14 w-auto mb-6" />
        <h1 className="text-3xl font-bold text-foreground">Welcome to Reli</h1>
        <p className="mt-2 text-lg text-muted-foreground">Who is using this phone?</p>
      </div>

      <div className="flex flex-col gap-4">
        <button
          onClick={() => navigate("/auth?role=caregiver")}
          className="flex items-center gap-4 rounded-3xl border-2 border-border bg-card p-6 text-left shadow-sm active:scale-[0.98] transition-transform focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-ring"
        >
          <span className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-primary/10 text-primary">
            <HeartHandshake className="h-8 w-8" />
          </span>
          <span>
            <span className="block text-2xl font-bold text-foreground">Caregiver</span>
            <span className="block text-base text-muted-foreground">I look after a loved one</span>
          </span>
        </button>

        <button
          onClick={() => navigate("/auth?role=senior")}
          className="flex items-center gap-4 rounded-3xl border-2 border-border bg-card p-6 text-left shadow-sm active:scale-[0.98] transition-transform focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-ring"
        >
          <span className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-accent/15 text-accent-foreground">
            <User className="h-8 w-8" />
          </span>
          <span>
            <span className="block text-2xl font-bold text-foreground">Senior / Myself</span>
            <span className="block text-base text-muted-foreground">I'm using Reli for me</span>
          </span>
        </button>
      </div>
    </main>
  );
};

export default NativeStart;
