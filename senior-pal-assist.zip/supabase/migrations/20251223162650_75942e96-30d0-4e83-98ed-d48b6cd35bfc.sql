-- Add explicit DENY policies for anonymous access on all tables
-- This provides defense-in-depth even though RESTRICTIVE policies already block anon

-- profiles table
CREATE POLICY "deny_anon_access_profiles"
  ON public.profiles
  AS RESTRICTIVE
  FOR ALL
  TO anon
  USING (false);

-- caregiver_seniors table
CREATE POLICY "deny_anon_access_caregiver_seniors"
  ON public.caregiver_seniors
  AS RESTRICTIVE
  FOR ALL
  TO anon
  USING (false);

-- caregiver_messages table
CREATE POLICY "deny_anon_access_caregiver_messages"
  ON public.caregiver_messages
  AS RESTRICTIVE
  FOR ALL
  TO anon
  USING (false);

-- senior_activity_log table
CREATE POLICY "deny_anon_access_senior_activity_log"
  ON public.senior_activity_log
  AS RESTRICTIVE
  FOR ALL
  TO anon
  USING (false);

-- senior_feature_settings table
CREATE POLICY "deny_anon_access_senior_feature_settings"
  ON public.senior_feature_settings
  AS RESTRICTIVE
  FOR ALL
  TO anon
  USING (false);

-- senior_reminders table
CREATE POLICY "deny_anon_access_senior_reminders"
  ON public.senior_reminders
  AS RESTRICTIVE
  FOR ALL
  TO anon
  USING (false);

-- life_story_entries table
CREATE POLICY "deny_anon_access_life_story_entries"
  ON public.life_story_entries
  AS RESTRICTIVE
  FOR ALL
  TO anon
  USING (false);

-- custom_trackers table
CREATE POLICY "deny_anon_access_custom_trackers"
  ON public.custom_trackers
  AS RESTRICTIVE
  FOR ALL
  TO anon
  USING (false);

-- site_admins table
CREATE POLICY "deny_anon_access_site_admins"
  ON public.site_admins
  AS RESTRICTIVE
  FOR ALL
  TO anon
  USING (false);

-- newsletter_subscribers - keep INSERT open for anon but deny other operations
CREATE POLICY "deny_anon_select_newsletter"
  ON public.newsletter_subscribers
  AS RESTRICTIVE
  FOR SELECT
  TO anon
  USING (false);

CREATE POLICY "deny_anon_update_newsletter"
  ON public.newsletter_subscribers
  AS RESTRICTIVE
  FOR UPDATE
  TO anon
  USING (false);

CREATE POLICY "deny_anon_delete_newsletter"
  ON public.newsletter_subscribers
  AS RESTRICTIVE
  FOR DELETE
  TO anon
  USING (false);