-- Trigger keeps role/plan immutable without policies querying profiles (which caused recursion)
CREATE OR REPLACE FUNCTION public.protect_profile_role_plan()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.role := OLD.role;
  NEW.plan := OLD.plan;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS protect_profile_role_plan_trigger ON public.profiles;
CREATE TRIGGER protect_profile_role_plan_trigger
BEFORE UPDATE ON public.profiles
FOR EACH ROW EXECUTE FUNCTION public.protect_profile_role_plan();

DROP POLICY IF EXISTS "Users can update their own profile" ON public.profiles;
CREATE POLICY "Users can update their own profile"
ON public.profiles FOR UPDATE TO authenticated
USING (auth.uid() = id)
WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "Caregivers can update their seniors profiles" ON public.profiles;
CREATE POLICY "Caregivers can update their seniors profiles"
ON public.profiles FOR UPDATE TO authenticated
USING (EXISTS (
  SELECT 1 FROM public.caregiver_seniors cs
  WHERE cs.senior_id = profiles.id AND cs.caregiver_id = auth.uid()
))
WITH CHECK (EXISTS (
  SELECT 1 FROM public.caregiver_seniors cs
  WHERE cs.senior_id = profiles.id AND cs.caregiver_id = auth.uid()
));