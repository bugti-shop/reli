// Shared helper: sends instant push notifications through Firebase Cloud
// Messaging via the Lovable connector gateway. No-ops safely (without
// throwing) when Firebase is not connected yet.

import type { NotifyEvent } from './notify-recipient.ts'

const GATEWAY_URL = 'https://connector-gateway.lovable.dev/firebase_messaging'

export interface PushPayload {
  title: string
  body: string
  /** In-app path to open when the notification is tapped. */
  path?: string
  /** SOS alarm: max priority, alarm channel on Android, Critical Alert on iOS. */
  urgent?: boolean
  /** Extra data fields delivered to the app (e.g. alert_id). */
  data?: Record<string, string>
  /** Same key = the OS replaces instead of stacking duplicates. */
  collapseKey?: string
  /** Override data.type (e.g. 'sos_cancel'). */
  type?: string
}

/**
 * Sends a push notification to every device a user has registered, honoring
 * their saved push preferences. Returns how many devices were reached.
 * Stale device tokens are removed automatically.
 */
export async function sendPushToUser(
  admin: any,
  userId: string,
  event: NotifyEvent,
  payload: PushPayload,
): Promise<number> {
  const lovableKey = Deno.env.get('LOVABLE_API_KEY')
  const connectionKey = Deno.env.get('FIREBASE_MESSAGING_API_KEY')

  if (!lovableKey || !connectionKey) {
    console.log('[push] skipped: Firebase is not connected yet')
    return 0
  }

  const { data: prefs } = await admin
    .from('notification_preferences')
    .select('push_enabled, notify_emergency, notify_messages, notify_reminders, notify_daily_summary')
    .eq('user_id', userId)
    .maybeSingle()

  // Push is opt-in: without saved preferences we do not send.
  // SOS alarms ring any registered device unless emergency alerts were switched off.
  if (!payload.urgent && payload.type !== 'sos_cancel' && (!prefs || prefs.push_enabled !== true)) return 0
  if (prefs && prefs[event] === false) return 0

  const { data: tokens } = await admin
    .from('push_tokens')
    .select('id, token')
    .eq('user_id', userId)

  if (!tokens || tokens.length === 0) return 0

  let delivered = 0

  for (const row of tokens) {
    try {
      const response = await fetch(`${GATEWAY_URL}/v1/projects/_/messages:send`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${lovableKey}`,
          'X-Connection-Api-Key': connectionKey,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify((() => {
          const title = payload.title.slice(0, 120)
          const body = payload.body.slice(0, 400)
          const type = payload.type || (payload.urgent ? 'sos' : 'info')
          const data = { ...(payload.data || {}), path: payload.path || '/dashboard', type, title, body }
          // SOS alarms/cancels are data-only on Android so the native Reli
          // service can post a full-screen alarm (or dismiss it) even when the
          // app is in the background; iOS and web get a visible alert block.
          const sosKind = payload.urgent || type === 'sos_cancel'
          return { message: {
            token: row.token,
            ...(sosKind ? {} : { notification: { title, body } }),
            data,
            ...(sosKind
              ? {
                  android: {
                    priority: 'HIGH',
                    ttl: '900s',
                    ...(payload.collapseKey ? { collapse_key: payload.collapseKey } : {}),
                  },
                  apns: {
                    headers: {
                      'apns-priority': '10',
                      'apns-push-type': 'alert',
                      ...(payload.collapseKey ? { 'apns-collapse-id': payload.collapseKey.slice(0, 64) } : {}),
                    },
                    payload: {
                      aps: payload.urgent
                        ? {
                            alert: { title, body },
                            sound: { critical: 1, name: 'sos_alarm.wav', volume: 1.0 },
                            'interruption-level': 'critical',
                            category: 'SOS_ALARM',
                          }
                        : { alert: { title, body }, sound: 'default' },
                    },
                  },
                  webpush: {
                    headers: { Urgency: 'high' },
                    notification: { title, body, requireInteraction: payload.urgent === true },
                  },
                }
              : {}),
          } }
        })()),
      })

      if (response.ok) {
        delivered++
        continue
      }

      const errorBody = await response.text()
      console.error(`[push] send failed [${response.status}]: ${errorBody}`)

      // A stale registration: drop it so we stop retrying it forever.
      if (response.status === 404 || response.status === 400) {
        await admin.from('push_tokens').delete().eq('id', row.id)
      }
    } catch (e) {
      console.error('[push] send threw', e)
    }
  }

  return delivered
}
