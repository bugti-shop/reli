export type Obs = {
  id: string;
  category: string;
  label: string;
  intensity: number | null;
  value_num: number | null;
  location: string | null;
  environment: string[];
  notes: string | null;
  observed_at: string;
};

export const EPISODE_CATS = ["symptom", "behavior"];
const HOUR = 3600_000;
const t = (o: Obs) => new Date(o.observed_at).getTime();
const fmtHour = (h: number) => {
  const hh = ((h + 11) % 12) + 1;
  return `${hh}:00 ${h < 12 || h === 24 ? "AM" : "PM"}`;
};

export type Pattern = { title: string; detail: string; strength: number };

/** Observational, non-causal pattern detection over caregiver records. */
export function detectPatterns(all: Obs[]): Pattern[] {
  const out: Pattern[] = [];
  const episodes = all.filter((o) => EPISODE_CATS.includes(o.category));
  const byLabel = new Map<string, Obs[]>();
  episodes.forEach((e) => byLabel.set(e.label, [...(byLabel.get(e.label) || []), e]));

  const naps = all.filter((o) => o.category === "sleep" && /nap/i.test(o.label));
  const nights = all.filter((o) => o.category === "sleep" && !/nap/i.test(o.label) && o.value_num != null);
  const meds = all.filter((o) => o.category === "medication");
  const intake = all.filter((o) => o.category === "food" || o.category === "activity");

  for (const [label, evs] of byLabel) {
    const recent = [...evs].sort((a, b) => t(b) - t(a)).slice(0, 10);
    const n = recent.length;
    if (n < 3) continue;
    const name = label.toLowerCase();

    // Time-of-day clustering within a 2-hour window
    let best = { start: 0, count: 0 };
    for (let h = 0; h < 24; h++) {
      const c = recent.filter((e) => {
        const x = new Date(e.observed_at).getHours();
        return x === h || x === (h + 1) % 24;
      }).length;
      if (c > best.count) best = { start: h, count: c };
    }
    if (best.count >= 3 && best.count / n >= 0.6)
      out.push({
        title: `${label}: similar time of day`,
        detail: `Possible pattern: ${best.count} of the last ${n} ${name} records were between ${fmtHour(best.start)} and ${fmtHour(best.start + 2)}.`,
        strength: best.count / n,
      });

    const after = (src: Obs[], winH: number, test: (s: Obs) => boolean = () => true) =>
      recent.filter((e) => src.some((s) => test(s) && t(e) - t(s) >= 0 && t(e) - t(s) <= winH * HOUR)).length;

    const longNap = after(naps, 4, (s) => (s.value_num ?? 0) >= 2);
    if (longNap >= 3)
      out.push({ title: `${label} after long naps`, detail: `Possible pattern: ${longNap} of the last ${n} ${name} records occurred within 4 hours after a nap longer than 2 hours.`, strength: longNap / n });

    const shortSleep = recent.filter((e) =>
      nights.some((s) => (s.value_num ?? 99) < 6 && t(e) - t(s) >= 0 && t(e) - t(s) <= 20 * HOUR),
    ).length;
    if (shortSleep >= 3)
      out.push({ title: `${label} after short sleep`, detail: `Possible pattern: on ${shortSleep} occasions, ${name} was recorded on a day after less than 6 hours of sleep.`, strength: shortSleep / n });

    const medNear = after(meds, 1);
    if (medNear >= 3)
      out.push({ title: `${label} near medication time`, detail: `Possible pattern: ${name} was recorded within 1 hour after medication on ${medNear} occasions. Worth discussing with the care team.`, strength: medNear / n });

    const intakeCounts = new Map<string, number>();
    recent.forEach((e) => {
      const seen = new Set<string>();
      intake.forEach((s) => { if (t(e) - t(s) >= 0 && t(e) - t(s) <= 3 * HOUR) seen.add(s.label); });
      seen.forEach((l) => intakeCounts.set(l, (intakeCounts.get(l) || 0) + 1));
    });
    intakeCounts.forEach((c, l) => {
      if (c >= 3) out.push({ title: `${label} after ${l.toLowerCase()}`, detail: `Possible pattern: ${l} was recorded in the 3 hours before ${c} of the last ${n} ${name} records.`, strength: c / n });
    });

    const tally = (vals: (string | null | undefined)[]) => {
      const m = new Map<string, number>();
      vals.filter(Boolean).forEach((v) => m.set(v!, (m.get(v!) || 0) + 1));
      return [...m.entries()].sort((a, b) => b[1] - a[1])[0];
    };
    const loc = tally(recent.map((e) => e.location));
    if (loc && loc[1] >= 3 && loc[1] / n >= 0.5)
      out.push({ title: `${label} in the ${loc[0].toLowerCase()}`, detail: `Possible pattern: ${loc[1]} of the last ${n} ${name} records happened in the ${loc[0].toLowerCase()}.`, strength: loc[1] / n });
    const env = tally(recent.flatMap((e) => e.environment || []));
    if (env && env[1] >= 3 && env[1] / n >= 0.5)
      out.push({ title: `${label} with ${env[0].toLowerCase()}`, detail: `Possible pattern: "${env[0]}" was noted alongside ${env[1]} of the last ${n} ${name} records. These frequently occurred together.`, strength: env[1] / n });
  }
  return out.sort((a, b) => b.strength - a.strength);
}

export function careSummary(all: Obs[], days: number, name: string): string {
  const since = Date.now() - days * 24 * HOUR;
  const rows = all.filter((o) => t(o) >= since);
  if (!rows.length) return `No observations were recorded for ${name} in the last ${days} days.`;
  const lines: string[] = [`Care observations for ${name} — last ${days} days (${rows.length} records).`];
  const eps = rows.filter((o) => EPISODE_CATS.includes(o.category));
  const counts = new Map<string, Obs[]>();
  eps.forEach((e) => counts.set(e.label, [...(counts.get(e.label) || []), e]));
  [...counts.entries()].sort((a, b) => b[1].length - a[1].length).forEach(([l, list]) => {
    const evening = list.filter((e) => { const h = new Date(e.observed_at).getHours(); return h >= 17 && h < 21; }).length;
    const avg = list.filter((e) => e.intensity).reduce((s, e, _, a) => s + (e.intensity || 0) / a.length, 0);
    lines.push(`• ${list.length} record(s) of ${l.toLowerCase()}${evening ? `; ${evening} between 5 PM and 9 PM` : ""}${avg ? `; average intensity ${avg.toFixed(1)}/5` : ""}.`);
  });
  const nights = rows.filter((o) => o.category === "sleep" && !/nap/i.test(o.label) && o.value_num != null);
  if (nights.length) {
    const avg = nights.reduce((s, n) => s + Number(n.value_num), 0) / nights.length;
    lines.push(`• Night sleep recorded ${nights.length} time(s), average ${avg.toFixed(1)} hours; ${nights.filter((n) => Number(n.value_num) < 6).length} night(s) under 6 hours.`);
  }
  const moods = rows.filter((o) => o.category === "mood");
  if (moods.length) {
    const m = new Map<string, number>(); moods.forEach((o) => m.set(o.label, (m.get(o.label) || 0) + 1));
    lines.push(`• Moods noted: ${[...m.entries()].sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k.toLowerCase()} (${v})`).join(", ")}.`);
  }
  const pats = detectPatterns(rows);
  if (pats.length) { lines.push("", "Possible patterns (observational, not a diagnosis):"); pats.slice(0, 6).forEach((p) => lines.push(`• ${p.detail}`)); }
  lines.push("", "These are caregiver observations to discuss with the care team. They do not show cause or diagnosis.");
  return lines.join("\n");
}
