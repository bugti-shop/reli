-- Medication dose history
CREATE TABLE public.medication_doses (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  medication_id uuid NOT NULL REFERENCES public.medications(id) ON DELETE CASCADE,
  senior_id uuid NOT NULL,
  medication_name text NOT NULL,
  scheduled_time text,
  dosage text,
  taken_at timestamp with time zone NOT NULL DEFAULT now(),
  taken_by uuid NOT NULL,
  taken_by_role text NOT NULL,
  notes text,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

CREATE INDEX medication_doses_senior_taken_idx ON public.medication_doses (senior_id, taken_at DESC);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.medication_doses TO authenticated;
GRANT ALL ON public.medication_doses TO service_role;

ALTER TABLE public.medication_doses ENABLE ROW LEVEL SECURITY;

CREATE POLICY "View medication doses" ON public.medication_doses
FOR SELECT TO authenticated USING (
  senior_id = auth.uid()
  OR EXISTS (SELECT 1 FROM public.caregiver_seniors cs WHERE cs.senior_id = medication_doses.senior_id AND cs.caregiver_id = auth.uid())
);

CREATE POLICY "Add medication doses" ON public.medication_doses
FOR INSERT TO authenticated WITH CHECK (
  taken_by = auth.uid()
  AND (
    senior_id = auth.uid()
    OR EXISTS (SELECT 1 FROM public.caregiver_seniors cs WHERE cs.senior_id = medication_doses.senior_id AND cs.caregiver_id = auth.uid())
  )
);

CREATE POLICY "Delete medication doses" ON public.medication_doses
FOR DELETE TO authenticated USING (
  taken_by = auth.uid()
  OR senior_id = auth.uid()
  OR EXISTS (SELECT 1 FROM public.caregiver_seniors cs WHERE cs.senior_id = medication_doses.senior_id AND cs.caregiver_id = auth.uid())
);

CREATE POLICY "deny_anon_access_medication_doses" ON public.medication_doses
AS RESTRICTIVE FOR ALL TO anon USING (false);

-- Reminder times for trackers
CREATE TABLE public.tracker_reminders (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  senior_id uuid NOT NULL,
  owner_id uuid NOT NULL,
  created_by_role text NOT NULL,
  kind text NOT NULL,
  label text,
  time text NOT NULL,
  enabled boolean NOT NULL DEFAULT true,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

CREATE INDEX tracker_reminders_senior_idx ON public.tracker_reminders (senior_id, kind);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.tracker_reminders TO authenticated;
GRANT ALL ON public.tracker_reminders TO service_role;

ALTER TABLE public.tracker_reminders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "View tracker reminders" ON public.tracker_reminders
FOR SELECT TO authenticated USING (
  senior_id = auth.uid()
  OR EXISTS (SELECT 1 FROM public.caregiver_seniors cs WHERE cs.senior_id = tracker_reminders.senior_id AND cs.caregiver_id = auth.uid())
);

CREATE POLICY "Create tracker reminders" ON public.tracker_reminders
FOR INSERT TO authenticated WITH CHECK (
  owner_id = auth.uid()
  AND (
    senior_id = auth.uid()
    OR EXISTS (SELECT 1 FROM public.caregiver_seniors cs WHERE cs.senior_id = tracker_reminders.senior_id AND cs.caregiver_id = auth.uid())
  )
);

CREATE POLICY "Update tracker reminders" ON public.tracker_reminders
FOR UPDATE TO authenticated USING (
  senior_id = auth.uid()
  OR EXISTS (SELECT 1 FROM public.caregiver_seniors cs WHERE cs.senior_id = tracker_reminders.senior_id AND cs.caregiver_id = auth.uid())
);

CREATE POLICY "Delete tracker reminders" ON public.tracker_reminders
FOR DELETE TO authenticated USING (
  owner_id = auth.uid()
  OR senior_id = auth.uid()
);

CREATE POLICY "deny_anon_access_tracker_reminders" ON public.tracker_reminders
AS RESTRICTIVE FOR ALL TO anon USING (false);

CREATE TRIGGER update_tracker_reminders_updated_at
BEFORE UPDATE ON public.tracker_reminders
FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

-- Validation trigger for kind values
CREATE OR REPLACE FUNCTION public.validate_tracker_reminder()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.kind NOT IN ('medication', 'blood_pressure', 'heart_rate') THEN
    RAISE EXCEPTION 'Invalid reminder kind: %', NEW.kind;
  END IF;
  IF NEW.time !~ '^([01][0-9]|2[0-3]):[0-5][0-9]$' THEN
    RAISE EXCEPTION 'Invalid reminder time: %', NEW.time;
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER validate_tracker_reminder_trigger
BEFORE INSERT OR UPDATE ON public.tracker_reminders
FOR EACH ROW EXECUTE FUNCTION public.validate_tracker_reminder();