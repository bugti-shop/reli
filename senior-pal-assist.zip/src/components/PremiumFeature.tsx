import { ReactNode } from "react";
import { Link } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Sparkles, Lock } from "lucide-react";
import { usePlan } from "@/hooks/use-plan";

interface PremiumFeatureProps {
  name: string;
  description?: string;
  userId: string;
  children: ReactNode;
}

/**
 * Gates a premium feature behind the user's plan. Free users see an
 * upgrade prompt instead of the feature.
 */
export const PremiumFeature = ({ name, description, userId, children }: PremiumFeatureProps) => {
  const { plan, isPremium } = usePlan(userId);

  if (plan === null) return null;

  if (!isPremium) {
    return (
      <Card className="p-6 border-2 border-primary/40 bg-primary/5">
        <div className="flex flex-col sm:flex-row sm:items-center gap-4">
          <div className="flex items-start gap-3 flex-1">
            <Lock className="w-6 h-6 text-primary mt-0.5 flex-shrink-0" />
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-xl font-semibold text-foreground">{name}</h3>
                <Badge className="bg-primary text-primary-foreground">Premium</Badge>
              </div>
              <p className="text-base text-muted-foreground mt-1">
                {description || `${name} is a Premium feature.`}
              </p>
            </div>
          </div>
          <Button asChild className="sm:self-center">
            <Link to="/pricing">
              <Sparkles className="w-4 h-4 mr-2" />
              Upgrade to unlock
            </Link>
          </Button>
        </div>
      </Card>
    );
  }

  return <>{children}</>;
};
