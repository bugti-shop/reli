REVOKE ALL ON FUNCTION public.enforce_senior_limit() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.enforce_senior_limit() FROM anon;
REVOKE ALL ON FUNCTION public.enforce_senior_limit() FROM authenticated;
REVOKE ALL ON FUNCTION public.has_effective_premium(uuid) FROM anon;