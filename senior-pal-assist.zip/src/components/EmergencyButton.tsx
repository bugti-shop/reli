import { useCallback, useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { AlertTriangle, CheckCircle2, Clock, Loader2, MapPin, Phone } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { isOnline } from "@/lib/offlineQueue";
import { getSosFix, watchSosFix, type SosFix } from "@/lib/sosLocation";

interface EmergencyButtonProps {
  seniorId: string;
  /** "header" renders the round dark-red phone button used in the dashboard header. */
  variant?: "default" | "header";
}

interface ActiveSos {
  id: string;
  status: string;
  created_at: string;
  latitude: number | null;
  accuracy_m: number | null;
}

interface CaregiverStatus {
  id: string;
  name: string;
  acknowledgedAt: string | null;
}

const OPEN = ["active", "partially_acknowledged", "acknowledged"];
const RETRY_MS = 45000;
const COOLDOWN_MS = 4000;

const statusLabel: Record<string, string> = {
  active: "Waiting for family",
  partially_acknowledged: "Partially acknowledged",
  acknowledged: "Everyone acknowledged",
};

export const EmergencyButton = ({ seniorId, variant = "default" }: EmergencyButtonProps) => {
  const [sos, setSos] = useState<ActiveSos | null>(null);
  const [open, setOpen] = useState(false);
  const [sending, setSending] = useState(false);
  const [caregivers, setCaregivers] = useState<CaregiverStatus[]>([]);
  const [liveLocation, setLiveLocation] = useState(true);
  const [locationState, setLocationState] = useState<"pending" | "found" | "none">("pending");
  const busy = useRef(false);
  const lastTap = useRef(0);
  const { toast } = useToast();

  const loadStatus = useCallback(
    async (alertId: string) => {
      const [{ data: links }, { data: acks }] = await Promise.all([
        supabase
          .from("caregiver_seniors")
          .select("caregiver_id, caregiver:profiles!caregiver_seniors_caregiver_id_fkey(full_name)")
          .eq("senior_id", seniorId),
        supabase.from("sos_acknowledgements").select("caregiver_id, acknowledged_at").eq("alert_id", alertId),
      ]);
      const ackMap = new Map((acks || []).map((a) => [a.caregiver_id, a.acknowledged_at]));
      setCaregivers(
        (links || []).map((l: any) => ({
          id: l.caregiver_id,
          name: l.caregiver?.full_name || "Family member",
          acknowledgedAt: ackMap.get(l.caregiver_id) ?? null,
        })),
      );
    },
    [seniorId],
  );

  // Restore an SOS that is still open (e.g. app reopened).
  useEffect(() => {
    supabase
      .from("emergency_alerts")
      .select("id, status, created_at, latitude, accuracy_m")
      .eq("senior_id", seniorId)
      .in("status", OPEN)
      .order("created_at", { ascending: false })
      .limit(1)
      .then(({ data }) => {
        if (data?.[0]) {
          setSos(data[0] as ActiveSos);
          setLocationState(data[0].latitude != null ? "found" : "none");
        }
      });
  }, [seniorId]);

  // Realtime status + acknowledgements for the open SOS.
  useEffect(() => {
    if (!sos?.id) return;
    loadStatus(sos.id);
    const channel = supabase
      .channel(`sos-senior-${sos.id}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "sos_acknowledgements", filter: `alert_id=eq.${sos.id}` }, () =>
        loadStatus(sos.id),
      )
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "emergency_alerts", filter: `id=eq.${sos.id}` }, (p) => {
        const row = p.new as ActiveSos;
        if (!OPEN.includes(row.status)) {
          setSos(null);
          setOpen(false);
          return;
        }
        setSos((s) => (s ? { ...s, ...row } : s));
      })
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [sos?.id, loadStatus]);

  // Retry delivery (same SOS id) for family phones that were offline.
  useEffect(() => {
    if (!sos?.id || sos.status === "acknowledged") return;
    const t = window.setInterval(() => {
      supabase.functions.invoke("notify-emergency", { body: { alertId: sos.id, action: "alarm" } }).catch(() => undefined);
    }, RETRY_MS);
    return () => window.clearInterval(t);
  }, [sos?.id, sos?.status]);

  // Live location while the SOS is open — starts automatically, stops when the SOS closes.
  useEffect(() => {
    if (!sos?.id || !liveLocation) return;
    let last = 0;
    return watchSosFix((f) => {
      if (Date.now() - last < 5000) return;
      last = Date.now();
      supabase.rpc("update_sos_location", {
        _alert_id: sos.id,
        _lat: f.latitude,
        _lng: f.longitude,
        _accuracy: f.accuracy ?? undefined,
        _captured_at: f.capturedAt,
      });
    });
  }, [sos?.id, liveLocation]);

  const pushLocation = async (alertId: string, fix: SosFix | null) => {
    if (!fix) return setLocationState("none");
    const { error } = await supabase.rpc("update_sos_location", {
      _alert_id: alertId,
      _lat: fix.latitude,
      _lng: fix.longitude,
      _accuracy: fix.accuracy ?? undefined,
      _captured_at: fix.capturedAt,
    });
    setLocationState(error ? "none" : "found");
  };

  /** One tap = SOS. Repeated taps reopen the existing SOS instead of creating another. */
  const trigger = async () => {
    const now = Date.now();
    if (sos) return setOpen(true);
    if (busy.current || now - lastTap.current < COOLDOWN_MS) return setOpen(true);
    lastTap.current = now;
    busy.current = true;
    void import("@/lib/native").then((m) => m.buzz("tap"));

    if (!isOnline()) {
      busy.current = false;
      toast({
        title: "No internet — call for help by phone",
        description: "Your family cannot be alerted without a connection. Please call them, or call 911.",
        variant: "destructive",
      });
      return;
    }

    setSending(true);
    setOpen(true);
    setLocationState("pending");
    const fixPromise = getSosFix();
    const requestId = crypto.randomUUID();

    // Retry the create call on network errors — the request id makes it idempotent.
    let result: { alert_id: string; is_new: boolean } | null = null;
    for (let i = 0; i < 3 && !result; i++) {
      const { data, error } = await supabase.rpc("trigger_sos", { _request_id: requestId });
      if (!error && data?.[0]) result = data[0];
      else if (i < 2) await new Promise((r) => setTimeout(r, 800));
    }
    setSending(false);
    busy.current = false;

    if (!result) {
      setOpen(false);
      toast({ title: "Could not send SOS", description: "Please call your family or 911 now.", variant: "destructive" });
      return;
    }

    setSos({ id: result.alert_id, status: "active", created_at: new Date().toISOString(), latitude: null, accuracy_m: null });
    supabase.functions.invoke("notify-emergency", { body: { alertId: result.alert_id, action: "alarm" } }).catch(() => undefined);
    fixPromise.then((fix) => pushLocation(result!.alert_id, fix));
  };

  const cancel = async () => {
    if (!sos) return;
    const { error } = await supabase.rpc("close_sos", { _alert_id: sos.id, _outcome: "cancelled" });
    if (error) {
      toast({ title: "Could not cancel", description: error.message, variant: "destructive" });
      return;
    }
    supabase.functions.invoke("notify-emergency", { body: { alertId: sos.id, action: "cancel" } }).catch(() => undefined);
    toast({ title: "SOS cancelled", description: "Your family has been told you are okay." });
    setSos(null);
    setOpen(false);
    setLiveLocation(true);
  };

  const pending = caregivers.filter((c) => !c.acknowledgedAt);
  const active = Boolean(sos);

  return (
    <>
      {variant === "header" ? (
        <Button
          onClick={trigger}
          variant="ghost"
          className="h-auto flex-col gap-0.5 rounded-xl px-1.5 py-0.5 text-destructive md:gap-1 md:px-2 md:py-1"
          aria-label={active ? "SOS active — view status" : "SOS Emergency — ring my family now"}
        >
          <span
            className={`flex h-[42px] w-[42px] items-center justify-center rounded-full bg-destructive text-destructive-foreground shadow-sm md:h-[62px] md:w-[62px] ${active ? "animate-pulse ring-4 ring-destructive/40" : ""}`}
          >
            <Phone className="h-[26px] w-[26px] fill-current md:h-[34px] md:w-[34px]" />
          </span>
          <span className="whitespace-nowrap text-[9px] font-semibold leading-tight md:text-xs">
            {active ? "SOS Active" : "SOS Emergency"}
          </span>
        </Button>
      ) : (
        <Button onClick={trigger} variant="destructive" size="sm" className="gap-1.5 font-semibold shadow-sm" aria-label="Emergency — ring my family">
          <AlertTriangle className="w-4 h-4" />
          <span className="hidden sm:inline">{active ? "SOS Active" : "Emergency"}</span>
        </Button>
      )}

      <Dialog open={open} onOpenChange={(o) => !sending && setOpen(o)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center text-2xl text-destructive">
              {sending ? "Sending SOS…" : "SOS sent to your family"}
            </DialogTitle>
            <DialogDescription className="text-center text-base">
              {sending ? "Ringing every family member's phone now." : statusLabel[sos?.status ?? "active"]}
            </DialogDescription>
          </DialogHeader>

          {sending ? (
            <div className="mx-auto flex h-24 w-24 items-center justify-center rounded-full bg-destructive text-destructive-foreground">
              <Loader2 className="h-10 w-10 animate-spin" />
            </div>
          ) : (
            <div className="space-y-4">
              <ul className="space-y-2" aria-live="polite">
                {caregivers.length === 0 && (
                  <li className="rounded-xl bg-muted p-3 text-sm">No family members are connected yet. Please call 911 or a neighbour.</li>
                )}
                {caregivers.map((c) => (
                  <li key={c.id} className="flex items-center justify-between rounded-xl bg-muted p-3">
                    <span className="font-semibold">{c.name}</span>
                    {c.acknowledgedAt ? (
                      <span className="flex items-center gap-1 text-sm font-semibold text-primary">
                        <CheckCircle2 className="h-4 w-4" /> Acknowledged{" "}
                        {new Date(c.acknowledgedAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 text-sm text-muted-foreground">
                        <Clock className="h-4 w-4" /> Pending
                      </span>
                    )}
                  </li>
                ))}
              </ul>
              {pending.length > 0 && caregivers.length > 0 && (
                <p className="text-center text-sm text-muted-foreground">Still ringing {pending.length} phone{pending.length > 1 ? "s" : ""}…</p>
              )}

              <div className="flex items-start gap-2 rounded-xl border p-3 text-sm">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0" />
                <div className="flex-1">
                  {locationState === "pending" && "Finding your location…"}
                  {locationState === "found" && "Your location was shared with your family."}
                  {locationState === "none" && "Location not available — allow location access so family can find you."}
                  <label className="mt-2 flex items-center justify-between gap-2">
                    <span>Live location sharing {liveLocation ? "on" : "off"}</span>
                    <Switch checked={liveLocation} onCheckedChange={setLiveLocation} />
                  </label>
                </div>
              </div>

              <div className="grid gap-2">
                <Button asChild size="lg" variant="destructive">
                  <a href="tel:911">
                    <Phone className="mr-2 h-5 w-5" /> Call 911
                  </a>
                </Button>
                <Button size="lg" variant="outline" onClick={cancel}>
                  Cancel SOS — I'm okay
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
};
