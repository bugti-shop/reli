# Senior App — Five Reference-Matched Screens

## Goal
Apply the same compact visual language from reference image 2 across Home, Health, Messages, My Life, and More without removing or changing any existing feature behavior.

## What will change
- Keep the five fixed bottom destinations and ensure only the selected screen is visible.
- Give every screen the same compact Reli header, cream background, black outline icon style, restrained spacing, and senior-friendly sizing.
- Replace oversized horizontal button rows with compact, icon-led section selectors that visually match the bottom navigation.
- Restyle Health around Trackers, Reminders, History, Activity, and Doctor while preserving all medication, vitals, history, reminder, report, and Premium behavior.
- Restyle Messages with a compact heading, matching message icon, clear compose action, and readable message rows while preserving read, contact, and delete actions.
- Restyle My Life around Journal, Life Story, Companion, and Trivia while respecting caregiver visibility controls.
- Restyle More around Help, Share, Caregivers, and Account while retaining profiles, settings, alerts, contact, accessibility controls, SOS, and logout.
- Keep Home’s blue information panel and four pastel quick-action tiles, then align its spacing and icon treatment with the reference navigation.

## Verification
- Check all five destinations at phone width for consistent spacing, no horizontal overflow, no content appended below another screen, and no bottom-bar overlap.
- Confirm every existing action and visibility/Premium rule remains reachable.
- Check the updated files for code issues.
