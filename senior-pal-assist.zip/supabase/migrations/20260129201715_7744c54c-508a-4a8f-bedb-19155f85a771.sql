-- Create caregiver_daily_logs table for tracking senior health/activity
CREATE TABLE public.caregiver_daily_logs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  caregiver_id UUID NOT NULL,
  senior_id UUID NOT NULL,
  log_date DATE NOT NULL DEFAULT CURRENT_DATE,
  mood TEXT,
  had_fall BOOLEAN DEFAULT false,
  confusion_noted BOOLEAN DEFAULT false,
  ate_well BOOLEAN DEFAULT true,
  slept_well BOOLEAN DEFAULT true,
  took_medications BOOLEAN DEFAULT true,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(caregiver_id, senior_id, log_date)
);

-- Enable RLS
ALTER TABLE public.caregiver_daily_logs ENABLE ROW LEVEL SECURITY;

-- Caregivers can create logs for their seniors
CREATE POLICY "Caregivers can create logs for their seniors"
ON public.caregiver_daily_logs
FOR INSERT
WITH CHECK (
  auth.uid() = caregiver_id AND
  EXISTS (
    SELECT 1 FROM caregiver_seniors
    WHERE caregiver_seniors.caregiver_id = auth.uid()
    AND caregiver_seniors.senior_id = caregiver_daily_logs.senior_id
  )
);

-- Caregivers can view their own logs
CREATE POLICY "Caregivers can view their logs"
ON public.caregiver_daily_logs
FOR SELECT
USING (caregiver_id = auth.uid());

-- Caregivers can update their own logs
CREATE POLICY "Caregivers can update their logs"
ON public.caregiver_daily_logs
FOR UPDATE
USING (caregiver_id = auth.uid());

-- Caregivers can delete their own logs
CREATE POLICY "Caregivers can delete their logs"
ON public.caregiver_daily_logs
FOR DELETE
USING (caregiver_id = auth.uid());

-- Deny anonymous access
CREATE POLICY "deny_anon_access_caregiver_daily_logs"
ON public.caregiver_daily_logs
FOR ALL
USING (false);

-- Add updated_at trigger
CREATE TRIGGER update_caregiver_daily_logs_updated_at
BEFORE UPDATE ON public.caregiver_daily_logs
FOR EACH ROW
EXECUTE FUNCTION public.handle_updated_at();