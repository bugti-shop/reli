ALTER TABLE public.senior_activity_log
  ADD COLUMN IF NOT EXISTS event_id text,
  ADD COLUMN IF NOT EXISTS feature text NOT NULL DEFAULT 'general',
  ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'completed',
  ADD COLUMN IF NOT EXISTS metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS actor_id uuid,
  ADD COLUMN IF NOT EXISTS actor_role text,
  ADD COLUMN IF NOT EXISTS occurred_at timestamptz NOT NULL DEFAULT now();
UPDATE public.senior_activity_log SET occurred_at = COALESCE(created_at, now()) WHERE occurred_at IS DISTINCT FROM created_at AND created_at IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS senior_activity_log_event_uniq ON public.senior_activity_log (senior_id, event_id) WHERE event_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS senior_activity_log_senior_time ON public.senior_activity_log (senior_id, occurred_at DESC);

-- Activity history is an audit trail: nobody edits or deletes it from the app.
DROP POLICY IF EXISTS "Seniors can update their own activity logs" ON public.senior_activity_log;
DROP POLICY IF EXISTS "Seniors can delete their own activity logs" ON public.senior_activity_log;
REVOKE UPDATE, DELETE ON public.senior_activity_log FROM authenticated;

-- Central writer used by triggers (server-side, always runs).
CREATE OR REPLACE FUNCTION public.record_senior_activity(_senior uuid, _event_id text, _type text, _desc text, _feature text, _status text, _meta jsonb, _actor uuid, _at timestamptz DEFAULT now())
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE r text;
BEGIN
  IF _senior IS NULL THEN RETURN; END IF;
  SELECT role::text INTO r FROM profiles WHERE id = _actor;
  INSERT INTO senior_activity_log (senior_id, event_id, activity_type, activity_description, feature, status, metadata, actor_id, actor_role, occurred_at)
  VALUES (_senior, left(_event_id, 200), left(_type, 80), left(_desc, 1000), _feature, _status, COALESCE(_meta, '{}'::jsonb), _actor, r, COALESCE(_at, now()))
  ON CONFLICT (senior_id, event_id) WHERE event_id IS NOT NULL DO NOTHING;
END $$;
REVOKE EXECUTE ON FUNCTION public.record_senior_activity(uuid,text,text,text,text,text,jsonb,uuid,timestamptz) FROM PUBLIC, anon, authenticated;

-- App-side events (feature opened, login/logout, settings...). Idempotent via client event id.
CREATE OR REPLACE FUNCTION public.log_my_activity(_event_id text, _type text, _desc text, _feature text DEFAULT 'general', _status text DEFAULT 'completed', _meta jsonb DEFAULT '{}'::jsonb)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE me uuid := auth.uid();
BEGIN
  IF me IS NULL THEN RAISE EXCEPTION 'Please sign in first'; END IF;
  IF NOT EXISTS (SELECT 1 FROM profiles WHERE id = me AND role = 'senior') THEN RETURN; END IF;
  IF _status NOT IN ('completed','pending','missed','skipped','cancelled','info') THEN _status := 'info'; END IF;
  IF pg_column_size(_meta) > 4000 THEN _meta := '{}'::jsonb; END IF;
  PERFORM record_senior_activity(me, 'app:' || left(_event_id, 120), _type, _desc, left(_feature, 40), _status, _meta, me, now());
END $$;
REVOKE EXECUTE ON FUNCTION public.log_my_activity(text,text,text,text,text,jsonb) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.log_my_activity(text,text,text,text,text,jsonb) TO authenticated;

-- Server-side capture from the real data tables.
CREATE OR REPLACE FUNCTION public.trg_activity_capture()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE n jsonb := CASE WHEN TG_OP = 'DELETE' THEN to_jsonb(OLD) ELSE to_jsonb(NEW) END;
  o jsonb := CASE WHEN TG_OP = 'UPDATE' THEN to_jsonb(OLD) ELSE NULL END;
  sid uuid := (n->>'senior_id')::uuid; actor uuid := COALESCE(auth.uid(), sid);
  eid text := TG_TABLE_NAME || ':' || TG_OP || ':' || (n->>'id') || ':' || extract(epoch from clock_timestamp())::text;
  verb text := CASE TG_OP WHEN 'INSERT' THEN 'added' WHEN 'UPDATE' THEN 'updated' ELSE 'deleted' END;
BEGIN
  CASE TG_TABLE_NAME
  WHEN 'medication_doses' THEN
    IF TG_OP = 'INSERT' THEN
      PERFORM record_senior_activity(sid, 'dose:' || (n->>'id'), 'Medication taken', 'Took ' || (n->>'medication_name') || COALESCE(' ' || (n->>'dosage'), '') || COALESCE(' (scheduled ' || (n->>'scheduled_time') || ')', ''), 'medication', 'completed',
        jsonb_build_object('medication', n->>'medication_name', 'dosage', n->>'dosage', 'scheduled_time', n->>'scheduled_time', 'notes', n->>'notes', 'recorded_by', n->>'taken_by_role'), actor, (n->>'taken_at')::timestamptz);
    ELSIF TG_OP = 'UPDATE' AND o->>'deleted_at' IS NULL AND n->>'deleted_at' IS NOT NULL THEN
      PERFORM record_senior_activity(sid, 'dose-undo:' || (n->>'id'), 'Medication unmarked', 'Removed "taken" for ' || (n->>'medication_name'), 'medication', 'cancelled', jsonb_build_object('medication', n->>'medication_name'), actor);
    END IF;
  WHEN 'medications' THEN
    IF TG_OP = 'UPDATE' AND (o->>'completed') IS DISTINCT FROM (n->>'completed') THEN RETURN NULL; END IF; -- doses already log this
    PERFORM record_senior_activity(sid, eid, 'Medication ' || verb, initcap(verb) || ' medication ' || (n->>'name') || ' at ' || (n->>'time'), 'medication', 'info',
      jsonb_build_object('medication', n->>'name', 'time', n->>'time', 'dosage', n->>'dosage', 'days', n->'days_of_week'), actor);
  WHEN 'vital_readings' THEN
    IF TG_OP = 'INSERT' THEN
      PERFORM record_senior_activity(sid, 'vital:' || (n->>'id'), CASE n->>'reading_type' WHEN 'blood_pressure' THEN 'Blood pressure recorded' WHEN 'heart_rate' THEN 'Heart rate recorded' ELSE 'Health reading recorded' END,
        CASE WHEN n->>'systolic' IS NOT NULL THEN 'BP ' || (n->>'systolic') || '/' || (n->>'diastolic') || ' mmHg' ELSE '' END || CASE WHEN n->>'bpm' IS NOT NULL THEN ' Heart rate ' || (n->>'bpm') || ' bpm' ELSE '' END,
        'health', 'completed', jsonb_build_object('systolic', n->'systolic', 'diastolic', n->'diastolic', 'bpm', n->'bpm', 'notes', n->>'notes'), actor, (n->>'recorded_at')::timestamptz);
    ELSIF TG_OP = 'UPDATE' AND o->>'deleted_at' IS NULL AND n->>'deleted_at' IS NOT NULL THEN
      PERFORM record_senior_activity(sid, 'vital-del:' || (n->>'id'), 'Health reading deleted', 'A ' || replace(n->>'reading_type','_',' ') || ' reading was deleted', 'health', 'cancelled', '{}'::jsonb, actor);
    END IF;
  WHEN 'journal_entries' THEN
    PERFORM record_senior_activity(sid, eid, 'Journal entry ' || verb, COALESCE(NULLIF(n->>'title',''), left(n->>'content', 200)), 'journal', 'completed', jsonb_build_object('mood', n->>'mood', 'entry_date', n->>'entry_date'), actor);
  WHEN 'care_observations' THEN
    PERFORM record_senior_activity(sid, eid, 'Health journal ' || verb, initcap(n->>'category') || ': ' || (n->>'label') || COALESCE(' — ' || left(n->>'notes', 300), ''), 'journal', 'completed',
      jsonb_build_object('category', n->>'category', 'intensity', n->'intensity', 'location', n->>'location'), actor, COALESCE((n->>'observed_at')::timestamptz, now()));
  WHEN 'senior_reminders' THEN
    IF TG_OP = 'UPDATE' AND (o->>'completed') IS DISTINCT FROM (n->>'completed') THEN
      PERFORM record_senior_activity(sid, eid, CASE WHEN (n->>'completed')::boolean THEN 'Reminder completed' ELSE 'Reminder reopened' END, n->>'message', 'reminders', CASE WHEN (n->>'completed')::boolean THEN 'completed' ELSE 'pending' END, jsonb_build_object('due', n->>'reminder_time'), actor);
    ELSIF TG_OP <> 'UPDATE' THEN
      PERFORM record_senior_activity(sid, eid, 'Reminder ' || verb, n->>'message', 'reminders', 'info', jsonb_build_object('due', n->>'reminder_time'), actor);
    END IF;
  WHEN 'custom_trackers' THEN
    IF TG_OP = 'UPDATE' AND (o->>'completed') IS DISTINCT FROM (n->>'completed') THEN
      PERFORM record_senior_activity(sid, eid, CASE WHEN (n->>'completed')::boolean THEN 'Task completed' ELSE 'Task marked not done' END, n->>'name', 'trackers', CASE WHEN (n->>'completed')::boolean THEN 'completed' ELSE 'pending' END, jsonb_build_object('value', n->>'value'), actor);
    ELSIF TG_OP = 'UPDATE' AND (o->>'value') IS DISTINCT FROM (n->>'value') THEN
      PERFORM record_senior_activity(sid, eid, 'Tracker updated', (n->>'name') || ': ' || COALESCE(n->>'value', '—'), 'trackers', 'completed', jsonb_build_object('previous', o->>'value', 'value', n->>'value'), actor);
    ELSIF TG_OP <> 'UPDATE' THEN
      PERFORM record_senior_activity(sid, eid, 'Tracker ' || verb, n->>'name', 'trackers', 'info', '{}'::jsonb, actor);
    END IF;
  WHEN 'doctor_questions' THEN
    PERFORM record_senior_activity(sid, eid, 'Doctor question ' || verb, left(n->>'question', 400), 'doctor', CASE WHEN (n->>'asked')::boolean THEN 'completed' ELSE 'pending' END, '{}'::jsonb, actor);
  WHEN 'life_story_entries' THEN
    IF TG_OP <> 'DELETE' AND COALESCE(n->>'response','') <> '' THEN
      PERFORM record_senior_activity(sid, eid, 'Life Story ' || verb, n->>'prompt', 'life_story', 'completed', '{}'::jsonb, actor);
    END IF;
  WHEN 'caregiver_messages' THEN
    IF TG_OP = 'INSERT' THEN
      PERFORM record_senior_activity(sid, 'msg:' || (n->>'id'), CASE WHEN n->>'sender_role' = 'senior' THEN 'Message sent to caregiver' ELSE 'Message from caregiver' END, left(n->>'message', 500), 'messages', 'info', '{}'::jsonb, actor);
    ELSIF TG_OP = 'UPDATE' AND (o->>'read') IS DISTINCT FROM (n->>'read') AND (n->>'read')::boolean AND n->>'sender_role' <> 'senior' THEN
      PERFORM record_senior_activity(sid, 'msg-read:' || (n->>'id'), 'Caregiver message read', left(n->>'message', 500), 'messages', 'completed', '{}'::jsonb, actor);
    END IF;
  WHEN 'senior_feature_settings' THEN
    PERFORM record_senior_activity(sid, eid, 'Dashboard settings changed', 'Feature visibility was ' || verb, 'settings', 'info', n - 'id' - 'created_at' - 'updated_at', actor);
  WHEN 'emergency_alerts' THEN
    IF TG_OP = 'INSERT' THEN
      PERFORM record_senior_activity(sid, 'sos:' || (n->>'id'), 'SOS triggered', 'Emergency SOS sent to caregivers' || CASE WHEN n->>'latitude' IS NOT NULL THEN ' with location' ELSE ' (location unavailable)' END, 'emergency', 'pending',
        jsonb_build_object('alert_id', n->>'id', 'latitude', n->'latitude', 'longitude', n->'longitude', 'accuracy_m', n->'accuracy_m'), actor);
    ELSIF TG_OP = 'UPDATE' AND (o->>'status') IS DISTINCT FROM (n->>'status') AND n->>'status' IN ('cancelled','resolved') THEN
      PERFORM record_senior_activity(sid, 'sos-' || (n->>'status') || ':' || (n->>'id'), CASE n->>'status' WHEN 'cancelled' THEN 'SOS cancelled' ELSE 'SOS resolved' END,
        CASE n->>'status' WHEN 'cancelled' THEN 'The senior cancelled the emergency' ELSE 'The emergency was marked resolved' END, 'emergency', CASE n->>'status' WHEN 'cancelled' THEN 'cancelled' ELSE 'completed' END, jsonb_build_object('alert_id', n->>'id'), actor);
    END IF;
  WHEN 'sos_acknowledgements' THEN
    SELECT senior_id INTO sid FROM emergency_alerts WHERE id = (n->>'alert_id')::uuid;
    PERFORM record_senior_activity(sid, 'sos-ack:' || (n->>'alert_id') || ':' || (n->>'caregiver_id'), 'SOS acknowledged',
      COALESCE((SELECT full_name FROM profiles WHERE id = (n->>'caregiver_id')::uuid), 'A caregiver') || ' acknowledged the SOS', 'emergency', 'completed', jsonb_build_object('alert_id', n->>'alert_id'), (n->>'caregiver_id')::uuid);
  ELSE NULL;
  END CASE;
  RETURN NULL;
EXCEPTION WHEN OTHERS THEN
  RAISE LOG 'activity capture failed on %: %', TG_TABLE_NAME, SQLERRM;
  RETURN NULL;
END $$;
REVOKE EXECUTE ON FUNCTION public.trg_activity_capture() FROM PUBLIC, anon, authenticated;

DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['medication_doses','medications','vital_readings','journal_entries','care_observations','senior_reminders','custom_trackers','doctor_questions','life_story_entries','caregiver_messages','senior_feature_settings','emergency_alerts','sos_acknowledgements'] LOOP
    EXECUTE format('DROP TRIGGER IF EXISTS activity_capture ON public.%I', t);
    EXECUTE format('CREATE TRIGGER activity_capture AFTER INSERT OR UPDATE OR DELETE ON public.%I FOR EACH ROW EXECUTE FUNCTION public.trg_activity_capture()', t);
  END LOOP;
END $$;

ALTER TABLE public.senior_activity_log REPLICA IDENTITY FULL;
DO $$ BEGIN
  ALTER PUBLICATION supabase_realtime ADD TABLE public.senior_activity_log;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;