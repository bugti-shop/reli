import { Capacitor } from "@capacitor/core";

/** True only inside the Android / iOS app build. */
export const isNativeApp = () => Capacitor.isNativePlatform();
export const nativePlatform = () => Capacitor.getPlatform() as "ios" | "android" | "web";

/** Strong vibration on phones; falls back to the browser API on the web. */
export const buzz = async (kind: "tap" | "alarm" = "tap") => {
  if (isNativeApp()) {
    try {
      const { Haptics, ImpactStyle, NotificationType } = await import("@capacitor/haptics");
      if (kind === "alarm") await Haptics.notification({ type: NotificationType.Error });
      else await Haptics.impact({ style: ImpactStyle.Heavy });
      if (kind === "alarm") await Haptics.vibrate({ duration: 800 });
      return;
    } catch { /* fall through */ }
  }
  navigator.vibrate?.(kind === "alarm" ? [800, 400] : 200);
};

/** Clears the app icon badge (e.g. after opening alerts). */
export const clearBadge = async () => {
  if (!isNativeApp()) return;
  try {
    const { Badge } = await import("@capawesome/capacitor-badge");
    await Badge.clear();
  } catch { /* unsupported launcher */ }
};

/**
 * One-time native setup: status bar, splash, deep links, Android back button,
 * badge clearing on resume and offline/online notices.
 */
export const initNativeShell = async (navigate: (path: string) => void, notify: (online: boolean) => void) => {
  if (!isNativeApp()) return;
  const [{ App }, { StatusBar, Style }, { SplashScreen }, { Network }] = await Promise.all([
    import("@capacitor/app"),
    import("@capacitor/status-bar"),
    import("@capacitor/splash-screen"),
    import("@capacitor/network"),
  ]);
  StatusBar.setStyle({ style: Style.Dark }).catch(() => undefined);
  SplashScreen.hide().catch(() => undefined);
  clearBadge();

  // reli://app/<path> and https://reli.care/<path> both open inside the app.
  App.addListener("appUrlOpen", ({ url }) => {
    try {
      const u = new URL(url);
      const path = u.protocol === "reli:" ? `/${u.pathname.replace(/^\/+/, "")}` : u.pathname;
      navigate(`${path}${u.search}${u.hash}`);
    } catch { /* ignore malformed links */ }
  });
  App.addListener("backButton", ({ canGoBack }) => {
    if (canGoBack) window.history.back();
    else App.minimizeApp();
  });
  App.addListener("appStateChange", ({ isActive }) => {
    if (isActive) clearBadge();
  });

  let wasOnline = (await Network.getStatus()).connected;
  Network.addListener("networkStatusChange", ({ connected }) => {
    if (connected !== wasOnline) notify(connected);
    wasOnline = connected;
  });
};
