import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bell, CalendarDays, Pill, Activity } from "lucide-react";

interface Item {
  key: string;
  minutes: number;
  time: string;
  title: string;
  detail: string;
  type: "medication" | "appointment" | "reading" | "custom";
}

const toMinutes = (t: string) => {
  const [h, m] = t.slice(0, 5).split(":").map(Number);
  return h * 60 + m;
};
const fmt = (mins: number) =>
  new Date(2000, 0, 1, Math.floor(mins / 60), mins % 60).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });

/** Today's reminders for a senior (medicines, readings, custom and appointments), shown on the caregiver home. */
export const SeniorRemindersOverview = ({ seniorId, seniorName, onManage }: { seniorId: string; seniorName: string; onManage: () => void }) => {
  const [items, setItems] = useState<Item[]>([]);

  const load = useCallback(async () => {
    const start = new Date(); start.setHours(0, 0, 0, 0);
    const end = new Date(start); end.setDate(end.getDate() + 1);
    const today = new Date().getDay();
    const [{ data: meds }, { data: rems }, { data: msgs }] = await Promise.all([
      supabase.from("medications").select("id, name, dosage, time, days_of_week").eq("senior_id", seniorId),
      supabase.from("tracker_reminders").select("id, kind, label, time, days_of_week").eq("senior_id", seniorId).eq("enabled", true),
      supabase.from("caregiver_messages").select("id, message, reminder_time").eq("senior_id", seniorId).eq("is_reminder", true)
        .gte("reminder_time", start.toISOString()).lt("reminder_time", end.toISOString()),
    ]);
    const onToday = (d: number[] | null) => !d || d.length === 0 || d.includes(today);
    const list: Item[] = [];
    (meds || []).forEach((m) => {
      if (!m.time || !onToday(m.days_of_week as number[] | null)) return;
      const mins = toMinutes(m.time);
      list.push({ key: `m-${m.id}`, minutes: mins, time: fmt(mins), title: m.name, detail: m.dosage || "Medicine", type: "medication" });
    });
    (rems || []).forEach((r) => {
      if (!onToday(r.days_of_week as number[] | null)) return;
      const mins = toMinutes(r.time);
      const label = r.label || (r.kind === "blood_pressure" ? "Blood pressure reading" : r.kind === "heart_rate" ? "Heart rate reading" : "Medication");
      list.push({ key: `r-${r.id}`, minutes: mins, time: fmt(mins), title: label, detail: r.kind === "custom" ? "Custom reminder" : "Tracker reminder", type: r.kind === "custom" ? "custom" : r.kind === "medication" ? "medication" : "reading" });
    });
    (msgs || []).forEach((m) => {
      if (!m.reminder_time) return;
      const d = new Date(m.reminder_time);
      const mins = d.getHours() * 60 + d.getMinutes();
      list.push({ key: `a-${m.id}`, minutes: mins, time: fmt(mins), title: m.message, detail: "Scheduled reminder", type: "appointment" });
    });
    list.sort((a, b) => a.minutes - b.minutes);
    setItems(list);
  }, [seniorId]);

  useEffect(() => {
    load();
    const t = window.setInterval(load, 60000);
    window.addEventListener("reli:schedule-changed", load);
    return () => { window.clearInterval(t); window.removeEventListener("reli:schedule-changed", load); };
  }, [load]);

  const nowMins = new Date().getHours() * 60 + new Date().getMinutes();
  const Icon = (t: Item["type"]) => (t === "medication" ? Pill : t === "appointment" ? CalendarDays : t === "reading" ? Activity : Bell);

  return (
    <Card className="border p-4 shadow-sm">
      <div className="mb-3 flex items-center justify-between gap-2">
        <h3 className="text-xl font-bold">{seniorName}'s Reminders Today</h3>
        <Button size="sm" variant="outline" onClick={onManage}>Manage</Button>
      </div>
      {items.length === 0 ? (
        <p className="text-sm text-muted-foreground">No reminders scheduled for today.</p>
      ) : (
        <ul className="space-y-2">
          {items.map((i) => {
            const I = Icon(i.type);
            const past = i.minutes < nowMins;
            return (
              <li key={i.key} className="flex items-start gap-3 rounded-lg bg-muted/40 p-2">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-dashboard-sky text-primary"><I className="h-4 w-4" /></span>
                <span className="min-w-0 flex-1">
                  <strong className="block break-words text-sm">{i.title}</strong>
                  <span className="text-xs text-muted-foreground">{i.detail}</span>
                </span>
                <span className={`shrink-0 text-sm font-semibold ${past ? "text-muted-foreground" : "text-primary"}`}>{i.time}</span>
              </li>
            );
          })}
        </ul>
      )}
    </Card>
  );
};
