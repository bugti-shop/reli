import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft, Loader2, Plus, Trash2, User } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface EmergencyContact {
  name: string;
  relationship: string;
  phone: string;
}

const SeniorProfile = () => {
  const { seniorId } = useParams<{ seniorId: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [fullName, setFullName] = useState("");
  const [age, setAge] = useState("");
  const [address, setAddress] = useState("");
  const [contacts, setContacts] = useState<EmergencyContact[]>([]);

  useEffect(() => {
    const load = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        navigate("/auth");
        return;
      }
      if (!seniorId) {
        navigate("/caregiver");
        return;
      }

      const { data, error } = await supabase
        .from("profiles")
        .select("full_name, age, address, emergency_contacts")
        .eq("id", seniorId)
        .maybeSingle();

      if (error || !data) {
        toast({
          title: "Couldn't open this profile",
          description: "You may not have access to it.",
          variant: "destructive",
        });
        navigate("/caregiver");
        return;
      }

      setFullName(data.full_name || "");
      setAge(data.age != null ? String(data.age) : "");
      setAddress(data.address || "");
      const raw = Array.isArray(data.emergency_contacts) ? data.emergency_contacts : [];
      setContacts(
        raw.map((c: any) => ({
          name: String(c?.name ?? ""),
          relationship: String(c?.relationship ?? ""),
          phone: String(c?.phone ?? ""),
        })),
      );
      setLoading(false);
    };
    load();
  }, [navigate, seniorId, toast]);

  const updateContact = (index: number, field: keyof EmergencyContact, value: string) => {
    setContacts((prev) => prev.map((c, i) => (i === index ? { ...c, [field]: value } : c)));
  };

  const handleSave = async () => {
    if (!seniorId) return;
    if (!fullName.trim()) {
      toast({ title: "Name is required", variant: "destructive" });
      return;
    }
    const parsedAge = age.trim() ? Number(age) : null;
    if (parsedAge !== null && (!Number.isInteger(parsedAge) || parsedAge < 0 || parsedAge > 120)) {
      toast({ title: "Please enter a valid age", description: "Age must be a whole number between 0 and 120.", variant: "destructive" });
      return;
    }

    setSaving(true);
    const cleaned = contacts
      .map((c) => ({ name: c.name.trim(), relationship: c.relationship.trim(), phone: c.phone.trim() }))
      .filter((c) => c.name || c.phone);

    const { error } = await supabase
      .from("profiles")
      .update({
        full_name: fullName.trim().slice(0, 100),
        age: parsedAge,
        address: address.trim().slice(0, 300) || null,
        emergency_contacts: cleaned,
      })
      .eq("id", seniorId);

    setSaving(false);

    if (error) {
      toast({ title: "Couldn't save changes", description: error.message, variant: "destructive" });
      return;
    }
    setContacts(cleaned);
    toast({ title: "Profile saved", description: "The details now show in the health summary." });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <main className="container mx-auto px-4 py-8 max-w-2xl">
        <Button variant="ghost" className="mb-6 -ml-2" onClick={() => navigate("/caregiver")}>
          <ArrowLeft className="w-4 h-4 mr-2" /> Back to dashboard
        </Button>

        <div className="flex items-center gap-3 mb-2">
          <div className="w-11 h-11 rounded-full bg-primary/10 flex items-center justify-center">
            <User className="w-5 h-5 text-primary" />
          </div>
          <h1 className="text-3xl font-bold">Senior profile</h1>
        </div>
        <p className="text-muted-foreground mb-6">
          Keep their details up to date — they appear at the top of both dashboards.
        </p>

        <Card className="p-6 space-y-5">
          <div>
            <Label htmlFor="fullName">Full name</Label>
            <Input id="fullName" value={fullName} onChange={(e) => setFullName(e.target.value)} className="mt-1 h-11" />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label htmlFor="age">Age</Label>
              <Input
                id="age"
                inputMode="numeric"
                value={age}
                onChange={(e) => setAge(e.target.value.replace(/[^\d]/g, ""))}
                placeholder="e.g. 78"
                className="mt-1 h-11"
              />
            </div>
            <div>
              <Label htmlFor="address">Home address</Label>
              <Input
                id="address"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="Street, city, state"
                className="mt-1 h-11"
              />
            </div>
          </div>
        </Card>

        <Card className="p-6 mt-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-semibold">Emergency contacts</h2>
              <p className="text-sm text-muted-foreground">Who to call first in an emergency.</p>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setContacts((prev) => [...prev, { name: "", relationship: "", phone: "" }])}
            >
              <Plus className="w-4 h-4 mr-1.5" /> Add
            </Button>
          </div>

          {contacts.length === 0 ? (
            <p className="text-sm text-muted-foreground">No emergency contacts yet.</p>
          ) : (
            <div className="space-y-4">
              {contacts.map((contact, index) => (
                <div key={index} className="rounded-lg border border-border p-4 space-y-3">
                  <div className="grid gap-3 sm:grid-cols-2">
                    <div>
                      <Label htmlFor={`contact-name-${index}`}>Name</Label>
                      <Input
                        id={`contact-name-${index}`}
                        value={contact.name}
                        onChange={(e) => updateContact(index, "name", e.target.value)}
                        className="mt-1 h-11"
                      />
                    </div>
                    <div>
                      <Label htmlFor={`contact-rel-${index}`}>Relationship</Label>
                      <Input
                        id={`contact-rel-${index}`}
                        value={contact.relationship}
                        onChange={(e) => updateContact(index, "relationship", e.target.value)}
                        placeholder="Daughter, neighbour…"
                        className="mt-1 h-11"
                      />
                    </div>
                  </div>
                  <div className="flex items-end gap-3">
                    <div className="flex-1">
                      <Label htmlFor={`contact-phone-${index}`}>Phone</Label>
                      <Input
                        id={`contact-phone-${index}`}
                        type="tel"
                        value={contact.phone}
                        onChange={(e) => updateContact(index, "phone", e.target.value)}
                        className="mt-1 h-11"
                      />
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-destructive"
                      aria-label="Remove contact"
                      onClick={() => setContacts((prev) => prev.filter((_, i) => i !== index))}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>

        <Button className="w-full h-12 mt-6 text-lg" onClick={handleSave} disabled={saving}>
          {saving ? "Saving…" : "Save profile"}
        </Button>
      </main>
    </div>
  );
};

export default SeniorProfile;
