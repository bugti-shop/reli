
CREATE TABLE public.shared_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL,
  senior_id uuid NOT NULL,
  created_by_role text NOT NULL CHECK (created_by_role IN ('senior','caregiver')),
  title text NOT NULL DEFAULT 'Wellness Summary',
  recipient_name text,
  notes text,
  include_medications boolean NOT NULL DEFAULT true,
  include_wellness boolean NOT NULL DEFAULT true,
  include_activity boolean NOT NULL DEFAULT true,
  date_range_days integer NOT NULL DEFAULT 14,
  share_token text NOT NULL UNIQUE DEFAULT encode(gen_random_bytes(24), 'hex'),
  expires_at timestamptz NOT NULL DEFAULT (now() + interval '30 days'),
  revoked boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_shared_reports_owner ON public.shared_reports(owner_id);
CREATE INDEX idx_shared_reports_senior ON public.shared_reports(senior_id);
CREATE INDEX idx_shared_reports_token ON public.shared_reports(share_token);

ALTER TABLE public.shared_reports ENABLE ROW LEVEL SECURITY;

-- Block anon entirely (public access happens via edge function with service role)
CREATE POLICY "deny_anon_access_shared_reports"
  ON public.shared_reports AS RESTRICTIVE FOR ALL
  TO anon
  USING (false) WITH CHECK (false);

-- Seniors: create about themselves
CREATE POLICY "Seniors can create their own shared reports"
  ON public.shared_reports FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = owner_id
    AND auth.uid() = senior_id
    AND created_by_role = 'senior'
  );

-- Caregivers: create for linked seniors
CREATE POLICY "Caregivers can create shared reports for their seniors"
  ON public.shared_reports FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = owner_id
    AND created_by_role = 'caregiver'
    AND EXISTS (
      SELECT 1 FROM public.caregiver_seniors
      WHERE caregiver_id = auth.uid() AND senior_id = shared_reports.senior_id
    )
  );

-- View: owner or related caregiver/senior
CREATE POLICY "Owners can view their shared reports"
  ON public.shared_reports FOR SELECT
  TO authenticated
  USING (owner_id = auth.uid());

CREATE POLICY "Linked seniors and caregivers can view shared reports"
  ON public.shared_reports FOR SELECT
  TO authenticated
  USING (
    senior_id = auth.uid()
    OR EXISTS (
      SELECT 1 FROM public.caregiver_seniors
      WHERE caregiver_id = auth.uid() AND senior_id = shared_reports.senior_id
    )
  );

-- Update / delete: only owner
CREATE POLICY "Owners can update their shared reports"
  ON public.shared_reports FOR UPDATE
  TO authenticated
  USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

CREATE POLICY "Owners can delete their shared reports"
  ON public.shared_reports FOR DELETE
  TO authenticated
  USING (owner_id = auth.uid());

CREATE TRIGGER set_shared_reports_updated_at
  BEFORE UPDATE ON public.shared_reports
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();
