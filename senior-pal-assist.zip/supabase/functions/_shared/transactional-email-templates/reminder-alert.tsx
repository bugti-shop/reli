import * as React from 'npm:react@18.3.1'
import {
  Body,
  Container,
  Head,
  Heading,
  Html,
  Preview,
  Section,
  Text,
} from 'npm:@react-email/components@0.0.22'
import type { TemplateEntry } from './registry.ts'

interface Props {
  recipientName?: string
  title?: string
  detail?: string
  time?: string
}

const Email = ({ recipientName, title = 'Reminder', detail, time }: Props) => (
  <Html lang="en" dir="ltr">
    <Head />
    <Preview>{title}</Preview>
    <Body style={main}>
      <Container style={container}>
        <Heading style={h1}>{title}</Heading>
        <Text style={text}>
          {recipientName ? `Hi ${recipientName}, ` : ''}this is your Reli reminder
          {time ? ` for ${time}` : ''}.
        </Text>
        {detail ? (
          <Section style={quote}>
            <Text style={quoteText}>{detail}</Text>
          </Section>
        ) : null}
        <Text style={footer}>Sent from Reli</Text>
      </Container>
    </Body>
  </Html>
)

export const template = {
  component: Email,
  subject: (data: Record<string, any>) => data.title || 'Your Reli reminder',
  displayName: 'Reminder alert',
  previewData: {
    recipientName: 'Mary',
    title: 'Time for your medication',
    detail: 'Lisinopril — 10 mg',
    time: '8:00 AM',
  },
} satisfies TemplateEntry

const main = { backgroundColor: '#ffffff', fontFamily: 'Arial, sans-serif' }
const container = { padding: '20px 25px' }
const h1 = {
  fontSize: '22px',
  fontWeight: 'bold' as const,
  color: 'hsl(24, 20%, 15%)',
  margin: '0 0 20px',
}
const text = {
  fontSize: '16px',
  color: 'hsl(24, 15%, 35%)',
  lineHeight: '1.6',
  margin: '0 0 18px',
}
const quote = {
  backgroundColor: 'hsl(206, 55%, 96%)',
  borderLeft: '4px solid hsl(206, 55%, 38%)',
  borderRadius: '10px',
  padding: '14px 18px',
  margin: '0 0 20px',
}
const quoteText = {
  fontSize: '18px',
  color: 'hsl(24, 20%, 15%)',
  lineHeight: '1.6',
  margin: '0',
}
const footer = { fontSize: '12px', color: '#999999', margin: '30px 0 0' }
