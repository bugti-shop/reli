// The app no longer uses an offline-cache service worker (it caused stale
// versions after deploys). This removes any old one and its caches.
// Firebase push worker (/firebase-messaging-sw.js) is left untouched.
const OLD_SW = "/sw.js";

export function registerServiceWorker() {
  if (typeof navigator === "undefined" || !("serviceWorker" in navigator)) return;

  void (async () => {
    try {
      const regs = await navigator.serviceWorker.getRegistrations();
      let removed = false;
      for (const r of regs) {
        const url =
          r.active?.scriptURL || r.waiting?.scriptURL || r.installing?.scriptURL || "";
        if (new URL(url, location.href).pathname === OLD_SW) {
          await r.unregister();
          removed = true;
        }
      }
      if ("caches" in window) {
        const keys = await caches.keys();
        await Promise.all(
          keys
            .filter((k) => /workbox|html-navigations|static-assets/.test(k))
            .map((k) => caches.delete(k)),
        );
      }
      if (removed && !sessionStorage.getItem("reli-sw-cleaned")) {
        sessionStorage.setItem("reli-sw-cleaned", "1");
        location.reload();
      }
    } catch {
      // ignore
    }
  })();
}
