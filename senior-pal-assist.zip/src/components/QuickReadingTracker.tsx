import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Droplet, Droplets, Scale, Plus, Trash2, Check, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { enqueue, isOnline } from "@/lib/offlineQueue";

export type QuickReadingType = "glucose" | "weight" | "water";

const CONFIG: Record<QuickReadingType, { title: string; unit: string; icon: typeof Droplet; min: number; max: number; placeholder: string; step: string }> = {
  glucose: { title: "Blood Glucose", unit: "mg/dL", icon: Droplet, min: 20, max: 600, placeholder: "110", step: "1" },
  weight: { title: "Weight", unit: "lb", icon: Scale, min: 40, max: 700, placeholder: "160", step: "0.1" },
  water: { title: "Water", unit: "glasses", icon: Droplets, min: 1, max: 20, placeholder: "1", step: "1" },
};

interface Reading { id: string; value: number | null; unit: string | null; recorded_at: string; created_by_role: string; recorded_by: string }

interface Props { type: QuickReadingType; userId: string; userRole: "senior" | "caregiver"; seniorId?: string }

export const QuickReadingTracker = ({ type, userId, userRole, seniorId }: Props) => {
  const cfg = CONFIG[type];
  const Icon = cfg.icon;
  const target = userRole === "senior" ? userId : seniorId;
  const { toast } = useToast();
  const [readings, setReadings] = useState<Reading[]>([]);
  const [adding, setAdding] = useState(false);
  const [value, setValue] = useState("");
  const [saving, setSaving] = useState(false);

  const load = async () => {
    if (!target) return;
    const { data } = await supabase.from("vital_readings").select("id,value,unit,recorded_at,created_by_role,recorded_by")
      .eq("senior_id", target).eq("reading_type", type).is("deleted_at", null)
      .order("recorded_at", { ascending: false }).limit(30);
    setReadings((data as Reading[]) || []);
  };

  useEffect(() => {
    load();
    if (!target) return;
    const ch = supabase.channel(`quick-${type}-${target}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "vital_readings", filter: `senior_id=eq.${target}` }, load)
      .subscribe();
    return () => { supabase.removeChannel(ch); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [target, type]);

  const save = async (raw: string) => {
    if (!target) return;
    const v = Number(raw);
    if (!Number.isFinite(v) || v < cfg.min || v > cfg.max) {
      toast({ title: "Check the number", description: `Enter a value between ${cfg.min} and ${cfg.max} ${cfg.unit}.`, variant: "destructive" });
      return;
    }
    const row = { senior_id: target, recorded_by: userId, created_by_role: userRole, reading_type: type, value: v, unit: cfg.unit, recorded_at: new Date().toISOString() };
    if (!isOnline()) {
      enqueue({ table: "vital_readings", op: "insert", payload: row, label: `${cfg.title} reading` });
      toast({ title: "Saved on this device", description: "It will upload automatically when you're back online." });
      setAdding(false); setValue(""); return;
    }
    setSaving(true);
    const { error } = await supabase.from("vital_readings").insert(row);
    setSaving(false);
    if (error) { toast({ title: "Could not save", description: "Please try again.", variant: "destructive" }); return; }
    toast({ title: `${cfg.title} saved`, description: `${v} ${cfg.unit} recorded.` });
    setAdding(false); setValue(""); load();
  };

  const remove = async (id: string) => {
    const { error } = await supabase.from("vital_readings").update({ deleted_at: new Date().toISOString() }).eq("id", id);
    if (error) { toast({ title: "Could not delete", variant: "destructive" }); return; }
    load();
  };

  const today = new Date().toDateString();
  const todayTotal = readings.filter((r) => new Date(r.recorded_at).toDateString() === today).reduce((a, r) => a + Number(r.value || 0), 0);
  const latest = readings[0];

  return (
    <Card className="p-6 border-2">
      <div className="mb-4 flex items-center justify-between gap-3">
        <h2 className="flex items-center gap-2 text-2xl font-semibold text-foreground"><Icon className="h-7 w-7 text-primary" />{cfg.title}</h2>
        {type === "water"
          ? <Button size="sm" className="gap-2" disabled={saving} onClick={() => save("1")}><Plus className="h-4 w-4" />1 glass</Button>
          : !adding && <Button size="sm" className="gap-2" onClick={() => setAdding(true)}><Plus className="h-4 w-4" />Add Reading</Button>}
      </div>
      <div className="mb-4 rounded-lg border bg-muted/40 p-4">
        <p className="text-sm text-muted-foreground">{type === "water" ? "Today" : "Latest"}</p>
        <p className="text-2xl font-bold text-foreground">
          {type === "water" ? `${todayTotal} ${cfg.unit}` : latest ? `${latest.value} ${latest.unit ?? cfg.unit}` : "No readings yet"}
        </p>
      </div>
      {adding && (
        <div className="mb-4 space-y-3 rounded-lg border p-4">
          <Label htmlFor={`q-${type}`} className="text-base">{cfg.title} ({cfg.unit})</Label>
          <Input id={`q-${type}`} type="number" inputMode="decimal" step={cfg.step} value={value} onChange={(e) => setValue(e.target.value)} placeholder={cfg.placeholder} className="h-12 text-lg" />
          <div className="flex gap-2">
            <Button className="flex-1" disabled={saving} onClick={() => save(value)}><Check className="mr-2 h-4 w-4" />Save</Button>
            <Button variant="outline" onClick={() => { setAdding(false); setValue(""); }}><X className="h-4 w-4" /></Button>
          </div>
        </div>
      )}
      <div className="max-h-[300px] space-y-2 overflow-y-auto">
        {readings.length === 0 ? <p className="py-4 text-center text-muted-foreground">Nothing recorded yet.</p> : readings.map((r) => (
          <div key={r.id} className="flex items-center justify-between gap-3 rounded-lg border bg-muted/30 p-3">
            <div>
              <p className="text-lg font-semibold text-foreground">{r.value} {r.unit}</p>
              <p className="text-sm text-muted-foreground">{new Date(r.recorded_at).toLocaleString()}{r.created_by_role === "caregiver" && userRole === "senior" ? " · added by your caregiver" : ""}</p>
            </div>
            {(r.recorded_by === userId || userRole === "senior") && (
              <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive" aria-label="Delete reading" onClick={() => remove(r.id)}><Trash2 className="h-4 w-4" /></Button>
            )}
          </div>
        ))}
      </div>
    </Card>
  );
};
