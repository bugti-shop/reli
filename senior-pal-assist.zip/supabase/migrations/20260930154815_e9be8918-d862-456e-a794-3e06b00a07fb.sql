ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS managed boolean NOT NULL DEFAULT false;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS managed_by uuid;

CREATE OR REPLACE FUNCTION public.add_senior_by_email(_email text)
 RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE
  me uuid := auth.uid();
  sid uuid;
  clean_email text := lower(trim(_email));
BEGIN
  IF me IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  IF NOT EXISTS (SELECT 1 FROM profiles WHERE id = me AND role = 'caregiver') THEN
    RAISE EXCEPTION 'NOT_CAREGIVER';
  END IF;
  SELECT id INTO sid FROM profiles WHERE lower(trim(email)) = clean_email AND role = 'senior' AND managed = false LIMIT 1;
  IF sid IS NULL THEN
    IF EXISTS (SELECT 1 FROM profiles WHERE lower(trim(email)) = clean_email AND role = 'caregiver') THEN
      RAISE EXCEPTION 'NOT_A_SENIOR_ACCOUNT';
    END IF;
    RAISE EXCEPTION 'SENIOR_NOT_FOUND';
  END IF;
  IF EXISTS (SELECT 1 FROM caregiver_seniors WHERE caregiver_id = me AND senior_id = sid) THEN
    RAISE EXCEPTION 'ALREADY_CONNECTED';
  END IF;
  INSERT INTO caregiver_seniors (caregiver_id, senior_id, relationship) VALUES (me, sid, 'caregiver');
  RETURN sid;
END;
$function$;

CREATE OR REPLACE FUNCTION public.protect_profile_role_plan()
 RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE jwt_role text;
BEGIN
  jwt_role := COALESCE(current_setting('request.jwt.claims', true)::json->>'role', '');
  IF jwt_role = 'service_role' OR jwt_role = '' THEN
    NEW.role := OLD.role;
    RETURN NEW;
  END IF;
  NEW.role := OLD.role;
  NEW.plan := OLD.plan;
  NEW.managed := OLD.managed;
  NEW.managed_by := OLD.managed_by;
  NEW.email := OLD.email;
  RETURN NEW;
END;
$function$;