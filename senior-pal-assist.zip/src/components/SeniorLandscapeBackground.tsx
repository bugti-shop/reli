import { useEffect, useState } from "react";
import preDawn from "@/assets/sky-v2-pre-dawn.webp";
import sunrise from "@/assets/sky-v2-sunrise.webp";
import morning from "@/assets/sky-v2-morning.webp";
import daylight from "@/assets/sky-v2-daylight.webp";
import afternoon from "@/assets/sky-v2-afternoon.webp";
import sunset from "@/assets/sky-v2-sunset.webp";
import blueHour from "@/assets/sky-v2-blue-hour.webp";
import night from "@/assets/sky-v2-night.webp";

type SkyPhase =
  | "preDawn"
  | "sunrise"
  | "morning"
  | "daylight"
  | "afternoon"
  | "sunset"
  | "blueHour"
  | "night";

interface ScheduledScene {
  key: SkyPhase;
  startsAt: number;
  src: string;
  framing: string;
  shade: string;
}

const SCENES: ScheduledScene[] = [
  { key: "night", startsAt: 0, src: night, framing: "object-[50%_46%]", shade: "bg-dashboard-blue-deep/30" },
  { key: "preDawn", startsAt: 4 * 60, src: preDawn, framing: "object-[50%_45%]", shade: "bg-dashboard-blue-deep/28" },
  { key: "sunrise", startsAt: 5 * 60, src: sunrise, framing: "object-[50%_44%]", shade: "bg-dashboard-blue-deep/24" },
  { key: "morning", startsAt: 7 * 60, src: morning, framing: "object-[50%_43%]", shade: "bg-dashboard-blue-deep/28" },
  { key: "daylight", startsAt: 10 * 60, src: daylight, framing: "object-[50%_42%]", shade: "bg-dashboard-blue-deep/34" },
  { key: "afternoon", startsAt: 15 * 60, src: afternoon, framing: "object-[50%_43%]", shade: "bg-dashboard-blue-deep/30" },
  { key: "sunset", startsAt: 17 * 60 + 30, src: sunset, framing: "object-[50%_44%]", shade: "bg-dashboard-blue-deep/22" },
  { key: "blueHour", startsAt: 18 * 60 + 30, src: blueHour, framing: "object-[50%_44%]", shade: "bg-dashboard-blue-deep/25" },
  { key: "night", startsAt: 20 * 60, src: night, framing: "object-[50%_46%]", shade: "bg-dashboard-blue-deep/30" },
];

const getMinuteOfDay = (date: Date) =>
  date.getHours() * 60 + date.getMinutes() + date.getSeconds() / 60;

type Coords = { lat: number; lng: number };
const COORDS_KEY = "reli-sky-coords";
export const TIME_OVERRIDE_KEY = "reli-sky-time-override";
export const TIME_OVERRIDE_EVENT = "reli-sky-time-override-changed";

/** Manual test time (minutes-of-day) set from Settings; null = real clock. */
export const readTimeOverride = (): number | null => {
  try {
    const raw = localStorage.getItem(TIME_OVERRIDE_KEY);
    if (raw === null) return null;
    const value = Number(raw);
    return Number.isFinite(value) ? value : null;
  } catch {
    return null;
  }
};

export const setTimeOverride = (minutes: number | null) => {
  try {
    if (minutes === null) localStorage.removeItem(TIME_OVERRIDE_KEY);
    else localStorage.setItem(TIME_OVERRIDE_KEY, String(minutes));
  } catch { /* ignore */ }
  window.dispatchEvent(new Event(TIME_OVERRIDE_EVENT));
};

/** Effective "now" for the sky: real clock, or today's date at the override time. */
const effectiveNow = (override: number | null): Date => {
  if (override === null) return new Date();
  const date = new Date();
  date.setHours(Math.floor(override / 60), Math.floor(override % 60), 0, 0);
  return date;
};

const readCoords = (): Coords | null => {
  try {
    const raw = localStorage.getItem(COORDS_KEY);
    return raw ? (JSON.parse(raw) as Coords) : null;
  } catch {
    return null;
  }
};

/** NOAA sunrise/sunset in local minutes-of-day for the given date & location. */
const getSunTimes = (date: Date, { lat, lng }: Coords) => {
  const rad = Math.PI / 180;
  const start = new Date(date.getFullYear(), 0, 0);
  const dayOfYear = Math.floor((date.getTime() - start.getTime()) / 86_400_000);
  const g = ((2 * Math.PI) / 365) * (dayOfYear - 1);
  const eqTime = 229.18 * (0.000075 + 0.001868 * Math.cos(g) - 0.032077 * Math.sin(g) - 0.014615 * Math.cos(2 * g) - 0.040849 * Math.sin(2 * g));
  const decl = 0.006918 - 0.399912 * Math.cos(g) + 0.070257 * Math.sin(g) - 0.006758 * Math.cos(2 * g) + 0.000907 * Math.sin(2 * g) - 0.002697 * Math.cos(3 * g) + 0.00148 * Math.sin(3 * g);
  const cosHa = Math.cos(90.833 * rad) / (Math.cos(lat * rad) * Math.cos(decl)) - Math.tan(lat * rad) * Math.tan(decl);
  if (cosHa > 1 || cosHa < -1) return null; // polar day/night
  const ha = Math.acos(cosHa) / rad;
  const tz = -date.getTimezoneOffset();
  const sunrise = 720 - 4 * (lng + ha) - eqTime + tz;
  const sunset = 720 - 4 * (lng - ha) - eqTime + tz;
  return { sunrise, sunset };
};

/** Build today's schedule; shifts phases around the real sunrise/sunset when location is known. */
const getSchedule = (date: Date, coords: Coords | null): ScheduledScene[] => {
  const sun = coords ? getSunTimes(date, coords) : null;
  if (!sun) return SCENES;
  const { sunrise: S, sunset: T } = sun;
  const starts: Record<SkyPhase, number> = {
    preDawn: S - 120,
    sunrise: S - 60,
    morning: S + 60,
    daylight: S + 240,
    afternoon: T - 195,
    sunset: T - 48,
    blueHour: T + 12,
    night: T + 102,
  };
  return SCENES.map((scene, index) => ({
    ...scene,
    startsAt: index === 0 ? 0 : Math.max(0, Math.min(1439, starts[scene.key])),
  }));
};

export const getSkyPhase = (date: Date = new Date(), coords: Coords | null = readCoords()): SkyPhase => {
  const minute = getMinuteOfDay(date);
  const scene = [...getSchedule(date, coords)].reverse().find((candidate) => minute >= candidate.startsAt);
  return scene?.key ?? "night";
};

const getSceneState = (date: Date, coords: Coords | null) => {
  const activeKey = getSkyPhase(date, coords);
  const index = SCENES.findIndex((scene) => scene.key === activeKey);
  const active = SCENES[index] ?? SCENES[0];
  const next = SCENES[(index + 1) % SCENES.length] ?? SCENES[0];
  return { active, next };
};

interface SeniorLandscapeBackgroundProps {
  className?: string;
}

/** Time-aware scenic background for the senior home summary. */
export const SeniorLandscapeBackground = ({ className = "" }: SeniorLandscapeBackgroundProps) => {
  const [coords, setCoords] = useState<Coords | null>(() => readCoords());
  const [override, setOverride] = useState<number | null>(() => readTimeOverride());
  const [sceneState, setSceneState] = useState(() => getSceneState(effectiveNow(override), coords));

  useEffect(() => {
    if (!("geolocation" in navigator)) return;
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const next = { lat: pos.coords.latitude, lng: pos.coords.longitude };
        try { localStorage.setItem(COORDS_KEY, JSON.stringify(next)); } catch { /* ignore */ }
        setCoords(next);
      },
      () => { /* permission denied: keep default schedule */ },
      { maximumAge: 6 * 60 * 60 * 1000, timeout: 10_000 },
    );
  }, []);

  useEffect(() => {
    const tick = () => setSceneState(getSceneState(effectiveNow(override), coords));
    tick();
    const id = window.setInterval(tick, 15_000);
    const onVisible = () => {
      if (document.visibilityState === "visible") tick();
    };
    const onOverride = () => setOverride(readTimeOverride());
    document.addEventListener("visibilitychange", onVisible);
    window.addEventListener(TIME_OVERRIDE_EVENT, onOverride);
    return () => {
      window.clearInterval(id);
      document.removeEventListener("visibilitychange", onVisible);
      window.removeEventListener(TIME_OVERRIDE_EVENT, onOverride);
    };
  }, [coords, override]);

  useEffect(() => {
    const preload = new Image();
    preload.src = sceneState.next.src;
  }, [sceneState.next.src]);

  return (
    <div aria-hidden="true" role="presentation" className={`overflow-hidden bg-dashboard-blue-deep ${className}`}>
      <img
        key={sceneState.active.key}
        src={sceneState.active.src}
        alt=""
        width={640}
        height={854}
        loading="eager"
        decoding="async"
        fetchPriority="high"
        className={`absolute inset-0 h-full w-full object-cover animate-in fade-in duration-1000 motion-reduce:animate-none md:object-center ${sceneState.active.framing}`}
      />
      <div className={`absolute inset-0 ${sceneState.active.shade}`} />
    </div>
  );
};

export default SeniorLandscapeBackground;
