import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Briefcase,
  CalendarHeart,
  ChevronDown,
  ChevronUp,
  ImagePlus,
  Loader2,
  PawPrint,
  Pencil,
  Plus,
  Sparkles,
  Trash2,
  Users,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

export type MemoryCategory = "best_days" | "first_job" | "best_friend" | "first_pet";

export interface LifeMemory {
  id: string;
  senior_id: string;
  category: MemoryCategory;
  details: Record<string, string>;
  image_path: string | null;
  imageUrl?: string | null;
}

export const MEMORY_CONFIG: Record<
  MemoryCategory,
  { title: string; icon: typeof Briefcase; fields: { key: string; label: string; long?: boolean }[] }
> = {
  best_days: {
    title: "My Best Days",
    icon: CalendarHeart,
    fields: [
      { key: "title", label: "Memory title" },
      { key: "date", label: "Date, year, or age" },
      { key: "place", label: "Where it happened" },
      { key: "people", label: "Who was there" },
      { key: "story", label: "Tell the full story", long: true },
    ],
  },
  first_job: {
    title: "My First Job",
    icon: Briefcase,
    fields: [
      { key: "job_title", label: "Job title" },
      { key: "employer", label: "Company / employer" },
      { key: "year", label: "Year or age when started" },
      { key: "address", label: "Where it was (address / city)" },
      { key: "pay", label: "First paycheck / pay" },
      { key: "coworkers", label: "Boss or co-workers I remember" },
      { key: "story", label: "What I remember most", long: true },
    ],
  },
  best_friend: {
    title: "Childhood Best Friends",
    icon: Users,
    fields: [
      { key: "name", label: "Name" },
      { key: "phone", label: "Phone number" },
      { key: "email", label: "Email" },
      { key: "address", label: "Address" },
      { key: "how_met", label: "How we met" },
      { key: "story", label: "Favorite memory together", long: true },
    ],
  },
  first_pet: {
    title: "My First Pet",
    icon: PawPrint,
    fields: [
      { key: "name", label: "Pet's name" },
      { key: "type", label: "Type of animal / breed" },
      { key: "age", label: "Age" },
      { key: "years", label: "Years we had them" },
      { key: "story", label: "Favorite memory", long: true },
    ],
  },
};

const CATEGORIES: MemoryCategory[] = ["best_days", "first_job", "best_friend", "first_pet"];

export const withSignedUrls = async (rows: LifeMemory[]) =>
  Promise.all(
    rows.map(async (memory) => {
      if (!memory.image_path) return { ...memory, imageUrl: null };
      const { data } = await supabase.storage.from("life-story-images").createSignedUrl(memory.image_path, 3600);
      return { ...memory, imageUrl: data?.signedUrl ?? null };
    }),
  );

interface Props {
  onChange?: (memories: LifeMemory[]) => void;
  expanded: "today" | MemoryCategory | null;
  onExpandedChange: (category: "today" | MemoryCategory | null) => void;
  onAddToday: () => void;
}

export const LifeStoryMemories = ({ onChange, expanded, onExpandedChange, onAddToday }: Props) => {
  const { toast } = useToast();
  const [memories, setMemories] = useState<LifeMemory[]>([]);
  const [userId, setUserId] = useState<string | null>(null);
  const [editing, setEditing] = useState<{ category: MemoryCategory; memory?: LifeMemory } | null>(null);
  const [form, setForm] = useState<Record<string, string>>({});
  const [file, setFile] = useState<File | null>(null);
  const [saving, setSaving] = useState(false);

  const load = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    setUserId(user.id);
    const { data } = await supabase
      .from("life_story_memories")
      .select("*")
      .eq("senior_id", user.id)
      .order("created_at");
    const rows = (data || []).map((row) => ({ ...row, category: row.category as MemoryCategory, details: row.details as Record<string, string> }));
    const list = await withSignedUrls(rows);
    setMemories(list);
    onChange?.(list);
  };

  useEffect(() => { void load(); }, []);

  const openEditor = (category: MemoryCategory, memory?: LifeMemory) => {
    onExpandedChange(category);
    setEditing({ category, memory });
    setForm(memory?.details || {});
    setFile(null);
  };

  const save = async () => {
    if (!editing || !userId) return;
    setSaving(true);
    try {
      let imagePath = editing.memory?.image_path ?? null;
      if (file) {
        const ext = file.name.split(".").pop() || "jpg";
        const path = `${userId}/${crypto.randomUUID()}.${ext}`;
        const { error: uploadError } = await supabase.storage.from("life-story-images").upload(path, file);
        if (uploadError) throw uploadError;
        if (imagePath) await supabase.storage.from("life-story-images").remove([imagePath]);
        imagePath = path;
      }
      const payload = { senior_id: userId, category: editing.category, details: form, image_path: imagePath };
      const query = editing.memory
        ? supabase.from("life_story_memories").update(payload).eq("id", editing.memory.id)
        : supabase.from("life_story_memories").insert(payload);
      const { error } = await query;
      if (error) throw error;
      toast({ title: "Memory saved!" });
      setEditing(null);
      await load();
    } catch (error) {
      console.error(error);
      toast({ title: "Could not save", description: "Please try again.", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const remove = async (memory: LifeMemory) => {
    if (!confirm("Delete this memory?")) return;
    if (memory.image_path) await supabase.storage.from("life-story-images").remove([memory.image_path]);
    await supabase.from("life_story_memories").delete().eq("id", memory.id);
    await load();
  };

  const addOptions = [
    { key: "today" as const, label: "Today's Story", icon: Sparkles },
    ...CATEGORIES.map((key) => ({ key, label: MEMORY_CONFIG[key].title, icon: MEMORY_CONFIG[key].icon })),
  ];

  return (
    <div className="space-y-2.5">
      {CATEGORIES.map((category) => {
        const config = MEMORY_CONFIG[category];
        const Icon = config.icon;
        const items = memories.filter((memory) => memory.category === category);
        const isOpen = expanded === category;
        return (
          <section key={category} className="overflow-hidden rounded-lg border bg-card shadow-sm">
            <Button
              variant="ghost"
              onClick={() => onExpandedChange(isOpen ? null : category)}
              className="h-16 w-full justify-start rounded-none px-4 hover:bg-muted/60"
            >
              <Icon className="mr-3 h-6 w-6 shrink-0 text-primary" />
              <span className="min-w-0 flex-1 truncate text-left text-base font-bold text-foreground">{config.title}</span>
              {items.length > 0 && <span className="mr-2 flex h-7 min-w-7 items-center justify-center rounded-full bg-primary/10 px-2 text-sm font-bold text-primary">{items.length}</span>}
              {isOpen ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
            </Button>

            {isOpen && (
              <div className="border-t px-4 pb-4 pt-3">
                {items.length === 0 ? (
                  <p className="mb-3 text-sm text-muted-foreground">Nothing added yet.</p>
                ) : (
                  <div className="mb-3 space-y-2">
                    {items.map((memory) => {
                      const previewField = config.fields.find((field) => memory.details?.[field.key]);
                      return (
                        <div key={memory.id} className="flex items-center gap-3 rounded-md bg-muted/45 p-2.5">
                          {memory.imageUrl ? (
                            <img src={memory.imageUrl} alt="" className="h-14 w-14 shrink-0 rounded-full object-cover" />
                          ) : (
                            <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-primary/10"><Icon className="h-6 w-6 text-primary" /></span>
                          )}
                          <div className="min-w-0 flex-1">
                            <p className="truncate font-semibold">{previewField ? memory.details[previewField.key] : config.title}</p>
                            {memory.details.story && <p className="line-clamp-2 text-sm text-muted-foreground">{memory.details.story}</p>}
                          </div>
                          <Button size="icon" variant="ghost" onClick={() => openEditor(category, memory)} aria-label={`Edit ${config.title}`}><Pencil className="h-4 w-4" /></Button>
                          <Button size="icon" variant="ghost" onClick={() => void remove(memory)} aria-label={`Delete ${config.title}`} className="text-destructive hover:text-destructive"><Trash2 className="h-4 w-4" /></Button>
                        </div>
                      );
                    })}
                  </div>
                )}
                <Button variant="outline" size="sm" onClick={() => openEditor(category)} className="w-full border-primary/40 text-primary">
                  <Plus className="mr-2 h-4 w-4" /> Add {config.title}
                </Button>
              </div>
            )}
          </section>
        );
      })}

      <div className="flex justify-center pt-1">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button size="icon" className="h-12 w-12 rounded-full shadow-md" aria-label="Add a Life Story memory">
              <Plus className="h-6 w-6" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="center" side="top" className="w-64 p-2">
            {addOptions.map(({ key, label, icon: Icon }) => (
              <DropdownMenuItem
                key={key}
                onSelect={() => key === "today" ? onAddToday() : openEditor(key)}
                className="min-h-11 gap-3 text-base"
              >
                <Icon className="h-5 w-5 text-primary" /> {label}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <Dialog open={Boolean(editing)} onOpenChange={(open) => !open && setEditing(null)}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader><DialogTitle>{editing && MEMORY_CONFIG[editing.category].title}</DialogTitle></DialogHeader>
          {editing && (
            <div className="space-y-3">
              <div className="space-y-1">
                <Label className="flex items-center gap-2"><ImagePlus className="h-4 w-4" /> Add a photo</Label>
                <Input type="file" accept="image/*" onChange={(event) => setFile(event.target.files?.[0] || null)} />
                {editing.memory?.imageUrl && !file && <img src={editing.memory.imageUrl} alt="Current memory" className="h-24 w-24 rounded-md object-cover" />}
              </div>
              {MEMORY_CONFIG[editing.category].fields.map((field) => (
                <div key={field.key} className="space-y-1">
                  <Label>{field.label}</Label>
                  {field.long ? (
                    <Textarea value={form[field.key] || ""} onChange={(event) => setForm({ ...form, [field.key]: event.target.value })} />
                  ) : (
                    <Input value={form[field.key] || ""} onChange={(event) => setForm({ ...form, [field.key]: event.target.value })} />
                  )}
                </div>
              ))}
            </div>
          )}
          <DialogFooter><Button onClick={() => void save()} disabled={saving}>{saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Save Memory</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};