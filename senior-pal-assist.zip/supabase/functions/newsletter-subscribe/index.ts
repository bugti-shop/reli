import { createClient } from 'npm:@supabase/supabase-js@2'
import { sendTemplateEmail } from '../_shared/transactional-email-templates/send-email.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  })

// Simple in-memory rate limit: max 5 requests per IP per 10 minutes
const RATE_LIMIT_WINDOW_MS = 10 * 60 * 1000
const RATE_LIMIT_MAX = 5
const ipHits = new Map<string, number[]>()

function isRateLimited(ip: string): boolean {
  const now = Date.now()
  const hits = (ipHits.get(ip) || []).filter((t) => now - t < RATE_LIMIT_WINDOW_MS)
  if (hits.length >= RATE_LIMIT_MAX) {
    ipHits.set(ip, hits)
    return true
  }
  hits.push(now)
  ipHits.set(ip, hits)
  return false
}

// Strict-enough email validation: local@domain.tld, no spaces, sane lengths
const isValidEmail = (email: string) =>
  email.length <= 255 &&
  /^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)+$/.test(email)

// Verify the domain can actually receive mail: it must publish MX records,
// or (as a fallback) an A/AAAA record for direct delivery.
const domainCanReceiveMail = async (email: string): Promise<boolean> => {
  const domain = email.split('@')[1]
  try {
    const mx = await Deno.resolveDns(domain, 'MX', { signal: AbortSignal.timeout(5000) })
    if (mx.length > 0) return true
  } catch {
    // No MX records (or lookup failed) — fall through to A/AAAA check.
  }
  for (const type of ['A', 'AAAA'] as const) {
    try {
      const records = await Deno.resolveDns(domain, type, { signal: AbortSignal.timeout(5000) })
      if (records.length > 0) return true
    } catch {
      // keep trying
    }
  }
  return false
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })

  const clientIp =
    req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
    req.headers.get('cf-connecting-ip') ||
    'unknown'

  if (isRateLimited(clientIp)) {
    return json({ error: 'Too many requests. Please try again later.' }, 429)
  }

  try {
    const body = await req.json().catch(() => ({}))
    const email = typeof body?.email === 'string' ? body.email.trim().toLowerCase() : ''

    if (!isValidEmail(email)) {
      return json({ error: 'Please enter a valid email address.' }, 400)
    }

    if (!(await domainCanReceiveMail(email))) {
      return json(
        { error: "That email domain doesn't exist or can't receive email. Please double-check the address." },
        400
      )
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const { error } = await supabase
      .from('newsletter_subscribers')
      .insert({ email })

    if (error) {
      if (error.code === '23505') {
        return json({ error: 'already_subscribed' }, 409)
      }
      console.error('Insert error:', error)
      return json({ error: 'Something went wrong. Please try again.' }, 500)
    }

    // Welcome email — failure here should not fail the subscription.
    try {
      await sendTemplateEmail('newsletter-welcome', email, {
        idempotencyKey: crypto.randomUUID(),
      })
    } catch (emailError) {
      console.error('Welcome email failed:', emailError)
    }

    return json({ success: true })
  } catch (error) {
    console.error('Error in newsletter-subscribe function:', error)
    return json({ error: 'Something went wrong. Please try again.' }, 500)
  }
})
