import { useCallback, useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export type Plan = "free" | "premium";

/**
 * Fetches the effective plan for a given user id. Premium applies when the user
 * OR anyone they are linked with (caregiver <-> senior) has an active plan, so a
 * single membership covers the whole care pair. On first load it also asks the
 * check-subscription function to sync profiles.plan with Stripe, so upgrades
 * take effect without any webhook. Returns null while loading.
 */
export const usePlan = (userId?: string) => {
  const [plan, setPlan] = useState<Plan | null>(null);
  const synced = useRef(false);

  const fetchPlan = useCallback(async () => {
    if (!userId) return;
    const { data, error } = await supabase.rpc("has_effective_premium", {
      _user_id: userId,
    });

    if (error) console.error("Error fetching plan:", error);
    setPlan(data === true ? "premium" : "free");
  }, [userId]);

  const syncWithStripe = useCallback(async () => {
    // Skip entirely when there is no active session (e.g. right after sign-out).
    const { data } = await supabase.auth.getSession();
    if (!data.session) return;
    try {
      // This reads Stripe directly and updates profiles.plan server-side.
      await supabase.functions.invoke("check-subscription");
    } catch (e) {
      console.error("Subscription check failed:", e);
    }
  }, []);

  const refresh = useCallback(async () => {
    if (!userId) return;
    await syncWithStripe();
    await fetchPlan();
  }, [userId, fetchPlan, syncWithStripe]);

  useEffect(() => {
    if (!userId) return;
    let cancelled = false;

    const load = async () => {
      await fetchPlan();
      // Sync with Stripe once per mount, then re-read.
      if (!synced.current) {
        synced.current = true;
        await syncWithStripe();
        if (!cancelled) await fetchPlan();
      }
    };

    load();
    return () => {
      cancelled = true;
    };
  }, [userId, fetchPlan, syncWithStripe]);

  return { plan, isPremium: plan === "premium", isFree: plan !== null && plan !== "premium", refresh };
};
