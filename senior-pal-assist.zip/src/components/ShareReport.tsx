import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { Share2, Copy, Trash2, Download, Link2, Loader2 } from "lucide-react";
import { generateSharedReportPdf, SharedReportData } from "@/lib/shareReportPdf";

interface Props {
  userId: string;
  userRole: "senior" | "caregiver";
  seniorId: string;
  seniorName?: string;
}

interface ReportRow {
  id: string;
  title: string;
  recipient_name: string | null;
  notes: string | null;
  share_token: string;
  expires_at: string;
  revoked: boolean;
  created_at: string;
  include_medications: boolean;
  include_wellness: boolean;
  include_activity: boolean;
  date_range_days: number;
  senior_id: string;
  owner_id: string;
}

export const ShareReport = ({ userId, userRole, seniorId, seniorName }: Props) => {
  const { toast } = useToast();
  const [title, setTitle] = useState("Wellness Summary");
  const [recipient, setRecipient] = useState("");
  const [notes, setNotes] = useState("");
  const [days, setDays] = useState(14);
  const [includeMeds, setIncludeMeds] = useState(true);
  const [includeWellness, setIncludeWellness] = useState(true);
  const [includeActivity, setIncludeActivity] = useState(true);
  const [expiresInDays, setExpiresInDays] = useState(30);
  const [creating, setCreating] = useState(false);
  const [reports, setReports] = useState<ReportRow[]>([]);
  const [downloading, setDownloading] = useState<string | null>(null);

  const loadReports = async () => {
    const { data } = await supabase
      .from("shared_reports")
      .select("*")
      .eq("senior_id", seniorId)
      .order("created_at", { ascending: false });
    setReports((data as ReportRow[]) || []);
  };

  useEffect(() => { loadReports(); }, [seniorId]);

  const shareUrl = (token: string) => `${window.location.origin}/share/${token}`;

  const handleCreate = async () => {
    if (!title.trim()) {
      toast({ title: "Title required", variant: "destructive" });
      return;
    }
    setCreating(true);
    const expires = new Date();
    expires.setDate(expires.getDate() + expiresInDays);
    const { error } = await supabase.from("shared_reports").insert({
      owner_id: userId,
      senior_id: seniorId,
      created_by_role: userRole,
      title: title.trim(),
      recipient_name: recipient.trim() || null,
      notes: notes.trim() || null,
      date_range_days: days,
      include_medications: includeMeds,
      include_wellness: includeWellness,
      include_activity: includeActivity,
      expires_at: expires.toISOString(),
    });
    setCreating(false);
    if (error) {
      toast({ title: "Could not create share", description: error.message, variant: "destructive" });
      return;
    }
    toast({ title: "Share created", description: "Copy the link or download the PDF below." });
    setNotes(""); setRecipient("");
    loadReports();
  };

  const copyLink = async (token: string) => {
    await navigator.clipboard.writeText(shareUrl(token));
    toast({ title: "Link copied" });
  };

  const revoke = async (id: string) => {
    const { error } = await supabase.from("shared_reports").update({ revoked: true }).eq("id", id);
    if (error) {
      toast({ title: "Could not revoke", description: error.message, variant: "destructive" });
      return;
    }
    toast({ title: "Link revoked" });
    loadReports();
  };

  const downloadPdf = async (token: string, fileName: string) => {
    setDownloading(token);
    try {
      const res = await fetch(
        `https://${import.meta.env.VITE_SUPABASE_PROJECT_ID}.supabase.co/functions/v1/get-shared-report?token=${encodeURIComponent(token)}`,
        { headers: { apikey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY } }
      );
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || "Failed to load report");
      }
      const data = (await res.json()) as SharedReportData;
      const doc = generateSharedReportPdf(data);
      doc.save(`${fileName.replace(/[^\w\-]+/g, "_")}.pdf`);
    } catch (e: any) {
      toast({ title: "Download failed", description: e.message, variant: "destructive" });
    } finally {
      setDownloading(null);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="p-5 border">
        <h3 className="text-base font-semibold flex items-center gap-2 mb-4">
          <Share2 className="w-4 h-4 text-primary" />
          Share an update {seniorName ? `about ${seniorName}` : ""}
        </h3>

        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="sr-title">Title</Label>
            <Input id="sr-title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Wellness Summary" />
          </div>
          <div>
            <Label htmlFor="sr-recipient">Recipient (optional)</Label>
            <Input id="sr-recipient" value={recipient} onChange={(e) => setRecipient(e.target.value)} placeholder="e.g. Sister Jane" />
          </div>
        </div>

        <div className="mt-4">
          <Label htmlFor="sr-notes">Personal notes for the recipient</Label>
          <Textarea
            id="sr-notes"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Add context, things to watch for, or a short message…"
            className="min-h-[90px]"
          />
        </div>

        <div className="grid sm:grid-cols-3 gap-4 mt-4">
          <div>
            <Label htmlFor="sr-days">Include data from past (days)</Label>
            <Input id="sr-days" type="number" min={1} max={365} value={days} onChange={(e) => setDays(Math.max(1, Math.min(365, Number(e.target.value) || 14)))} />
          </div>
          <div>
            <Label htmlFor="sr-exp">Link expires in (days)</Label>
            <Input id="sr-exp" type="number" min={1} max={365} value={expiresInDays} onChange={(e) => setExpiresInDays(Math.max(1, Math.min(365, Number(e.target.value) || 30)))} />
          </div>
        </div>

        <div className="grid sm:grid-cols-3 gap-3 mt-5">
          <label className="flex items-center justify-between rounded-md border p-3">
            <span className="text-sm font-medium">Medications</span>
            <Switch checked={includeMeds} onCheckedChange={setIncludeMeds} />
          </label>
          <label className="flex items-center justify-between rounded-md border p-3">
            <span className="text-sm font-medium">Wellness logs</span>
            <Switch checked={includeWellness} onCheckedChange={setIncludeWellness} />
          </label>
          <label className="flex items-center justify-between rounded-md border p-3">
            <span className="text-sm font-medium">Activity & trackers</span>
            <Switch checked={includeActivity} onCheckedChange={setIncludeActivity} />
          </label>
        </div>

        <Button onClick={handleCreate} disabled={creating} className="mt-5 w-full sm:w-auto">
          {creating ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Share2 className="w-4 h-4 mr-2" />}
          Create share
        </Button>
      </Card>

      <Card className="p-5 border">
        <h3 className="text-base font-semibold mb-4 flex items-center gap-2">
          <Link2 className="w-4 h-4 text-primary" /> Existing shares
        </h3>
        {reports.length === 0 ? (
          <p className="text-sm text-muted-foreground">You haven't shared anything yet.</p>
        ) : (
          <div className="space-y-3">
            {reports.map((r) => {
              const expired = new Date(r.expires_at) < new Date();
              const status = r.revoked ? "Revoked" : expired ? "Expired" : "Active";
              return (
                <div key={r.id} className="rounded-lg border p-4 space-y-2">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <p className="font-semibold text-foreground">{r.title}</p>
                      <p className="text-xs text-muted-foreground">
                        {r.recipient_name ? `For ${r.recipient_name} · ` : ""}
                        Past {r.date_range_days} days · {status} · expires {new Date(r.expires_at).toLocaleDateString()}
                      </p>
                    </div>
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      status === "Active" ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"
                    }`}>{status}</span>
                  </div>
                  {r.notes && <p className="text-sm text-muted-foreground italic">"{r.notes}"</p>}
                  <div className="flex flex-wrap gap-2 pt-1">
                    <Button size="sm" variant="outline" onClick={() => copyLink(r.share_token)} disabled={r.revoked || expired}>
                      <Copy className="w-3.5 h-3.5 mr-1.5" /> Copy link
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => downloadPdf(r.share_token, r.title)} disabled={r.revoked || expired || downloading === r.share_token}>
                      {downloading === r.share_token ? <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" /> : <Download className="w-3.5 h-3.5 mr-1.5" />}
                      Download PDF
                    </Button>
                    {r.owner_id === userId && !r.revoked && (
                      <Button size="sm" variant="ghost" onClick={() => revoke(r.id)} className="text-destructive hover:text-destructive">
                        <Trash2 className="w-3.5 h-3.5 mr-1.5" /> Revoke
                      </Button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </Card>
    </div>
  );
};
