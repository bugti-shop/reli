# Continuous, Fast Time-Based Backgrounds

## What will change
- Replace fixed time blocks with a continuous 24-hour scene cycle: night → sunrise → daylight → sunset → night.
- Blend only the two neighboring scenes at any moment, so transitions stay smooth without loading all four images.
- Create smaller mobile-first image variants and show the correct scene immediately on first open.
- Tune each scene’s mobile crop and zoom so the sun, moon, mountains, and lake remain naturally framed inside the dashboard card.
- Keep wider-screen framing balanced without changing dashboard content.

## Validation
- Test morning, daylight, evening, and night times at mobile size.
- Confirm each scene fills the card with no borders, stretching, overflow, or blank loading state.
- Confirm only the needed scene images load initially and the preview remains error-free.

## Technical details
- Use smooth interpolation around four daily scene anchors rather than abrupt thresholds.
- Render the current and next scene only, with browser-prioritized decoding for the visible image.
- Use compact WebP assets sized for the dashboard’s actual mobile display area.
