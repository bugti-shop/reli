import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Heart, HeartPulse, Plus, Trash2, X, Check, TrendingUp } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { CloudOff } from "lucide-react";
import { enqueue, isOnline } from "@/lib/offlineQueue";
import { usePendingQueue } from "@/hooks/use-offline-sync";

type ReadingType = "blood_pressure" | "heart_rate";

interface VitalReading {
  id: string;
  senior_id: string;
  recorded_by: string;
  created_by_role: string;
  reading_type: string;
  systolic: number | null;
  diastolic: number | null;
  bpm: number | null;
  notes: string | null;
  recorded_at: string;
}

interface VitalsTrackerProps {
  type: ReadingType;
  userId: string;
  userRole: "senior" | "caregiver";
  seniorId?: string;
  seniorName?: string;
}

const bpCategory = (systolic: number, diastolic: number) => {
  if (systolic >= 180 || diastolic >= 120) return { label: "Very high — seek care", tone: "text-destructive" };
  if (systolic >= 140 || diastolic >= 90) return { label: "High", tone: "text-destructive" };
  if (systolic >= 130 || diastolic >= 80) return { label: "Elevated", tone: "text-amber-600 dark:text-amber-400" };
  if (systolic < 90 || diastolic < 60) return { label: "Low", tone: "text-amber-600 dark:text-amber-400" };
  return { label: "Normal", tone: "text-green-600 dark:text-green-500" };
};

const hrCategory = (bpm: number) => {
  if (bpm > 100) return { label: "High", tone: "text-destructive" };
  if (bpm < 50) return { label: "Low", tone: "text-amber-600 dark:text-amber-400" };
  return { label: "Normal", tone: "text-green-600 dark:text-green-500" };
};

export const VitalsTracker = ({ type, userId, userRole, seniorId, seniorName }: VitalsTrackerProps) => {
  const isBP = type === "blood_pressure";
  const targetSeniorId = userRole === "senior" ? userId : seniorId;
  const { toast } = useToast();

  const [readings, setReadings] = useState<VitalReading[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [systolic, setSystolic] = useState("");
  const [diastolic, setDiastolic] = useState("");
  const [bpm, setBpm] = useState("");
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);
  const pendingAll = usePendingQueue("vital_readings");
  const pending = pendingAll.filter(
    (p) => (p.payload as { reading_type?: string })?.reading_type === type
  );

  useEffect(() => {
    if (targetSeniorId) fetchReadings();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [targetSeniorId, type]);

  const fetchReadings = async () => {
    if (!targetSeniorId) return;
    const { data, error } = await supabase
      .from("vital_readings")
      .select("*")
      .eq("senior_id", targetSeniorId)
      .eq("reading_type", type)
      .is("deleted_at", null)
      .order("recorded_at", { ascending: false })
      .limit(30);

    if (error) {
      console.error("Error fetching vitals:", error);
      return;
    }
    setReadings(data || []);
  };

  const resetForm = () => {
    setSystolic("");
    setDiastolic("");
    setBpm("");
    setNotes("");
    setIsAdding(false);
  };

  const handleSave = async () => {
    if (!targetSeniorId) return;

    if (isBP) {
      const s = parseInt(systolic, 10);
      const d = parseInt(diastolic, 10);
      if (!s || !d || s < 50 || s > 300 || d < 30 || d > 200) {
        toast({ title: "Check the numbers", description: "Enter a valid top and bottom reading.", variant: "destructive" });
        return;
      }
    } else {
      const b = parseInt(bpm, 10);
      if (!b || b < 20 || b > 250) {
        toast({ title: "Check the number", description: "Enter a valid heart rate in beats per minute.", variant: "destructive" });
        return;
      }
    }

    const row = {
      senior_id: targetSeniorId,
      recorded_by: userId,
      created_by_role: userRole,
      reading_type: type,
      systolic: isBP ? parseInt(systolic, 10) : null,
      diastolic: isBP ? parseInt(diastolic, 10) : null,
      bpm: isBP ? null : parseInt(bpm, 10),
      notes: notes.trim() || null,
      recorded_at: new Date().toISOString(),
    };

    if (!isOnline()) {
      enqueue({
        table: "vital_readings",
        op: "insert",
        payload: row,
        label: isBP ? "Blood pressure reading" : "Heart rate reading",
      });
      toast({
        title: "Saved on this device",
        description: "No internet right now — it will upload automatically later.",
      });
      resetForm();
      return;
    }

    setSaving(true);
    const { error } = await supabase.from("vital_readings").insert(row);
    setSaving(false);

    if (error) {
      console.error("Error saving reading:", error);
      toast({ title: "Error", description: "Could not save the reading. Please try again.", variant: "destructive" });
      return;
    }

    toast({ title: "Reading saved", description: isBP ? `${systolic}/${diastolic} recorded.` : `${bpm} bpm recorded.` });
    resetForm();
    fetchReadings();
  };

  const handleDelete = async (id: string) => {
    // Soft delete: the reading leaves this list but stays in Tracker History.
    const { error } = await supabase
      .from("vital_readings")
      .update({ deleted_at: new Date().toISOString() })
      .eq("id", id);
    if (error) {
      console.error("Error deleting reading:", error);
      toast({ title: "Error", description: "Could not delete the reading.", variant: "destructive" });
      return;
    }
    toast({ title: "Reading removed", description: "It stays in Tracker History for your records." });
    fetchReadings();
  };

  const latest = readings[0];
  const average = (() => {
    if (readings.length === 0) return null;
    const recent = readings.slice(0, 7);
    if (isBP) {
      const s = Math.round(recent.reduce((a, r) => a + (r.systolic || 0), 0) / recent.length);
      const d = Math.round(recent.reduce((a, r) => a + (r.diastolic || 0), 0) / recent.length);
      return `${s}/${d}`;
    }
    return `${Math.round(recent.reduce((a, r) => a + (r.bpm || 0), 0) / recent.length)} bpm`;
  })();

  const Icon = isBP ? HeartPulse : Heart;
  const title = isBP ? "Blood Pressure" : "Heart Rate";

  return (
    <Card className="rounded-xl border bg-card p-4 shadow-sm sm:p-5">
      <div className="mb-4 flex items-center justify-between gap-3">
        <h2 className="flex items-center gap-3 text-xl font-bold text-foreground sm:text-2xl">
          <span className="flex h-11 w-11 items-center justify-center rounded-full bg-dashboard-sky text-primary"><Icon className="h-6 w-6" /></span>
          {title}
        </h2>
        {!isAdding && (
          <Button onClick={() => setIsAdding(true)} size="sm" className="gap-2">
            <Plus className="w-4 h-4" /> Add Reading
          </Button>
        )}
      </div>

      {/* Summary */}
      <div className="mb-4 grid grid-cols-2 gap-3">
        <div className="rounded-xl bg-dashboard-sky/55 p-4">
          <p className="text-sm text-muted-foreground">Latest</p>
          {latest ? (
            <>
              <p className="text-2xl font-bold text-foreground">
                {isBP ? `${latest.systolic}/${latest.diastolic}` : `${latest.bpm} bpm`}
              </p>
              <p className={`text-sm font-medium ${isBP
                ? bpCategory(latest.systolic || 0, latest.diastolic || 0).tone
                : hrCategory(latest.bpm || 0).tone}`}>
                {isBP
                  ? bpCategory(latest.systolic || 0, latest.diastolic || 0).label
                  : hrCategory(latest.bpm || 0).label}
              </p>
            </>
          ) : (
            <p className="text-lg text-muted-foreground italic">No readings yet</p>
          )}
        </div>
        <div className="rounded-xl bg-dashboard-mint/70 p-4">
          <p className="text-sm text-muted-foreground flex items-center gap-1">
            <TrendingUp className="w-4 h-4" /> Last 7 average
          </p>
          <p className="text-2xl font-bold text-foreground">{average || "—"}</p>
        </div>
      </div>

      {/* Add form */}
      {isAdding && (
        <div className="mb-4 rounded-xl border bg-background p-4">
          <div className="space-y-4">
            {isBP ? (
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label htmlFor="systolic" className="text-base">Top number (systolic)</Label>
                  <Input id="systolic" type="number" inputMode="numeric" value={systolic}
                    onChange={(e) => setSystolic(e.target.value)} placeholder="120" className="text-lg h-12" />
                </div>
                <div>
                  <Label htmlFor="diastolic" className="text-base">Bottom number (diastolic)</Label>
                  <Input id="diastolic" type="number" inputMode="numeric" value={diastolic}
                    onChange={(e) => setDiastolic(e.target.value)} placeholder="80" className="text-lg h-12" />
                </div>
              </div>
            ) : (
              <div>
                <Label htmlFor="bpm" className="text-base">Beats per minute</Label>
                <Input id="bpm" type="number" inputMode="numeric" value={bpm}
                  onChange={(e) => setBpm(e.target.value)} placeholder="72" className="text-lg h-12" />
              </div>
            )}
            <div>
              <Label htmlFor={`notes-${type}`} className="text-base">Notes (optional)</Label>
              <Textarea id={`notes-${type}`} value={notes} onChange={(e) => setNotes(e.target.value)}
                placeholder="e.g. taken after breakfast, sitting down" className="text-base" />
            </div>
            <div className="flex gap-2">
              <Button onClick={handleSave} disabled={saving} className="flex-1">
                <Check className="w-4 h-4 mr-2" /> Save Reading
              </Button>
              <Button variant="outline" onClick={resetForm}>
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* History */}
      <div className="space-y-2 max-h-[360px] overflow-y-auto">
        {pending.map((p) => {
          const v = p.payload as { systolic?: number; diastolic?: number; bpm?: number };
          return (
            <div
              key={p.id}
              className="flex items-start gap-3 rounded-xl border border-dashed bg-muted/30 p-3"
            >
              <CloudOff className="w-5 h-5 text-amber-600 dark:text-amber-400 mt-1" />
              <div>
                <p className="text-lg font-semibold text-foreground">
                  {isBP ? `${v.systolic}/${v.diastolic}` : `${v.bpm} bpm`}
                </p>
                <p className="text-sm text-muted-foreground">
                  Saved on this device · waiting to upload
                </p>
              </div>
            </div>
          );
        })}

        {readings.length === 0 && pending.length === 0 ? (
          <p className="text-muted-foreground text-base text-center py-6">
            No {title.toLowerCase()} readings recorded yet.
          </p>
        ) : (
          readings.map((r) => {
            const cat = isBP
              ? bpCategory(r.systolic || 0, r.diastolic || 0)
              : hrCategory(r.bpm || 0);
            return (
              <div key={r.id} className="flex items-start justify-between gap-3 border-t px-1 py-3 first:border-t-0">
                <div>
                  <p className="text-lg font-semibold text-foreground">
                    {isBP ? `${r.systolic}/${r.diastolic}` : `${r.bpm} bpm`}
                    <span className={`ml-2 text-sm font-medium ${cat.tone}`}>{cat.label}</span>
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {new Date(r.recorded_at).toLocaleString()}
                    {r.created_by_role === "caregiver" && userRole === "senior" && " · added by your caregiver"}
                    {r.created_by_role === "senior" && userRole === "caregiver" && ` · added by ${seniorName || "senior"}`}
                  </p>
                  {r.notes && <p className="text-sm text-foreground/80 mt-1">{r.notes}</p>}
                </div>
                {(r.recorded_by === userId || userRole === "senior") && (
                  <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive"
                    onClick={() => handleDelete(r.id)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                )}
              </div>
            );
          })
        )}
      </div>
    </Card>
  );
};
