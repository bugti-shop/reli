-- Allow seniors to view their caregivers' profiles
CREATE POLICY "Seniors can view their caregivers profiles"
ON profiles
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM caregiver_seniors
    WHERE caregiver_seniors.caregiver_id = profiles.id
    AND caregiver_seniors.senior_id = auth.uid()
  )
);