import { createClient } from 'npm:@supabase/supabase-js@2'
import { sendTemplateEmail } from '../_shared/transactional-email-templates/send-email.ts'
import { resolveEmailRecipient, resolveSmsRecipient } from '../_shared/notify-recipient.ts'
import { sendSms, toE164 } from '../_shared/send-sms.ts'
import { sendPushToUser } from '../_shared/send-push.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  })

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })

  try {
    const authHeader = req.headers.get('Authorization') ?? ''
    const userClient = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_ANON_KEY')!,
      { global: { headers: { Authorization: authHeader } } }
    )
    const { data: userData } = await userClient.auth.getUser()
    const user = userData?.user
    if (!user) return json({ error: 'Unauthorized' }, 401)

    const body = await req.json().catch(() => ({}))
    const messageId = typeof body?.messageId === 'string' ? body.messageId : ''
    if (!/^[0-9a-f-]{36}$/i.test(messageId)) return json({ error: 'Invalid messageId' }, 400)

    const admin = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    )

    const { data: msg } = await admin
      .from('caregiver_messages')
      .select('id, caregiver_id, senior_id, message, is_reminder, reminder_time, sender_role')
      .eq('id', messageId)
      .maybeSingle()

    if (!msg) return json({ error: 'Message not found' }, 404)

    const fromSenior = msg.sender_role === 'senior'
    const senderId = fromSenior ? msg.senior_id : msg.caregiver_id
    const recipientId = fromSenior ? msg.caregiver_id : msg.senior_id
    if (senderId !== user.id) return json({ error: 'Forbidden' }, 403)

    const { data: sender } = await admin
      .from('profiles')
      .select('full_name')
      .eq('id', senderId)
      .maybeSingle()

    const caregiverName = sender?.full_name || (fromSenior ? 'Your family member' : 'Your caregiver')

    let pushed = 0
    try {
      pushed = await sendPushToUser(admin, recipientId, 'notify_messages', {
        title: `New message from ${caregiverName}`,
        body: String(msg.message || '').slice(0, 300),
        path: '/dashboard',
      })
    } catch (e) {
      console.error('message push failed', e)
    }

    let texted = false
    const smsTo = await resolveSmsRecipient(admin, recipientId, 'notify_messages')
    const phone = toE164(smsTo?.phone)
    if (phone) {
      try {
        const smsResult = await sendSms(
          phone,
          `Reli — new message from ${caregiverName}: "${String(msg.message || '').slice(0, 300)}"`
        )
        texted = smsResult.sent
      } catch (e) {
        console.error('message text failed', e)
      }
    }

    const recipient = await resolveEmailRecipient(admin, recipientId, 'notify_messages')
    if (!recipient) return json({ sent: false, texted, pushed, reason: 'email_off' })

    const result = await sendTemplateEmail('caregiver-message', recipient.email, {
      templateData: {
        recipientName: recipient.name?.split(' ')[0] ?? undefined,
        caregiverName,
        message: String(msg.message || '').slice(0, 2000),
        isReminder: !!msg.is_reminder,
        reminderTime: msg.reminder_time
          ? new Date(msg.reminder_time).toLocaleString('en-US')
          : undefined,
      },
      idempotencyKey: `caregiver-message-${msg.id}`,
    })

    return json({ ...result, texted, pushed })
  } catch (error) {
    console.error('notify-message error', error)
    return json({ error: 'Failed to send notification' }, 500)
  }
})
