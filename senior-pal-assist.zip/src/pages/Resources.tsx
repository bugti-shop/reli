import { useNavigate } from "react-router-dom";
import Header from "@/components/Header";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Resources as ResourcesContent } from "@/components/Resources";
import { Heart, Users } from "lucide-react";

const ResourcesPage = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className="flex-1 max-w-6xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-10">
        <div className="mb-8 text-center">
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-3">Resources</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Guides, trusted organizations, and support lines for seniors and the people who care for them.
          </p>
        </div>

        <Tabs defaultValue="senior" className="w-full">
          <TabsList className="grid w-full max-w-md mx-auto grid-cols-2 mb-6">
            <TabsTrigger value="senior" className="gap-1.5">
              <Heart className="w-4 h-4" /> For Seniors
            </TabsTrigger>
            <TabsTrigger value="caregiver" className="gap-1.5">
              <Users className="w-4 h-4" /> For Caregivers
            </TabsTrigger>
          </TabsList>
          <TabsContent value="senior">
            <ResourcesContent audience="senior" />
          </TabsContent>
          <TabsContent value="caregiver">
            <ResourcesContent audience="caregiver" />
          </TabsContent>
        </Tabs>
      </main>

      <footer className="bg-secondary/30 border-t border-border py-8 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-muted-foreground">
            © {new Date().getFullYear()} Reli. All rights reserved.
          </p>
          <div className="flex justify-center gap-6 mt-3 flex-wrap">
            <button onClick={() => navigate("/privacy-policy")} className="text-muted-foreground hover:text-foreground underline transition-colors">Privacy Policy</button>
            <button onClick={() => navigate("/terms-of-service")} className="text-muted-foreground hover:text-foreground underline transition-colors">Terms of Service</button>
            <button onClick={() => navigate("/contact")} className="text-muted-foreground hover:text-foreground underline transition-colors">Contact</button>
            <button onClick={() => navigate("/faq")} className="text-muted-foreground hover:text-foreground underline transition-colors">FAQ</button>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default ResourcesPage;
