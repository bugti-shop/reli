import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Bell, BellRing, Plus, Trash2, HeartPulse, Heart, Pill, Sparkles } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useTrackerNotifications } from "@/hooks/use-tracker-notifications";
import { usePlan } from "@/hooks/use-plan";
import { Link } from "react-router-dom";

type ReminderKind = "medication" | "blood_pressure" | "heart_rate" | "custom";

interface Reminder {
  id: string;
  source: "tracker" | "medication";
  kind: ReminderKind;
  title: string;
  time: string;
  enabled: boolean;
  days: number[];
  owner_id: string;
}

interface TrackerRemindersProps {
  userId: string;
  userRole: "senior" | "caregiver";
  seniorId: string;
  seniorName?: string;
}

const kindMeta: Record<ReminderKind, { label: string; icon: typeof Pill }> = {
  medication: { label: "Medication", icon: Pill },
  blood_pressure: { label: "Blood pressure", icon: HeartPulse },
  heart_rate: { label: "Heart rate", icon: Heart },
  custom: { label: "Custom reminder", icon: Bell },
};

const DAYS = [
  { value: 0, short: "Sun" },
  { value: 1, short: "Mon" },
  { value: 2, short: "Tue" },
  { value: 3, short: "Wed" },
  { value: 4, short: "Thu" },
  { value: 5, short: "Fri" },
  { value: 6, short: "Sat" },
];

const ALL_DAYS = [0, 1, 2, 3, 4, 5, 6];

const describeDays = (days: number[]) => {
  const sorted = [...new Set(days)].sort((a, b) => a - b);
  if (sorted.length === 0 || sorted.length === 7) return "Every day";
  if (sorted.join(",") === "1,2,3,4,5") return "Weekdays";
  if (sorted.join(",") === "0,6") return "Weekends";
  return sorted.map((d) => DAYS[d].short).join(", ");
};

export const TrackerReminders = ({ userId, userRole, seniorId, seniorName }: TrackerRemindersProps) => {
  const { toast } = useToast();
  const { isPremium } = usePlan(userId);
  const { permission, requestPermission, reloadSchedule } = useTrackerNotifications(
    userRole === "senior" ? seniorId : undefined,
  );

  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [kind, setKind] = useState<ReminderKind>("blood_pressure");
  const [customLabel, setCustomLabel] = useState("");
  const [medName, setMedName] = useState("");
  const [medDosage, setMedDosage] = useState("");
  const [time, setTime] = useState("");
  const [days, setDays] = useState<number[]>(ALL_DAYS);
  const [saving, setSaving] = useState(false);

  const fetchReminders = async () => {
    const [{ data: trackerRows, error }, { data: medRows, error: medError }] = await Promise.all([
      supabase.from("tracker_reminders").select("*").eq("senior_id", seniorId).order("time", { ascending: true }),
      supabase.from("medications").select("*").eq("senior_id", seniorId).order("time", { ascending: true }),
    ]);

    if (error || medError) {
      console.error("Error fetching reminders:", error || medError);
      return;
    }

    const combined: Reminder[] = [
      ...(trackerRows || []).map((r: any) => ({
        id: r.id,
        source: "tracker" as const,
        kind: (r.kind as ReminderKind) || "custom",
        title: r.kind === "custom" ? r.label || "Custom reminder" : kindMeta[(r.kind as ReminderKind) || "custom"].label,
        time: String(r.time).slice(0, 5),
        enabled: r.enabled,
        days: (r.days_of_week as number[]) ?? ALL_DAYS,
        owner_id: r.owner_id,
      })),
      ...(medRows || []).map((m: any) => ({
        id: m.id,
        source: "medication" as const,
        kind: "medication" as ReminderKind,
        title: `${m.name}${m.dosage ? ` — ${m.dosage}` : ""}`,
        time: String(m.time).slice(0, 5),
        enabled: true,
        days: (m.days_of_week as number[]) ?? ALL_DAYS,
        owner_id: m.owner_id,
      })),
    ].sort((a, b) => a.time.localeCompare(b.time));

    setReminders(combined);
  };

  useEffect(() => {
    fetchReminders();
    const onChange = () => fetchReminders();
    window.addEventListener("reli:schedule-changed", onChange);
    return () => window.removeEventListener("reli:schedule-changed", onChange);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [seniorId]);

  const toggleDay = (value: number) => {
    setDays((prev) => (prev.includes(value) ? prev.filter((d) => d !== value) : [...prev, value].sort((a, b) => a - b)));
  };

  const addReminder = async () => {
    if (!/^([01][0-9]|2[0-3]):[0-5][0-9]$/.test(time)) {
      toast({ title: "Pick a time", description: "Choose the time of day for this reminder.", variant: "destructive" });
      return;
    }
    if (days.length === 0) {
      toast({ title: "Pick the days", description: "Choose at least one day of the week.", variant: "destructive" });
      return;
    }
    const trimmedLabel = customLabel.trim().slice(0, 100);
    if (kind === "custom" && !isPremium) {
      toast({ title: "Premium feature", description: "Custom reminders are part of Premium.", variant: "destructive" });
      return;
    }
    if (kind === "custom" && !trimmedLabel) {
      toast({ title: "Name it", description: "Type what this reminder is for.", variant: "destructive" });
      return;
    }

    const trimmedMedName = medName.trim().slice(0, 100);
    const trimmedDosage = medDosage.trim().slice(0, 100);
    if (kind === "medication" && !trimmedMedName) {
      toast({ title: "Medication name", description: "Type the name of the medication.", variant: "destructive" });
      return;
    }

    setSaving(true);

    // Medication reminders are saved as medications so they also show in the
    // medication tracker and the readings header — no duplicate alerts.
    const { error } =
      kind === "medication"
        ? await supabase.from("medications").insert({
            senior_id: seniorId,
            owner_id: userId,
            created_by_role: userRole,
            name: trimmedMedName,
            dosage: trimmedDosage || null,
            time,
            days_of_week: days,
          })
        : await supabase.from("tracker_reminders").insert({
            senior_id: seniorId,
            owner_id: userId,
            created_by_role: userRole,
            kind,
            label: kind === "custom" ? trimmedLabel : kindMeta[kind].label.toLowerCase(),
            time,
            days_of_week: days,
          });
    setSaving(false);

    if (error) {
      console.error("Error adding reminder:", error);
      toast({ title: "Error", description: "Could not add the reminder.", variant: "destructive" });
      return;
    }

    toast({
      title: "Reminder added",
      description: `${kind === "custom" ? trimmedLabel : kind === "medication" ? `${trimmedMedName}${trimmedDosage ? ` — ${trimmedDosage}` : ""}` : kindMeta[kind].label} at ${time} · ${describeDays(days)}.`,
    });
    setTime("");
    setCustomLabel("");
    setMedName("");
    setMedDosage("");
    setDays(ALL_DAYS);
    fetchReminders();
    reloadSchedule();
    window.dispatchEvent(new Event("reli:schedule-changed"));
  };

  const toggleReminder = async (reminder: Reminder) => {
    const { error } = await supabase
      .from("tracker_reminders")
      .update({ enabled: !reminder.enabled })
      .eq("id", reminder.id);

    if (error) {
      console.error("Error updating reminder:", error);
      toast({ title: "Error", description: "Could not update the reminder.", variant: "destructive" });
      return;
    }
    fetchReminders();
    reloadSchedule();
    window.dispatchEvent(new Event("reli:schedule-changed"));
  };

  const removeReminder = async (reminder: Reminder) => {
    const { error } = await supabase
      .from(reminder.source === "medication" ? "medications" : "tracker_reminders")
      .delete()
      .eq("id", reminder.id);
    if (error) {
      console.error("Error deleting reminder:", error);
      toast({ title: "Error", description: "Could not remove the reminder.", variant: "destructive" });
      return;
    }
    setReminders((prev) => prev.filter((r) => !(r.id === reminder.id && r.source === reminder.source)));
    toast({ title: "Reminder removed", description: `${reminder.title} at ${reminder.time} was deleted.` });
    fetchReminders();
    reloadSchedule();
    window.dispatchEvent(new Event("reli:schedule-changed"));
  };

  const handleEnableNotifications = async () => {
    const result = await requestPermission();
    if (result === "granted") {
      toast({ title: "Notifications on", description: "You'll be alerted at each reminder time." });
    } else if (result === "denied") {
      toast({
        title: "Notifications blocked",
        description: "Allow notifications in your browser or phone settings to get alerts.",
        variant: "destructive",
      });
    } else if (result === "unsupported") {
      toast({ title: "Not supported", description: "This device can't show notifications, but in-app alerts still work." });
    }
  };

  return (
    <Card className="rounded-xl border bg-card p-4 shadow-sm sm:p-5">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
        <h2 className="flex items-center gap-3 text-xl font-bold sm:text-2xl">
          <span className="flex h-11 w-11 items-center justify-center rounded-full bg-dashboard-sky text-primary"><Bell className="h-6 w-6" /></span>
          Reminders
        </h2>
        {userRole === "senior" && (
          <Button
            variant={permission === "granted" ? "outline" : "default"}
            size="sm"
            onClick={handleEnableNotifications}
            disabled={permission === "granted"}
            className="gap-2"
          >
            <BellRing className="w-4 h-4" />
            {permission === "granted" ? "Notifications on" : "Turn on notifications"}
          </Button>
        )}
      </div>

      <p className="mb-4 text-sm text-muted-foreground">
        {userRole === "senior"
          ? "Set the times and days you'd like to be reminded to take medications or record a reading."
          : `Set reminder times and days for ${seniorName || "this senior"} — they'll get an alert on their device.`}
      </p>

      <div className="mb-6 grid gap-3 rounded-xl bg-dashboard-sky/45 p-4 sm:grid-cols-3">
        <div>
          <Label htmlFor="reminder-kind" className="text-base">What for</Label>
          <select
            id="reminder-kind"
            value={kind}
            onChange={(e) => setKind(e.target.value as ReminderKind)}
            className="w-full h-11 mt-1 rounded-md border border-input bg-background px-3 text-base"
          >
            <option value="blood_pressure">Blood pressure reading</option>
            <option value="heart_rate">Heart rate reading</option>
            <option value="medication">Medication</option>
            <option value="custom" disabled={!isPremium}>Custom reminder (Premium)</option>
          </select>
          {!isPremium && (
            <p className="text-sm text-muted-foreground mt-1">
              Custom reminders are a Premium feature.{" "}
              <Link to="/pricing" className="text-primary underline">Upgrade to unlock</Link>.
            </p>
          )}
        </div>
        {kind === "custom" && isPremium && (
          <div className="sm:col-span-2">
            <div className="flex items-center gap-2 flex-wrap">
              <Label htmlFor="reminder-label" className="text-base">Custom reminder name</Label>
              <Badge className="bg-primary text-primary-foreground gap-1">
                <Sparkles className="w-3 h-3" /> Premium
              </Badge>
            </div>
            <Input
              id="reminder-label"
              value={customLabel}
              onChange={(e) => setCustomLabel(e.target.value)}
              maxLength={100}
              placeholder="e.g., Drink a glass of water, Walk the dog"
              className="text-base h-11 mt-1"
            />
          </div>
        )}
        {kind === "medication" && (
          <>
            <div>
              <Label htmlFor="med-name" className="text-base">Medication name</Label>
              <Input
                id="med-name"
                value={medName}
                onChange={(e) => setMedName(e.target.value)}
                maxLength={100}
                placeholder="e.g., Lisinopril"
                className="text-base h-11 mt-1"
              />
            </div>
            <div>
              <Label htmlFor="med-dosage" className="text-base">Dosage</Label>
              <Input
                id="med-dosage"
                value={medDosage}
                onChange={(e) => setMedDosage(e.target.value)}
                maxLength={100}
                placeholder="e.g., 10 mg, 1 tablet"
                className="text-base h-11 mt-1"
              />
            </div>
          </>
        )}
        <div>
          <Label htmlFor="reminder-time" className="text-base">Time</Label>
          <Input
            id="reminder-time"
            type="time"
            value={time}
            onChange={(e) => setTime(e.target.value)}
            className="text-base h-11 mt-1"
          />
        </div>
        <div className="sm:col-span-3">
          <Label className="text-base">Which days? ({days.length} {days.length === 1 ? "time" : "times"} a week)</Label>
          <div className="flex flex-wrap gap-2 mt-2">
            {DAYS.map((d) => {
              const active = days.includes(d.value);
              return (
                <Button
                  key={d.value}
                  type="button"
                  variant={active ? "default" : "outline"}
                  onClick={() => toggleDay(d.value)}
                  aria-pressed={active}
                  className="h-11 min-w-[64px] text-base"
                >
                  {d.short}
                </Button>
              );
            })}
          </div>
          <div className="flex flex-wrap gap-2 mt-2">
            <Button type="button" variant="ghost" size="sm" onClick={() => setDays(ALL_DAYS)}>Every day</Button>
            <Button type="button" variant="ghost" size="sm" onClick={() => setDays([1, 2, 3, 4, 5])}>Weekdays</Button>
            <Button type="button" variant="ghost" size="sm" onClick={() => setDays([0, 6])}>Weekends</Button>
          </div>
        </div>
        <div className="flex items-end sm:col-span-3">
          <Button onClick={addReminder} disabled={saving} className="w-full h-11 gap-2">
            <Plus className="w-4 h-4" /> Add Reminder
          </Button>
        </div>
      </div>

      {reminders.length === 0 ? (
        <p className="text-muted-foreground text-base text-center py-4">No reminders set yet.</p>
      ) : (
        <div className="space-y-2">
          {reminders.map((r) => {
            const Icon = kindMeta[r.kind].icon;
            return (
              <div
                key={`${r.source}-${r.id}`}
                className="flex items-center justify-between gap-3 border-t px-1 py-3 first:border-t-0"
              >
                <div className="flex items-center gap-3">
                  <Icon className="w-5 h-5 text-primary" />
                  <div>
                    <p className="text-lg font-medium">{r.title}</p>
                    <p className="text-sm text-muted-foreground">
                      {describeDays(r.days)} at {r.time}
                      {!r.enabled && " · paused"}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  {r.source === "tracker" && (
                    <>
                      {r.enabled ? <Badge variant="secondary">On</Badge> : <Badge variant="outline">Off</Badge>}
                      <Switch checked={r.enabled} onCheckedChange={() => toggleReminder(r)} aria-label="Toggle reminder" />
                    </>
                  )}
                  {(r.owner_id === userId || userRole === "senior") && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-destructive hover:text-destructive"
                      onClick={() => removeReminder(r)}
                      aria-label={`Delete reminder ${r.title}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </Card>
  );
};

export default TrackerReminders;
