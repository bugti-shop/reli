import * as React from 'npm:react@18.3.1'
import {
  Body,
  Container,
  Head,
  Heading,
  Html,
  Preview,
  Section,
  Text,
} from 'npm:@react-email/components@0.0.22'
import type { TemplateEntry } from './registry.ts'

interface Props {
  recipientName?: string
  caregiverName?: string
  message?: string
  isReminder?: boolean
  reminderTime?: string
}

const Email = ({
  recipientName,
  caregiverName = 'Your caregiver',
  message = '',
  isReminder = false,
  reminderTime,
}: Props) => (
  <Html lang="en" dir="ltr">
    <Head />
    <Preview>{isReminder ? `New reminder from ${caregiverName}` : `New message from ${caregiverName}`}</Preview>
    <Body style={main}>
      <Container style={container}>
        <Heading style={h1}>
          {isReminder ? 'New reminder' : 'New message'} from {caregiverName}
        </Heading>
        <Text style={text}>
          {recipientName ? `Hi ${recipientName},` : 'Hello,'} you have a new{' '}
          {isReminder ? 'reminder' : 'message'} waiting in Reli.
        </Text>
        <Section style={quote}>
          <Text style={quoteText}>{message}</Text>
        </Section>
        {isReminder && reminderTime ? (
          <Text style={text}>Reminder time: {reminderTime}</Text>
        ) : null}
        <Text style={footer}>Sent from Reli</Text>
      </Container>
    </Body>
  </Html>
)

export const template = {
  component: Email,
  subject: (data: Record<string, any>) =>
    data.isReminder
      ? `Reminder from ${data.caregiverName || 'your caregiver'}`
      : `New message from ${data.caregiverName || 'your caregiver'}`,
  displayName: 'Caregiver message',
  previewData: {
    recipientName: 'Mary',
    caregiverName: 'Jake',
    message: 'Remember to take your afternoon walk today!',
    isReminder: false,
  },
} satisfies TemplateEntry

const main = { backgroundColor: '#ffffff', fontFamily: 'Arial, sans-serif' }
const container = { padding: '20px 25px' }
const h1 = {
  fontSize: '22px',
  fontWeight: 'bold' as const,
  color: 'hsl(24, 20%, 15%)',
  margin: '0 0 20px',
}
const text = {
  fontSize: '16px',
  color: 'hsl(24, 15%, 35%)',
  lineHeight: '1.6',
  margin: '0 0 18px',
}
const quote = {
  backgroundColor: 'hsl(206, 55%, 96%)',
  borderLeft: '4px solid hsl(206, 55%, 38%)',
  borderRadius: '10px',
  padding: '14px 18px',
  margin: '0 0 20px',
}
const quoteText = {
  fontSize: '18px',
  color: 'hsl(24, 20%, 15%)',
  lineHeight: '1.6',
  margin: '0',
}
const footer = { fontSize: '12px', color: '#999999', margin: '30px 0 0' }
