# Caregiver Dashboard Visual Match

## Goal
Make the Caregiver dashboard feel like the same Reli app as the Senior/Myself dashboard while preserving caregiver-specific workflows, permissions, and data.

## What will change
- Replace the current sticky text header with the same Reli logo header, spacing, background, and compact mobile treatment used on the Senior dashboard.
- Restyle the blue summary area to match the Senior scenic card: same mountain background behavior, rounded shape, text readability, spacing, and compact health tiles.
- Keep caregiver context inside that card: caregiver greeting, number of seniors managed, selected senior, edit-profile action, and that senior's latest BP, heart rate, medications, and emergency details.
- Turn the senior picker into a compact, highly visible control directly below the summary card; keep both linked and caregiver-managed seniors supported.
- Replace the caregiver's expandable four-button dock with the same fixed five-item bottom navigation structure and visual treatment as the Senior dashboard.
- Reorganize the existing caregiver screens under five caregiver-specific destinations:
  - **Home:** emergency alerts, Add Senior, senior picker, join requests, messages, reminders, and today's activity.
  - **Daily Log:** caregiver daily entry and history.
  - **Trackers:** medications, vitals, reminders, history, insights, and custom trackers.
  - **Care:** doctor questions and Life Story (hidden for managed seniors as today).
  - **More:** senior feature controls, reports/sharing, caregiver resources, notification/contact settings, caregiver profile, and logout.
- Match the Senior dashboard's page width, compact mobile spacing, headings, sub-navigation buttons, card rhythm, colors, and fixed-bottom safe-area spacing.
- Remove the old side drawer and old caregiver bottom-bar presentation after all destinations are available in the new five-item navigation.

## Functionality preserved
- Add a linked senior by email or invite code.
- Create and later invite a managed senior without an account.
- Switch between multiple seniors and edit their profiles.
- Review/approve/decline/cancel/remove caregiver connection requests.
- Read and send messages/reminders.
- Review emergency alerts and daily activity.
- Daily logs, medication/vital/custom tracking, interaction checks, reminders, history, health insights, doctor questions, Life Story, reports, resources, settings, and feature visibility.
- Free/Premium limits and existing backend access rules remain unchanged.

## Verification
- Check the caregiver flow with a signed-in account and selected senior.
- Confirm every old caregiver destination remains reachable in the new navigation.
- Verify the scenic summary and bottom navigation at mobile and desktop sizes.
- Confirm no overlaps with the fixed bottom navigation and no build/runtime errors.

## Technical details
- Reuse `SeniorBottomNav`, `SeniorLandscapeBackground`, and the compact `DashboardHealthSummary` reference variant instead of creating a second visual system.
- Keep the caregiver data calls and role props unchanged; this is a presentation and navigation restructuring only.
- Record the shared dashboard-shell decision in the project architecture rules.
