import { supabase } from "@/integrations/supabase/client";

export type CalendarEventType = "appointment" | "task" | "other";

export interface CalendarEvent {
  id: string;
  senior_id: string;
  owner_id: string;
  created_by_role: string;
  title: string;
  event_date: string; // yyyy-mm-dd
  event_time: string | null; // HH:MM or null
  event_type: string;
  notes: string | null;
  completed: boolean;
  created_at: string;
  updated_at: string;
}

export const EVENT_TYPE_LABELS: Record<string, string> = {
  appointment: "Appointment",
  task: "Task",
  other: "Other",
};

/** Local yyyy-mm-dd for a Date (no timezone drift). */
export function toISODate(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function parseISODate(iso: string): Date {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(y, (m ?? 1) - 1, d ?? 1);
}

/** Monday-based start of the week containing `d`. */
export function startOfWeek(d: Date): Date {
  const out = new Date(d);
  const day = out.getDay(); // 0 Sun .. 6 Sat
  const diff = day === 0 ? -6 : 1 - day;
  out.setDate(out.getDate() + diff);
  out.setHours(0, 0, 0, 0);
  return out;
}

export function addDays(d: Date, n: number): Date {
  const out = new Date(d);
  out.setDate(out.getDate() + n);
  return out;
}

export function eventsByDate(events: CalendarEvent[]): Map<string, CalendarEvent[]> {
  const map = new Map<string, CalendarEvent[]>();
  for (const e of events) {
    const list = map.get(e.event_date) ?? [];
    list.push(e);
    map.set(e.event_date, list);
  }
  return map;
}

export function formatEventTime(time: string | null): string {
  if (!time) return "";
  const [h, m] = time.split(":").map(Number);
  const d = new Date();
  d.setHours(h ?? 0, m ?? 0, 0, 0);
  return d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
}

export async function fetchCalendarEvents(seniorId: string, fromISO: string, toISO: string): Promise<CalendarEvent[]> {
  const { data, error } = await supabase
    .from("calendar_events")
    .select("*")
    .eq("senior_id", seniorId)
    .gte("event_date", fromISO)
    .lte("event_date", toISO)
    .order("event_date", { ascending: true })
    .order("event_time", { ascending: true, nullsFirst: false });
  if (error) throw error;
  return (data ?? []) as CalendarEvent[];
}

export interface AddCalendarEventInput {
  seniorId: string;
  ownerId: string;
  role: "caregiver" | "senior";
  title: string;
  date: string;
  time: string | null;
  type: CalendarEventType;
  notes: string | null;
}

export async function addCalendarEvent(input: AddCalendarEventInput): Promise<void> {
  const { error } = await supabase.from("calendar_events").insert({
    senior_id: input.seniorId,
    owner_id: input.ownerId,
    created_by_role: input.role,
    title: input.title.trim(),
    event_date: input.date,
    event_time: input.time,
    event_type: input.type,
    notes: input.notes?.trim() ? input.notes.trim() : null,
    completed: false,
  });
  if (error) throw error;
}

export async function setEventCompleted(id: string, completed: boolean): Promise<void> {
  const { error } = await supabase
    .from("calendar_events")
    .update({ completed, completed_at: completed ? new Date().toISOString() : null })
    .eq("id", id);
  if (error) throw error;
}

export async function deleteCalendarEvent(id: string): Promise<void> {
  const { error } = await supabase.from("calendar_events").delete().eq("id", id);
  if (error) throw error;
}
