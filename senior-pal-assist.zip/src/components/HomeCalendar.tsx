import { useCallback, useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import {
  CalendarDays, CalendarIcon, Check, Plus, Trash2,
} from "lucide-react";
import {
  addCalendarEvent, addDays, deleteCalendarEvent, fetchCalendarEvents, formatEventTime,
  parseISODate, setEventCompleted, startOfWeek, toISODate,
  EVENT_TYPE_LABELS, type CalendarEvent, type CalendarEventType,
} from "@/lib/calendarEvents";

const WEEKDAY_LABELS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
type ViewMode = "day" | "week" | "month";

interface HomeCalendarProps {
  seniorId: string;
  role: "caregiver" | "senior";
}

export const HomeCalendar = ({ seniorId, role }: HomeCalendarProps) => {
  const { toast } = useToast();
  const [view, setView] = useState<ViewMode>("day");
  const [selected, setSelected] = useState<Date>(new Date());
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [loading, setLoading] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [userId, setUserId] = useState<string | null>(null);
  const [form, setForm] = useState({
    title: "",
    date: toISODate(new Date()),
    time: "",
    type: "appointment" as CalendarEventType,
    notes: "",
  });

  const loadEvents = useCallback(async () => {
    setLoading(true);
    try {
      // Load a wide window around the selected month so week/month views stay covered.
      const base = parseISODate(toISODate(selected));
      const from = toISODate(addDays(new Date(base.getFullYear(), base.getMonth(), 1), -14));
      const to = toISODate(addDays(new Date(base.getFullYear(), base.getMonth() + 1, 0), 14));
      setEvents(await fetchCalendarEvents(seniorId, from, to));
    } catch {
      toast({ title: "Couldn't load calendar", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [seniorId, selected, toast]);

  useEffect(() => { loadEvents(); }, [loadEvents]);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setUserId(data.user?.id ?? null));
  }, []);

  const byDate = useMemo(() => {
    const map = new Map<string, CalendarEvent[]>();
    for (const e of events) {
      const list = map.get(e.event_date) ?? [];
      list.push(e);
      map.set(e.event_date, list);
    }
    return map;
  }, [events]);

  const weekStart = useMemo(() => startOfWeek(selected), [selected]);
  const weekDays = useMemo(() => Array.from({ length: 7 }, (_, i) => addDays(weekStart, i)), [weekStart]);

  const monthTitle = selected.toLocaleDateString("en-US", { month: "long", year: "numeric" });

  const monthGrid = useMemo(() => {
    const first = new Date(selected.getFullYear(), selected.getMonth(), 1);
    const gridStart = startOfWeek(first);
    return Array.from({ length: 42 }, (_, i) => addDays(gridStart, i));
  }, [selected]);

  const dayEvents = (byDate.get(toISODate(selected)) ?? []).sort(
    (a, b) => (a.event_time ?? "99:99").localeCompare(b.event_time ?? "99:99"),
  );

  const weekEvents = useMemo(
    () => events.filter((e) => {
      const d = parseISODate(e.event_date);
      return d >= weekStart && d < addDays(weekStart, 7);
    }),
    [events, weekStart],
  );

  const handleAdd = async () => {
    if (!userId) { toast({ title: "Please sign in first", variant: "destructive" }); return; }
    if (!form.title.trim()) { toast({ title: "Give it a title first", variant: "destructive" }); return; }
    setSaving(true);
    try {
      await addCalendarEvent({
        seniorId,
        ownerId: userId,
        role,
        title: form.title,
        date: form.date,
        time: form.time || null,
        type: form.type,
        notes: form.notes || null,
      });
      setDialogOpen(false);
      setForm({ title: "", date: toISODate(selected), time: "", type: "appointment", notes: "" });
      setSelected(parseISODate(form.date));
      await loadEvents();
      toast({ title: "Added to the calendar" });
    } catch (e) {
      toast({ title: "Couldn't add entry", description: e instanceof Error ? e.message : undefined, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const toggleDone = async (e: CalendarEvent) => {
    setEvents((prev) => prev.map((x) => (x.id === e.id ? { ...x, completed: !x.completed } : x)));
    try { await setEventCompleted(e.id, !e.completed); } catch {
      setEvents((prev) => prev.map((x) => (x.id === e.id ? { ...x, completed: e.completed } : x)));
      toast({ title: "Couldn't update entry", variant: "destructive" });
    }
  };

  const remove = async (e: CalendarEvent) => {
    setEvents((prev) => prev.filter((x) => x.id !== e.id));
    try { await deleteCalendarEvent(e.id); } catch {
      await loadEvents();
      toast({ title: "Couldn't delete entry", variant: "destructive" });
    }
  };

  const openAddFor = (d: Date) => {
    setForm({ title: "", date: toISODate(d), time: "", type: "appointment", notes: "" });
    setDialogOpen(true);
  };

  const EventRow = ({ e }: { e: CalendarEvent }) => (
    <div className={`flex items-start gap-3 rounded-xl border border-border/50 bg-background p-3 ${e.completed ? "opacity-60" : ""}`}>
      <button
        type="button"
        aria-label={e.completed ? "Mark as not done" : "Mark as done"}
        onClick={() => toggleDone(e)}
        className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full border-2 transition-colors ${e.completed ? "border-primary bg-primary text-primary-foreground" : "border-muted-foreground/40"}`}
      >
        {e.completed && <Check className="h-3 w-3" />}
      </button>
      <div className="min-w-0 flex-1">
        <p className={`truncate text-sm font-semibold text-foreground ${e.completed ? "line-through" : ""}`}>{e.title}</p>
        <p className="text-xs text-muted-foreground">
          {formatEventTime(e.event_time) || "All day"}
          {e.notes ? ` · ${e.notes}` : ""}
        </p>
      </div>
      <span className="shrink-0 rounded-full bg-muted px-2 py-0.5 text-[10px] font-medium text-muted-foreground">{EVENT_TYPE_LABELS[e.event_type] ?? "Other"}</span>
      <button type="button" aria-label="Delete entry" onClick={() => remove(e)} className="shrink-0 text-muted-foreground/60 hover:text-destructive">
        <Trash2 className="h-4 w-4" />
      </button>
    </div>
  );

  const DayChip = ({ d, compact }: { d: Date; compact?: boolean }) => {
    const iso = toISODate(d);
    const isToday = iso === toISODate(new Date());
    const isSelected = iso === toISODate(selected);
    const count = (byDate.get(iso) ?? []).length;
    const inMonth = d.getMonth() === selected.getMonth();
    return (
      <button type="button" onClick={() => { setSelected(d); setView("day"); }} className="flex flex-col items-center gap-1 outline-none">
        <span className={`text-[10px] font-bold uppercase tracking-wider ${isSelected ? "text-primary" : "text-muted-foreground"}`}>
          {WEEKDAY_LABELS[(d.getDay() + 6) % 7]}
        </span>
        <span className={`flex ${compact ? "h-8 w-8" : "h-10 w-10"} flex-col items-center justify-center rounded-xl transition-transform ${
          isSelected ? "scale-105 bg-foreground text-primary-foreground shadow-lg" : isToday ? "bg-primary/10 text-primary" : "text-foreground"
        } ${!inMonth && !isSelected ? "opacity-40" : ""}`}>
          <span className={`text-sm font-bold leading-none ${isSelected ? "text-primary-foreground" : ""}`}>{d.getDate()}</span>
          {!compact && <span className={`text-[8px] font-semibold uppercase leading-tight ${isSelected ? "text-primary-foreground/70" : "text-muted-foreground"}`}>
            {d.toLocaleDateString("en-US", { month: "short" })}
          </span>}
        </span>
        <span className="flex h-1.5 items-center justify-center gap-0.5">
          {Array.from({ length: Math.min(count, 3) }).map((_, i) => (
            <span key={i} className={`h-1 w-1 rounded-full ${isSelected ? "bg-primary-foreground/80" : "bg-destructive"}`} />
          ))}
        </span>
      </button>
    );
  };

  return (
    <div className="relative overflow-hidden rounded-[1.65rem] border border-border/40 bg-card shadow-sm md:rounded-[2rem]">
      <div className="p-5 pb-4">
        <div className="mb-4 flex items-center justify-between gap-2">
          <h3 className="font-heading text-lg font-bold tracking-tight text-foreground md:text-2xl">{monthTitle}</h3>
          <div className="flex rounded-full bg-muted p-1">
            {(["day", "week", "month"] as ViewMode[]).map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => setView(m)}
                className={`rounded-full px-3 py-1 text-xs font-semibold capitalize transition-all md:px-4 ${view === m ? "bg-card text-primary shadow-sm" : "text-muted-foreground"}`}
              >
                {m}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-7 text-center">
          {view === "month"
            ? monthGrid.slice(0, 7).map((d) => <DayChip key={toISODate(d)} d={d} compact />)
            : weekDays.map((d) => <DayChip key={toISODate(d)} d={d} />)}
        </div>

        {view === "month" && (
          <div className="mt-2 grid grid-cols-7 gap-y-1 text-center">
            {monthGrid.slice(7).map((d) => <DayChip key={toISODate(d)} d={d} compact />)}
          </div>
        )}

        <div className="mt-3 h-px w-full bg-border/60" />
      </div>

      <div className="relative min-h-[11rem] px-5 pb-6">
        <div aria-hidden className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-[0.04]">
          <HeartWatermark />
        </div>
        {view === "day" && (
          dayEvents.length ? (
            <div className="relative space-y-2">
              {dayEvents.map((e) => <EventRow key={e.id} e={e} />)}
            </div>
          ) : (
            <div className="relative flex flex-col items-center justify-center py-10 text-center">
              <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-full border border-border bg-card shadow-sm">
                <CalendarIcon className="h-5 w-5 text-muted-foreground" />
              </div>
              <p className="text-sm font-medium text-muted-foreground">{loading ? "Loading…" : "No tasks for this date yet."}</p>
            </div>
          )
        )}

        {view === "week" && (
          weekEvents.length ? (
            <div className="relative space-y-3">
              {weekDays.map((d) => {
                const list = byDate.get(toISODate(d)) ?? [];
                if (!list.length) return null;
                return (
                  <div key={toISODate(d)}>
                    <p className="mb-1 text-xs font-bold uppercase tracking-wide text-muted-foreground">
                      {d.toLocaleDateString("en-US", { weekday: "long", month: "short", day: "numeric" })}
                    </p>
                    <div className="space-y-2">{list.map((e) => <EventRow key={e.id} e={e} />)}</div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="relative flex flex-col items-center justify-center py-10 text-center">
              <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-full border border-border bg-card shadow-sm">
                <CalendarIcon className="h-5 w-5 text-muted-foreground" />
              </div>
              <p className="text-sm font-medium text-muted-foreground">{loading ? "Loading…" : "No tasks this week yet."}</p>
            </div>
          )
        )}

        {view === "month" && (
          (byDate.get(toISODate(selected)) ?? []).length ? (
            <div className="relative mt-2 space-y-2">{dayEvents.map((e) => <EventRow key={e.id} e={e} />)}</div>
          ) : (
            <div className="relative flex flex-col items-center justify-center py-8 text-center">
              <p className="text-sm font-medium text-muted-foreground">{loading ? "Loading…" : "No tasks for this date yet."}</p>
            </div>
          )
        )}

        <Button
          type="button"
          size="icon"
          onClick={() => openAddFor(selected)}
          aria-label="Add calendar entry"
          className="absolute bottom-0 right-0 h-12 w-12 rounded-full bg-destructive text-destructive-foreground shadow-lg transition-transform hover:bg-destructive/90 active:scale-90"
        >
          <Plus className="h-6 w-6" />
        </Button>
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><CalendarDays className="h-5 w-5 text-primary" />Add to Calendar</DialogTitle>
            <DialogDescription>Mark an appointment or task for this date.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label htmlFor="cal-title">Title</Label>
              <Input id="cal-title" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Doctor visit, appointment, task…" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="cal-date">Date</Label>
                <Input id="cal-date" type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="cal-time">Time (optional)</Label>
                <Input id="cal-time" type="time" value={form.time} onChange={(e) => setForm({ ...form, time: e.target.value })} />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Type</Label>
              <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v as CalendarEventType })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="appointment">Appointment</SelectItem>
                  <SelectItem value="task">Task</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="cal-notes">Notes (optional)</Label>
              <Textarea id="cal-notes" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} className="min-h-[70px]" placeholder="Address, who's coming, anything to remember…" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleAdd} disabled={saving}>{saving ? "Adding…" : "Add"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

const HeartWatermark = () => (
  <svg width="220" height="220" viewBox="0 0 24 24" fill="currentColor" className="text-primary">
    <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
  </svg>
);
