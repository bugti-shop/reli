import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { CalendarDays, Pill, Plus, X, CheckCircle2, Circle, User, CloudOff } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";
import { enqueue, getQueue, isOnline, removeFromQueue } from "@/lib/offlineQueue";
import { usePendingQueue } from "@/hooks/use-offline-sync";
import { MedicationInteractions } from "@/components/MedicationInteractions";

interface Medication {
  id: string;
  name: string;
  time: string;
  dosage: string | null;
  notes: string | null;
  completed: boolean;
  completed_at: string | null;
  created_by_role: string;
  owner_id: string;
  days_of_week?: number[] | null;
}

const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const ALL_DAYS = [0, 1, 2, 3, 4, 5, 6];
const describeDays = (days?: number[] | null) => {
  const sorted = [...new Set(days ?? ALL_DAYS)].sort((a, b) => a - b);
  if (sorted.length === 0 || sorted.length === 7) return "Every day";
  if (sorted.join(",") === "1,2,3,4,5") return "Weekdays";
  if (sorted.join(",") === "0,6") return "Weekends";
  return `${sorted.length}×/week: ${sorted.map((d) => DAYS[d]).join(", ")}`;
};

interface SharedMedicationTrackerProps {
  userId: string;
  userRole: "senior" | "caregiver";
  seniorId: string;
  seniorName?: string;
  onDoseLogged?: () => void;
}

export const SharedMedicationTracker = ({
  userId,
  userRole,
  seniorId,
  seniorName,
  onDoseLogged,
}: SharedMedicationTrackerProps) => {
  const [medications, setMedications] = useState<Medication[]>([]);
  const [newMedName, setNewMedName] = useState("");
  const [newMedTime, setNewMedTime] = useState("");
  const [newMedDosage, setNewMedDosage] = useState("");
  const [newMedDays, setNewMedDays] = useState<number[]>(ALL_DAYS);
  const [isLoading, setIsLoading] = useState(true);
  const [isAdding, setIsAdding] = useState(false);
  const { toast } = useToast();
  const pendingDoses = usePendingQueue("medication_doses");
  const pendingMedIds = new Set(
    pendingDoses.map((p) => String((p.payload as { medication_id?: string })?.medication_id || ""))
  );

  useEffect(() => {
    fetchMedications();
    const onChange = () => fetchMedications();
    window.addEventListener("reli:schedule-changed", onChange);
    return () => window.removeEventListener("reli:schedule-changed", onChange);
  }, [seniorId]);

  const fetchMedications = async () => {
    setIsLoading(true);
    const { data, error } = await supabase
      .from("medications")
      .select("*")
      .eq("senior_id", seniorId)
      .order("time", { ascending: true });

    if (error) {
      console.error("Error fetching medications:", error);
    } else {
      setMedications(data || []);
    }
    setIsLoading(false);
  };

  const addMedication = async () => {
    if (!newMedName.trim() || !newMedTime) {
      toast({
        title: "Missing Information",
        description: "Please enter both medication name and time.",
        variant: "destructive",
      });
      return;
    }
    if (newMedDays.length === 0) {
      toast({
        title: "Pick the days",
        description: "Choose at least one day of the week.",
        variant: "destructive",
      });
      return;
    }

    const { error } = await supabase.from("medications").insert({
      owner_id: userId,
      senior_id: seniorId,
      created_by_role: userRole,
      name: newMedName.trim(),
      time: newMedTime,
      dosage: newMedDosage.trim() || null,
      days_of_week: newMedDays,
    });

    if (error) {
      console.error("Error adding medication:", error);
      toast({
        title: "Error",
        description: "Failed to add medication. Please try again.",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Medication Added",
      description: `${newMedName} at ${newMedTime} · ${describeDays(newMedDays)}. Added to Reminders too.`,
    });
    setNewMedName("");
    setNewMedTime("");
    setNewMedDosage("");
    setNewMedDays(ALL_DAYS);
    setIsAdding(false);
    fetchMedications();
    window.dispatchEvent(new Event("reli:schedule-changed"));
    window.dispatchEvent(new Event("reli:med-added"));
  };

  const toggleDay = (value: number) =>
    setNewMedDays((prev) =>
      prev.includes(value) ? prev.filter((d) => d !== value) : [...prev, value].sort((a, b) => a - b)
    );

  const toggleCompleted = async (medication: Medication) => {
    const newCompleted = !medication.completed;
    const takenAt = new Date().toISOString();

    if (!isOnline()) {
      enqueue({
        table: "medications",
        op: "update",
        matchId: medication.id,
        payload: { completed: newCompleted, completed_at: newCompleted ? takenAt : null },
        label: `${medication.name} ${newCompleted ? "marked as taken" : "un-checked"}`,
      });
      if (newCompleted) {
        enqueue({
          table: "medication_doses",
          op: "insert",
          payload: {
            medication_id: medication.id,
            senior_id: seniorId,
            medication_name: medication.name,
            scheduled_time: medication.time,
            dosage: medication.dosage,
            taken_at: takenAt,
            taken_by: userId,
            taken_by_role: userRole,
          },
          label: `${medication.name} dose`,
        });
      } else {
        // Cancel a dose that hasn't been uploaded yet
        getQueue()
          .filter(
            (q) =>
              q.table === "medication_doses" &&
              (q.payload as { medication_id?: string })?.medication_id === medication.id
          )
          .forEach((q) => removeFromQueue(q.id));
      }

      setMedications((prev) =>
        prev.map((m) =>
          m.id === medication.id
            ? { ...m, completed: newCompleted, completed_at: newCompleted ? takenAt : null }
            : m
        )
      );
      toast({
        title: "Saved on this device",
        description: "No internet right now — this will upload automatically later.",
      });
      onDoseLogged?.();
      return;
    }

    const { error } = await supabase
      .from("medications")
      .update({
        completed: newCompleted,
        completed_at: newCompleted ? takenAt : null,
      })
      .eq("id", medication.id);

    if (error) {
      console.error("Error updating medication:", error);
      toast({
        title: "Error",
        description: "Failed to update medication status.",
        variant: "destructive",
      });
      return;
    }

    if (newCompleted) {
      // Record this dose in the permanent history
      const { error: doseError } = await supabase.from("medication_doses").insert({
        medication_id: medication.id,
        senior_id: seniorId,
        medication_name: medication.name,
        scheduled_time: medication.time,
        dosage: medication.dosage,
        taken_at: takenAt,
        taken_by: userId,
        taken_by_role: userRole,
      });
      if (doseError) console.error("Error recording dose:", doseError);
      toast({
        title: "Marked as taken",
        description: `${medication.name} recorded at ${new Date(takenAt).toLocaleTimeString([], {
          hour: "numeric",
          minute: "2-digit",
        })}.`,
      });
      onDoseLogged?.();
    } else {
      // Undo: remove the most recent dose record for this medication today
      const startOfDay = new Date();
      startOfDay.setHours(0, 0, 0, 0);
      const { data: recent } = await supabase
        .from("medication_doses")
        .select("id")
        .eq("medication_id", medication.id)
        .is("deleted_at", null)
        .gte("taken_at", startOfDay.toISOString())
        .order("taken_at", { ascending: false })
        .limit(1);

      if (recent?.[0]) {
        const { error: delError } = await supabase
          .from("medication_doses")
          .update({ deleted_at: new Date().toISOString() })
          .eq("id", recent[0].id);
        if (delError) console.error("Error removing dose record:", delError);
      }
      onDoseLogged?.();
    }

    fetchMedications();
  };

  const removeMedication = async (id: string) => {
    const { error } = await supabase
      .from("medications")
      .delete()
      .eq("id", id);

    if (error) {
      console.error("Error removing medication:", error);
      toast({
        title: "Error",
        description: "Failed to remove medication.",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Medication Removed",
      description: "Medication has been removed from the list.",
    });
    fetchMedications();
    window.dispatchEvent(new Event("reli:schedule-changed"));
  };

  const resetAllCompleted = async () => {
    const { error } = await supabase
      .from("medications")
      .update({ completed: false, completed_at: null })
      .eq("senior_id", seniorId);

    if (error) {
      console.error("Error resetting medications:", error);
      toast({
        title: "Error",
        description: "Failed to reset medications.",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "All Reset",
      description: "All medications have been reset for a new day.",
    });
    fetchMedications();
  };

  const completedCount = medications.filter((m) => m.completed).length;
  const canDelete = (med: Medication) => med.owner_id === userId;

  return (
    <div className="relative space-y-5 pb-20">
      <div className="grid grid-cols-2 gap-3">
        <div className="flex min-h-24 items-center gap-3 rounded-xl border bg-card p-4 shadow-sm">
          <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-dashboard-sky text-primary"><CalendarDays className="h-6 w-6" /></span>
          <div><p className="text-2xl font-bold">{medications.length}</p><p className="text-sm font-semibold">scheduled</p><p className="text-xs text-muted-foreground">Today</p></div>
        </div>
        <div className="flex min-h-24 items-center gap-3 rounded-xl border bg-card p-4 shadow-sm">
          <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-dashboard-mint text-primary"><CheckCircle2 className="h-6 w-6" /></span>
          <div><p className="text-2xl font-bold">{completedCount}</p><p className="text-sm font-semibold">taken</p><p className="text-xs text-muted-foreground">So far today</p></div>
        </div>
      </div>

      <div className="flex items-center justify-between gap-3">
        <h2 className="text-xl font-bold sm:text-2xl">Today's Medications</h2>
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium text-muted-foreground">{new Date().toLocaleDateString([], { weekday: "short", month: "short", day: "numeric" })}</span>
          {completedCount > 0 && <Button variant="ghost" size="sm" onClick={resetAllCompleted}>Reset</Button>}
        </div>
      </div>

      {isAdding && <div className="rounded-xl border bg-card p-4 shadow-sm">
        <div className="mb-3 flex items-center justify-between"><h3 className="text-lg font-bold">Add Medication</h3><Button variant="ghost" size="icon" onClick={() => setIsAdding(false)} aria-label="Close add medication"><X className="h-5 w-5" /></Button></div>
        <div className="grid gap-4 md:grid-cols-4">
          <div>
            <Label htmlFor="med-name">Medication Name</Label>
            <Input
              id="med-name"
              placeholder="e.g., Blood Pressure Pill"
              value={newMedName}
              onChange={(e) => setNewMedName(e.target.value)}
              className="text-base"
            />
          </div>
          <div>
            <Label htmlFor="med-time">Time</Label>
            <Input
              id="med-time"
              type="time"
              value={newMedTime}
              onChange={(e) => setNewMedTime(e.target.value)}
              className="text-base"
            />
          </div>
          <div>
            <Label htmlFor="med-dosage">Dosage (optional)</Label>
            <Input
              id="med-dosage"
              placeholder="e.g., 10mg"
              value={newMedDosage}
              onChange={(e) => setNewMedDosage(e.target.value)}
              className="text-base"
            />
          </div>
          <div className="flex items-end">
            <Button onClick={addMedication} className="w-full">
              <Plus className="w-5 h-5 mr-2" />
              Add
            </Button>
          </div>
        </div>
        <div className="mt-4">
          <Label>Days to take it ({newMedDays.length}× per week)</Label>
          <div className="flex flex-wrap gap-2 mt-2">
            {DAYS.map((d, i) => (
              <Button
                key={d}
                type="button"
                size="sm"
                variant={newMedDays.includes(i) ? "default" : "outline"}
                onClick={() => toggleDay(i)}
                aria-pressed={newMedDays.includes(i)}
                className="min-w-[3.25rem]"
              >
                {d}
              </Button>
            ))}
            <Button type="button" size="sm" variant="ghost" onClick={() => setNewMedDays(ALL_DAYS)}>
              Every day
            </Button>
          </div>
        </div>
      </div>}

      {isLoading ? (
        <p className="text-center text-muted-foreground py-8">Loading medications...</p>
      ) : medications.length > 0 ? (
        <div className="space-y-3">
          {medications.map((med) => (
            <div
              key={med.id}
              className={`rounded-xl border bg-card p-4 shadow-sm transition-opacity ${med.completed ? "opacity-70" : ""}`}
            >
              <div className="flex items-center justify-between gap-2">
                <div className="flex min-w-0 flex-1 items-center gap-3">
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-dashboard-sky text-primary"><Pill className="h-6 w-6" /></span>
                  <div className="min-w-0 flex-1">
                    <p className={`text-base font-bold ${med.completed ? "line-through text-muted-foreground" : ""}`}>{med.name}</p>
                    <p className="text-sm text-muted-foreground">{med.dosage || "Dose not specified"} · {med.time}</p>
                    <p className="text-xs text-muted-foreground">{describeDays(med.days_of_week)}</p>
                    <div className="mt-1 flex flex-wrap gap-1">
                      {pendingMedIds.has(med.id) && <Badge variant="outline" className="gap-1 text-[10px]"><CloudOff className="h-3 w-3" />Waiting to upload</Badge>}
                      {userRole === "caregiver" && med.created_by_role === "senior" && <Badge variant="outline" className="text-[10px]"><User className="mr-1 h-3 w-3" />Added by senior</Badge>}
                      {userRole === "senior" && med.created_by_role === "caregiver" && <Badge variant="outline" className="text-[10px]"><User className="mr-1 h-3 w-3" />From caregiver</Badge>}
                    </div>
                  </div>
                </div>
                <div className="flex shrink-0 items-center gap-1">
                  <Button
                    onClick={() => toggleCompleted(med)}
                    variant={med.completed ? "secondary" : "outline"}
                    size="sm"
                    className="gap-1 text-primary"
                    aria-label={med.completed ? `Mark ${med.name} not taken` : `Mark ${med.name} taken`}
                  >
                    {med.completed ? <CheckCircle2 className="h-5 w-5" /> : <Circle className="h-5 w-5" />}
                    <span className="hidden sm:inline">{med.completed ? "Taken" : "Mark taken"}</span>
                  </Button>
                {canDelete(med) && (
                    <Button onClick={() => removeMedication(med.id)} variant="ghost" size="icon" className="text-destructive hover:text-destructive" aria-label={`Remove ${med.name}`}><X className="h-5 w-5" /></Button>
                )}
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="rounded-xl border border-dashed bg-card/60 px-4 py-8 text-center text-muted-foreground">No medications scheduled yet.</div>
      )}

      <MedicationInteractions seniorId={seniorId} medCount={medications.length} />

      {!isAdding && <Button onClick={() => setIsAdding(true)} size="icon" className="fixed bottom-24 right-5 z-30 h-14 w-14 rounded-full bg-destructive text-destructive-foreground shadow-lg hover:bg-destructive/90 md:absolute md:bottom-0 md:right-0" aria-label="Add medication"><Plus className="!h-7 !w-7" /></Button>}
    </div>
  );
};
