import { useState, useEffect } from "react";

type FontSize = "small" | "medium" | "large";

const fontSizeClasses = {
  small: "text-sm",
  medium: "text-base",
  large: "text-lg",
};

const fontSizeScales = {
  small: 0.875,
  medium: 1,
  large: 1.25,
};

export const useFontSize = () => {
  const [fontSize, setFontSize] = useState<FontSize>(() => {
    const saved = localStorage.getItem("fontSize");
    return (saved as FontSize) || "medium";
  });

  useEffect(() => {
    localStorage.setItem("fontSize", fontSize);
    document.documentElement.style.fontSize = `${fontSizeScales[fontSize]}rem`;
  }, [fontSize]);

  return { fontSize, setFontSize, fontSizeClasses };
};
