import { Card } from "@/components/ui/card";
import Header from "@/components/Header";
import Newsletter from "@/components/Newsletter";

const TermsOfService = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="py-12 px-4">
        <div className="max-w-4xl mx-auto">
          <Card className="p-8">
          <h1 className="text-4xl font-bold text-foreground mb-2">Terms of Service</h1>
          <p className="text-muted-foreground mb-8">Effective: December 2025</p>

          <div className="space-y-6 text-foreground">
            <section>
              <h2 className="text-2xl font-semibold mb-3">1. Acceptance of Terms</h2>
              <p className="text-muted-foreground leading-relaxed">
                By accessing or using Reli ("Service"), you agree to be bound by these Terms of Service ("Terms"). 
                If you do not agree to these Terms, do not use the Service. We reserve the right to modify these Terms 
                at any time, and your continued use of the Service constitutes acceptance of any changes.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">2. Description of Service</h2>
              <p className="text-muted-foreground leading-relaxed mb-3">
                Reli provides an AI-powered companion platform designed to support seniors and their caregivers through:
              </p>
              <ul className="list-disc pl-6 space-y-2 text-muted-foreground leading-relaxed">
                <li>Conversational AI assistance and companionship</li>
                <li>Medication tracking and reminders</li>
                <li>Activity logging and monitoring</li>
                <li>Caregiver-senior communication tools</li>
                <li>Personalized well-being support</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">3. User Accounts and Eligibility</h2>
              <h3 className="text-xl font-semibold mb-2">3.1 Account Creation</h3>
              <p className="text-muted-foreground leading-relaxed mb-3">
                You must create an account to use the Service. You agree to provide accurate, current, and complete 
                information and to update this information as necessary.
              </p>
              
              <h3 className="text-xl font-semibold mb-2">3.2 Eligibility</h3>
              <ul className="list-disc pl-6 space-y-2 text-muted-foreground leading-relaxed mb-3">
                <li>You must be at least 18 years old to create an account as a caregiver</li>
                <li>Senior accounts may be created by the senior or their authorized caregiver</li>
                <li>You must comply with all applicable laws in your jurisdiction</li>
              </ul>

              <h3 className="text-xl font-semibold mb-2">3.3 Account Security</h3>
              <p className="text-muted-foreground leading-relaxed">
                You are responsible for maintaining the confidentiality of your account credentials and for all activities 
                that occur under your account. Notify us immediately of any unauthorized access.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">4. Acceptable Use</h2>
              <p className="text-muted-foreground leading-relaxed mb-3">You agree NOT to:</p>
              <ul className="list-disc pl-6 space-y-2 text-muted-foreground leading-relaxed">
                <li>Use the Service for any unlawful purpose or in violation of these Terms</li>
                <li>Attempt to gain unauthorized access to any portion of the Service</li>
                <li>Interfere with or disrupt the Service or servers</li>
                <li>Transmit viruses, malware, or other malicious code</li>
                <li>Impersonate any person or entity</li>
                <li>Harass, abuse, or harm another person</li>
                <li>Collect or store personal data about other users without permission</li>
                <li>Use automated systems to access the Service without authorization</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">5. Medical Disclaimer</h2>
              <div className="bg-muted/50 p-4 rounded-lg mb-3">
                <p className="text-foreground font-semibold mb-2">IMPORTANT MEDICAL DISCLAIMER</p>
                <p className="text-muted-foreground leading-relaxed">
                  Reli is NOT a medical device and does NOT provide medical advice, diagnosis, or treatment. 
                  The Service is designed for informational and companionship purposes only.
                </p>
              </div>
              <ul className="list-disc pl-6 space-y-2 text-muted-foreground leading-relaxed">
                <li>Always consult qualified healthcare professionals for medical decisions</li>
                <li>Do not disregard professional medical advice based on information from the Service</li>
                <li>In case of medical emergency, call emergency services immediately</li>
                <li>Medication reminders are tools only—you are responsible for taking medications as prescribed</li>
                <li>The AI companion cannot replace human care, professional counseling, or medical supervision</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">6. Privacy and Data Protection</h2>
              <p className="text-muted-foreground leading-relaxed">
                Your use of the Service is also governed by our Privacy Notice, which explains how we collect, use, 
                and protect your information. By using the Service, you consent to our data practices as described 
                in the Privacy Notice.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">7. Intellectual Property</h2>
              <h3 className="text-xl font-semibold mb-2">7.1 Our Rights</h3>
              <p className="text-muted-foreground leading-relaxed mb-3">
                All content, features, and functionality of the Service, including but not limited to text, graphics, 
                logos, icons, images, audio clips, and software, are the exclusive property of Reli and are protected 
                by copyright, trademark, and other intellectual property laws.
              </p>

              <h3 className="text-xl font-semibold mb-2">7.2 Your Rights</h3>
              <p className="text-muted-foreground leading-relaxed">
                You retain ownership of any content you provide to the Service. By submitting content, you grant 
                Reli a worldwide, non-exclusive, royalty-free license to use, reproduce, and process your content 
                solely to provide and improve the Service.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">8. Caregiver-Senior Relationships</h2>
              <h3 className="text-xl font-semibold mb-2">8.1 Authorization</h3>
              <p className="text-muted-foreground leading-relaxed mb-3">
                Caregivers must have proper authorization to access a senior's account and information. You represent 
                and warrant that you have obtained all necessary permissions.
              </p>

              <h3 className="text-xl font-semibold mb-2">8.2 Responsibilities</h3>
              <ul className="list-disc pl-6 space-y-2 text-muted-foreground leading-relaxed">
                <li>Caregivers are responsible for using senior data appropriately and ethically</li>
                <li>Seniors or their legal representatives can revoke caregiver access at any time</li>
                <li>Reli is not responsible for disputes between caregivers and seniors</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">9. Payment and Fees</h2>
              <p className="text-muted-foreground leading-relaxed mb-3">
                If you purchase any paid features or subscriptions:
              </p>
              <ul className="list-disc pl-6 space-y-2 text-muted-foreground leading-relaxed">
                <li>All fees are in U.S. dollars unless otherwise stated</li>
                <li>Fees are non-refundable except as required by law</li>
                <li>You authorize us to charge your payment method for all fees</li>
                <li>We may change fees with advance notice</li>
                <li>You are responsible for all taxes associated with your purchase</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">10. Limitation of Liability</h2>
              <div className="bg-muted/50 p-4 rounded-lg">
                <p className="text-muted-foreground leading-relaxed mb-3">
                  TO THE MAXIMUM EXTENT PERMITTED BY LAW, RELI SHALL NOT BE LIABLE FOR:
                </p>
                <ul className="list-disc pl-6 space-y-2 text-muted-foreground leading-relaxed">
                  <li>Any indirect, incidental, special, consequential, or punitive damages</li>
                  <li>Loss of profits, data, use, or goodwill</li>
                  <li>Service interruptions or errors</li>
                  <li>Third-party actions or content</li>
                  <li>Unauthorized access to or alteration of your data</li>
                  <li>Any damages arising from reliance on the Service for medical decisions</li>
                </ul>
                <p className="text-muted-foreground leading-relaxed mt-3">
                  OUR TOTAL LIABILITY SHALL NOT EXCEED THE AMOUNT YOU PAID TO RELI IN THE 12 MONTHS 
                  PRECEDING THE CLAIM, OR $100, WHICHEVER IS GREATER.
                </p>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">11. Disclaimers</h2>
              <p className="text-muted-foreground leading-relaxed mb-3">
                THE SERVICE IS PROVIDED "AS IS" AND "AS AVAILABLE" WITHOUT WARRANTIES OF ANY KIND, 
                EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO:
              </p>
              <ul className="list-disc pl-6 space-y-2 text-muted-foreground leading-relaxed">
                <li>Warranties of merchantability, fitness for a particular purpose, or non-infringement</li>
                <li>Guarantees of accuracy, reliability, or completeness of content</li>
                <li>Guarantees of uninterrupted or error-free operation</li>
                <li>Warranties regarding the AI companion's responses or suggestions</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">12. Indemnification</h2>
              <p className="text-muted-foreground leading-relaxed">
                You agree to indemnify, defend, and hold harmless Reli and its officers, directors, employees, 
                and agents from any claims, liabilities, damages, losses, and expenses (including legal fees) 
                arising from your use of the Service, violation of these Terms, or infringement of any rights 
                of another party.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">13. Termination</h2>
              <h3 className="text-xl font-semibold mb-2">13.1 By You</h3>
              <p className="text-muted-foreground leading-relaxed mb-3">
                You may terminate your account at any time through account settings or by contacting us.
              </p>

              <h3 className="text-xl font-semibold mb-2">13.2 By Us</h3>
              <p className="text-muted-foreground leading-relaxed mb-3">
                We may suspend or terminate your access to the Service at any time for:
              </p>
              <ul className="list-disc pl-6 space-y-2 text-muted-foreground leading-relaxed">
                <li>Violation of these Terms</li>
                <li>Fraudulent or illegal activity</li>
                <li>Extended periods of inactivity</li>
                <li>Any reason with or without notice</li>
              </ul>

              <h3 className="text-xl font-semibold mb-2">13.3 Effect of Termination</h3>
              <p className="text-muted-foreground leading-relaxed">
                Upon termination, your right to use the Service ceases immediately. We may delete your data 
                in accordance with our Privacy Notice and retention policies.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">14. Dispute Resolution</h2>
              <h3 className="text-xl font-semibold mb-2">14.1 Informal Resolution</h3>
              <p className="text-muted-foreground leading-relaxed mb-3">
                Before filing a claim, you agree to contact us at <a href="mailto:info@reli.care" className="text-primary hover:underline">info@reli.care</a> to attempt to resolve 
                the dispute informally.
              </p>

              <h3 className="text-xl font-semibold mb-2">14.2 Arbitration</h3>
              <p className="text-muted-foreground leading-relaxed mb-3">
                Any dispute that cannot be resolved informally shall be resolved through binding arbitration 
                in accordance with the American Arbitration Association's rules, except where prohibited by law.
              </p>

              <h3 className="text-xl font-semibold mb-2">14.3 Class Action Waiver</h3>
              <p className="text-muted-foreground leading-relaxed">
                You agree to bring claims only in your individual capacity and not as part of any class action, 
                except where prohibited by law.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">15. Governing Law</h2>
              <p className="text-muted-foreground leading-relaxed">
                These Terms are governed by the laws of the United States and the State of [Your State], 
                without regard to conflict of law principles. For EU/EEA residents, mandatory consumer 
                protection laws of your country of residence also apply.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">16. Changes to These Terms</h2>
              <p className="text-muted-foreground leading-relaxed">
                We reserve the right to modify these Terms at any time. We will provide notice of material 
                changes by posting the updated Terms and updating the "Effective" date. Your continued use 
                of the Service after changes constitutes acceptance.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">17. Miscellaneous</h2>
              <ul className="list-disc pl-6 space-y-2 text-muted-foreground leading-relaxed">
                <li><span className="font-medium text-foreground">Severability:</span> If any provision is found invalid, the remaining provisions continue in effect</li>
                <li><span className="font-medium text-foreground">Entire Agreement:</span> These Terms and the Privacy Notice constitute the entire agreement</li>
                <li><span className="font-medium text-foreground">No Waiver:</span> Our failure to enforce any right does not waive that right</li>
                <li><span className="font-medium text-foreground">Assignment:</span> We may assign these Terms; you may not without our consent</li>
                <li><span className="font-medium text-foreground">Force Majeure:</span> We are not liable for delays due to circumstances beyond our control</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">18. Contact Information</h2>
              <p className="text-muted-foreground leading-relaxed mb-3">
                For questions about these Terms of Service, please contact us:
              </p>
              <p className="text-muted-foreground leading-relaxed">
                Email: <a href="mailto:info@reli.care" className="text-primary hover:underline">info@reli.care</a>
              </p>
            </section>
          </div>
          </Card>
        </div>
      </div>
      <Newsletter />
    </div>
  );
};

export default TermsOfService;
