CREATE TYPE public.user_plan AS ENUM ('free', 'premium');

ALTER TABLE public.profiles
ADD COLUMN plan public.user_plan NOT NULL DEFAULT 'free';

-- Re-apply the profile self-update policy, keeping role locked and now also keeping plan locked
DROP POLICY IF EXISTS "Users can update their own profile" ON public.profiles;
CREATE POLICY "Users can update their own profile"
  ON public.profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (
    auth.uid() = id
    AND role = (SELECT role FROM public.profiles WHERE id = auth.uid())
    AND plan = (SELECT plan FROM public.profiles WHERE id = auth.uid())
  );