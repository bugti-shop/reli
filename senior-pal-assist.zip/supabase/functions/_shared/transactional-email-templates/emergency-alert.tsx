import * as React from 'npm:react@18.3.1'
import {
  Body,
  Container,
  Head,
  Heading,
  Html,
  Preview,
  Section,
  Text,
} from 'npm:@react-email/components@0.0.22'
import type { TemplateEntry } from './registry.ts'

interface Props {
  recipientName?: string
  seniorName?: string
  message?: string
  sentAt?: string
}

const Email = ({
  recipientName,
  seniorName = 'Someone in your care',
  message,
  sentAt,
}: Props) => (
  <Html lang="en" dir="ltr">
    <Head />
    <Preview>Emergency help requested by {seniorName}</Preview>
    <Body style={main}>
      <Container style={container}>
        <Section style={banner}>
          <Text style={bannerText}>Emergency alert from Reli</Text>
        </Section>
        <Heading style={h1}>{seniorName} needs help now</Heading>
        <Text style={text}>
          {recipientName ? `${recipientName}, ` : ''}
          {seniorName} pressed the emergency button in Reli
          {sentAt ? ` at ${sentAt}` : ''}. Please check on them right away.
        </Text>
        {message ? (
          <Section style={quote}>
            <Text style={messageLabel}>Message from {seniorName}</Text>
            <Text style={quoteText}>{message}</Text>
          </Section>
        ) : null}
        <Text style={text}>
          If you cannot reach them, call emergency services.
        </Text>
        <Text style={footer}>Sent from Reli</Text>
      </Container>
    </Body>
  </Html>
)

export const template = {
  component: Email,
  subject: (data: Record<string, any>) => {
    const seniorName = String(data.seniorName || 'Someone in your care')
    const message = typeof data.message === 'string' ? data.message.trim() : ''
    const summary = message ? ` — ${message.slice(0, 90)}` : ''
    return `Emergency: ${seniorName} needs help${summary}`
  },
  displayName: 'Emergency alert',
  previewData: {
    recipientName: 'Jake',
    seniorName: 'Mary',
    message: 'I fell in the kitchen.',
    sentAt: '2:14 PM',
  },
} satisfies TemplateEntry

const main = { backgroundColor: '#ffffff', fontFamily: 'Arial, sans-serif' }
const container = { padding: '20px 25px' }
const banner = {
  backgroundColor: 'hsl(0, 72%, 45%)',
  borderRadius: '10px',
  padding: '10px 16px',
  margin: '0 0 20px',
}
const bannerText = {
  color: '#ffffff',
  fontSize: '14px',
  fontWeight: 'bold' as const,
  margin: '0',
}
const h1 = {
  fontSize: '24px',
  fontWeight: 'bold' as const,
  color: 'hsl(0, 72%, 35%)',
  margin: '0 0 16px',
}
const text = {
  fontSize: '16px',
  color: 'hsl(24, 15%, 35%)',
  lineHeight: '1.6',
  margin: '0 0 18px',
}
const quote = {
  backgroundColor: 'hsl(0, 72%, 97%)',
  borderLeft: '4px solid hsl(0, 72%, 45%)',
  borderRadius: '10px',
  padding: '14px 18px',
  margin: '0 0 20px',
}
const quoteText = {
  fontSize: '18px',
  color: 'hsl(24, 20%, 15%)',
  lineHeight: '1.6',
  margin: '0',
}
const messageLabel = {
  fontSize: '13px',
  color: 'hsl(0, 72%, 35%)',
  fontWeight: 'bold' as const,
  margin: '0 0 6px',
}
const footer = { fontSize: '12px', color: '#999999', margin: '30px 0 0' }
