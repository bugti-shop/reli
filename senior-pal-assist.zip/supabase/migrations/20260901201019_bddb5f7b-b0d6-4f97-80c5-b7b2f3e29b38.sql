CREATE TABLE public.doctor_questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  senior_id uuid NOT NULL,
  owner_id uuid NOT NULL,
  created_by_role text NOT NULL DEFAULT 'senior',
  question text NOT NULL,
  answer text,
  asked boolean NOT NULL DEFAULT false,
  asked_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.doctor_questions TO authenticated;
GRANT ALL ON public.doctor_questions TO service_role;

ALTER TABLE public.doctor_questions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Deny anon access to doctor_questions"
ON public.doctor_questions AS RESTRICTIVE FOR ALL TO anon USING (false);

CREATE POLICY "Senior or linked caregiver can view doctor questions"
ON public.doctor_questions FOR SELECT TO authenticated
USING (
  senior_id = auth.uid()
  OR EXISTS (SELECT 1 FROM public.caregiver_seniors cs WHERE cs.senior_id = doctor_questions.senior_id AND cs.caregiver_id = auth.uid())
);

CREATE POLICY "Senior or linked caregiver can add doctor questions"
ON public.doctor_questions FOR INSERT TO authenticated
WITH CHECK (
  owner_id = auth.uid()
  AND (
    senior_id = auth.uid()
    OR EXISTS (SELECT 1 FROM public.caregiver_seniors cs WHERE cs.senior_id = doctor_questions.senior_id AND cs.caregiver_id = auth.uid())
  )
);

CREATE POLICY "Senior or linked caregiver can update doctor questions"
ON public.doctor_questions FOR UPDATE TO authenticated
USING (
  senior_id = auth.uid()
  OR EXISTS (SELECT 1 FROM public.caregiver_seniors cs WHERE cs.senior_id = doctor_questions.senior_id AND cs.caregiver_id = auth.uid())
)
WITH CHECK (
  senior_id = auth.uid()
  OR EXISTS (SELECT 1 FROM public.caregiver_seniors cs WHERE cs.senior_id = doctor_questions.senior_id AND cs.caregiver_id = auth.uid())
);

CREATE POLICY "Senior or linked caregiver can delete doctor questions"
ON public.doctor_questions FOR DELETE TO authenticated
USING (
  senior_id = auth.uid()
  OR EXISTS (SELECT 1 FROM public.caregiver_seniors cs WHERE cs.senior_id = doctor_questions.senior_id AND cs.caregiver_id = auth.uid())
);

CREATE TRIGGER update_doctor_questions_updated_at
BEFORE UPDATE ON public.doctor_questions
FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();