import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft, Loader2, UserCog } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

const CaregiverProfile = () => {
  const navigate = useNavigate();
  const { toast } = useToast();

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [userId, setUserId] = useState<string | null>(null);
  const [originalEmail, setOriginalEmail] = useState("");
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");

  useEffect(() => {
    const load = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        navigate("/auth");
        return;
      }
      setUserId(user.id);

      const { data } = await supabase
        .from("profiles")
        .select("full_name, phone, email")
        .eq("id", user.id)
        .maybeSingle();

      setFullName(data?.full_name || "");
      setPhone(data?.phone || "");
      setEmail(data?.email || user.email || "");
      setOriginalEmail(data?.email || user.email || "");
      setLoading(false);
    };
    load();
  }, [navigate]);

  const handleSave = async () => {
    if (!userId) return;
    if (!fullName.trim()) {
      toast({ title: "Name is required", variant: "destructive" });
      return;
    }
    const trimmedEmail = email.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmedEmail)) {
      toast({ title: "Please enter a valid email address", variant: "destructive" });
      return;
    }

    setSaving(true);

    const { error } = await supabase
      .from("profiles")
      .update({
        full_name: fullName.trim().slice(0, 100),
        phone: phone.trim().slice(0, 30) || null,
        email: trimmedEmail,
      })
      .eq("id", userId);

    if (error) {
      setSaving(false);
      toast({ title: "Couldn't save changes", description: error.message, variant: "destructive" });
      return;
    }

    let emailPending = false;
    if (trimmedEmail.toLowerCase() !== originalEmail.toLowerCase()) {
      const { error: authError } = await supabase.auth.updateUser({ email: trimmedEmail });
      if (authError) {
        toast({
          title: "Email not fully updated",
          description: authError.message,
          variant: "destructive",
        });
      } else {
        emailPending = true;
        setOriginalEmail(trimmedEmail);
      }
    }

    setSaving(false);
    toast({
      title: "Profile saved",
      description: emailPending
        ? "Check your new email inbox to confirm the address for signing in."
        : "The people you care for will see your updated details.",
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <main className="container mx-auto px-4 py-8 max-w-2xl">
        <Button variant="ghost" className="mb-6 -ml-2" onClick={() => navigate("/caregiver")}>
          <ArrowLeft className="w-4 h-4 mr-2" /> Back to dashboard
        </Button>

        <div className="flex items-center gap-3 mb-2">
          <div className="w-11 h-11 rounded-full bg-primary/10 flex items-center justify-center">
            <UserCog className="w-5 h-5 text-primary" />
          </div>
          <h1 className="text-3xl font-bold">My profile</h1>
        </div>
        <p className="text-muted-foreground mb-6">
          Seniors you care for see this name, phone and email alongside your messages.
        </p>

        <Card className="p-6 space-y-5">
          <div>
            <Label htmlFor="cgName">Full name</Label>
            <Input id="cgName" value={fullName} onChange={(e) => setFullName(e.target.value)} className="mt-1 h-11" />
          </div>
          <div>
            <Label htmlFor="cgPhone">Phone</Label>
            <Input
              id="cgPhone"
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="Where they can reach you"
              className="mt-1 h-11"
            />
          </div>
          <div>
            <Label htmlFor="cgEmail">Email</Label>
            <Input
              id="cgEmail"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="mt-1 h-11"
            />
          </div>
        </Card>

        <Button className="w-full h-12 mt-6 text-lg" onClick={handleSave} disabled={saving}>
          {saving ? "Saving…" : "Save profile"}
        </Button>
      </main>
    </div>
  );
};

export default CaregiverProfile;
