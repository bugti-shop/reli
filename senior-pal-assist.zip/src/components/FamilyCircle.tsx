import { useCallback, useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Copy, Trash2, UserPlus, Users } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface Member {
  id: string;
  caregiver_id: string;
  relationship: string;
  profile: { full_name: string | null; email: string } | null;
}

/** Senior's family circle: invite family by code/link, see and remove members. */
export const FamilyCircle = ({ seniorId }: { seniorId: string }) => {
  const [members, setMembers] = useState<Member[]>([]);
  const [code, setCode] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const { toast } = useToast();

  const load = useCallback(async () => {
    const { data } = await supabase
      .from("caregiver_seniors")
      .select("id, caregiver_id, relationship, profile:profiles!caregiver_seniors_caregiver_id_fkey(full_name, email)")
      .eq("senior_id", seniorId);
    setMembers((data as unknown as Member[]) || []);
  }, [seniorId]);

  useEffect(() => { load(); }, [load]);

  const invite = async (relationship: "family" | "caregiver") => {
    setBusy(true);
    const { data: auth } = await supabase.auth.getUser();
    const { data, error } = await supabase
      .from("circle_invites")
      .insert({ senior_id: seniorId, created_by: auth.user!.id, relationship })
      .select("code")
      .single();
    setBusy(false);
    if (error) return toast({ title: "Could not create invite", description: error.message, variant: "destructive" });
    setCode(data.code);
  };

  const link = code ? `${window.location.origin}/join/${code}` : "";

  const share = async () => {
    const text = `Join my care circle on Reli so you get my SOS alerts and can see my health updates: ${link} (code ${code})`;
    if (navigator.share) {
      await navigator.share({ title: "Join my Reli circle", text }).catch(() => undefined);
    } else {
      await navigator.clipboard.writeText(text);
      toast({ title: "Invite copied", description: "Paste it in a message to your family." });
    }
  };

  const remove = async (m: Member) => {
    if (!window.confirm(`Remove ${m.profile?.full_name || m.profile?.email} from your circle?`)) return;
    const { error } = await supabase.from("caregiver_seniors").delete().eq("id", m.id);
    if (error) return toast({ title: "Could not remove", description: error.message, variant: "destructive" });
    load();
  };

  return (
    <Card className="space-y-4 p-4 sm:col-span-2">
      <div className="flex items-center gap-2">
        <Users className="h-5 w-5 text-primary" />
        <h3 className="text-lg font-semibold">My Caregivers</h3>
      </div>
      <p className="text-sm text-muted-foreground">
        People in your circle get your SOS alarm and can follow your medicines, readings and activity.
      </p>

      <ul className="space-y-2">
        {members.length === 0 && <li className="text-sm text-muted-foreground">No one yet. Invite your family below.</li>}
        {members.map((m) => (
          <li key={m.id} className="flex items-center justify-between gap-2 rounded-md border px-3 py-2">
            <div className="min-w-0">
              <p className="truncate font-medium">{m.profile?.full_name || m.profile?.email}</p>
              <p className="text-xs capitalize text-muted-foreground">{m.relationship}</p>
            </div>
            <Button variant="ghost" size="icon" aria-label="Remove from circle" onClick={() => remove(m)}>
              <Trash2 className="h-4 w-4" />
            </Button>
          </li>
        ))}
      </ul>

      {code ? (
        <div className="space-y-2 rounded-md bg-muted p-3 text-center">
          <p className="text-sm">Invite code (valid 7 days)</p>
          <p className="text-3xl font-bold tracking-widest">{code}</p>
          <Button className="w-full gap-2" onClick={share}><Copy className="h-4 w-4" /> Share invite</Button>
          <Button variant="ghost" size="sm" onClick={() => setCode(null)}>Done</Button>
        </div>
      ) : (
        <div className="grid gap-2 sm:grid-cols-2">
          <Button disabled={busy} className="gap-2" onClick={() => invite("family")}><UserPlus className="h-4 w-4" /> Invite family member</Button>
          <Button disabled={busy} variant="outline" className="gap-2" onClick={() => invite("caregiver")}><UserPlus className="h-4 w-4" /> Invite caregiver</Button>
        </div>
      )}
    </Card>
  );
};
