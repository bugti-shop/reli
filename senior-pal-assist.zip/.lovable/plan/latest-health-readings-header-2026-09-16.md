# Latest Health Readings Header

## Goal
Make the senior dashboard’s blue top area a health-at-a-glance focus while preserving the greeting, date, time, weather, and voice button.

## What will change
- Load the senior’s latest blood pressure and heart-rate entries.
- Load today’s medication completion status and identify the next untaken medication.
- Add four prominent summary tiles: Blood Pressure, Heart Rate, Meds Taken, and Next Medication.
- Show the recorded time for each reading and clear, calm empty states when data is unavailable.
- Keep the layout large, high-contrast, and readable on both desktop and mobile.
- Refresh the summary after medication changes so the header stays current.

## Technical details
- Add a focused header-summary component backed by existing `vital_readings` and `medications` data.
- Use existing semantic colors and controls, with no database changes.
- Connect medication updates to the summary through the existing dose callback.
- Verify the signed-in senior dashboard at desktop and mobile widths.
