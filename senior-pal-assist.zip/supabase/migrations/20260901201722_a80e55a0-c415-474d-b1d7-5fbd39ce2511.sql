CREATE TABLE public.emergency_alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  senior_id uuid NOT NULL,
  message text,
  acknowledged boolean NOT NULL DEFAULT false,
  acknowledged_by uuid,
  acknowledged_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE ON public.emergency_alerts TO authenticated;
GRANT ALL ON public.emergency_alerts TO service_role;

ALTER TABLE public.emergency_alerts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Deny anon access to emergency_alerts"
ON public.emergency_alerts AS RESTRICTIVE FOR ALL TO anon USING (false);

CREATE POLICY "Senior or linked caregiver can view emergency alerts"
ON public.emergency_alerts FOR SELECT TO authenticated
USING (
  senior_id = auth.uid()
  OR EXISTS (SELECT 1 FROM public.caregiver_seniors cs WHERE cs.senior_id = emergency_alerts.senior_id AND cs.caregiver_id = auth.uid())
);

CREATE POLICY "Senior can raise their own emergency alert"
ON public.emergency_alerts FOR INSERT TO authenticated
WITH CHECK (senior_id = auth.uid());

CREATE POLICY "Senior or linked caregiver can update emergency alerts"
ON public.emergency_alerts FOR UPDATE TO authenticated
USING (
  senior_id = auth.uid()
  OR EXISTS (SELECT 1 FROM public.caregiver_seniors cs WHERE cs.senior_id = emergency_alerts.senior_id AND cs.caregiver_id = auth.uid())
)
WITH CHECK (
  senior_id = auth.uid()
  OR EXISTS (SELECT 1 FROM public.caregiver_seniors cs WHERE cs.senior_id = emergency_alerts.senior_id AND cs.caregiver_id = auth.uid())
);

CREATE TRIGGER update_emergency_alerts_updated_at
BEFORE UPDATE ON public.emergency_alerts
FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

ALTER PUBLICATION supabase_realtime ADD TABLE public.emergency_alerts;