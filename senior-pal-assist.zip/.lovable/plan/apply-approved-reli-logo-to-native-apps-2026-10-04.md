# Apply approved Reli logo to native apps

## Changes
- Use the approved exact heart-check artwork as the single source for Android and iOS branding.
- Regenerate Android launcher/adaptive/round icons with safe spacing so the logo is not cropped by device masks.
- Add a dedicated Android monochrome heart notification icon and make both SOS and standard push notifications use it instead of the launcher/exclamation fallback.
- Update the existing Android and iOS launch screen assets to use `#427eb3` with the centered white heart; do not add another splash screen or launch step.
- Keep web/home-screen icons aligned with the approved logo where the existing asset generator owns them.

## Validation
- Confirm icon and splash dimensions, transparency, exact background color, and Android notification-icon monochrome format.
- Run native asset generation and Capacitor sync, then check the project build signal and generated native resources.

## Technical details
- Preserve package/bundle ID `com.reli.care`.
- Keep native folders committed and repeatable through `npm run assets:generate` followed by the existing Capacitor sync workflow.
