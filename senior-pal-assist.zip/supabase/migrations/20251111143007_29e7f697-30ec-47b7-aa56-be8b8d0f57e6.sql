-- Create app role enum
CREATE TYPE public.app_role AS ENUM ('senior', 'caregiver');

-- Create profiles table
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  full_name TEXT,
  role app_role NOT NULL DEFAULT 'senior',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS on profiles
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Users can view their own profile"
  ON public.profiles FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = id);

-- Create caregiver_seniors relationship table
CREATE TABLE public.caregiver_seniors (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  caregiver_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  senior_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(caregiver_id, senior_id)
);

-- Enable RLS on caregiver_seniors
ALTER TABLE public.caregiver_seniors ENABLE ROW LEVEL SECURITY;

-- Policies for caregiver_seniors
CREATE POLICY "Caregivers can view their seniors"
  ON public.caregiver_seniors FOR SELECT
  USING (auth.uid() = caregiver_id);

CREATE POLICY "Seniors can view their caregivers"
  ON public.caregiver_seniors FOR SELECT
  USING (auth.uid() = senior_id);

CREATE POLICY "Caregivers can add seniors"
  ON public.caregiver_seniors FOR INSERT
  WITH CHECK (auth.uid() = caregiver_id);

-- Create messages table for caregiver-to-senior communication
CREATE TABLE public.caregiver_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  caregiver_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  senior_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  message TEXT NOT NULL,
  is_reminder BOOLEAN DEFAULT FALSE,
  reminder_time TIMESTAMP WITH TIME ZONE,
  read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS on caregiver_messages
ALTER TABLE public.caregiver_messages ENABLE ROW LEVEL SECURITY;

-- Policies for caregiver_messages
CREATE POLICY "Caregivers can create messages for their seniors"
  ON public.caregiver_messages FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.caregiver_seniors
      WHERE caregiver_id = auth.uid() AND senior_id = public.caregiver_messages.senior_id
    )
  );

CREATE POLICY "Caregivers can view messages to their seniors"
  ON public.caregiver_messages FOR SELECT
  USING (caregiver_id = auth.uid());

CREATE POLICY "Seniors can view their messages"
  ON public.caregiver_messages FOR SELECT
  USING (senior_id = auth.uid());

CREATE POLICY "Seniors can update message read status"
  ON public.caregiver_messages FOR UPDATE
  USING (senior_id = auth.uid());

-- Create activity log table
CREATE TABLE public.senior_activity_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  senior_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  activity_type TEXT NOT NULL,
  activity_description TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS on senior_activity_log
ALTER TABLE public.senior_activity_log ENABLE ROW LEVEL SECURITY;

-- Policies for senior_activity_log
CREATE POLICY "Seniors can create their own activity logs"
  ON public.senior_activity_log FOR INSERT
  WITH CHECK (auth.uid() = senior_id);

CREATE POLICY "Seniors can view their own activity logs"
  ON public.senior_activity_log FOR SELECT
  USING (auth.uid() = senior_id);

CREATE POLICY "Caregivers can view their seniors' activity logs"
  ON public.senior_activity_log FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.caregiver_seniors
      WHERE caregiver_id = auth.uid() AND senior_id = public.senior_activity_log.senior_id
    )
  );

-- Create function to handle new user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, role)
  VALUES (
    NEW.id,
    NEW.email,
    NEW.raw_user_meta_data->>'full_name',
    COALESCE((NEW.raw_user_meta_data->>'role')::app_role, 'senior')
  );
  RETURN NEW;
END;
$$;

-- Trigger to create profile on user signup
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.handle_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;

-- Trigger for profiles updated_at
CREATE TRIGGER handle_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();