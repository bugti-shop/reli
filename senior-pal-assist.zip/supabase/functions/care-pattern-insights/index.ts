import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors'
import { createClient } from 'npm:@supabase/supabase-js@2'
import { z } from 'npm:zod@3'

const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), { status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })

const Body = z.discriminatedUnion('action', [
  z.object({ action: z.literal('fda'), senior_id: z.string().uuid(), symptoms: z.array(z.string().max(80)).max(20) }),
  z.object({ action: z.literal('ask'), senior_id: z.string().uuid(), pattern: z.string().max(600), context: z.string().max(4000) }),
])

// Plain-language symptom -> terms used in FDA label text
const TERMS: Record<string, string[]> = {
  pain: ['pain'], dizziness: ['dizziness', 'dizzy', 'vertigo'], nausea: ['nausea'],
  'shortness of breath': ['dyspnea', 'shortness of breath'], fatigue: ['fatigue', 'somnolence', 'drowsiness'],
  headache: ['headache'], confusion: ['confusion', 'confusional state', 'disorientation'],
  agitation: ['agitation', 'restlessness'], hallucination: ['hallucination'], fall: ['falls', 'fall '],
  anxious: ['anxiety'], tired: ['fatigue', 'somnolence'], sad: ['depression'], angry: ['aggression', 'irritability'],
  wandering: ['wandering'], 'repeating questions': ['memory impairment', 'amnesia'],
}

const RX = 'https://rxnav.nlm.nih.gov/REST'
const stripDose = (n: string) => n.toLowerCase().replace(/\([^)]*\)/g, ' ')
  .replace(/\d+(\.\d+)?\s*(mg|mcg|µg|g|iu|ml|units?|%)\b/g, ' ')
  .replace(/\b(tablets?|tabs?|capsules?|caps?|extra strength|er|xr|sr|dr|daily)\b/g, ' ')
  .replace(/[^a-z -]/g, ' ').replace(/\s+/g, ' ').trim()

async function ingredient(raw: string): Promise<string> {
  const c = stripDose(raw)
  try {
    const a = await (await fetch(`${RX}/approximateTerm.json?term=${encodeURIComponent(c)}&maxEntries=3`)).json()
    for (const cand of a?.approximateGroup?.candidate ?? []) {
      const r = await (await fetch(`${RX}/rxcui/${cand.rxcui}/related.json?tty=IN`)).json()
      const n = r?.relatedGroup?.conceptGroup?.find((g: any) => g.tty === 'IN')?.conceptProperties?.[0]?.name
      if (n) return String(n).toLowerCase()
    }
  } catch { /* fall back */ }
  return c.split(' ')[0]
}

async function labelText(ing: string): Promise<string | null> {
  const q = `(openfda.generic_name:"${ing}" OR active_ingredient:"${ing}")`
  try {
    const res = await fetch(`https://api.fda.gov/drug/label.json?search=${encodeURIComponent(q)}&limit=3`)
    if (!res.ok) return null
    const docs: any[] = (await res.json()).results ?? []
    const pick = (r: any) => [r.adverse_reactions, r.warnings_and_cautions, r.warnings].flat().filter(Boolean).join(' ')
    const best = docs.map(pick).sort((a, b) => b.length - a.length)[0]
    return best && best.length > 100 ? best : null
  } catch { return null }
}

const snippet = (text: string, term: string) => {
  const i = text.toLowerCase().indexOf(term)
  return i < 0 ? null : text.slice(Math.max(0, i - 160), i + 220).replace(/\s+/g, ' ').trim()
}

async function askAI(prompt: string): Promise<string> {
  const res = await fetch('https://ai.gateway.lovable.dev/v1/responses', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Lovable-API-Key': Deno.env.get('LOVABLE_API_KEY')!, 'X-Lovable-AIG-SDK': 'fetch' },
    body: JSON.stringify({
      model: 'openai/gpt-6-astra', stream: true, store: false,
      reasoning: { effort: 'low', summary: 'auto' }, include: ['reasoning.encrypted_content'],
      instructions: 'You help family caregivers understand patterns in their own observation records. Never diagnose, never claim one thing caused another, never tell them to start, stop or change medication. Use neutral words like "possible pattern" and "frequently occurred together". Reply in under 170 words with three short parts: "What the records show", "Things worth noting next time" (2-3 bullets), and "Questions for the care team" (2-3 bullets). If anything sounds sudden or severe, first say to contact emergency services or the doctor.',
      input: prompt,
    }),
  })
  if (!res.ok) {
    const err = new Error(res.status === 429 ? 'Too many requests, please try again in a minute.' : res.status === 402 ? 'AI credits are used up for now.' : 'The AI service could not answer right now.')
    ;(err as any).status = res.status
    throw err
  }
  const reader = res.body!.getReader(); const dec = new TextDecoder(); let buf = ''; let out = ''
  for (;;) {
    const { done, value } = await reader.read(); if (done) break
    buf += dec.decode(value, { stream: true })
    const lines = buf.split('\n'); buf = lines.pop() ?? ''
    for (const l of lines) {
      if (!l.startsWith('data:')) continue
      try { const e = JSON.parse(l.slice(5)); if (e.type === 'response.output_text.delta') out += e.delta; if (e.type === 'error' || e.type === 'response.failed') throw new Error('AI request failed') } catch (e) { if ((e as Error).message === 'AI request failed') throw e }
    }
  }
  if (!out.trim()) throw new Error('No answer was returned. Please try again later.')
  return out.trim()
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  try {
    const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, {
      global: { headers: { Authorization: req.headers.get('Authorization') ?? '' } },
    })
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return json({ error: 'Please sign in.' }, 401)
    const parsed = Body.safeParse(await req.json())
    if (!parsed.success) return json({ error: 'Invalid request.' }, 400)
    const b = parsed.data

    // Access check: RLS returns rows only for the senior or linked caregivers.
    const allowed = user.id === b.senior_id || !!(await supabase.from('caregiver_seniors').select('id').eq('senior_id', b.senior_id).eq('caregiver_id', user.id).maybeSingle()).data
    if (!allowed) return json({ error: 'Not allowed.' }, 403)

    if (b.action === 'ask') return json({ answer: await askAI(`Pattern: ${b.pattern}\n\nRecent records:\n${b.context}`) })

    const { data: meds } = await supabase.from('medications').select('name').eq('senior_id', b.senior_id)
    const names = [...new Set((meds ?? []).map((m) => m.name as string))].slice(0, 10)
    const symptoms = [...new Set(b.symptoms.map((s) => s.toLowerCase()))].filter((s) => TERMS[s] || s.length > 3)
    if (!names.length || !symptoms.length) return json({ matches: [], checked: names })
    const results = await Promise.all(names.map(async (n) => {
      const ing = await ingredient(n)
      const text = await labelText(ing)
      if (!text) return []
      return symptoms.flatMap((s) => {
        for (const t of TERMS[s] ?? [s]) { const q = snippet(text, t); if (q) return [{ medication: n, ingredient: ing, symptom: s, quote: q }] }
        return []
      })
    }))
    return json({ matches: results.flat(), checked: names, source: 'U.S. FDA drug labels via openFDA; names matched with NIH RxNorm' })
  } catch (e) {
    const status = (e as any).status
    return json({ error: (e as Error).message }, status === 429 || status === 402 ? status : 500)
  }
})
