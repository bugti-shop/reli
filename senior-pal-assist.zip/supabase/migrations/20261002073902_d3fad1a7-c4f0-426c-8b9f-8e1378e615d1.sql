ALTER TABLE public.vital_readings ADD COLUMN IF NOT EXISTS value numeric, ADD COLUMN IF NOT EXISTS unit text;
ALTER TABLE public.vital_readings DROP CONSTRAINT IF EXISTS vital_readings_reading_type_check;
ALTER TABLE public.vital_readings ADD CONSTRAINT vital_readings_reading_type_check CHECK (reading_type IN ('blood_pressure','heart_rate','glucose','weight','water'));
CREATE OR REPLACE FUNCTION public.trg_activity_capture()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE n jsonb := CASE WHEN TG_OP = 'DELETE' THEN to_jsonb(OLD) ELSE to_jsonb(NEW) END;
  o jsonb := CASE WHEN TG_OP = 'UPDATE' THEN to_jsonb(OLD) ELSE NULL END;
  sid uuid := (n->>'senior_id')::uuid; actor uuid := COALESCE(auth.uid(), sid);
  eid text := TG_TABLE_NAME || ':' || TG_OP || ':' || (n->>'id') || ':' || extract(epoch from clock_timestamp())::text;
  verb text := CASE TG_OP WHEN 'INSERT' THEN 'added' WHEN 'UPDATE' THEN 'updated' ELSE 'deleted' END;
BEGIN
  CASE TG_TABLE_NAME
  WHEN 'medication_doses' THEN
    IF TG_OP = 'INSERT' THEN
      PERFORM record_senior_activity(sid, 'dose:' || (n->>'id'), 'Medication taken', 'Took ' || (n->>'medication_name') || COALESCE(' ' || (n->>'dosage'), '') || COALESCE(' (scheduled ' || (n->>'scheduled_time') || ')', ''), 'medication', 'completed',
        jsonb_build_object('medication', n->>'medication_name', 'dosage', n->>'dosage', 'scheduled_time', n->>'scheduled_time', 'notes', n->>'notes', 'recorded_by', n->>'taken_by_role'), actor, (n->>'taken_at')::timestamptz);
    ELSIF TG_OP = 'UPDATE' AND o->>'deleted_at' IS NULL AND n->>'deleted_at' IS NOT NULL THEN
      PERFORM record_senior_activity(sid, 'dose-undo:' || (n->>'id'), 'Medication unmarked', 'Removed "taken" for ' || (n->>'medication_name'), 'medication', 'cancelled', jsonb_build_object('medication', n->>'medication_name'), actor);
    END IF;
  WHEN 'medications' THEN
    IF TG_OP = 'UPDATE' AND (o->>'completed') IS DISTINCT FROM (n->>'completed') THEN RETURN NULL; END IF;
    PERFORM record_senior_activity(sid, eid, 'Medication ' || verb, initcap(verb) || ' medication ' || (n->>'name') || ' at ' || (n->>'time'), 'medication', 'info',
      jsonb_build_object('medication', n->>'name', 'time', n->>'time', 'dosage', n->>'dosage', 'days', n->'days_of_week'), actor);
  WHEN 'vital_readings' THEN
    IF TG_OP = 'INSERT' THEN
      PERFORM record_senior_activity(sid, 'vital:' || (n->>'id'),
        CASE n->>'reading_type' WHEN 'blood_pressure' THEN 'Blood pressure recorded' WHEN 'heart_rate' THEN 'Heart rate recorded'
          WHEN 'glucose' THEN 'Blood glucose recorded' WHEN 'weight' THEN 'Weight recorded' WHEN 'water' THEN 'Water logged' ELSE 'Health reading recorded' END,
        CASE n->>'reading_type'
          WHEN 'blood_pressure' THEN 'BP ' || (n->>'systolic') || '/' || (n->>'diastolic') || ' mmHg'
          WHEN 'heart_rate' THEN 'Heart rate ' || (n->>'bpm') || ' bpm'
          ELSE COALESCE(n->>'value','') || ' ' || COALESCE(n->>'unit','') END || COALESCE(' — ' || left(n->>'notes', 300), ''),
        CASE WHEN n->>'reading_type' = 'water' THEN 'trackers' ELSE 'health' END, 'completed',
        jsonb_build_object('type', n->>'reading_type', 'systolic', n->'systolic', 'diastolic', n->'diastolic', 'bpm', n->'bpm', 'value', n->'value', 'unit', n->>'unit', 'notes', n->>'notes'), actor, (n->>'recorded_at')::timestamptz);
    ELSIF TG_OP = 'UPDATE' AND o->>'deleted_at' IS NULL AND n->>'deleted_at' IS NOT NULL THEN
      PERFORM record_senior_activity(sid, 'vital-del:' || (n->>'id'), 'Health reading deleted', 'A ' || replace(n->>'reading_type','_',' ') || ' reading was deleted', CASE WHEN n->>'reading_type' = 'water' THEN 'trackers' ELSE 'health' END, 'cancelled', jsonb_build_object('type', n->>'reading_type'), actor);
    END IF;
  WHEN 'journal_entries' THEN
    PERFORM record_senior_activity(sid, eid, 'Journal entry ' || verb, COALESCE(NULLIF(n->>'title',''), left(n->>'content', 200)), 'journal', 'completed', jsonb_build_object('mood', n->>'mood', 'entry_date', n->>'entry_date'), actor);
  WHEN 'care_observations' THEN
    PERFORM record_senior_activity(sid, eid, 'Health journal ' || verb, initcap(n->>'category') || ': ' || (n->>'label') || COALESCE(' — ' || left(n->>'notes', 300), ''), 'journal', 'completed',
      jsonb_build_object('category', n->>'category', 'intensity', n->'intensity', 'location', n->>'location'), actor, COALESCE((n->>'observed_at')::timestamptz, now()));
  WHEN 'senior_reminders' THEN
    IF TG_OP = 'UPDATE' AND (o->>'completed') IS DISTINCT FROM (n->>'completed') THEN
      PERFORM record_senior_activity(sid, eid, CASE WHEN (n->>'completed')::boolean THEN 'Reminder completed' ELSE 'Reminder reopened' END, n->>'message', 'reminders', CASE WHEN (n->>'completed')::boolean THEN 'completed' ELSE 'pending' END, jsonb_build_object('due', n->>'reminder_time'), actor);
    ELSIF TG_OP <> 'UPDATE' THEN
      PERFORM record_senior_activity(sid, eid, 'Reminder ' || verb, n->>'message', 'reminders', 'info', jsonb_build_object('due', n->>'reminder_time'), actor);
    END IF;
  WHEN 'custom_trackers' THEN
    IF TG_OP = 'UPDATE' AND (o->>'completed') IS DISTINCT FROM (n->>'completed') THEN
      PERFORM record_senior_activity(sid, eid, CASE WHEN (n->>'completed')::boolean THEN 'Task completed' ELSE 'Task marked not done' END, n->>'name', 'trackers', CASE WHEN (n->>'completed')::boolean THEN 'completed' ELSE 'pending' END, jsonb_build_object('value', n->>'value'), actor);
    ELSIF TG_OP = 'UPDATE' AND (o->>'value') IS DISTINCT FROM (n->>'value') THEN
      PERFORM record_senior_activity(sid, eid, 'Tracker updated', (n->>'name') || ': ' || COALESCE(n->>'value', '—'), 'trackers', 'completed', jsonb_build_object('previous', o->>'value', 'value', n->>'value'), actor);
    ELSIF TG_OP <> 'UPDATE' THEN
      PERFORM record_senior_activity(sid, eid, 'Tracker ' || verb, n->>'name', 'trackers', 'info', '{}'::jsonb, actor);
    END IF;
  WHEN 'doctor_questions' THEN
    PERFORM record_senior_activity(sid, eid, 'Doctor question ' || verb, left(n->>'question', 400), 'doctor', CASE WHEN (n->>'asked')::boolean THEN 'completed' ELSE 'pending' END, '{}'::jsonb, actor);
  WHEN 'life_story_entries' THEN
    IF TG_OP <> 'DELETE' AND COALESCE(n->>'response','') <> '' THEN
      PERFORM record_senior_activity(sid, eid, 'Life Story ' || verb, n->>'prompt', 'life_story', 'completed', '{}'::jsonb, actor);
    END IF;
  WHEN 'caregiver_messages' THEN
    IF TG_OP = 'INSERT' THEN
      PERFORM record_senior_activity(sid, 'msg:' || (n->>'id'), CASE WHEN n->>'sender_role' = 'senior' THEN 'Message sent to caregiver' ELSE 'Message from caregiver' END, left(n->>'message', 500), 'messages', 'info', '{}'::jsonb, actor);
    ELSIF TG_OP = 'UPDATE' AND (o->>'read') IS DISTINCT FROM (n->>'read') AND (n->>'read')::boolean AND n->>'sender_role' <> 'senior' THEN
      PERFORM record_senior_activity(sid, 'msg-read:' || (n->>'id'), 'Caregiver message read', left(n->>'message', 500), 'messages', 'completed', '{}'::jsonb, actor);
    END IF;
  WHEN 'senior_feature_settings' THEN
    PERFORM record_senior_activity(sid, eid, 'Dashboard settings changed', 'Feature visibility was ' || verb, 'settings', 'info', n - 'id' - 'created_at' - 'updated_at', actor);
  WHEN 'emergency_alerts' THEN
    IF TG_OP = 'INSERT' THEN
      PERFORM record_senior_activity(sid, 'sos:' || (n->>'id'), 'SOS triggered', 'Emergency SOS sent to caregivers' || CASE WHEN n->>'latitude' IS NOT NULL THEN ' with location' ELSE ' (location unavailable)' END, 'emergency', 'pending',
        jsonb_build_object('alert_id', n->>'id', 'latitude', n->'latitude', 'longitude', n->'longitude', 'accuracy_m', n->'accuracy_m'), actor);
    ELSIF TG_OP = 'UPDATE' AND (o->>'status') IS DISTINCT FROM (n->>'status') AND n->>'status' IN ('cancelled','resolved') THEN
      PERFORM record_senior_activity(sid, 'sos-' || (n->>'status') || ':' || (n->>'id'), CASE n->>'status' WHEN 'cancelled' THEN 'SOS cancelled' ELSE 'SOS resolved' END,
        CASE n->>'status' WHEN 'cancelled' THEN 'The senior cancelled the emergency' ELSE 'The emergency was marked resolved' END, 'emergency', CASE n->>'status' WHEN 'cancelled' THEN 'cancelled' ELSE 'completed' END, jsonb_build_object('alert_id', n->>'id'), actor);
    END IF;
  WHEN 'sos_acknowledgements' THEN
    SELECT senior_id INTO sid FROM emergency_alerts WHERE id = (n->>'alert_id')::uuid;
    PERFORM record_senior_activity(sid, 'sos-ack:' || (n->>'alert_id') || ':' || (n->>'caregiver_id'), 'SOS acknowledged',
      COALESCE((SELECT full_name FROM profiles WHERE id = (n->>'caregiver_id')::uuid), 'A caregiver') || ' acknowledged the SOS', 'emergency', 'completed', jsonb_build_object('alert_id', n->>'alert_id'), (n->>'caregiver_id')::uuid);
  ELSE NULL;
  END CASE;
  RETURN NULL;
EXCEPTION WHEN OTHERS THEN
  RAISE LOG 'activity capture failed on %: %', TG_TABLE_NAME, SQLERRM;
  RETURN NULL;
END $$;
REVOKE EXECUTE ON FUNCTION public.trg_activity_capture() FROM PUBLIC, anon, authenticated;