import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BookOpen, Download, ChevronLeft, ChevronRight, Loader2, ChevronUp, ChevronDown } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { jsPDF } from "jspdf";
import { LifeMemory, MEMORY_CONFIG, withSignedUrls } from "@/components/LifeStoryMemories";

interface LifeStoryEntry {
  id: string;
  prompt: string;
  response: string | null;
  prompt_date: string;
  created_at: string;
  image_path: string | null;
  imageUrl?: string | null;
}

const toDataUrl = async (url: string) => {
  const blob = await (await fetch(url)).blob();
  return await new Promise<string>((resolve) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.readAsDataURL(blob);
  });
};

const addPdfImage = async (doc: jsPDF, imageUrl: string | null | undefined, x: number, y: number) => {
  if (!imageUrl) return 0;
  try {
    const data = await toDataUrl(imageUrl);
    const props = doc.getImageProperties(data);
    const width = 80;
    const height = Math.min(90, (props.height / props.width) * width);
    doc.addImage(data, props.fileType || "JPEG", x, y, width, height);
    return height + 10;
  } catch (error) {
    console.error("Could not add Life Story image to PDF", error);
    return 0;
  }
};

interface LifeStoryViewerProps {
  seniorId: string;
  seniorName: string;
  isCollapsed?: boolean;
  onToggleCollapse?: () => void;
}

export const LifeStoryViewer = ({ seniorId, seniorName, isCollapsed, onToggleCollapse }: LifeStoryViewerProps) => {
  const [entries, setEntries] = useState<LifeStoryEntry[]>([]);
  const [memories, setMemories] = useState<LifeMemory[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isExporting, setIsExporting] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const { toast } = useToast();

  useEffect(() => {
    fetchEntries();
  }, [seniorId]);

  const fetchEntries = async () => {
    setIsLoading(true);
    const [{ data, error }, { data: memoryData, error: memoryError }] = await Promise.all([
      supabase.from("life_story_entries").select("*").eq("senior_id", seniorId).not("response", "is", null).order("prompt_date", { ascending: false }),
      supabase.from("life_story_memories").select("*").eq("senior_id", seniorId).order("created_at"),
    ]);

    if (error) {
      console.error("Error fetching life stories:", error);
      toast({
        title: "Error",
        description: "Could not load life stories.",
        variant: "destructive",
      });
    } else {
      const signedEntries = await Promise.all((data || []).map(async (entry) => {
        if (!entry.image_path) return { ...entry, imageUrl: null };
        const { data: signed } = await supabase.storage.from("life-story-images").createSignedUrl(entry.image_path, 3600);
        return { ...entry, imageUrl: signed?.signedUrl ?? null };
      }));
      setEntries(signedEntries);
    }
    if (memoryError) {
      console.error("Error fetching special memories:", memoryError);
    } else {
      const rows = (memoryData || []).map((row) => ({ ...row, category: row.category as LifeMemory["category"], details: row.details as Record<string, string> }));
      setMemories(await withSignedUrls(rows));
    }
    setIsLoading(false);
  };

  const exportToPDF = async () => {
    if (entries.length === 0 && memories.length === 0) {
      toast({
        title: "No stories to export",
        description: "There are no life story entries to export.",
        variant: "destructive",
      });
      return;
    }

    setIsExporting(true);

    try {
      const doc = new jsPDF();
      const pageWidth = doc.internal.pageSize.getWidth();
      const pageHeight = doc.internal.pageSize.getHeight();
      const margin = 20;
      const maxWidth = pageWidth - margin * 2;
      let yPosition = margin;

      // Title page
      doc.setFontSize(28);
      doc.setFont("helvetica", "bold");
      const title = `${seniorName}'s`;
      const titleWidth = doc.getTextWidth(title);
      doc.text(title, (pageWidth - titleWidth) / 2, pageHeight / 2 - 20);

      doc.setFontSize(36);
      const subtitle = "Life Story";
      const subtitleWidth = doc.getTextWidth(subtitle);
      doc.text(subtitle, (pageWidth - subtitleWidth) / 2, pageHeight / 2 + 10);

      doc.setFontSize(14);
      doc.setFont("helvetica", "normal");
      const dateText = `Created ${new Date().toLocaleDateString("en-US", {
        year: "numeric",
        month: "long",
        day: "numeric",
      })}`;
      const dateWidth = doc.getTextWidth(dateText);
      doc.text(dateText, (pageWidth - dateWidth) / 2, pageHeight / 2 + 40);

      // Sort entries by date ascending for the book
      const sortedEntries = [...entries].sort(
        (a, b) => new Date(a.prompt_date).getTime() - new Date(b.prompt_date).getTime()
      );

      // Add entries
      for (const entry of sortedEntries) {
        doc.addPage();
        yPosition = margin;

        // Date
        doc.setFontSize(12);
        doc.setFont("helvetica", "italic");
        doc.setTextColor(100, 100, 100);
        const entryDate = new Date(entry.prompt_date).toLocaleDateString("en-US", {
          weekday: "long",
          year: "numeric",
          month: "long",
          day: "numeric",
        });
        doc.text(entryDate, margin, yPosition);
        yPosition += 15;

        // Prompt (question)
        doc.setFontSize(16);
        doc.setFont("helvetica", "bold");
        doc.setTextColor(139, 90, 43); // Amber color
        const promptLines = doc.splitTextToSize(entry.prompt, maxWidth);
        doc.text(promptLines, margin, yPosition);
        yPosition += promptLines.length * 8 + 10;

        yPosition += await addPdfImage(doc, entry.imageUrl, margin, yPosition);

        // Response
        doc.setFontSize(12);
        doc.setFont("helvetica", "normal");
        doc.setTextColor(0, 0, 0);
        const responseLines = doc.splitTextToSize(entry.response || "", maxWidth);

        // Check if we need to add pages for long responses
        for (let i = 0; i < responseLines.length; i++) {
          if (yPosition > pageHeight - margin) {
            doc.addPage();
            yPosition = margin;
          }
          doc.text(responseLines[i], margin, yPosition);
          yPosition += 7;
        }
      }

      for (const memory of memories) {
        doc.addPage();
        yPosition = margin;
        doc.setFontSize(18);
        doc.setFont("helvetica", "bold");
        doc.setTextColor(38, 69, 105);
        doc.text(MEMORY_CONFIG[memory.category].title, margin, yPosition);
        yPosition += 14;
        yPosition += await addPdfImage(doc, memory.imageUrl, margin, yPosition);
        doc.setFontSize(12);
        doc.setFont("helvetica", "normal");
        doc.setTextColor(0, 0, 0);
        for (const field of MEMORY_CONFIG[memory.category].fields) {
          const value = memory.details[field.key];
          if (!value) continue;
          const lines = doc.splitTextToSize(`${field.label}: ${value}`, maxWidth);
          if (yPosition + lines.length * 7 > pageHeight - margin) { doc.addPage(); yPosition = margin; }
          doc.text(lines, margin, yPosition);
          yPosition += lines.length * 7 + 3;
        }
      }

      // Save the PDF
      const fileName = `${seniorName.replace(/\s+/g, "_")}_Life_Story.pdf`;
      doc.save(fileName);

      toast({
        title: "PDF Exported!",
        description: `${fileName} has been downloaded.`,
      });
    } catch (error) {
      console.error("Error exporting PDF:", error);
      toast({
        title: "Export failed",
        description: "Could not create the PDF. Please try again.",
        variant: "destructive",
      });
    }

    setIsExporting(false);
  };

  const navigate = (direction: "prev" | "next") => {
    if (direction === "prev" && currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    } else if (direction === "next" && currentIndex < entries.length - 1) {
      setCurrentIndex(currentIndex + 1);
    }
  };

  if (isLoading) {
    return (
      <Card className="p-6 bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-950/30 dark:to-orange-950/30 border-2">
        <div className="flex items-center justify-center py-8">
          <Loader2 className="w-8 h-8 animate-spin text-amber-600" />
        </div>
      </Card>
    );
  }

  return (
    <Card className="bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-950/30 dark:to-orange-950/30 border-2 border-amber-200 dark:border-amber-800">
      <CardHeader className="pb-4">
        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-2xl font-semibold flex items-center gap-2 text-amber-800 dark:text-amber-200">
              <BookOpen className="w-7 h-7 flex-shrink-0" />
              {seniorName}'s Life Story
            </CardTitle>
            {onToggleCollapse && (
              <Button variant="ghost" size="sm" onClick={onToggleCollapse}>
                {isCollapsed ? <ChevronDown className="w-5 h-5" /> : <ChevronUp className="w-5 h-5" />}
              </Button>
            )}
          </div>
          {!isCollapsed && (
            <Button
              onClick={exportToPDF}
              disabled={isExporting || (entries.length === 0 && memories.length === 0)}
              className="bg-amber-600 hover:bg-amber-700 text-white self-start"
            >
              {isExporting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Creating PDF...
                </>
              ) : (
                <>
                  <Download className="w-4 h-4 mr-2" />
                  Export as PDF Book
                </>
              )}
            </Button>
          )}
        </div>
      </CardHeader>
      {!isCollapsed && (
        <CardContent>
          {entries.length === 0 && memories.length === 0 ? (
            <p className="text-muted-foreground text-lg text-center py-8">
              No life story entries recorded yet.
            </p>
          ) : (
            <div className="space-y-4">
              {memories.length > 0 && (
                <div className="grid gap-2 sm:grid-cols-2">
                  {memories.map((memory) => {
                    const config = MEMORY_CONFIG[memory.category];
                    const Icon = config.icon;
                    const firstField = config.fields.find((field) => memory.details[field.key]);
                    return (
                      <div key={memory.id} className="flex items-center gap-3 rounded-lg border bg-card p-3">
                        {memory.imageUrl ? <img src={memory.imageUrl} alt="" className="h-14 w-14 rounded-full object-cover" /> : <Icon className="h-7 w-7 text-primary" />}
                        <div className="min-w-0"><p className="font-semibold">{config.title}</p>{firstField && <p className="truncate text-sm text-muted-foreground">{memory.details[firstField.key]}</p>}</div>
                      </div>
                    );
                  })}
                </div>
              )}
              {/* Navigation */}
              {entries.length > 0 && <div className="flex items-center justify-between">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => navigate("prev")}
                  disabled={currentIndex === 0}
                  className="border-amber-300"
                >
                  <ChevronLeft className="w-4 h-4 mr-1" />
                  Previous
                </Button>
                <span className="text-sm text-muted-foreground">
                  {currentIndex + 1} of {entries.length} memories
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => navigate("next")}
                  disabled={currentIndex === entries.length - 1}
                  className="border-amber-300"
                >
                  Next
                  <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </div>}

              {/* Current Entry */}
              {entries.length > 0 && <div className="bg-white/60 dark:bg-background/40 rounded-lg p-5 border border-amber-200 dark:border-amber-700">
                <p className="text-xs text-muted-foreground mb-2">
                  {new Date(entries[currentIndex].prompt_date).toLocaleDateString("en-US", {
                    weekday: "long",
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                  })}
                </p>
                <p className="text-lg font-medium text-amber-700 dark:text-amber-300 mb-3">
                  {entries[currentIndex].prompt}
                </p>
                {entries[currentIndex].imageUrl && <img src={entries[currentIndex].imageUrl} alt="Life Story memory" className="mb-3 h-32 w-full rounded-md object-cover" />}
                <p className="text-foreground whitespace-pre-wrap leading-relaxed">
                  {entries[currentIndex].response}
                </p>
              </div>}

              {/* Entry count summary */}
              <p className="text-sm text-center text-muted-foreground">
                {entries.length + memories.length} {entries.length + memories.length === 1 ? "memory" : "memories"} recorded
              </p>
            </div>
          )}
        </CardContent>
      )}
    </Card>
  );
};
