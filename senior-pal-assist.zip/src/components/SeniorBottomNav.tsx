import { LucideIcon } from "lucide-react";
import { Button } from "@/components/ui/button";

export interface BottomNavItem {
  value: string;
  label: string;
  icon: LucideIcon;
}

interface SeniorBottomNavProps {
  items: BottomNavItem[];
  active: string;
  onChange: (value: string) => void;
}

/** Five fixed destinations matching the senior dashboard's app-style dock. */
export const SeniorBottomNav = ({ items, active, onChange }: SeniorBottomNavProps) => {
  return (
    <nav
      aria-label="Main sections"
      className="fixed inset-x-0 bottom-0 z-40 rounded-t-[1.45rem] bg-card shadow-[0_-3px_14px_hsl(var(--foreground)/0.05)]"
    >
      <ul className="mx-auto grid h-[72px] max-w-3xl grid-cols-5 px-2 pb-[max(0.15rem,env(safe-area-inset-bottom))] md:h-[78px] md:px-4 md:pb-[max(0.25rem,env(safe-area-inset-bottom))]">
        {items.map((item) => {
          const Icon = item.icon;
          const isActive = active === item.value;
          const isHome = item.value === "home";
          return (
            <li key={item.value} className="relative min-w-0">
              <Button
                type="button"
                variant="ghost"
                aria-current={isActive ? "page" : undefined}
                aria-label={item.label}
                onClick={() => {
                  onChange(item.value);
                  window.scrollTo({ top: 0, left: 0, behavior: "smooth" });
                }}
                className={`relative h-full w-full min-w-0 rounded-none px-0 text-[10px] hover:bg-transparent md:max-w-28 md:text-[11px] ${
                  isActive && !isHome ? "text-nav-active hover:text-nav-active" : "text-nav-icon hover:text-nav-icon"
                } ${
                  isActive ? "font-semibold" : "font-medium"
                }`}
              >
                <span className={`${isHome ? "absolute left-1/2 top-[-16px] flex h-[3.25rem] w-[3.25rem] -translate-x-1/2 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-md ring-[5px] ring-card md:top-[-17px] md:h-14 md:w-14 md:ring-[6px]" : "absolute left-1/2 top-[13px] flex h-6 w-7 -translate-x-1/2 items-center justify-center md:top-[15px] md:h-7 md:w-8"}`}>
                  {isHome ? (
                    <svg viewBox="0 0 24 24" aria-hidden="true" className="!size-[30px]">
                      <path fill="currentColor" d="M2.8 10.8 12 2.7l9.2 8.1-1.7 1.9-1.1-1v8.1c0 .8-.6 1.4-1.4 1.4h-3.2v-6.1h-3.6v6.1H7c-.8 0-1.4-.6-1.4-1.4v-8.1l-1.1 1-1.7-1.9Z" />
                    </svg>
                  ) : (
                    <Icon className="!h-[1.35rem] !w-[1.35rem] md:!h-[1.45rem] md:!w-[1.45rem]" strokeWidth={1.9} strokeLinecap="round" strokeLinejoin="round" fill={isActive ? "currentColor" : "none"} />
                  )}
                </span>
                <span className="absolute inset-x-0 bottom-[8px] w-full truncate text-center leading-none md:bottom-[9px]">{item.label}</span>
              </Button>
            </li>
          );
        })}
      </ul>
    </nav>
  );
};

export default SeniorBottomNav;
