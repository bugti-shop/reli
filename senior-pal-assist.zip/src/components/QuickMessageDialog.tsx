import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Send, Heart, Loader2, CheckCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { User } from "@supabase/supabase-js";

interface Caregiver {
  id: string;
  full_name: string;
  email: string;
}

interface QuickMessageDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  caregivers: Caregiver[];
  user: User | null;
}

const quickMessages = [
  "I'm doing well today!",
  "Just wanted to say hello.",
  "Can you call me when you're free?",
  "I need some help with something.",
  "Thank you for everything!",
];

export const QuickMessageDialog = ({
  open,
  onOpenChange,
  caregivers,
  user,
}: QuickMessageDialogProps) => {
  const [selectedCaregiver, setSelectedCaregiver] = useState<string>("");
  const [message, setMessage] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [isSent, setIsSent] = useState(false);
  const { toast } = useToast();

  const handleQuickMessage = (msg: string) => {
    setMessage(msg);
  };

  const handleSend = async () => {
    if (!selectedCaregiver || !message.trim() || !user) {
      toast({
        title: "Missing Information",
        description: "Please select a caregiver and write a message.",
        variant: "destructive",
      });
      return;
    }

    setIsSending(true);

    try {
      const { data: inserted, error } = await supabase
        .from("caregiver_messages")
        .insert({
          caregiver_id: selectedCaregiver,
          senior_id: user.id,
          message: message.trim(),
          sender_role: "senior",
          read: false,
        })
        .select("id")
        .single();

      if (error) throw error;

      if (inserted?.id) {
        supabase.functions
          .invoke("notify-message", { body: { messageId: inserted.id } })
          .catch((e) => console.error("message notification failed", e));
      }

      await supabase.from("senior_activity_log").insert({
        senior_id: user.id,
        activity_type: "Message Sent",
        activity_description: `Sent message to caregiver: "${message.substring(0, 50)}${message.length > 50 ? '...' : ''}"`,
      });


      setIsSent(true);
      toast({
        title: "Message Sent!",
        description: "Your caregiver will be notified.",
      });

      // Reset after showing success
      setTimeout(() => {
        setIsSent(false);
        setMessage("");
        setSelectedCaregiver("");
        onOpenChange(false);
      }, 2000);
    } catch (error) {
      console.error("Error sending message:", error);
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSending(false);
    }
  };

  const handleClose = () => {
    if (!isSending) {
      setMessage("");
      setSelectedCaregiver("");
      setIsSent(false);
      onOpenChange(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-3xl flex items-center gap-3">
            <Heart className="w-10 h-10 text-primary" />
            Send a Message
          </DialogTitle>
        </DialogHeader>

        {isSent ? (
          <div className="flex flex-col items-center justify-center py-12 gap-4">
            <CheckCircle className="w-16 h-16 text-green-500" />
            <p className="text-2xl font-semibold text-green-600">Message Sent!</p>
          </div>
        ) : (
          <div className="space-y-6 py-4">
            {caregivers.length === 0 ? (
              <p className="text-xl text-muted-foreground text-center py-8">
                You don't have any caregivers connected yet.
              </p>
            ) : (
              <>
                <div className="space-y-2">
                  <label className="text-xl font-medium">To:</label>
                  <Select value={selectedCaregiver} onValueChange={setSelectedCaregiver}>
                    <SelectTrigger className="h-14 text-xl">
                      <SelectValue placeholder="Select a caregiver" />
                    </SelectTrigger>
                    <SelectContent>
                      {caregivers.map((caregiver) => (
                        <SelectItem
                          key={caregiver.id}
                          value={caregiver.id}
                          className="text-lg py-3"
                        >
                          {caregiver.full_name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-xl font-medium">Quick Messages:</label>
                  <div className="flex flex-wrap gap-2">
                    {quickMessages.map((msg, index) => (
                      <Button
                        key={index}
                        variant="outline"
                        size="sm"
                        className="text-base"
                        onClick={() => handleQuickMessage(msg)}
                      >
                        {msg}
                      </Button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xl font-medium">Your Message:</label>
                  <Textarea
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Type your message here..."
                    className="min-h-[120px] text-xl"
                  />
                </div>

                <Button
                  size="lg"
                  className="w-full h-16 text-xl"
                  onClick={handleSend}
                  disabled={isSending || !selectedCaregiver || !message.trim()}
                >
                  {isSending ? (
                    <>
                      <Loader2 className="w-6 h-6 mr-2 animate-spin" />
                      Sending...
                    </>
                  ) : (
                    <>
                      <Send className="w-6 h-6 mr-2" />
                      Send Message
                    </>
                  )}
                </Button>
              </>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};
