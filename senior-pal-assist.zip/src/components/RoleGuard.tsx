import { ReactNode, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { DashboardSkeleton } from "@/components/DashboardSkeleton";

type Role = "senior" | "caregiver";

/** Allows a dashboard only for accounts whose stored (server-locked) role matches. */
export const RoleGuard = ({ role, children }: { role: Role; children: ReactNode }) => {
  const navigate = useNavigate();
  const [ok, setOk] = useState(false);

  useEffect(() => {
    let active = true;
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { navigate("/auth", { replace: true }); return; }
      const { data } = await supabase.from("profiles").select("role").eq("id", user.id).maybeSingle();
      if (!active) return;
      const actual = (data?.role as Role | undefined) ?? "senior";
      if (actual !== role) {
        toast.error(
          actual === "caregiver"
            ? "This email is registered as a caregiver account, so it can only open the Caregiver Dashboard."
            : "This email is registered as a Senior/Myself account, so it can't open the Caregiver Dashboard.",
        );
        navigate(actual === "caregiver" ? "/caregiver" : "/dashboard", { replace: true });
        return;
      }
      setOk(true);
    })();
    return () => { active = false; };
  }, [role, navigate]);

  return ok ? <>{children}</> : <DashboardSkeleton />;
};
