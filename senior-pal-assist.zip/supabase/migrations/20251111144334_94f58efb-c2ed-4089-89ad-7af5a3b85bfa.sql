-- Drop the problematic policy
DROP POLICY IF EXISTS "Caregivers can search for seniors by email" ON public.profiles;

-- Create a better policy that allows anyone to view senior profiles (since this is needed for caregivers to add them)
-- But keep personal data protected by only showing limited fields
CREATE POLICY "Anyone can view basic senior profiles"
  ON public.profiles FOR SELECT
  USING (
    auth.uid() = id OR 
    role = 'senior'
  );