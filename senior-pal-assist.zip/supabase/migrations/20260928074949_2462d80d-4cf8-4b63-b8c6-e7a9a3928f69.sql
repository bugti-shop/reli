CREATE TABLE public.circle_invites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  senior_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_by uuid NOT NULL,
  code text NOT NULL UNIQUE DEFAULT upper(substr(replace(gen_random_uuid()::text,'-',''),1,8)),
  relationship text NOT NULL DEFAULT 'family',
  expires_at timestamptz NOT NULL DEFAULT now() + interval '7 days',
  used_by uuid,
  used_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, DELETE ON public.circle_invites TO authenticated;
GRANT ALL ON public.circle_invites TO service_role;
ALTER TABLE public.circle_invites ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Senior or linked caregiver can view invites" ON public.circle_invites FOR SELECT TO authenticated
USING (senior_id = auth.uid() OR EXISTS (SELECT 1 FROM public.caregiver_seniors cs WHERE cs.senior_id = circle_invites.senior_id AND cs.caregiver_id = auth.uid()));
CREATE POLICY "Senior or linked caregiver can create invites" ON public.circle_invites FOR INSERT TO authenticated
WITH CHECK (created_by = auth.uid() AND relationship IN ('family','caregiver') AND (senior_id = auth.uid() OR EXISTS (SELECT 1 FROM public.caregiver_seniors cs WHERE cs.senior_id = circle_invites.senior_id AND cs.caregiver_id = auth.uid())));
CREATE POLICY "Senior or creator can delete invites" ON public.circle_invites FOR DELETE TO authenticated
USING (senior_id = auth.uid() OR created_by = auth.uid());

ALTER TABLE public.caregiver_seniors ADD COLUMN IF NOT EXISTS relationship text NOT NULL DEFAULT 'caregiver';
CREATE POLICY "Seniors can remove circle members" ON public.caregiver_seniors FOR DELETE TO authenticated USING (auth.uid() = senior_id);

ALTER TABLE public.emergency_alerts ADD COLUMN IF NOT EXISTS latitude double precision, ADD COLUMN IF NOT EXISTS longitude double precision;

CREATE OR REPLACE FUNCTION public.accept_circle_invite(_code text)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE inv public.circle_invites; me uuid := auth.uid();
BEGIN
  IF me IS NULL THEN RAISE EXCEPTION 'Please sign in first'; END IF;
  SELECT * INTO inv FROM public.circle_invites WHERE code = upper(trim(_code)) FOR UPDATE;
  IF inv.id IS NULL THEN RAISE EXCEPTION 'Invite code not found'; END IF;
  IF inv.used_at IS NOT NULL THEN RAISE EXCEPTION 'This invite was already used'; END IF;
  IF inv.expires_at < now() THEN RAISE EXCEPTION 'This invite has expired'; END IF;
  IF inv.senior_id = me THEN RAISE EXCEPTION 'You cannot join your own circle'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.profiles WHERE id = me AND role = 'caregiver') THEN
    RAISE EXCEPTION 'Please join with a family/caregiver account';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM public.caregiver_seniors WHERE caregiver_id = me AND senior_id = inv.senior_id) THEN
    INSERT INTO public.caregiver_seniors (caregiver_id, senior_id, relationship) VALUES (me, inv.senior_id, inv.relationship);
  END IF;
  UPDATE public.circle_invites SET used_by = me, used_at = now() WHERE id = inv.id;
  RETURN inv.senior_id;
END; $$;
REVOKE EXECUTE ON FUNCTION public.accept_circle_invite(text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.accept_circle_invite(text) TO authenticated;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_publication_tables WHERE pubname='supabase_realtime' AND tablename='emergency_alerts') THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.emergency_alerts;
  END IF;
END $$;