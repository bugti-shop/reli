import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { History, ChevronDown, ChevronUp, Smile, Meh, Frown, AlertTriangle, Lock } from "lucide-react";
import { format, parseISO, subDays } from "date-fns";

interface DailyLogHistoryProps {
  caregiverId: string;
  seniorId: string;
  seniorName: string;
}

interface LogRow {
  id: string;
  log_date: string;
  mood: string | null;
  had_fall: boolean;
  confusion_noted: boolean;
  ate_well: boolean;
  slept_well: boolean;
  took_medications: boolean;
  notes: string | null;
}

const moodMeta: Record<string, { label: string; icon: typeof Smile; color: string }> = {
  happy: { label: "Happy", icon: Smile, color: "text-green-500" },
  neutral: { label: "Neutral", icon: Meh, color: "text-yellow-500" },
  sad: { label: "Sad", icon: Frown, color: "text-blue-500" },
  anxious: { label: "Anxious", icon: AlertTriangle, color: "text-orange-500" },
};

export const DailyLogHistory = ({ caregiverId, seniorId, seniorName }: DailyLogHistoryProps) => {
  const [logs, setLogs] = useState<LogRow[]>([]);
  const [open, setOpen] = useState(false);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [plan, setPlan] = useState<"free" | "premium" | null>(null);

  useEffect(() => {
    const fetchPlan = async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("plan")
        .eq("id", caregiverId)
        .maybeSingle();

      if (error) {
        console.error("Error fetching plan:", error);
      }
      setPlan((data?.plan as "free" | "premium") ?? "free");
    };
    fetchPlan();
  }, [caregiverId]);

  useEffect(() => {
    const fetchLogs = async () => {
      if (!plan) return;
      const today = format(new Date(), "yyyy-MM-dd");
      const cutoff = format(subDays(new Date(), 30), "yyyy-MM-dd");

      let query = supabase
        .from("caregiver_daily_logs")
        .select("*")
        .eq("caregiver_id", caregiverId)
        .eq("senior_id", seniorId)
        .lt("log_date", today)
        .order("log_date", { ascending: false })
        .limit(plan === "premium" ? 1000 : 30);

      if (plan !== "premium") {
        query = query.gte("log_date", cutoff);
      }

      const { data, error } = await query;

      if (error) {
        console.error("Error fetching log history:", error);
        return;
      }
      setLogs((data || []) as LogRow[]);
    };
    fetchLogs();
  }, [caregiverId, seniorId, plan]);

  const isFree = plan !== "premium";

  return (
    <Card className="p-6 bg-card/90 backdrop-blur border-2">
      <button
        onClick={() => setOpen((o) => !o)}
        className="w-full flex items-center justify-between text-left"
      >
        <h2 className="text-2xl font-semibold flex items-center gap-2">
          <History className="w-6 h-6 text-primary" />
          Past Daily Logs
          {logs.length > 0 && (
            <Badge variant="secondary" className="ml-1">{logs.length}</Badge>
          )}
        </h2>
        {open ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
      </button>

      {open && (
        <div className="mt-4 space-y-2">
          {logs.length === 0 ? (
            <p className="text-muted-foreground py-4">
              No previous logs for {seniorName} yet.
            </p>
          ) : (
            logs.map((log) => {
              const mood = log.mood ? moodMeta[log.mood] : null;
              const MoodIcon = mood?.icon;
              const isOpen = expandedId === log.id;
              return (
                <div key={log.id} className="border rounded-lg bg-background/50">
                  <button
                    className="w-full flex items-center justify-between gap-3 p-3 text-left"
                    onClick={() => setExpandedId(isOpen ? null : log.id)}
                  >
                    <span className="font-medium text-lg">
                      {format(parseISO(log.log_date), "EEE, MMM d, yyyy")}
                    </span>
                    <span className="flex items-center gap-2">
                      {mood && MoodIcon && (
                        <span className="flex items-center gap-1 text-sm text-muted-foreground">
                          <MoodIcon className={`w-4 h-4 ${mood.color}`} />
                          {mood.label}
                        </span>
                      )}
                      {log.had_fall && <Badge variant="destructive">Fall</Badge>}
                      {log.confusion_noted && <Badge variant="destructive">Confusion</Badge>}
                      {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </span>
                  </button>

                  {isOpen && (
                    <div className="px-3 pb-3 space-y-2 text-base">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-1">
                        <p>Fall: <strong>{log.had_fall ? "Yes" : "No"}</strong></p>
                        <p>Confusion: <strong>{log.confusion_noted ? "Yes" : "No"}</strong></p>
                        <p>Ate well: <strong>{log.ate_well ? "Yes" : "No"}</strong></p>
                        <p>Slept well: <strong>{log.slept_well ? "Yes" : "No"}</strong></p>
                        <p>Took medications: <strong>{log.took_medications ? "Yes" : "No"}</strong></p>
                      </div>
                      {log.notes && (
                        <p className="text-muted-foreground whitespace-pre-wrap">
                          Notes: {log.notes}
                        </p>
                      )}
                    </div>
                  )}
                </div>
              );
            })
          )}

          {isFree && (
            <div className="mt-4 p-4 rounded-lg border bg-muted/30 flex items-start gap-3">
              <Lock className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
              <div>
                <p className="font-medium text-sm">Free plan: last 30 days shown</p>
                <p className="text-sm text-muted-foreground">
                  Upgrade to Premium to access the complete daily log history for {seniorName}.
                </p>
              </div>
            </div>
          )}
        </div>
      )}
    </Card>
  );
};

export default DailyLogHistory;
