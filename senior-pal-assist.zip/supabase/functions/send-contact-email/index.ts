import { sendTemplateEmail } from '../_shared/transactional-email-templates/send-email.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  })

// Simple in-memory rate limit: max 3 requests per IP per 10 minutes
const RATE_LIMIT_WINDOW_MS = 10 * 60 * 1000
const RATE_LIMIT_MAX = 3
const ipHits = new Map<string, number[]>()

function isRateLimited(ip: string): boolean {
  const now = Date.now()
  const hits = (ipHits.get(ip) || []).filter((t) => now - t < RATE_LIMIT_WINDOW_MS)
  if (hits.length >= RATE_LIMIT_MAX) {
    ipHits.set(ip, hits)
    return true
  }
  hits.push(now)
  ipHits.set(ip, hits)
  return false
}

const isValidEmail = (email: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })

  const clientIp =
    req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
    req.headers.get('cf-connecting-ip') ||
    'unknown'

  if (isRateLimited(clientIp)) {
    return json({ error: 'Too many requests. Please try again later.' }, 429)
  }

  try {
    const body = await req.json().catch(() => ({}))
    const name = typeof body?.name === 'string' ? body.name.trim() : ''
    const email = typeof body?.email === 'string' ? body.email.trim() : ''
    const message = typeof body?.message === 'string' ? body.message.trim() : ''

    if (!name || name.length > 100 || !isValidEmail(email) || email.length > 255 || !message || message.length > 2000) {
      return json({ error: 'Invalid input. Please check your form data and try again.' }, 400)
    }

    // Notification to info@reli.care (fixed recipient on the template);
    // replyTo lets the team respond straight to the sender.
    await sendTemplateEmail('contact-notification', 'info@reli.care', {
      templateData: { senderName: name, senderEmail: email, message },
      replyTo: email,
      idempotencyKey: crypto.randomUUID(),
    })

    // Confirmation to the sender — failure here should not fail the request.
    try {
      await sendTemplateEmail('contact-confirmation', email, {
        templateData: { senderName: name },
        idempotencyKey: crypto.randomUUID(),
      })
    } catch (confirmError) {
      console.error('Confirmation email failed:', confirmError)
    }

    return json({ success: true })
  } catch (error) {
    console.error('Error in send-contact-email function:', error)
    return json({ error: 'Failed to send message. Please try again later.' }, 500)
  }
})
