import { useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { initNativeShell, isNativeApp } from "@/lib/native";

/**
 * Phone-app glue: deep links, back button, offline notice, and registering
 * this phone for alerts once someone is signed in. Renders nothing on the web.
 */
export const NativeBridge = () => {
  const navigate = useNavigate();
  const started = useRef(false);

  useEffect(() => {
    if (!isNativeApp() || started.current) return;
    started.current = true;
    initNativeShell(
      (path) => navigate(path),
      (online) =>
        toast({
          title: online ? "Back online" : "You're offline",
          description: online
            ? "Reli is connected again."
            : "Some features need internet. Your SOS will send as soon as you're back online.",
        }),
    );
  }, [navigate]);

  useEffect(() => {
    if (!isNativeApp()) return;
    const register = async (userId: string) => {
      const { enablePush } = await import("@/lib/push");
      await enablePush(userId).catch(() => undefined);
    };
    supabase.auth.getSession().then(({ data }) => {
      if (data.session?.user) register(data.session.user.id);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === "SIGNED_IN" && session?.user) register(session.user.id);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  return null;
};
