import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { Loader2, Trash2, ShieldCheck } from "lucide-react";
import { toast } from "sonner";

const CATEGORIES = [
  { id: "messages", label: "Messages & notes" },
  { id: "medications", label: "Medications & dose history" },
  { id: "vitals", label: "Health readings (BP, heart rate, glucose, weight, water)" },
  { id: "journal", label: "Journal, daily logs & pattern records" },
  { id: "life_story", label: "Life Story answers & photos" },
  { id: "trackers", label: "Trackers & reminders" },
  { id: "doctor", label: "Doctor questions & shared reports" },
  { id: "sos", label: "SOS history & locations" },
  { id: "activity", label: "Activity history" },
] as const;

type Step = "email" | "code" | "done";

export const AccountDeletion = ({ defaultEmail = "", onAccountDeleted }: { defaultEmail?: string; onAccountDeleted?: () => void }) => {
  const [email, setEmail] = useState(defaultEmail);
  const [step, setStep] = useState<Step>("email");
  const [code, setCode] = useState("");
  const [scope, setScope] = useState<"data" | "account">("data");
  const [cats, setCats] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [doneText, setDoneText] = useState("");

  const call = async (body: Record<string, unknown>) => {
    const { data, error } = await supabase.functions.invoke("account-deletion", { body });
    if (error) {
      let msg = "Something went wrong. Please try again.";
      try { msg = (await (error as any).context?.json())?.error ?? msg; } catch { /* ignore */ }
      throw new Error(msg);
    }
    return data;
  };

  const sendCode = async () => {
    setBusy(true);
    try {
      await call({ action: "send_code", email });
      toast.success("If an account uses this email, a 6-digit code has been sent.");
      setStep("code");
    } catch (e: any) { toast.error(e.message); } finally { setBusy(false); }
  };

  const confirm = async () => {
    if (scope === "data" && !cats.length) return toast.error("Please choose what to delete.");
    if (scope === "account" && !window.confirm("This permanently deletes your Reli account and all its data. Continue?")) return;
    setBusy(true);
    try {
      await call({ action: "delete", email, code, scope, categories: scope === "data" ? cats : undefined });
      if (scope === "account") {
        setDoneText("Your account and all its data have been permanently deleted.");
        await supabase.auth.signOut({ scope: "local" }).catch(() => {});
        onAccountDeleted?.();
      } else {
        setDoneText("The selected data has been permanently deleted. Your account is still active.");
      }
      setStep("done");
    } catch (e: any) { toast.error(e.message); } finally { setBusy(false); }
  };

  return (
    <Card className="border-destructive/40">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-destructive">
          <Trash2 className="w-5 h-5" /> Delete account or data
        </CardTitle>
        <CardDescription>
          Delete only some of your data, or your whole Reli account. We confirm it's you with a 6-digit code sent to your email.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-5">
        {step === "email" && (
          <div className="space-y-3">
            <Label htmlFor="del-email">Account email</Label>
            <Input id="del-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
            <Button onClick={sendCode} disabled={busy || !/\S+@\S+\.\S+/.test(email)} className="w-full min-h-12">
              {busy && <Loader2 className="w-4 h-4 mr-2 animate-spin" />} Send verification code
            </Button>
          </div>
        )}

        {step === "code" && (
          <div className="space-y-5">
            <div className="space-y-2">
              <Label>6-digit code sent to {email}</Label>
              <InputOTP maxLength={6} value={code} onChange={setCode} inputMode="numeric">
                <InputOTPGroup>
                  {[0, 1, 2, 3, 4, 5].map((i) => <InputOTPSlot key={i} index={i} />)}
                </InputOTPGroup>
              </InputOTP>
              <button type="button" className="text-sm text-primary underline" onClick={sendCode} disabled={busy}>
                Send a new code
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <Button variant={scope === "data" ? "default" : "outline"} onClick={() => setScope("data")}>Delete some data</Button>
              <Button variant={scope === "account" ? "destructive" : "outline"} onClick={() => setScope("account")}>Delete account</Button>
            </div>

            {scope === "data" ? (
              <div className="space-y-3">
                {CATEGORIES.map((c) => (
                  <label key={c.id} className="flex items-start gap-3 text-sm cursor-pointer">
                    <Checkbox
                      checked={cats.includes(c.id)}
                      onCheckedChange={(v) => setCats((p) => (v ? [...p, c.id] : p.filter((x) => x !== c.id)))}
                    />
                    <span>{c.label}</span>
                  </label>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">
                Your profile, links to family members, and every record listed above will be permanently removed. This can't be undone.
              </p>
            )}

            <Button variant="destructive" className="w-full min-h-12" disabled={busy || code.length !== 6} onClick={confirm}>
              {busy && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              {scope === "account" ? "Permanently delete my account" : "Delete selected data"}
            </Button>
          </div>
        )}

        {step === "done" && (
          <div className="flex items-start gap-3 text-sm">
            <ShieldCheck className="w-5 h-5 text-primary shrink-0" />
            <p>{doneText}</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
