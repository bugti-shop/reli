import * as React from 'npm:react@18.3.1'
import {
  Body,
  Container,
  Head,
  Heading,
  Html,
  Preview,
  Section,
  Text,
} from 'npm:@react-email/components@0.0.22'
import type { TemplateEntry } from './registry.ts'

interface PersonSummary {
  name?: string
  medsTaken?: number
  medsTotal?: number
  bloodPressure?: string
  heartRate?: string
  log?: string
  journal?: string
}

interface Props {
  recipientName?: string
  dateLabel?: string
  people?: PersonSummary[]
}

const Email = ({ recipientName, dateLabel, people = [] }: Props) => (
  <Html lang="en" dir="ltr">
    <Head />
    <Preview>Your Reli daily summary{dateLabel ? ` for ${dateLabel}` : ''}</Preview>
    <Body style={main}>
      <Container style={container}>
        <Heading style={h1}>Daily summary</Heading>
        <Text style={text}>
          {recipientName ? `Hi ${recipientName}, ` : ''}here is how the day went
          {dateLabel ? ` on ${dateLabel}` : ''}.
        </Text>

        {people.length === 0 ? (
          <Text style={text}>Nothing was recorded today.</Text>
        ) : (
          people.map((p, i) => (
            <Section key={i} style={card}>
              {p.name ? <Text style={cardTitle}>{p.name}</Text> : null}
              <Text style={line}>
                Medications:{' '}
                {typeof p.medsTotal === 'number' && p.medsTotal > 0
                  ? `${p.medsTaken ?? 0} of ${p.medsTotal} taken`
                  : 'none scheduled'}
              </Text>
              <Text style={line}>Blood pressure: {p.bloodPressure || 'no reading'}</Text>
              <Text style={line}>Heart rate: {p.heartRate || 'no reading'}</Text>
              {p.log ? <Text style={line}>Daily log: {p.log}</Text> : null}
              {p.journal ? <Text style={line}>Journal: {p.journal}</Text> : null}
            </Section>
          ))
        )}

        <Text style={footer}>Sent from Reli. This is a wellness summary, not medical advice.</Text>
      </Container>
    </Body>
  </Html>
)

export const template = {
  component: Email,
  subject: (data: Record<string, any>) =>
    data.dateLabel ? `Your Reli daily summary — ${data.dateLabel}` : 'Your Reli daily summary',
  displayName: 'Daily summary',
  previewData: {
    recipientName: 'Jake',
    dateLabel: 'Tuesday, September 15',
    people: [
      {
        name: 'Mary',
        medsTaken: 2,
        medsTotal: 3,
        bloodPressure: '128/78 at 9:10 AM',
        heartRate: '72 bpm at 9:12 AM',
        log: 'Good mood, ate well, slept well',
        journal: 'Wrote about the garden',
      },
    ],
  },
} satisfies TemplateEntry

const main = { backgroundColor: '#ffffff', fontFamily: 'Arial, sans-serif' }
const container = { padding: '20px 25px' }
const h1 = {
  fontSize: '22px',
  fontWeight: 'bold' as const,
  color: 'hsl(24, 20%, 15%)',
  margin: '0 0 20px',
}
const text = {
  fontSize: '16px',
  color: 'hsl(24, 15%, 35%)',
  lineHeight: '1.6',
  margin: '0 0 18px',
}
const card = {
  backgroundColor: 'hsl(206, 55%, 96%)',
  borderLeft: '4px solid hsl(206, 55%, 38%)',
  borderRadius: '10px',
  padding: '14px 18px',
  margin: '0 0 16px',
}
const cardTitle = {
  fontSize: '18px',
  fontWeight: 'bold' as const,
  color: 'hsl(24, 20%, 15%)',
  margin: '0 0 8px',
}
const line = {
  fontSize: '15px',
  color: 'hsl(24, 20%, 15%)',
  lineHeight: '1.5',
  margin: '0 0 4px',
}
const footer = { fontSize: '12px', color: '#999999', margin: '30px 0 0' }
