# Senior Dashboard UI — Exact Reference Layout

## Goal
Rebuild the senior dashboard to match the supplied Reli mobile reference: compact branded header, large blue greeting/voice/health panel, four pastel home tiles, and a five-item bottom navigation with a raised Home button. Preserve every existing feature and all current data/actions.

## Navigation structure
Each bottom item becomes its own dedicated screen. Switching items replaces the visible page content and returns to the top, instead of appending the selected feature below the Home content.

- **Home** — greeting, live date/time/weather, tap-to-speak, latest blood pressure and heart rate, medications, reminders, messages, and Daily Trivia tiles.
- **Health** — medications, blood pressure, heart rate, tracker reminders, tracker history, Trends & Insights, Custom Trackers, Activity, and Doctor Report.
- **Messages** — complete two-way message list, unread state, caregiver contact details, message deletion, and Message Caregiver action.
- **My Life** — Journal, Life Story, AI Companion, and Daily Trivia.
- **More** — Share Report, Resources/Help, caregiver list and calling, profile, Settings, Contact, motion/font controls, and Logout.

Caregiver-controlled hidden features remain completely hidden. Premium-only features retain their existing access rules.

## Visual match
- Recreate the reference’s cream page, blue Reli branding, compact profile area, large rounded steel-blue panel, white microphone circle, two translucent latest-reading tiles, four pastel action tiles, and fixed white bottom bar.
- Keep the centered raised blue Home control and the exact five labels: **Health, Messages, Home, My Life, More**.
- Use the app’s semantic color tokens, adjusted to match the reference palette, with senior-friendly type and touch sizes.
- Desktop keeps the same visual language in a centered, wider layout without stretching or compressing controls.

## Interaction fixes
- Replace the current nine-tab expandable mobile dock with the five fixed destinations.
- Remove the old desktop tab strip from the senior experience and use the same five-section model there.
- Home tiles open their related dedicated destination or dialog.
- Voice commands map old feature names to their new parent destination, then focus the requested section.
- Only the active destination is rendered; Home-only cards and reminders will no longer remain above or below other destinations.
- Preserve emergency alerts with an immediately reachable SOS control.

## Verification
- Check all five destinations on phone and desktop sizes.
- Confirm no horizontal overflow, hidden content, overlapping bottom navigation, or content appended under the wrong destination.
- Confirm every existing senior feature remains reachable and existing actions still work.
- Confirm caregiver feature-visibility rules and Premium gates remain intact.
