# Refine mobile landing illustration and controls

## Goal
Match the supplied mobile screenshot more precisely while applying the requested text alignment, badge typography, and illustration bubble refinements.

## Changes
- Align “See Pricing” beneath the start of “Myself,” and “Learn More” beneath the start of “Caregivers,” not beneath the button edges.
- Add clear blue underlines beneath both links.
- Enlarge and rebalance the App Store and Google Play badge typography so it fills each badge cleanly without changing the compact badge proportions.
- Slightly zoom the family artwork and attach it flush to the left and right page edges.
- Restyle all three illustration messages as speech bubbles with tails and requested two-line wording.
- Place “Brighter days together” inside a visible picture frame and soften its lettering.

## Verification
- Check the mobile view for exact alignment, edge-to-edge artwork, readable badge text, complete speech bubbles, and no horizontal overflow.
- Confirm desktop remains balanced.
