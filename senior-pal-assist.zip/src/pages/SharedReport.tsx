import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2, Download, Heart } from "lucide-react";
import { generateSharedReportPdf, SharedReportData } from "@/lib/shareReportPdf";

const SharedReport = () => {
  const { token } = useParams<{ token: string }>();
  const [data, setData] = useState<SharedReportData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const res = await fetch(
          `https://${import.meta.env.VITE_SUPABASE_PROJECT_ID}.supabase.co/functions/v1/get-shared-report?token=${encodeURIComponent(token || "")}`,
          { headers: { apikey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY } }
        );
        const json = await res.json();
        if (!res.ok) throw new Error(json.error || "Unable to load");
        setData(json);
      } catch (e: any) {
        setError(e.message);
      } finally {
        setLoading(false);
      }
    };
    if (token) load();
  }, [token]);

  const downloadPdf = () => {
    if (!data) return;
    const doc = generateSharedReportPdf(data);
    doc.save(`${data.report.title.replace(/[^\w\-]+/g, "_")}.pdf`);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <Card className="p-8 max-w-md text-center">
          <Heart className="w-10 h-10 mx-auto text-primary mb-3" />
          <h1 className="text-xl font-bold mb-2">Link unavailable</h1>
          <p className="text-muted-foreground">{error || "This shared report could not be loaded."}</p>
        </Card>
      </div>
    );
  }

  const { report, senior, owner, data: d } = data;

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-20 border-b bg-card/80 backdrop-blur">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
          <h1 className="text-lg font-bold flex items-center gap-2">
            <Heart className="w-5 h-5 text-primary" /> Reli
          </h1>
          <Button size="sm" onClick={downloadPdf}>
            <Download className="w-4 h-4 mr-1.5" /> Download PDF
          </Button>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8 space-y-6">
        <div>
          <h2 className="text-3xl font-bold">{report.title}</h2>
          <p className="text-muted-foreground mt-1">
            About <span className="font-semibold text-foreground">{senior.full_name}</span>
            {" · "}Shared by {owner.full_name} ({owner.role})
            {report.recipient_name ? ` · Prepared for ${report.recipient_name}` : ""}
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            Covers last {report.date_range_days} days · Link expires {new Date(report.expires_at).toLocaleDateString()}
          </p>
        </div>

        {report.notes && (
          <Card className="p-5 border-l-4 border-l-primary bg-primary/5">
            <p className="text-sm font-semibold mb-1">A note from {owner.full_name}</p>
            <p className="whitespace-pre-wrap text-foreground">{report.notes}</p>
          </Card>
        )}

        {report.include_medications && (
          <Card className="p-5">
            <h3 className="text-xl font-semibold mb-3">Medications</h3>
            {d.medications.length === 0 ? (
              <p className="text-muted-foreground text-sm">No medications recorded.</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="text-left text-muted-foreground border-b">
                    <tr><th className="py-2 pr-3">Name</th><th className="pr-3">Dosage</th><th className="pr-3">Time</th><th className="pr-3">Status</th><th>Notes</th></tr>
                  </thead>
                  <tbody>
                    {d.medications.map((m: any, i: number) => (
                      <tr key={i} className="border-b last:border-0">
                        <td className="py-2 pr-3 font-medium">{m.name}</td>
                        <td className="pr-3">{m.dosage || "—"}</td>
                        <td className="pr-3">{m.time}</td>
                        <td className="pr-3">{m.completed ? "Taken" : "Not taken"}</td>
                        <td>{m.notes || ""}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>
        )}

        {report.include_wellness && (
          <Card className="p-5">
            <h3 className="text-xl font-semibold mb-3">Daily Wellness Logs</h3>
            {d.wellness.length === 0 ? (
              <p className="text-muted-foreground text-sm">No wellness logs in this period.</p>
            ) : (
              <div className="space-y-3">
                {d.wellness.map((w: any, i: number) => (
                  <div key={i} className="rounded-md border p-3">
                    <div className="flex justify-between mb-1">
                      <p className="font-semibold">{new Date(w.log_date).toLocaleDateString()}</p>
                      <p className="text-sm text-muted-foreground">Mood: {w.mood || "—"}</p>
                    </div>
                    <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted-foreground">
                      <span>Meds: {w.took_medications ? "✓" : "✗"}</span>
                      <span>Slept well: {w.slept_well ? "✓" : "✗"}</span>
                      <span>Ate well: {w.ate_well ? "✓" : "✗"}</span>
                      {w.confusion_noted && <span className="text-destructive">Confusion noted</span>}
                      {w.had_fall && <span className="text-destructive">Fall noted</span>}
                    </div>
                    {w.notes && <p className="text-sm mt-2">{w.notes}</p>}
                  </div>
                ))}
              </div>
            )}
          </Card>
        )}

        {report.include_activity && (
          <>
            <Card className="p-5">
              <h3 className="text-xl font-semibold mb-3">Recent Activity</h3>
              {d.activity.length === 0 ? (
                <p className="text-muted-foreground text-sm">No activity recorded.</p>
              ) : (
                <ul className="space-y-2">
                  {d.activity.map((a: any, i: number) => (
                    <li key={i} className="text-sm border-b last:border-0 pb-2">
                      <span className="font-medium">{a.activity_type}</span> — {a.activity_description}
                      <span className="text-muted-foreground ml-2">{new Date(a.created_at).toLocaleString()}</span>
                    </li>
                  ))}
                </ul>
              )}
            </Card>
            {d.customTrackers.length > 0 && (
              <Card className="p-5">
                <h3 className="text-xl font-semibold mb-3">Custom Trackers</h3>
                <ul className="space-y-2">
                  {d.customTrackers.map((t: any, i: number) => (
                    <li key={i} className="text-sm border-b last:border-0 pb-2">
                      <span className="font-medium">{t.name}</span>: {t.value || (t.completed ? "Completed" : "—")}
                      <span className="text-muted-foreground ml-2">{t.updated_at ? new Date(t.updated_at).toLocaleString() : ""}</span>
                    </li>
                  ))}
                </ul>
              </Card>
            )}
          </>
        )}

        <p className="text-xs text-center text-muted-foreground pt-6">
          Shared securely via Reli · This link will expire on {new Date(report.expires_at).toLocaleDateString()}
        </p>
      </main>
    </div>
  );
};

export default SharedReport;
