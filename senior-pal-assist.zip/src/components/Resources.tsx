import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Phone,
  ExternalLink,
  BookOpen,
  Heart,
  Shield,
  Brain,
  Pill,
  Users,
  AlertTriangle,
  Activity,
  HandHeart,
} from "lucide-react";

type Audience = "senior" | "caregiver";

interface ResourceLink {
  title: string;
  description: string;
  url: string;
}

interface Hotline {
  name: string;
  number: string;
  description: string;
}

interface Guide {
  title: string;
  summary: string;
  body: string;
}

interface AudienceContent {
  intro: string;
  guides: Guide[];
  links: ResourceLink[];
  hotlines: Hotline[];
}

const content: Record<Audience, AudienceContent> = {
  senior: {
    intro:
      "Helpful guides, trusted organizations, and support lines to make everyday life a little easier.",
    guides: [
      {
        title: "Getting the Most Out of Reli",
        summary: "A gentle walkthrough of the features designed for you.",
        body:
          "Start your day by checking the greeting card for the date, time, and weather. Tap the big microphone to talk to your AI companion whenever you want company or have a question. Use Daily Trivia for a quick brain warm-up, and check the Reminders section so nothing slips by.",
      },
      {
        title: "Staying Safe at Home",
        summary: "Simple steps to prevent falls and keep your home senior-friendly.",
        body:
          "Keep walkways clear of cords and rugs that can slide. Add nightlights in hallways and the bathroom. Place a phone or your tablet within reach of your bed. Keep a list of emergency contacts on the fridge and saved in Reli's Caregivers section.",
      },
      {
        title: "Talking to Your Doctor",
        summary: "Make the most of every medical appointment.",
        body:
          "Use Reli's Doctor Report to bring a summary of how you've been feeling. Write down your top three questions before you go. Bring a list of all medications and supplements you take, including dosages. Ask a caregiver or family member to join in person or by phone if you'd like extra support.",
      },
    ],
    links: [
      {
        title: "AARP",
        description: "Trusted advice on health, finances, caregiving, and everyday life for adults 50+.",
        url: "https://www.aarp.org",
      },
      {
        title: "Medicare.gov",
        description: "Official site for Medicare benefits, plans, and coverage information.",
        url: "https://www.medicare.gov",
      },
      {
        title: "National Institute on Aging",
        description: "Research-backed health information from the NIH for older adults.",
        url: "https://www.nia.nih.gov",
      },
      {
        title: "Eldercare Locator",
        description: "Free service to find local support: meals, transportation, in-home help, and more.",
        url: "https://eldercare.acl.gov",
      },
      {
        title: "SilverSneakers",
        description: "Fitness programs and classes designed for older adults.",
        url: "https://www.silversneakers.com",
      },
      {
        title: "BenefitsCheckUp",
        description: "Find federal, state, and private programs to help pay for medications, food, and more.",
        url: "https://www.benefitscheckup.org",
      },
    ],
    hotlines: [
      {
        name: "Emergency",
        number: "911",
        description: "For immediate medical, fire, or police emergencies.",
      },
      {
        name: "988 Suicide & Crisis Lifeline",
        number: "988",
        description: "Free, confidential support 24/7 for emotional distress.",
      },
      {
        name: "Eldercare Locator",
        number: "1-800-677-1116",
        description: "Connects you to services for older adults in your area.",
      },
      {
        name: "Adult Protective Services",
        number: "1-800-677-1116",
        description: "Report suspected elder abuse or neglect.",
      },
      {
        name: "Medicare",
        number: "1-800-633-4227",
        description: "Questions about Medicare benefits and claims.",
      },
    ],
  },
  caregiver: {
    intro:
      "Tools, education, and support communities to help you care well — without burning out.",
    guides: [
      {
        title: "Avoiding Caregiver Burnout",
        summary: "Practical habits that protect your own wellbeing.",
        body:
          "Block at least 30 minutes a day that's just for you. Accept help when it's offered, and ask for it when it's not. Use Reli's Daily Log to notice patterns in your loved one's mood and your own. Schedule respite care before you need it — not when you're already exhausted.",
      },
      {
        title: "Coordinating Care Across Family",
        summary: "Keep everyone aligned without endless group texts.",
        body:
          "Use Reli to track medications, reminders, and daily wellness in one place that all caregivers can see. Hold a brief weekly check-in (15 minutes is enough). Assign clear roles: who handles appointments, who handles bills, who's on call for emergencies.",
      },
      {
        title: "Recognizing Cognitive Decline",
        summary: "Early signs to watch for, and when to seek help.",
        body:
          "Watch for repeated questions, missed medications, confusion about time or place, changes in mood or personality, and difficulty with familiar tasks. If you notice several signs over weeks or months, request a cognitive evaluation with their primary care doctor. Early support makes a meaningful difference.",
      },
      {
        title: "Medication Safety",
        summary: "Reduce errors and dangerous interactions.",
        body:
          "Keep one master list of every medication, dose, and prescriber. Use Reli's Medication Tracker so doses are shared and visible. Request a medication review with the pharmacist at least once a year, especially when a new prescription is added.",
      },
    ],
    links: [
      {
        title: "Family Caregiver Alliance",
        description: "Education, support groups, and policy information for family caregivers.",
        url: "https://www.caregiver.org",
      },
      {
        title: "Alzheimer's Association",
        description: "24/7 helpline, care planning, and dementia resources.",
        url: "https://www.alz.org",
      },
      {
        title: "AARP Caregiving",
        description: "Practical guides, legal/financial tools, and a caregiver community.",
        url: "https://www.aarp.org/caregiving",
      },
      {
        title: "Caregiver Action Network",
        description: "Free peer support, education, and resources for family caregivers.",
        url: "https://www.caregiveraction.org",
      },
      {
        title: "ARCH National Respite Network",
        description: "Find respite care providers and programs in your state.",
        url: "https://archrespite.org",
      },
      {
        title: "Medicare.gov — Care Compare",
        description: "Compare nursing homes, home health, and hospice providers.",
        url: "https://www.medicare.gov/care-compare",
      },
      {
        title: "VA Caregiver Support",
        description: "Resources for those caring for veterans of any era.",
        url: "https://www.caregiver.va.gov",
      },
    ],
    hotlines: [
      {
        name: "Emergency",
        number: "911",
        description: "For immediate medical, fire, or police emergencies.",
      },
      {
        name: "Alzheimer's Association Helpline",
        number: "1-800-272-3900",
        description: "24/7 support for dementia caregivers.",
      },
      {
        name: "Family Caregiver Alliance",
        number: "1-800-445-8106",
        description: "Information and referrals for family caregivers.",
      },
      {
        name: "Eldercare Locator",
        number: "1-800-677-1116",
        description: "Find local services and programs for older adults.",
      },
      {
        name: "988 Suicide & Crisis Lifeline",
        number: "988",
        description: "Free, confidential support for caregivers in distress.",
      },
    ],
  },
};

const guideIcons = [BookOpen, Shield, Heart, Brain, Pill, Activity, HandHeart, Users];

interface ResourcesProps {
  audience: Audience;
}

export const Resources = ({ audience }: ResourcesProps) => {
  const data = content[audience];

  return (
    <div className="space-y-8">
      <p className="text-base text-muted-foreground">{data.intro}</p>

      {/* Hotlines */}
      <section>
        <h3 className="text-lg font-semibold text-foreground mb-3 flex items-center gap-2">
          <Phone className="w-5 h-5 text-primary" />
          Support Lines
        </h3>
        <div className="grid sm:grid-cols-2 gap-3">
          {data.hotlines.map((h) => (
            <Card key={h.name} className="p-4 border hover:shadow-md transition-shadow">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-full bg-destructive/10 flex items-center justify-center flex-shrink-0">
                  {h.name === "Emergency" ? (
                    <AlertTriangle className="w-5 h-5 text-destructive" />
                  ) : (
                    <Phone className="w-5 h-5 text-primary" />
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="font-semibold text-foreground">{h.name}</p>
                    <a
                      href={`tel:${h.number.replace(/[^0-9+]/g, "")}`}
                      className="text-primary font-bold hover:underline"
                    >
                      {h.number}
                    </a>
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">{h.description}</p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </section>

      {/* Guides */}
      <section>
        <h3 className="text-lg font-semibold text-foreground mb-3 flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-primary" />
          Guides from Reli
        </h3>
        <div className="grid md:grid-cols-2 gap-4">
          {data.guides.map((g, idx) => {
            const Icon = guideIcons[idx % guideIcons.length];
            return (
              <Card key={g.title} className="p-5 border hover:shadow-md transition-shadow">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                  <h4 className="font-semibold text-foreground">{g.title}</h4>
                </div>
                <p className="text-sm text-muted-foreground italic mb-2">{g.summary}</p>
                <p className="text-sm text-foreground leading-relaxed">{g.body}</p>
              </Card>
            );
          })}
        </div>
      </section>

      {/* External links */}
      <section>
        <h3 className="text-lg font-semibold text-foreground mb-3 flex items-center gap-2">
          <ExternalLink className="w-5 h-5 text-primary" />
          Trusted Organizations
        </h3>
        <div className="grid sm:grid-cols-2 gap-3">
          {data.links.map((l) => (
            <a
              key={l.title}
              href={l.url}
              target="_blank"
              rel="noopener noreferrer"
              className="group"
            >
              <Card className="p-4 border h-full hover:shadow-md hover:border-primary/40 transition-all">
                <div className="flex items-start justify-between gap-2">
                  <p className="font-semibold text-foreground group-hover:text-primary transition-colors">
                    {l.title}
                  </p>
                  <ExternalLink className="w-4 h-4 text-muted-foreground flex-shrink-0 mt-0.5" />
                </div>
                <p className="text-sm text-muted-foreground mt-1">{l.description}</p>
              </Card>
            </a>
          ))}
        </div>
        <Badge variant="outline" className="mt-4 text-xs">
          External links open in a new tab. Reli is not affiliated with these organizations.
        </Badge>
      </section>
    </div>
  );
};

export default Resources;
