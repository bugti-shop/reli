import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "https://esm.sh/resend@2.0.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const bodySchema = z.object({
  to: z.string().trim().email().max(255),
  personName: z.string().trim().max(120).optional(),
  questions: z.array(z.string().trim().min(1).max(500)).min(1).max(100),
});

function escapeHtml(text: string): string {
  const map: Record<string, string> = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };
  return text.replace(/[&<>"']/g, (c) => map[c]);
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization") ?? "";
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );
    const { data: userData, error: userError } = await supabase.auth.getUser();
    if (userError || !userData?.user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      });
    }

    const parsed = bodySchema.safeParse(await req.json());
    if (!parsed.success) {
      return new Response(JSON.stringify({ error: parsed.error.flatten().fieldErrors }), {
        status: 400,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      });
    }

    const { to, personName, questions } = parsed.data;
    const heading = personName
      ? `Questions for ${escapeHtml(personName)}'s doctor`
      : "Questions for the doctor";

    const list = questions.map((q) => `<li style="margin-bottom:8px">${escapeHtml(q)}</li>`).join("");

    const response = await resend.emails.send({
      from: "Reli <noreply@reli.care>",
      to: [to],
      subject: heading,
      html: `
        <div style="font-family:Arial,Helvetica,sans-serif;color:#1f2937">
          <h2>${heading}</h2>
          <p>Bring this list to the next appointment.</p>
          <ol style="font-size:16px;line-height:1.5">${list}</ol>
          <p style="color:#6b7280;font-size:13px">Sent from Reli</p>
        </div>
      `,
    });

    console.log("Doctor questions email sent", response);

    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  } catch (error) {
    console.error("send-doctor-questions error", error);
    return new Response(JSON.stringify({ error: "Failed to send email." }), {
      status: 500,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  }
});
