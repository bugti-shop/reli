// Shared helper: sends an SMS through Twilio via the Lovable connector gateway.
// No-ops safely (without throwing) when Twilio is not connected yet.

const GATEWAY_URL = 'https://connector-gateway.lovable.dev/twilio'

export type SendSmsResult =
  | { sent: true; sid: string }
  | { sent: false; reason: 'not_configured' | 'failed' }

export async function sendSms(to: string, message: string): Promise<SendSmsResult> {
  const lovableKey = Deno.env.get('LOVABLE_API_KEY')
  const twilioKey = Deno.env.get('TWILIO_API_KEY')
  const from = Deno.env.get('TWILIO_FROM_NUMBER')

  if (!lovableKey || !twilioKey || !from) {
    console.log('[sms] skipped: Twilio is not configured yet')
    return { sent: false, reason: 'not_configured' }
  }

  const body = new URLSearchParams({
    To: to,
    From: from,
    Body: message.slice(0, 600),
  })

  const response = await fetch(`${GATEWAY_URL}/Messages.json`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${lovableKey}`,
      'X-Connection-Api-Key': twilioKey,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body,
  })

  if (!response.ok) {
    const errorBody = await response.text()
    console.error(`[sms] send failed [${response.status}]: ${errorBody}`)
    return { sent: false, reason: 'failed' }
  }

  const data = await response.json().catch(() => ({}))
  return { sent: true, sid: data?.sid ?? '' }
}

/** Normalizes a US-style phone number into E.164, or null when unusable. */
export function toE164(raw: string | null | undefined): string | null {
  if (!raw) return null
  const trimmed = raw.trim()
  if (trimmed.startsWith('+')) {
    const digits = trimmed.slice(1).replace(/\D/g, '')
    return digits.length >= 8 ? `+${digits}` : null
  }
  const digits = trimmed.replace(/\D/g, '')
  if (digits.length === 10) return `+1${digits}`
  if (digits.length === 11 && digits.startsWith('1')) return `+${digits}`
  return null
}
