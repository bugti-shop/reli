CREATE OR REPLACE FUNCTION public.has_effective_premium(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles p WHERE p.id = _user_id AND p.plan = 'premium'
  ) OR EXISTS (
    SELECT 1 FROM public.caregiver_seniors cs
    JOIN public.profiles p ON p.id = cs.senior_id
    WHERE cs.caregiver_id = _user_id AND p.plan = 'premium'
  ) OR EXISTS (
    SELECT 1 FROM public.caregiver_seniors cs
    JOIN public.profiles p ON p.id = cs.caregiver_id
    WHERE cs.senior_id = _user_id AND p.plan = 'premium'
  )
$$;

REVOKE ALL ON FUNCTION public.has_effective_premium(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.has_effective_premium(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_effective_premium(uuid) TO service_role;

CREATE OR REPLACE FUNCTION public.enforce_senior_limit()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  existing_count integer;
BEGIN
  SELECT COUNT(*) INTO existing_count
  FROM public.caregiver_seniors
  WHERE caregiver_id = NEW.caregiver_id;

  IF existing_count >= 2 AND NOT public.has_effective_premium(NEW.caregiver_id) THEN
    RAISE EXCEPTION 'SENIOR_LIMIT_REACHED: Free plan supports up to 2 seniors per caregiver';
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS enforce_senior_limit_trigger ON public.caregiver_seniors;
CREATE TRIGGER enforce_senior_limit_trigger
BEFORE INSERT ON public.caregiver_seniors
FOR EACH ROW EXECUTE FUNCTION public.enforce_senior_limit();