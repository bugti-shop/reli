# Home Calendar — Caregiver & Senior Dashboards

## What we're building
An appointments/calendar card on the Home page of both the caregiver and senior dashboards, styled after the "Integrated card view" direction the user selected (white rounded card, bold month title, Day/Week/Month pill toggle, week strip with day headers + date/month labels, dark rounded-square selected day, friendly empty state, coral + button). Adapted to Reli tokens (cream background, Reli Blue, coral accent, Sora/Manrope, soft heart watermark inside the card).

Placement (from the live caregiver home):
- Caregiver home: a new card directly under the "Add Senior" card, above "Caregiving Network" — high visibility, before the network/messages sections.
- Senior home: a new card after the 2x2 quick-action tile grid, before the Family Circle section.
- The scenic blue welcome card and five-item bottom nav stay untouched.

## Calendar behavior
- Month title + Day/Week/Month segmented toggle (default Day).
- Day view: selected day's week strip + agenda list of that day's events ("No tasks for this date yet." when empty).
- Week view: the 7-day strip with event-count dots per day + all events of that week.
- Month view: compact month grid with per-day event dots, tap a day to select.
- Coral + button opens an Add Appointment dialog: title, date, time, type (Appointment / Task / Other), notes. Caregivers add for the currently selected senior; seniors add for themselves.
- Events can be marked done and deleted by their creator (caregivers can manage any event of their linked seniors).

## Backend (Lovable Cloud)
- New table `calendar_events` (public schema) with:
  - id uuid pk, senior_id (required), owner_id, created_by_role ('caregiver' | 'senior'), title, event_date (date), event_time (text, nullable), event_type, notes, completed boolean, timestamps.
- RLS following the existing linked-family pattern (same model as `senior_reminders`):
  - A senior sees/edits only their own events.
  - A caregiver sees/edits events only for seniors linked to them via `caregiver_seniors`.
  - Grants: SELECT/INSERT/UPDATE/DELETE for authenticated (policy-scoped), ALL for service_role. No anon access.
- New events appear in the senior's activity history via the existing activity-capture pattern (add event type "calendar_event").

## Files
- New: `src/components/HomeCalendar.tsx` — the shared calendar card (both dashboards reuse it).
- New: `src/lib/calendarEvents.ts` — queries (fetch by range, add, complete, delete) using the supabase client.
- Edit: `src/pages/CaregiverDashboard.tsx` — insert the card under Add Senior.
- Edit: `src/pages/Dashboard.tsx` — insert the card after the quick-action grid on Home.
- Migration: table + grants + RLS policies (+ activity-capture trigger).

## Out of scope (can be added later if wanted)
- Reminder notifications/emails at appointment time (would reuse the existing reminder/notification system).
- Full calendar page/tab — this stays a Home card as requested.
