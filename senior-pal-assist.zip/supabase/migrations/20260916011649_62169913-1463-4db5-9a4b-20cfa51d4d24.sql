ALTER TABLE public.caregiver_messages
  ADD COLUMN IF NOT EXISTS sender_role text NOT NULL DEFAULT 'caregiver';

CREATE POLICY "Seniors can send messages to their caregivers"
ON public.caregiver_messages
FOR INSERT
TO authenticated
WITH CHECK (
  sender_role = 'senior'
  AND senior_id = auth.uid()
  AND EXISTS (
    SELECT 1 FROM public.caregiver_seniors cs
    WHERE cs.senior_id = auth.uid() AND cs.caregiver_id = caregiver_messages.caregiver_id
  )
);