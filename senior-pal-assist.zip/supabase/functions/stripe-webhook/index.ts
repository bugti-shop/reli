import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@18.5.0";
import { createClient } from "npm:@supabase/supabase-js@2.57.2";

const PAID_PRODUCT_IDS = [
  "prod_VGa2TZxenqsAvd", // Premium monthly
  "prod_VGa3caIZmDeTuH", // Premium annual
  "prod_VGa4X6nKpeFHrj", // Premium Plus monthly
  "prod_VGa4v4i27Gjouq", // Premium Plus annual
];

const log = (step: string, details?: unknown) => {
  console.log(`[STRIPE-WEBHOOK] ${step}${details ? ` - ${JSON.stringify(details)}` : ""}`);
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok");
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });

  const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");
  const webhookSecret = Deno.env.get("STRIPE_WEBHOOK_SECRET");
  if (!stripeKey || !webhookSecret) {
    log("Missing configuration");
    return new Response("Not configured", { status: 500 });
  }

  const stripe = new Stripe(stripeKey, { apiVersion: "2025-08-27.basil" });
  const signature = req.headers.get("stripe-signature");
  const body = await req.text();

  let event: Stripe.Event;
  try {
    event = await stripe.webhooks.constructEventAsync(body, signature ?? "", webhookSecret);
  } catch (e) {
    log("Signature verification failed", { message: e instanceof Error ? e.message : String(e) });
    return new Response("Invalid signature", { status: 400 });
  }

  log("Event received", { type: event.type, id: event.id });

  const supabaseAdmin = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
    { auth: { persistSession: false } }
  );

  const syncCustomer = async (customerId: string) => {
    const customer = await stripe.customers.retrieve(customerId);
    const email = (customer as Stripe.Customer).email;
    if (!email) {
      log("Customer has no email", { customerId });
      return;
    }

    const subscriptions = await stripe.subscriptions.list({
      customer: customerId,
      status: "active",
      limit: 10,
    });

    const hasPaid = subscriptions.data.some((sub) =>
      sub.items.data.some((item) => PAID_PRODUCT_IDS.includes(item.price.product as string))
    );
    let plan = hasPaid ? "premium" : "free";
    // Never downgrade someone who pays through the App Store / Google Play.
    if (!hasPaid) {
      const { data: prof } = await supabaseAdmin.from("profiles").select("id").ilike("email", email).maybeSingle();
      if (prof) {
        const { data: storeActive } = await supabaseAdmin.rpc("has_store_premium", { _user_id: prof.id });
        if (storeActive) plan = "premium";
      }
    }

    const { error } = await supabaseAdmin
      .from("profiles")
      .update({ plan })
      .ilike("email", email);
    if (error) log("Plan update failed", { message: error.message });
    else log("Plan synced", { email, plan });
  };

  try {
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;
        if (typeof session.customer === "string") await syncCustomer(session.customer);
        break;
      }
      case "customer.subscription.created":
      case "customer.subscription.updated":
      case "customer.subscription.deleted":
      case "customer.subscription.paused":
      case "customer.subscription.resumed":
      case "invoice.payment_succeeded":
      case "invoice.payment_failed": {
        const obj = event.data.object as { customer?: string | Stripe.Customer | null };
        const customerId = typeof obj.customer === "string" ? obj.customer : obj.customer?.id;
        if (customerId) await syncCustomer(customerId);
        break;
      }
      default:
        log("Ignored event", { type: event.type });
    }
  } catch (e) {
    log("ERROR", { message: e instanceof Error ? e.message : String(e) });
    return new Response("Handler error", { status: 500 });
  }

  return new Response(JSON.stringify({ received: true }), {
    headers: { "Content-Type": "application/json" },
    status: 200,
  });
});
