import { initializeApp, getApps, getApp } from "firebase/app";
import { getMessaging, getToken, isSupported, onMessage } from "firebase/messaging";
import { supabase } from "@/integrations/supabase/client";

const appId = import.meta.env.VITE_LOVABLE_CONNECTOR_FIREBASE_MESSAGING_APP_ID as
  | string
  | undefined;
const vapidKey = import.meta.env.VITE_LOVABLE_CONNECTOR_FIREBASE_MESSAGING_VAPID_KEY as
  | string
  | undefined;

const firebaseConfig = {
  apiKey: import.meta.env.VITE_LOVABLE_CONNECTOR_FIREBASE_MESSAGING_WEB_API_KEY as string,
  projectId: import.meta.env.VITE_LOVABLE_CONNECTOR_FIREBASE_MESSAGING_PROJECT_ID as string,
  appId: appId as string,
  messagingSenderId: appId?.split(":")[1] ?? "",
};

export const pushIsConfigured = () =>
  Boolean(
    firebaseConfig.apiKey &&
      firebaseConfig.projectId &&
      appId &&
      vapidKey &&
      firebaseConfig.messagingSenderId,
  );

export type PushStatus =
  | "registered"
  | "not-configured"
  | "unsupported"
  | "open-in-new-tab"
  | "denied"
  | "failed";

export interface PushResult {
  status: PushStatus;
  token?: string;
}

const messagingApp = () => (getApps().length ? getApp() : initializeApp(firebaseConfig));

const isNativeApp = () =>
  Boolean((window as any).Capacitor?.isNativePlatform?.());

/** Registers an iOS/Android app build for push through Capacitor. */
const enableNativePush = async (userId?: string): Promise<PushResult> => {
  try {
    const { PushNotifications } = await import("@capacitor/push-notifications");
    let status = await PushNotifications.checkPermissions();
    if (status.receive !== "granted") status = await PushNotifications.requestPermissions();
    if (status.receive !== "granted") return { status: "denied" };

    // Android: dedicated max-importance alarm channel for SOS alerts.
    if ((window as any).Capacitor?.getPlatform?.() === "android") {
      await PushNotifications.createChannel({
        id: "sos_alarm",
        name: "SOS Emergency Alarm",
        description: "Rings when a family member presses SOS",
        importance: 5,
        visibility: 1,
        vibration: true,
        lights: true,
        sound: "sos_alarm.wav",
      }).catch(() => undefined);
    }

    const token = await new Promise<string | null>((resolve) => {
      const timer = window.setTimeout(() => resolve(null), 10000);
      PushNotifications.addListener("registration", (t) => {
        window.clearTimeout(timer);
        resolve(t.value);
      });
      PushNotifications.addListener("registrationError", () => {
        window.clearTimeout(timer);
        resolve(null);
      });
      PushNotifications.register();
    });

    if (!token) return { status: "failed" };

    if (userId) {
      await supabase.from("push_tokens").upsert(
        {
          user_id: userId,
          token,
          platform: (window as any).Capacitor?.getPlatform?.() || "native",
        },
        { onConflict: "token" },
      );
    }
    return { status: "registered", token };
  } catch (e) {
    console.error("Native push registration failed:", e);
    return { status: "failed" };
  }
};

/**
 * Asks the browser for notification permission and registers this device so
 * instant alerts can reach it. Must be called from a click handler.
 */
export const enablePush = async (userId?: string): Promise<PushResult> => {
  if (isNativeApp()) return enableNativePush(userId);
  if (!pushIsConfigured()) return { status: "not-configured" };
  if (!("Notification" in window) || !("serviceWorker" in navigator)) {
    return { status: "unsupported" };
  }
  if (!(await isSupported().catch(() => false))) return { status: "unsupported" };
  if (window.top !== window.self) return { status: "open-in-new-tab" };

  const permission =
    Notification.permission === "granted"
      ? "granted"
      : await Notification.requestPermission();
  if (permission !== "granted") return { status: "denied" };

  try {
    const query = new URLSearchParams(firebaseConfig as Record<string, string>).toString();
    const serviceWorkerRegistration = await navigator.serviceWorker.register(
      `/firebase-messaging-sw.js?${query}`,
    );
    const messaging = getMessaging(messagingApp());
    const token = await getToken(messaging, { vapidKey, serviceWorkerRegistration });
    if (!token) return { status: "denied" };

    if (userId) {
      await supabase
        .from("push_tokens")
        .upsert({ user_id: userId, token, platform: "web" }, { onConflict: "token" });
    }

    return { status: "registered", token };
  } catch (e) {
    console.error("Push registration failed:", e);
    return { status: "failed" };
  }
};

/** Shows alerts that arrive while the app is open in the foreground. */
export const listenForPush = (
  handler: (payload: { title?: string; body?: string }) => void,
) => {
  if (!pushIsConfigured()) return () => {};
  try {
    const messaging = getMessaging(messagingApp());
    return onMessage(messaging, (payload) =>
      handler({
        title: payload.notification?.title,
        body: payload.notification?.body,
      }),
    );
  } catch {
    return () => {};
  }
};
