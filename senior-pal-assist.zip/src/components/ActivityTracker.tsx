import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Activity, Plus, Check, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ActivityItem {
  id: string;
  name: string;
  time: string;
  completed: boolean;
}

export const ActivityTracker = () => {
  const [isEnabled, setIsEnabled] = useState(() => {
    const saved = localStorage.getItem('activityTrackerEnabled');
    return saved ? JSON.parse(saved) : false;
  });
  const [activities, setActivities] = useState<ActivityItem[]>(() => {
    const saved = localStorage.getItem('activities');
    return saved ? JSON.parse(saved) : [];
  });
  const [newActivityName, setNewActivityName] = useState("");
  const [newActivityTime, setNewActivityTime] = useState("");
  const { toast } = useToast();

  useEffect(() => {
    localStorage.setItem('activityTrackerEnabled', JSON.stringify(isEnabled));
  }, [isEnabled]);

  useEffect(() => {
    localStorage.setItem('activities', JSON.stringify(activities));
  }, [activities]);

  const addActivity = () => {
    if (!newActivityName.trim() || !newActivityTime) {
      toast({
        title: "Missing Information",
        description: "Please enter both activity name and time.",
        variant: "destructive",
      });
      return;
    }

    const newActivity: ActivityItem = {
      id: Date.now().toString(),
      name: newActivityName.trim(),
      time: newActivityTime,
      completed: false,
    };

    setActivities([...activities, newActivity]);
    setNewActivityName("");
    setNewActivityTime("");
    toast({
      title: "Activity Added",
      description: `${newActivity.name} scheduled for ${newActivity.time}`,
    });
  };

  const toggleActivity = (id: string) => {
    setActivities(activities.map(activity => 
      activity.id === id ? { ...activity, completed: !activity.completed } : activity
    ));
  };

  const removeActivity = (id: string) => {
    setActivities(activities.filter(activity => activity.id !== id));
    toast({
      title: "Activity Removed",
      description: "Activity has been removed from your list.",
    });
  };

  if (!isEnabled) {
    return (
      <Card className="p-6 bg-gradient-to-r from-purple-50/50 to-purple-100/50 dark:from-purple-950/20 dark:to-purple-900/20 backdrop-blur border-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Activity className="w-8 h-8 text-primary" />
            <h2 className="text-2xl font-semibold">Activity Tracker</h2>
          </div>
          <div className="flex items-center gap-3">
            <Label htmlFor="activity-toggle" className="text-base">Enable Tracking</Label>
            <Switch
              id="activity-toggle"
              checked={isEnabled}
              onCheckedChange={setIsEnabled}
            />
          </div>
        </div>
        <p className="text-muted-foreground mt-4">
          Enable activity tracking to keep track of your daily activities, exercises, and appointments.
        </p>
      </Card>
    );
  }

  return (
    <Card className="p-6 bg-gradient-to-r from-purple-50/50 to-purple-100/50 dark:from-purple-950/20 dark:to-purple-900/20 backdrop-blur border-2">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <Activity className="w-8 h-8 text-primary" />
          <h2 className="text-2xl font-semibold">Activity Tracker</h2>
        </div>
        <div className="flex items-center gap-3">
          <Label htmlFor="activity-toggle" className="text-base">Enabled</Label>
          <Switch
            id="activity-toggle"
            checked={isEnabled}
            onCheckedChange={setIsEnabled}
          />
        </div>
      </div>

      {/* Add New Activity */}
      <div className="mb-6 p-4 bg-card/80 rounded-lg border">
        <h3 className="text-lg font-semibold mb-3">Add Activity</h3>
        <div className="grid gap-4 md:grid-cols-3">
          <div>
            <Label htmlFor="activity-name">Activity Name</Label>
            <Input
              id="activity-name"
              placeholder="e.g., Morning Walk"
              value={newActivityName}
              onChange={(e) => setNewActivityName(e.target.value)}
              className="text-base"
            />
          </div>
          <div>
            <Label htmlFor="activity-time">Time</Label>
            <Input
              id="activity-time"
              type="time"
              value={newActivityTime}
              onChange={(e) => setNewActivityTime(e.target.value)}
              className="text-base"
            />
          </div>
          <div className="flex items-end">
            <Button onClick={addActivity} className="w-full">
              <Plus className="w-5 h-5 mr-2" />
              Add
            </Button>
          </div>
        </div>
      </div>

      {/* Activity List */}
      {activities.length > 0 ? (
        <div className="space-y-3">
          {activities.map((activity) => (
            <Card key={activity.id} className={`p-4 ${activity.completed ? 'bg-green-50 dark:bg-green-950/20' : 'bg-card'}`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4 flex-1">
                  <Button
                    onClick={() => toggleActivity(activity.id)}
                    variant={activity.completed ? "default" : "outline"}
                    size="sm"
                    className="rounded-full w-10 h-10 p-0"
                  >
                    {activity.completed && <Check className="w-5 h-5" />}
                  </Button>
                  <div>
                    <p className={`text-lg font-medium ${activity.completed ? 'line-through text-muted-foreground' : ''}`}>
                      {activity.name}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Scheduled: {activity.time}
                    </p>
                  </div>
                </div>
                <Button
                  onClick={() => removeActivity(activity.id)}
                  variant="ghost"
                  size="sm"
                >
                  <X className="w-5 h-5" />
                </Button>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <p className="text-center text-muted-foreground py-8">
          No activities added yet. Add your first activity above.
        </p>
      )}
    </Card>
  );
};
