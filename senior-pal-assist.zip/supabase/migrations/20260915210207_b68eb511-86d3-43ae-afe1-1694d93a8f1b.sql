CREATE OR REPLACE FUNCTION public.enforce_senior_limit()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  existing_seniors integer;
  existing_caregivers integer;
BEGIN
  SELECT COUNT(*) INTO existing_seniors
  FROM public.caregiver_seniors
  WHERE caregiver_id = NEW.caregiver_id;

  IF existing_seniors >= 2 AND NOT public.has_effective_premium(NEW.caregiver_id) THEN
    RAISE EXCEPTION 'SENIOR_LIMIT_REACHED: Free plan supports up to 2 seniors per caregiver';
  END IF;

  SELECT COUNT(*) INTO existing_caregivers
  FROM public.caregiver_seniors
  WHERE senior_id = NEW.senior_id;

  IF existing_caregivers >= 2 AND NOT public.has_effective_premium(NEW.senior_id) THEN
    RAISE EXCEPTION 'CAREGIVER_LIMIT_REACHED: Free plan supports up to 2 caregivers per senior';
  END IF;

  RETURN NEW;
END;
$function$;