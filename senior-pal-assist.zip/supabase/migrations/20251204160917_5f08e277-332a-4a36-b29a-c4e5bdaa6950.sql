-- Create custom_trackers table for flexible data tracking
CREATE TABLE public.custom_trackers (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  owner_id UUID NOT NULL,
  senior_id UUID NOT NULL,
  name TEXT NOT NULL,
  value TEXT,
  tracker_type TEXT NOT NULL DEFAULT 'text',
  shared_with_senior BOOLEAN NOT NULL DEFAULT true,
  created_by_role TEXT NOT NULL CHECK (created_by_role IN ('senior', 'caregiver')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.custom_trackers ENABLE ROW LEVEL SECURITY;

-- Seniors can view their own trackers (created by them or shared with them)
CREATE POLICY "Seniors can view their own trackers"
ON public.custom_trackers
FOR SELECT
USING (
  senior_id = auth.uid() AND (created_by_role = 'senior' OR shared_with_senior = true)
);

-- Seniors can create their own trackers
CREATE POLICY "Seniors can create their own trackers"
ON public.custom_trackers
FOR INSERT
WITH CHECK (
  auth.uid() = owner_id AND 
  auth.uid() = senior_id AND 
  created_by_role = 'senior'
);

-- Seniors can update their own trackers
CREATE POLICY "Seniors can update their own trackers"
ON public.custom_trackers
FOR UPDATE
USING (
  senior_id = auth.uid() AND created_by_role = 'senior'
);

-- Seniors can delete their own trackers
CREATE POLICY "Seniors can delete their own trackers"
ON public.custom_trackers
FOR DELETE
USING (
  senior_id = auth.uid() AND created_by_role = 'senior'
);

-- Caregivers can view trackers for their seniors
CREATE POLICY "Caregivers can view their seniors trackers"
ON public.custom_trackers
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM caregiver_seniors
    WHERE caregiver_seniors.caregiver_id = auth.uid()
    AND caregiver_seniors.senior_id = custom_trackers.senior_id
  )
);

-- Caregivers can create trackers for their seniors
CREATE POLICY "Caregivers can create trackers for their seniors"
ON public.custom_trackers
FOR INSERT
WITH CHECK (
  auth.uid() = owner_id AND
  created_by_role = 'caregiver' AND
  EXISTS (
    SELECT 1 FROM caregiver_seniors
    WHERE caregiver_seniors.caregiver_id = auth.uid()
    AND caregiver_seniors.senior_id = custom_trackers.senior_id
  )
);

-- Caregivers can update their own trackers
CREATE POLICY "Caregivers can update their trackers"
ON public.custom_trackers
FOR UPDATE
USING (
  owner_id = auth.uid() AND created_by_role = 'caregiver'
);

-- Caregivers can delete their own trackers
CREATE POLICY "Caregivers can delete their trackers"
ON public.custom_trackers
FOR DELETE
USING (
  owner_id = auth.uid() AND created_by_role = 'caregiver'
);

-- Add trigger for updated_at
CREATE TRIGGER update_custom_trackers_updated_at
BEFORE UPDATE ON public.custom_trackers
FOR EACH ROW
EXECUTE FUNCTION public.handle_updated_at();