import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { usePlan } from "@/hooks/use-plan";
import { History, ChevronDown, ChevronUp, Lock, Pill, HeartPulse, Heart, Trash2 } from "lucide-react";
import { format, parseISO, subDays } from "date-fns";
import { useToast } from "@/hooks/use-toast";

interface TrackerHistoryProps {
  userId: string;
  userRole: "senior" | "caregiver";
  seniorId: string;
  seniorName?: string;
}

interface DoseRow {
  id: string;
  medication_name: string;
  scheduled_time: string | null;
  dosage: string | null;
  taken_at: string;
  taken_by: string;
  taken_by_role: string;
  notes: string | null;
  deleted_at: string | null;
}

interface ReadingRow {
  id: string;
  reading_type: string;
  systolic: number | null;
  diastolic: number | null;
  bpm: number | null;
  recorded_at: string;
  recorded_by: string;
  created_by_role: string;
  notes: string | null;
  deleted_at: string | null;
}

const FREE_DAYS = 30;

export const TrackerHistory = ({ userId, userRole, seniorId, seniorName }: TrackerHistoryProps) => {
  const { toast } = useToast();
  const { plan, isPremium } = usePlan(userId);
  const [open, setOpen] = useState(true);
  const [doses, setDoses] = useState<DoseRow[]>([]);
  const [readings, setReadings] = useState<ReadingRow[]>([]);

  const fetchHistory = async () => {
    if (!plan) return;
    const cutoff = subDays(new Date(), FREE_DAYS).toISOString();

    let doseQuery = supabase
      .from("medication_doses")
      .select("*")
      .eq("senior_id", seniorId)
      .order("taken_at", { ascending: false })
      .limit(isPremium ? 2000 : 200);

    let readingQuery = supabase
      .from("vital_readings")
      .select("*")
      .eq("senior_id", seniorId)
      .order("recorded_at", { ascending: false })
      .limit(isPremium ? 2000 : 200);

    if (!isPremium) {
      doseQuery = doseQuery.gte("taken_at", cutoff);
      readingQuery = readingQuery.gte("recorded_at", cutoff);
    }

    const [{ data: doseData, error: doseError }, { data: readingData, error: readingError }] =
      await Promise.all([doseQuery, readingQuery]);

    if (doseError) console.error("Error fetching dose history:", doseError);
    if (readingError) console.error("Error fetching reading history:", readingError);

    setDoses((doseData || []) as DoseRow[]);
    setReadings((readingData || []) as ReadingRow[]);
  };

  useEffect(() => {
    fetchHistory();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [seniorId, plan]);

  const deleteDose = async (id: string) => {
    // Soft delete keeps the record visible in history, marked as removed.
    const { error } = await supabase
      .from("medication_doses")
      .update({ deleted_at: new Date().toISOString() })
      .eq("id", id);
    if (error) {
      console.error("Error deleting dose:", error);
      toast({ title: "Error", description: "Could not remove that record.", variant: "destructive" });
      return;
    }
    toast({ title: "Marked as removed", description: "The record stays in history for your records." });
    fetchHistory();
  };

  const bp = readings.filter((r) => r.reading_type === "blood_pressure");
  const hr = readings.filter((r) => r.reading_type === "heart_rate");

  const emptyText = (what: string) =>
    isPremium
      ? `No ${what} recorded yet.`
      : `No ${what} recorded in the last ${FREE_DAYS} days.`;

  return (
    <Card className="rounded-xl border bg-card p-4 shadow-sm sm:p-5">
      <Button
        type="button"
        variant="ghost"
        onClick={() => {
          setOpen((o) => !o);
          fetchHistory();
        }}
        className="h-auto w-full justify-between px-0 text-left hover:bg-transparent"
      >
        <h2 className="flex items-center gap-3 text-xl font-bold sm:text-2xl">
          <span className="flex h-11 w-11 items-center justify-center rounded-full bg-dashboard-sky text-primary"><History className="h-6 w-6" /></span>
          Tracker History
          <Badge variant="secondary" className="ml-1">{doses.length + readings.length}</Badge>
        </h2>
        {open ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
      </Button>

      {open && (
        <div className="mt-4">
          <p className="text-sm text-muted-foreground mb-3">
            {isPremium
              ? "Premium: showing your complete history, including records you removed."
              : `Free plan: showing the last ${FREE_DAYS} days, including records you removed.`}
          </p>

          <Tabs defaultValue="meds">
            <TabsList className="mb-3 grid h-auto w-full grid-cols-3 bg-dashboard-sky/60 p-1">
              <TabsTrigger value="meds" className="gap-2">
                <Pill className="w-4 h-4" /> Medications
              </TabsTrigger>
              <TabsTrigger value="bp" className="gap-2">
                <HeartPulse className="w-4 h-4" /> Blood Pressure
              </TabsTrigger>
              <TabsTrigger value="hr" className="gap-2">
                <Heart className="w-4 h-4" /> Heart Rate
              </TabsTrigger>
            </TabsList>

            <TabsContent value="meds">
              <div className="space-y-2 max-h-[420px] overflow-y-auto">
                {doses.length === 0 ? (
                  <p className="text-muted-foreground text-base py-4 text-center">{emptyText("doses")}</p>
                ) : (
                  doses.map((d) => (
                    <div key={d.id} className="flex items-start justify-between gap-3 border-t px-1 py-3 first:border-t-0">
                      <div>
                        <p className="text-lg font-medium">
                          {d.medication_name}
                          {d.dosage ? <span className="text-muted-foreground text-base"> · {d.dosage}</span> : null}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          Taken {format(parseISO(d.taken_at), "EEE, MMM d, yyyy 'at' h:mm a")}
                          {d.scheduled_time ? ` · scheduled ${d.scheduled_time}` : ""}
                          {d.taken_by_role === "caregiver" ? " · marked by caregiver" : ""}
                        </p>
                        {d.deleted_at && (
                          <Badge variant="outline" className="mt-1">Removed {format(parseISO(d.deleted_at), "MMM d")}</Badge>
                        )}
                        {d.notes && <p className="text-sm text-foreground/80 mt-1">{d.notes}</p>}
                      </div>
                      {!d.deleted_at && (
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-destructive hover:text-destructive"
                          onClick={() => deleteDose(d.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  ))
                )}
              </div>
            </TabsContent>

            <TabsContent value="bp">
              <div className="space-y-2 max-h-[420px] overflow-y-auto">
                {bp.length === 0 ? (
                  <p className="text-muted-foreground text-base py-4 text-center">{emptyText("blood pressure readings")}</p>
                ) : (
                  bp.map((r) => (
                    <div key={r.id} className="border-t px-1 py-3 first:border-t-0">
                      <p className="text-lg font-medium">{r.systolic}/{r.diastolic}</p>
                      <p className="text-sm text-muted-foreground">
                        {format(parseISO(r.recorded_at), "EEE, MMM d, yyyy 'at' h:mm a")}
                        {r.created_by_role === "caregiver" ? " · added by caregiver" : ""}
                      </p>
                      {r.deleted_at && (
                        <Badge variant="outline" className="mt-1">Removed {format(parseISO(r.deleted_at), "MMM d")}</Badge>
                      )}
                      {r.notes && <p className="text-sm text-foreground/80 mt-1">{r.notes}</p>}
                    </div>
                  ))
                )}
              </div>
            </TabsContent>

            <TabsContent value="hr">
              <div className="space-y-2 max-h-[420px] overflow-y-auto">
                {hr.length === 0 ? (
                  <p className="text-muted-foreground text-base py-4 text-center">{emptyText("heart rate readings")}</p>
                ) : (
                  hr.map((r) => (
                    <div key={r.id} className="border-t px-1 py-3 first:border-t-0">
                      <p className="text-lg font-medium">{r.bpm} bpm</p>
                      <p className="text-sm text-muted-foreground">
                        {format(parseISO(r.recorded_at), "EEE, MMM d, yyyy 'at' h:mm a")}
                        {r.created_by_role === "caregiver" ? " · added by caregiver" : ""}
                      </p>
                      {r.deleted_at && (
                        <Badge variant="outline" className="mt-1">Removed {format(parseISO(r.deleted_at), "MMM d")}</Badge>
                      )}
                      {r.notes && <p className="text-sm text-foreground/80 mt-1">{r.notes}</p>}
                    </div>
                  ))
                )}
              </div>
            </TabsContent>
          </Tabs>

          {!isPremium && (
            <div className="mt-4 p-4 rounded-lg border bg-muted/30 flex items-start gap-3">
              <Lock className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
              <div>
                <p className="font-medium text-sm">Free plan: last {FREE_DAYS} days shown</p>
                <p className="text-sm text-muted-foreground">
                  Upgrade to Premium to see the complete medication and reading history. Nothing is deleted — older
                  records unlock as soon as you upgrade.
                </p>
              </div>
            </div>
          )}
        </div>
      )}
    </Card>
  );
};

export default TrackerHistory;
