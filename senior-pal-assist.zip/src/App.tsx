import { RoleGuard } from "@/components/RoleGuard";
import React from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Landing from "./pages/Landing";
import NativeStart from "./pages/NativeStart";
import { NativeBridge } from "./components/NativeBridge";
import { isNativeApp } from "./lib/native";
import Dashboard from "./pages/Dashboard";
import Auth from "./pages/Auth";
import ResetPassword from "./pages/ResetPassword";
import CaregiverDashboard from "./pages/CaregiverDashboard";
import PrivacyPolicy from "./pages/PrivacyPolicy";
import TermsOfService from "./pages/TermsOfService";
import Contact from "./pages/Contact";
import FAQ from "./pages/FAQ";
import ResourcesPage from "./pages/Resources";
import SharedReport from "./pages/SharedReport";
import Settings from "./pages/Settings";
import SeniorProfile from "./pages/SeniorProfile";
import CaregiverProfile from "./pages/CaregiverProfile";
import Pricing from "./pages/Pricing";
import NotFound from "./pages/NotFound";
import ScrollToTop from "./components/ScrollToTop";
import CookieConsent from "./components/CookieConsent";
import JoinCircle from "./pages/JoinCircle";
import DeleteAccount from "./pages/DeleteAccount";
import { SosAlarm } from "./components/SosAlarm";
import { useMobileScrollbar } from "./hooks/use-mobile-scrollbar";

const queryClient = new QueryClient();

const AppContent = () => {
  useMobileScrollbar();
  return null;
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AppContent />
        <NativeBridge />
        <ScrollToTop />

        <Routes>
          <Route path="/" element={isNativeApp() ? <NativeStart /> : <Landing />} />
          <Route path="/auth" element={<Auth />} />
          <Route path="/reset-password" element={<ResetPassword />} />
          <Route path="/dashboard" element={<RoleGuard role="senior"><Dashboard /></RoleGuard>} />
          <Route path="/caregiver" element={<RoleGuard role="caregiver"><CaregiverDashboard /></RoleGuard>} />
          <Route path="/delete-account" element={<DeleteAccount />} />
          <Route path="/privacy-policy" element={<PrivacyPolicy />} />
          <Route path="/terms-of-service" element={<TermsOfService />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/faq" element={<FAQ />} />
          <Route path="/resources" element={<ResourcesPage />} />
          <Route path="/share/:token" element={<SharedReport />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/senior-profile/:seniorId" element={<SeniorProfile />} />
          <Route path="/caregiver-profile" element={<RoleGuard role="caregiver"><CaregiverProfile /></RoleGuard>} />
          <Route path="/pricing" element={<Pricing />} />
          <Route path="/join" element={<JoinCircle />} />
          <Route path="/join/:code" element={<JoinCircle />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
        <SosAlarm />
        <CookieConsent />
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
