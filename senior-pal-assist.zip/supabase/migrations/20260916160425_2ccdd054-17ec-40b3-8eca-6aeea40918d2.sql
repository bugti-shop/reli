REVOKE ALL ON FUNCTION public.protect_profile_role_plan() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.handle_updated_at() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.enforce_senior_limit() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.validate_tracker_reminder() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;