import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface AddReminderDialogProps {
  userId: string;
  onReminderAdded: () => void;
}

export const AddReminderDialog = ({ userId, onReminderAdded }: AddReminderDialogProps) => {
  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState("");
  const [reminderTime, setReminderTime] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!message.trim() || !reminderTime) {
      toast({
        title: "Missing Information",
        description: "Please enter a reminder message and time.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    
    const { error } = await supabase.from("senior_reminders").insert({
      senior_id: userId,
      message: message.trim(),
      reminder_time: new Date(reminderTime).toISOString(),
    });

    setIsSubmitting(false);

    if (error) {
      console.error("Error creating reminder:", error);
      toast({
        title: "Error",
        description: "Could not create reminder. Please try again.",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Reminder Created",
      description: "Your reminder has been added.",
    });

    setMessage("");
    setReminderTime("");
    setOpen(false);
    onReminderAdded();
  };

  // Get minimum datetime (now)
  const getMinDateTime = () => {
    const now = new Date();
    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    return now.toISOString().slice(0, 16);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="lg" className="h-14 text-lg">
          <Plus className="w-5 h-5 mr-2" />
          Add Reminder
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl">Add a Reminder</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6 mt-4">
          <div className="space-y-2">
            <Label htmlFor="message" className="text-lg">What do you want to remember?</Label>
            <Input
              id="message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="e.g., Take medication, Call doctor..."
              className="text-lg h-12"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="time" className="text-lg">When?</Label>
            <Input
              id="time"
              type="datetime-local"
              value={reminderTime}
              onChange={(e) => setReminderTime(e.target.value)}
              min={getMinDateTime()}
              className="text-lg h-12"
            />
          </div>
          <Button type="submit" className="w-full h-14 text-lg" disabled={isSubmitting}>
            {isSubmitting ? "Creating..." : "Create Reminder"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
};
