import { useCallback, useEffect, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Users } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

const JoinCircle = () => {
  const { code: codeParam } = useParams();
  const navigate = useNavigate();
  const [code, setCode] = useState(codeParam ?? "");
  const [signedIn, setSignedIn] = useState<boolean | null>(null);
  const [status, setStatus] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const attempted = useRef(false);
  const { toast } = useToast();

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setSignedIn(Boolean(data.user)));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => setSignedIn(Boolean(session?.user)));
    if (codeParam) localStorage.setItem("reli-pending-invite", codeParam);
    return () => listener.subscription.unsubscribe();
  }, [codeParam]);

  const join = useCallback(async () => {
    setBusy(true);
    setStatus(null);
    const normalizedCode = code.trim().toUpperCase();
    const { error: requestError } = await supabase.rpc("request_circle_invite", { _code: normalizedCode });
    if (!requestError) {
      setBusy(false);
      localStorage.removeItem("reli-pending-invite");
      setStatus("Your request was sent. A caregiver will approve you before any information is shared.");
      toast({ title: "Request sent", description: "You’ll get access after a caregiver approves you." });
      return;
    }
    if (!requestError.message.includes("standard code flow")) {
      setBusy(false);
      setStatus(requestError.message);
      return;
    }
    const { error } = await supabase.rpc("accept_circle_invite", { _code: normalizedCode });
    setBusy(false);
    if (error) {
      const msg = error.message.includes("LIMIT_REACHED")
        ? "This circle is full on the free plan. Premium allows more family members."
        : error.message;
      return setStatus(msg);
    }
    localStorage.removeItem("reli-pending-invite");
    toast({ title: "You're connected", description: "You can now follow your loved one in Reli." });
    navigate("/caregiver");
  }, [code, navigate, toast]);

  useEffect(() => {
    if (signedIn && code.trim().length >= 6 && !attempted.current) {
      attempted.current = true;
      join();
    }
  }, [signedIn, code, join]);

  return (
    <main className="flex min-h-screen items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md space-y-4 p-6 text-center">
        <Users className="mx-auto h-10 w-10 text-primary" />
        <h1 className="text-2xl font-bold">Join as a caregiver</h1>
        <p className="text-muted-foreground">
          You'll get SOS alarms and can follow your loved one's health and activity.
        </p>
        <Input value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} placeholder="Invite code" className="text-center text-xl tracking-widest" maxLength={12} />
        {signedIn === false ? (
          <div className="space-y-2">
            <p className="text-sm">Every family member needs their own Reli account. Create a free <b>Caregiver / Family</b> account with the <b>same email the invite was sent to</b> (or sign in) — you'll come right back here.</p>
            <Button className="w-full" onClick={() => navigate("/auth?role=caregiver")}>Sign up or sign in</Button>
          </div>
        ) : status?.startsWith("Your request was sent") ? (
          <Button className="w-full" onClick={() => navigate("/")}>Done</Button>
        ) : (
          <Button className="w-full" disabled={busy || code.trim().length < 6} onClick={join}>{busy ? "Sending request…" : "Join circle"}</Button>
        )}
        {status && <p className={`text-sm ${status.startsWith("Your request was sent") ? "text-muted-foreground" : "text-destructive"}`}>{status}</p>}
      </Card>
    </main>
  );
};

export default JoinCircle;
