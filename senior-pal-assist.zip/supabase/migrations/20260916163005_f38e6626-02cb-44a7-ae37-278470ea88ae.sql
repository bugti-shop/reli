ALTER TABLE public.tracker_reminders
  ADD COLUMN IF NOT EXISTS days_of_week smallint[] NOT NULL DEFAULT '{0,1,2,3,4,5,6}';

ALTER TABLE public.medications
  ADD COLUMN IF NOT EXISTS days_of_week smallint[] NOT NULL DEFAULT '{0,1,2,3,4,5,6}';