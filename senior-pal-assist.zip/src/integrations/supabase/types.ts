export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      account_deletion_codes: {
        Row: {
          attempts: number
          code_hash: string
          created_at: string
          email: string
          expires_at: string
          id: string
          used_at: string | null
        }
        Insert: {
          attempts?: number
          code_hash: string
          created_at?: string
          email: string
          expires_at: string
          id?: string
          used_at?: string | null
        }
        Update: {
          attempts?: number
          code_hash?: string
          created_at?: string
          email?: string
          expires_at?: string
          id?: string
          used_at?: string | null
        }
        Relationships: []
      }
      calendar_events: {
        Row: {
          completed: boolean
          completed_at: string | null
          created_at: string
          created_by_role: string
          event_date: string
          event_time: string | null
          event_type: string
          id: string
          notes: string | null
          owner_id: string
          senior_id: string
          title: string
          updated_at: string
        }
        Insert: {
          completed?: boolean
          completed_at?: string | null
          created_at?: string
          created_by_role?: string
          event_date: string
          event_time?: string | null
          event_type?: string
          id?: string
          notes?: string | null
          owner_id: string
          senior_id: string
          title: string
          updated_at?: string
        }
        Update: {
          completed?: boolean
          completed_at?: string | null
          created_at?: string
          created_by_role?: string
          event_date?: string
          event_time?: string | null
          event_type?: string
          id?: string
          notes?: string | null
          owner_id?: string
          senior_id?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "calendar_events_senior_id_fkey"
            columns: ["senior_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      care_observations: {
        Row: {
          caregiver_id: string
          category: string
          created_at: string
          environment: string[]
          id: string
          intensity: number | null
          label: string
          location: string | null
          notes: string | null
          observed_at: string
          senior_id: string
          value_num: number | null
        }
        Insert: {
          caregiver_id?: string
          category: string
          created_at?: string
          environment?: string[]
          id?: string
          intensity?: number | null
          label: string
          location?: string | null
          notes?: string | null
          observed_at?: string
          senior_id: string
          value_num?: number | null
        }
        Update: {
          caregiver_id?: string
          category?: string
          created_at?: string
          environment?: string[]
          id?: string
          intensity?: number | null
          label?: string
          location?: string | null
          notes?: string | null
          observed_at?: string
          senior_id?: string
          value_num?: number | null
        }
        Relationships: []
      }
      caregiver_daily_logs: {
        Row: {
          ate_well: boolean | null
          caregiver_id: string
          confusion_noted: boolean | null
          created_at: string
          had_fall: boolean | null
          id: string
          log_date: string
          mood: string | null
          notes: string | null
          senior_id: string
          slept_well: boolean | null
          took_medications: boolean | null
          updated_at: string
        }
        Insert: {
          ate_well?: boolean | null
          caregiver_id: string
          confusion_noted?: boolean | null
          created_at?: string
          had_fall?: boolean | null
          id?: string
          log_date?: string
          mood?: string | null
          notes?: string | null
          senior_id: string
          slept_well?: boolean | null
          took_medications?: boolean | null
          updated_at?: string
        }
        Update: {
          ate_well?: boolean | null
          caregiver_id?: string
          confusion_noted?: boolean | null
          created_at?: string
          had_fall?: boolean | null
          id?: string
          log_date?: string
          mood?: string | null
          notes?: string | null
          senior_id?: string
          slept_well?: boolean | null
          took_medications?: boolean | null
          updated_at?: string
        }
        Relationships: []
      }
      caregiver_messages: {
        Row: {
          caregiver_id: string
          created_at: string | null
          id: string
          is_reminder: boolean | null
          message: string
          read: boolean | null
          reminder_time: string | null
          sender_role: string
          senior_id: string
        }
        Insert: {
          caregiver_id: string
          created_at?: string | null
          id?: string
          is_reminder?: boolean | null
          message: string
          read?: boolean | null
          reminder_time?: string | null
          sender_role?: string
          senior_id: string
        }
        Update: {
          caregiver_id?: string
          created_at?: string | null
          id?: string
          is_reminder?: boolean | null
          message?: string
          read?: boolean | null
          reminder_time?: string | null
          sender_role?: string
          senior_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "caregiver_messages_caregiver_id_fkey"
            columns: ["caregiver_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "caregiver_messages_senior_id_fkey"
            columns: ["senior_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      caregiver_seniors: {
        Row: {
          caregiver_id: string
          created_at: string | null
          id: string
          relationship: string
          senior_id: string
        }
        Insert: {
          caregiver_id: string
          created_at?: string | null
          id?: string
          relationship?: string
          senior_id: string
        }
        Update: {
          caregiver_id?: string
          created_at?: string | null
          id?: string
          relationship?: string
          senior_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "caregiver_seniors_caregiver_id_fkey"
            columns: ["caregiver_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "caregiver_seniors_senior_id_fkey"
            columns: ["senior_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      circle_invites: {
        Row: {
          approved_at: string | null
          code: string
          created_at: string
          created_by: string
          declined_at: string | null
          expires_at: string
          id: string
          invitee_email: string | null
          relationship: string
          requested_at: string | null
          senior_id: string
          used_at: string | null
          used_by: string | null
        }
        Insert: {
          approved_at?: string | null
          code?: string
          created_at?: string
          created_by: string
          declined_at?: string | null
          expires_at?: string
          id?: string
          invitee_email?: string | null
          relationship?: string
          requested_at?: string | null
          senior_id: string
          used_at?: string | null
          used_by?: string | null
        }
        Update: {
          approved_at?: string | null
          code?: string
          created_at?: string
          created_by?: string
          declined_at?: string | null
          expires_at?: string
          id?: string
          invitee_email?: string | null
          relationship?: string
          requested_at?: string | null
          senior_id?: string
          used_at?: string | null
          used_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "circle_invites_senior_id_fkey"
            columns: ["senior_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      custom_trackers: {
        Row: {
          completed: boolean
          completed_at: string | null
          created_at: string
          created_by_role: string
          id: string
          name: string
          owner_id: string
          senior_id: string
          shared_with_senior: boolean
          tracker_type: string
          updated_at: string
          value: string | null
        }
        Insert: {
          completed?: boolean
          completed_at?: string | null
          created_at?: string
          created_by_role: string
          id?: string
          name: string
          owner_id: string
          senior_id: string
          shared_with_senior?: boolean
          tracker_type?: string
          updated_at?: string
          value?: string | null
        }
        Update: {
          completed?: boolean
          completed_at?: string | null
          created_at?: string
          created_by_role?: string
          id?: string
          name?: string
          owner_id?: string
          senior_id?: string
          shared_with_senior?: boolean
          tracker_type?: string
          updated_at?: string
          value?: string | null
        }
        Relationships: []
      }
      doctor_questions: {
        Row: {
          answer: string | null
          asked: boolean
          asked_at: string | null
          created_at: string
          created_by_role: string
          id: string
          owner_id: string
          question: string
          senior_id: string
          updated_at: string
        }
        Insert: {
          answer?: string | null
          asked?: boolean
          asked_at?: string | null
          created_at?: string
          created_by_role?: string
          id?: string
          owner_id: string
          question: string
          senior_id: string
          updated_at?: string
        }
        Update: {
          answer?: string | null
          asked?: boolean
          asked_at?: string | null
          created_at?: string
          created_by_role?: string
          id?: string
          owner_id?: string
          question?: string
          senior_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      emergency_alerts: {
        Row: {
          accuracy_m: number | null
          acknowledged: boolean
          acknowledged_at: string | null
          acknowledged_by: string | null
          cancelled_at: string | null
          cancelled_by: string | null
          client_request_id: string | null
          created_at: string
          id: string
          latitude: number | null
          location_captured_at: string | null
          longitude: number | null
          message: string | null
          resolved_at: string | null
          resolved_by: string | null
          senior_id: string
          status: string
          updated_at: string
        }
        Insert: {
          accuracy_m?: number | null
          acknowledged?: boolean
          acknowledged_at?: string | null
          acknowledged_by?: string | null
          cancelled_at?: string | null
          cancelled_by?: string | null
          client_request_id?: string | null
          created_at?: string
          id?: string
          latitude?: number | null
          location_captured_at?: string | null
          longitude?: number | null
          message?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          senior_id: string
          status?: string
          updated_at?: string
        }
        Update: {
          accuracy_m?: number | null
          acknowledged?: boolean
          acknowledged_at?: string | null
          acknowledged_by?: string | null
          cancelled_at?: string | null
          cancelled_by?: string | null
          client_request_id?: string | null
          created_at?: string
          id?: string
          latitude?: number | null
          location_captured_at?: string | null
          longitude?: number | null
          message?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          senior_id?: string
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      journal_entries: {
        Row: {
          content: string
          created_at: string
          entry_date: string
          id: string
          mood: string | null
          senior_id: string
          title: string | null
          updated_at: string
        }
        Insert: {
          content: string
          created_at?: string
          entry_date?: string
          id?: string
          mood?: string | null
          senior_id: string
          title?: string | null
          updated_at?: string
        }
        Update: {
          content?: string
          created_at?: string
          entry_date?: string
          id?: string
          mood?: string | null
          senior_id?: string
          title?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      life_story_entries: {
        Row: {
          created_at: string
          id: string
          image_path: string | null
          prompt: string
          prompt_date: string
          response: string | null
          senior_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          image_path?: string | null
          prompt: string
          prompt_date?: string
          response?: string | null
          senior_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          image_path?: string | null
          prompt?: string
          prompt_date?: string
          response?: string | null
          senior_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      life_story_memories: {
        Row: {
          category: string
          created_at: string
          details: Json
          id: string
          image_path: string | null
          senior_id: string
          updated_at: string
        }
        Insert: {
          category: string
          created_at?: string
          details?: Json
          id?: string
          image_path?: string | null
          senior_id: string
          updated_at?: string
        }
        Update: {
          category?: string
          created_at?: string
          details?: Json
          id?: string
          image_path?: string | null
          senior_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      medication_doses: {
        Row: {
          created_at: string
          deleted_at: string | null
          dosage: string | null
          id: string
          medication_id: string | null
          medication_name: string
          notes: string | null
          scheduled_time: string | null
          senior_id: string
          taken_at: string
          taken_by: string
          taken_by_role: string
        }
        Insert: {
          created_at?: string
          deleted_at?: string | null
          dosage?: string | null
          id?: string
          medication_id?: string | null
          medication_name: string
          notes?: string | null
          scheduled_time?: string | null
          senior_id: string
          taken_at?: string
          taken_by: string
          taken_by_role: string
        }
        Update: {
          created_at?: string
          deleted_at?: string | null
          dosage?: string | null
          id?: string
          medication_id?: string | null
          medication_name?: string
          notes?: string | null
          scheduled_time?: string | null
          senior_id?: string
          taken_at?: string
          taken_by?: string
          taken_by_role?: string
        }
        Relationships: [
          {
            foreignKeyName: "medication_doses_medication_id_fkey"
            columns: ["medication_id"]
            isOneToOne: false
            referencedRelation: "medications"
            referencedColumns: ["id"]
          },
        ]
      }
      medications: {
        Row: {
          completed: boolean
          completed_at: string | null
          created_at: string
          created_by_role: string
          days_of_week: number[]
          dosage: string | null
          id: string
          name: string
          notes: string | null
          owner_id: string
          senior_id: string
          time: string
          updated_at: string
        }
        Insert: {
          completed?: boolean
          completed_at?: string | null
          created_at?: string
          created_by_role: string
          days_of_week?: number[]
          dosage?: string | null
          id?: string
          name: string
          notes?: string | null
          owner_id: string
          senior_id: string
          time: string
          updated_at?: string
        }
        Update: {
          completed?: boolean
          completed_at?: string | null
          created_at?: string
          created_by_role?: string
          days_of_week?: number[]
          dosage?: string | null
          id?: string
          name?: string
          notes?: string | null
          owner_id?: string
          senior_id?: string
          time?: string
          updated_at?: string
        }
        Relationships: []
      }
      newsletter_subscribers: {
        Row: {
          email: string
          id: string
          is_active: boolean
          subscribed_at: string
          unsubscribed_at: string | null
        }
        Insert: {
          email: string
          id?: string
          is_active?: boolean
          subscribed_at?: string
          unsubscribed_at?: string | null
        }
        Update: {
          email?: string
          id?: string
          is_active?: boolean
          subscribed_at?: string
          unsubscribed_at?: string | null
        }
        Relationships: []
      }
      notification_preferences: {
        Row: {
          created_at: string
          daily_summary_time: string
          daily_summary_timezone: string
          email: string | null
          email_enabled: boolean
          id: string
          notify_daily_summary: boolean
          notify_emergency: boolean
          notify_messages: boolean
          notify_reminders: boolean
          phone: string | null
          push_enabled: boolean
          sms_enabled: boolean
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          daily_summary_time?: string
          daily_summary_timezone?: string
          email?: string | null
          email_enabled?: boolean
          id?: string
          notify_daily_summary?: boolean
          notify_emergency?: boolean
          notify_messages?: boolean
          notify_reminders?: boolean
          phone?: string | null
          push_enabled?: boolean
          sms_enabled?: boolean
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          daily_summary_time?: string
          daily_summary_timezone?: string
          email?: string | null
          email_enabled?: boolean
          id?: string
          notify_daily_summary?: boolean
          notify_emergency?: boolean
          notify_messages?: boolean
          notify_reminders?: boolean
          phone?: string | null
          push_enabled?: boolean
          sms_enabled?: boolean
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          address: string | null
          age: number | null
          created_at: string | null
          email: string
          emergency_contacts: Json
          full_name: string | null
          id: string
          managed: boolean
          managed_by: string | null
          phone: string | null
          plan: Database["public"]["Enums"]["user_plan"]
          role: Database["public"]["Enums"]["app_role"]
          updated_at: string | null
        }
        Insert: {
          address?: string | null
          age?: number | null
          created_at?: string | null
          email: string
          emergency_contacts?: Json
          full_name?: string | null
          id: string
          managed?: boolean
          managed_by?: string | null
          phone?: string | null
          plan?: Database["public"]["Enums"]["user_plan"]
          role?: Database["public"]["Enums"]["app_role"]
          updated_at?: string | null
        }
        Update: {
          address?: string | null
          age?: number | null
          created_at?: string | null
          email?: string
          emergency_contacts?: Json
          full_name?: string | null
          id?: string
          managed?: boolean
          managed_by?: string | null
          phone?: string | null
          plan?: Database["public"]["Enums"]["user_plan"]
          role?: Database["public"]["Enums"]["app_role"]
          updated_at?: string | null
        }
        Relationships: []
      }
      push_tokens: {
        Row: {
          created_at: string
          id: string
          platform: string
          token: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          platform?: string
          token: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          platform?: string
          token?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      senior_activity_log: {
        Row: {
          activity_description: string
          activity_type: string
          actor_id: string | null
          actor_role: string | null
          created_at: string | null
          event_id: string | null
          feature: string
          id: string
          metadata: Json
          occurred_at: string
          senior_id: string
          status: string
        }
        Insert: {
          activity_description: string
          activity_type: string
          actor_id?: string | null
          actor_role?: string | null
          created_at?: string | null
          event_id?: string | null
          feature?: string
          id?: string
          metadata?: Json
          occurred_at?: string
          senior_id: string
          status?: string
        }
        Update: {
          activity_description?: string
          activity_type?: string
          actor_id?: string | null
          actor_role?: string | null
          created_at?: string | null
          event_id?: string | null
          feature?: string
          id?: string
          metadata?: Json
          occurred_at?: string
          senior_id?: string
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "senior_activity_log_senior_id_fkey"
            columns: ["senior_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      senior_feature_settings: {
        Row: {
          caregiver_id: string
          created_at: string
          id: string
          senior_id: string
          show_activity_tracker: boolean
          show_ai_companion: boolean
          show_doctor_report: boolean
          show_life_story: boolean
          show_medication_tracker: boolean
          show_trivia: boolean
          updated_at: string
        }
        Insert: {
          caregiver_id: string
          created_at?: string
          id?: string
          senior_id: string
          show_activity_tracker?: boolean
          show_ai_companion?: boolean
          show_doctor_report?: boolean
          show_life_story?: boolean
          show_medication_tracker?: boolean
          show_trivia?: boolean
          updated_at?: string
        }
        Update: {
          caregiver_id?: string
          created_at?: string
          id?: string
          senior_id?: string
          show_activity_tracker?: boolean
          show_ai_companion?: boolean
          show_doctor_report?: boolean
          show_life_story?: boolean
          show_medication_tracker?: boolean
          show_trivia?: boolean
          updated_at?: string
        }
        Relationships: []
      }
      senior_reminders: {
        Row: {
          completed: boolean
          created_at: string
          id: string
          message: string
          reminder_time: string
          senior_id: string
        }
        Insert: {
          completed?: boolean
          created_at?: string
          id?: string
          message: string
          reminder_time: string
          senior_id: string
        }
        Update: {
          completed?: boolean
          created_at?: string
          id?: string
          message?: string
          reminder_time?: string
          senior_id?: string
        }
        Relationships: []
      }
      shared_reports: {
        Row: {
          created_at: string
          created_by_role: string
          date_range_days: number
          expires_at: string
          id: string
          include_activity: boolean
          include_medications: boolean
          include_wellness: boolean
          notes: string | null
          owner_id: string
          recipient_name: string | null
          revoked: boolean
          senior_id: string
          share_token: string
          title: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by_role: string
          date_range_days?: number
          expires_at?: string
          id?: string
          include_activity?: boolean
          include_medications?: boolean
          include_wellness?: boolean
          notes?: string | null
          owner_id: string
          recipient_name?: string | null
          revoked?: boolean
          senior_id: string
          share_token?: string
          title?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by_role?: string
          date_range_days?: number
          expires_at?: string
          id?: string
          include_activity?: boolean
          include_medications?: boolean
          include_wellness?: boolean
          notes?: string | null
          owner_id?: string
          recipient_name?: string | null
          revoked?: boolean
          senior_id?: string
          share_token?: string
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      site_admins: {
        Row: {
          created_at: string | null
          id: string
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          user_id?: string
        }
        Relationships: []
      }
      sos_acknowledgements: {
        Row: {
          acknowledged_at: string
          alert_id: string
          caregiver_id: string
          id: string
        }
        Insert: {
          acknowledged_at?: string
          alert_id: string
          caregiver_id: string
          id?: string
        }
        Update: {
          acknowledged_at?: string
          alert_id?: string
          caregiver_id?: string
          id?: string
        }
        Relationships: [
          {
            foreignKeyName: "sos_acknowledgements_alert_id_fkey"
            columns: ["alert_id"]
            isOneToOne: false
            referencedRelation: "emergency_alerts"
            referencedColumns: ["id"]
          },
        ]
      }
      sos_deliveries: {
        Row: {
          alert_id: string
          attempts: number
          caregiver_id: string
          created_at: string
          delivered_at: string | null
          devices_reached: number
          id: string
          kind: string
          last_attempt_at: string | null
          last_error: string | null
          status: string
        }
        Insert: {
          alert_id: string
          attempts?: number
          caregiver_id: string
          created_at?: string
          delivered_at?: string | null
          devices_reached?: number
          id?: string
          kind?: string
          last_attempt_at?: string | null
          last_error?: string | null
          status?: string
        }
        Update: {
          alert_id?: string
          attempts?: number
          caregiver_id?: string
          created_at?: string
          delivered_at?: string | null
          devices_reached?: number
          id?: string
          kind?: string
          last_attempt_at?: string | null
          last_error?: string | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "sos_deliveries_alert_id_fkey"
            columns: ["alert_id"]
            isOneToOne: false
            referencedRelation: "emergency_alerts"
            referencedColumns: ["id"]
          },
        ]
      }
      sos_location_updates: {
        Row: {
          accuracy_m: number | null
          alert_id: string
          captured_at: string
          created_at: string
          id: string
          latitude: number
          longitude: number
        }
        Insert: {
          accuracy_m?: number | null
          alert_id: string
          captured_at: string
          created_at?: string
          id?: string
          latitude: number
          longitude: number
        }
        Update: {
          accuracy_m?: number | null
          alert_id?: string
          captured_at?: string
          created_at?: string
          id?: string
          latitude?: number
          longitude?: number
        }
        Relationships: [
          {
            foreignKeyName: "sos_location_updates_alert_id_fkey"
            columns: ["alert_id"]
            isOneToOne: false
            referencedRelation: "emergency_alerts"
            referencedColumns: ["id"]
          },
        ]
      }
      store_entitlements: {
        Row: {
          active: boolean
          expires_at: string | null
          last_event_id: string | null
          product_id: string | null
          store: string
          updated_at: string
          user_id: string
        }
        Insert: {
          active?: boolean
          expires_at?: string | null
          last_event_id?: string | null
          product_id?: string | null
          store: string
          updated_at?: string
          user_id: string
        }
        Update: {
          active?: boolean
          expires_at?: string | null
          last_event_id?: string | null
          product_id?: string | null
          store?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      tracker_reminders: {
        Row: {
          created_at: string
          created_by_role: string
          days_of_week: number[]
          enabled: boolean
          id: string
          kind: string
          label: string | null
          owner_id: string
          senior_id: string
          time: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by_role: string
          days_of_week?: number[]
          enabled?: boolean
          id?: string
          kind: string
          label?: string | null
          owner_id: string
          senior_id: string
          time: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by_role?: string
          days_of_week?: number[]
          enabled?: boolean
          id?: string
          kind?: string
          label?: string | null
          owner_id?: string
          senior_id?: string
          time?: string
          updated_at?: string
        }
        Relationships: []
      }
      vital_readings: {
        Row: {
          bpm: number | null
          created_at: string
          created_by_role: string
          deleted_at: string | null
          diastolic: number | null
          id: string
          notes: string | null
          reading_type: string
          recorded_at: string
          recorded_by: string
          senior_id: string
          systolic: number | null
          unit: string | null
          updated_at: string
          value: number | null
        }
        Insert: {
          bpm?: number | null
          created_at?: string
          created_by_role: string
          deleted_at?: string | null
          diastolic?: number | null
          id?: string
          notes?: string | null
          reading_type: string
          recorded_at?: string
          recorded_by: string
          senior_id: string
          systolic?: number | null
          unit?: string | null
          updated_at?: string
          value?: number | null
        }
        Update: {
          bpm?: number | null
          created_at?: string
          created_by_role?: string
          deleted_at?: string | null
          diastolic?: number | null
          id?: string
          notes?: string | null
          reading_type?: string
          recorded_at?: string
          recorded_by?: string
          senior_id?: string
          systolic?: number | null
          unit?: string | null
          updated_at?: string
          value?: number | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      accept_circle_invite: { Args: { _code: string }; Returns: string }
      acknowledge_sos: { Args: { _alert_id: string }; Returns: string }
      add_senior_by_email: { Args: { _email: string }; Returns: string }
      approve_circle_invite: { Args: { _invite_id: string }; Returns: string }
      cancel_circle_invite: { Args: { _invite_id: string }; Returns: undefined }
      close_sos: {
        Args: { _alert_id: string; _outcome?: string }
        Returns: string
      }
      decline_circle_invite: {
        Args: { _invite_id: string }
        Returns: undefined
      }
      has_effective_premium: { Args: { _user_id: string }; Returns: boolean }
      has_store_premium: { Args: { _user_id: string }; Returns: boolean }
      is_site_admin: { Args: { _user_id: string }; Returns: boolean }
      log_my_activity: {
        Args: {
          _desc: string
          _event_id: string
          _feature?: string
          _meta?: Json
          _status?: string
          _type: string
        }
        Returns: undefined
      }
      record_senior_activity: {
        Args: {
          _actor: string
          _at?: string
          _desc: string
          _event_id: string
          _feature: string
          _meta: Json
          _senior: string
          _status: string
          _type: string
        }
        Returns: undefined
      }
      remove_circle_member: { Args: { _link_id: string }; Returns: undefined }
      request_circle_invite: { Args: { _code: string }; Returns: string }
      trigger_sos: {
        Args: {
          _accuracy?: number
          _captured_at?: string
          _lat?: number
          _lng?: number
          _request_id: string
        }
        Returns: {
          alert_id: string
          is_new: boolean
        }[]
      }
      update_sos_location: {
        Args: {
          _accuracy?: number
          _alert_id: string
          _captured_at?: string
          _lat: number
          _lng: number
        }
        Returns: undefined
      }
    }
    Enums: {
      app_role: "senior" | "caregiver"
      user_plan: "free" | "premium"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["senior", "caregiver"],
      user_plan: ["free", "premium"],
    },
  },
} as const
