CREATE TABLE public.journal_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  senior_id uuid NOT NULL,
  entry_date date NOT NULL DEFAULT CURRENT_DATE,
  title text,
  content text NOT NULL,
  mood text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.journal_entries TO authenticated;
GRANT ALL ON public.journal_entries TO service_role;

ALTER TABLE public.journal_entries ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Seniors manage their own journal"
ON public.journal_entries FOR ALL TO authenticated
USING (auth.uid() = senior_id)
WITH CHECK (auth.uid() = senior_id);

CREATE POLICY "Linked caregivers can view senior journal"
ON public.journal_entries FOR SELECT TO authenticated
USING (EXISTS (
  SELECT 1 FROM public.caregiver_seniors cs
  WHERE cs.senior_id = journal_entries.senior_id
    AND cs.caregiver_id = auth.uid()
));

CREATE INDEX idx_journal_entries_senior_date ON public.journal_entries (senior_id, entry_date DESC);

CREATE TRIGGER update_journal_entries_updated_at
BEFORE UPDATE ON public.journal_entries
FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();