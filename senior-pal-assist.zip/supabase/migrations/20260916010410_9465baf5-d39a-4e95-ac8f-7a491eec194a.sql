CREATE POLICY "Seniors can delete their messages"
ON public.caregiver_messages
FOR DELETE
TO authenticated
USING (senior_id = auth.uid());