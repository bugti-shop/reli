import type { CapacitorConfig } from '@capacitor/cli';

// Production builds load the bundled app from `dist`. Set CAP_LIVE_RELOAD=1
// while developing to load the Lovable preview instead (never ship this).
const liveReload = process.env.CAP_LIVE_RELOAD === '1';

const config: CapacitorConfig = {
  appId: 'com.reli.care',
  appName: 'Reli',
  webDir: 'dist',
  ...(liveReload
    ? {
        server: {
          url: 'https://1b7db766-f4d9-4f96-a0bc-d09948773d32.lovableproject.com?forceHideBadge=true',
          cleartext: true,
        },
      }
    : {}),
  android: { allowMixedContent: false },
  ios: { contentInset: 'automatic' },
  plugins: {
    SplashScreen: { launchShowDuration: 800, backgroundColor: '#427EB3', showSpinner: false },
    StatusBar: { style: 'LIGHT', backgroundColor: '#1E5BB8', overlaysWebView: false },
    PushNotifications: { presentationOptions: ['badge', 'sound', 'alert'] },
  },
};

export default config;
