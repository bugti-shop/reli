import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Crown, ExternalLink, Loader2, RefreshCw } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { usePlan } from "@/hooks/use-plan";
import { toast } from "@/hooks/use-toast";

interface PlanSettingsProps {
  userId: string;
}

export const PlanSettings = ({ userId }: PlanSettingsProps) => {
  const navigate = useNavigate();
  const { plan, isPremium, refresh } = usePlan(userId);
  const [managing, setManaging] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const openPortal = async () => {
    setManaging(true);
    try {
      const { data, error } = await supabase.functions.invoke("customer-portal");
      if (error) throw error;
      if (data?.url) window.open(data.url, "_blank");
      else throw new Error("No portal link returned");
    } catch (e) {
      console.error("Portal error:", e);
      toast({
        title: "Could not open billing",
        description: "We couldn't open your billing page. Please try again.",
        variant: "destructive",
      });
    } finally {
      setManaging(false);
    }
  };

  const recheck = async () => {
    setRefreshing(true);
    await refresh();
    setRefreshing(false);
    toast({ title: "Plan updated", description: "Your plan status has been refreshed." });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Crown className="w-5 h-5 text-primary" />
          Manage plan
        </CardTitle>
        <CardDescription>See your current plan, upgrade, or change your billing details.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between rounded-lg border p-4">
          <div>
            <p className="font-medium">Current plan</p>
            <p className="text-sm text-muted-foreground">
              {plan === null
                ? "Checking…"
                : isPremium
                  ? "Premium — full history and smart tools, shared with your care partner."
                  : "Free — 30 days of history, up to 2 seniors and 2 caregivers."}
            </p>
          </div>
          {plan !== null && (
            <Badge variant={isPremium ? "default" : "secondary"} className="text-sm">
              {isPremium ? "Premium" : "Free"}
            </Badge>
          )}
        </div>

        <div className="flex flex-wrap gap-3">
          {!isPremium && (
            <Button onClick={() => navigate("/pricing")} className="min-h-11">
              Upgrade to Premium
            </Button>
          )}
          <Button variant="outline" onClick={openPortal} disabled={managing} className="min-h-11">
            {managing ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <ExternalLink className="w-4 h-4 mr-2" />}
            {isPremium ? "Manage billing" : "Billing history"}
          </Button>
          <Button variant="ghost" onClick={recheck} disabled={refreshing} className="min-h-11">
            {refreshing ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <RefreshCw className="w-4 h-4 mr-2" />}
            Refresh plan
          </Button>
        </div>

        <p className="text-sm text-muted-foreground">
          One membership covers the senior and their caregivers. Cancel any time from the billing page.
        </p>
      </CardContent>
    </Card>
  );
};
