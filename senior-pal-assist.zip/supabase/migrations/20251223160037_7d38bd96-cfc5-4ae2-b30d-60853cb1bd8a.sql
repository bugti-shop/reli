-- Add DELETE policy for caregiver_messages
CREATE POLICY "Caregivers can delete their messages"
  ON public.caregiver_messages
  FOR DELETE
  TO authenticated
  USING (caregiver_id = auth.uid());

-- Add UPDATE policy for caregivers to edit their messages
CREATE POLICY "Caregivers can update their messages"
  ON public.caregiver_messages
  FOR UPDATE
  TO authenticated
  USING (caregiver_id = auth.uid());

-- Add UPDATE policy for senior_activity_log
CREATE POLICY "Seniors can update their own activity logs"
  ON public.senior_activity_log
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = senior_id);

-- Add DELETE policy for senior_activity_log
CREATE POLICY "Seniors can delete their own activity logs"
  ON public.senior_activity_log
  FOR DELETE
  TO authenticated
  USING (auth.uid() = senior_id);

-- Add DELETE policy for caregiver_seniors relationships
CREATE POLICY "Caregivers can remove senior relationships"
  ON public.caregiver_seniors
  FOR DELETE
  TO authenticated
  USING (auth.uid() = caregiver_id);

-- Add DELETE policy for life_story_entries
CREATE POLICY "Seniors can delete their own life story entries"
  ON public.life_story_entries
  FOR DELETE
  TO authenticated
  USING (auth.uid() = senior_id);