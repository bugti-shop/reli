ALTER TABLE public.emergency_alerts
  ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'active',
  ADD COLUMN IF NOT EXISTS client_request_id text,
  ADD COLUMN IF NOT EXISTS accuracy_m double precision,
  ADD COLUMN IF NOT EXISTS location_captured_at timestamptz,
  ADD COLUMN IF NOT EXISTS cancelled_by uuid,
  ADD COLUMN IF NOT EXISTS cancelled_at timestamptz,
  ADD COLUMN IF NOT EXISTS resolved_by uuid,
  ADD COLUMN IF NOT EXISTS resolved_at timestamptz;

UPDATE public.emergency_alerts SET status = 'resolved', resolved_at = COALESCE(acknowledged_at, updated_at) WHERE status = 'active';

CREATE UNIQUE INDEX IF NOT EXISTS emergency_alerts_one_open_per_senior
  ON public.emergency_alerts (senior_id) WHERE status IN ('active','partially_acknowledged','acknowledged');
CREATE UNIQUE INDEX IF NOT EXISTS emergency_alerts_client_request
  ON public.emergency_alerts (senior_id, client_request_id) WHERE client_request_id IS NOT NULL;

DROP POLICY IF EXISTS "Senior can raise their own emergency alert" ON public.emergency_alerts;
DROP POLICY IF EXISTS "Senior or linked caregiver can update emergency alerts" ON public.emergency_alerts;

CREATE TABLE public.sos_acknowledgements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  alert_id uuid NOT NULL REFERENCES public.emergency_alerts(id) ON DELETE CASCADE,
  caregiver_id uuid NOT NULL,
  acknowledged_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (alert_id, caregiver_id)
);
GRANT SELECT ON public.sos_acknowledgements TO authenticated;
GRANT ALL ON public.sos_acknowledgements TO service_role;
ALTER TABLE public.sos_acknowledgements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Senior or linked caregiver can view acknowledgements" ON public.sos_acknowledgements
  FOR SELECT TO authenticated USING (EXISTS (
    SELECT 1 FROM public.emergency_alerts a WHERE a.id = alert_id AND (a.senior_id = auth.uid() OR EXISTS (
      SELECT 1 FROM public.caregiver_seniors cs WHERE cs.senior_id = a.senior_id AND cs.caregiver_id = auth.uid()))));

CREATE TABLE public.sos_deliveries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  alert_id uuid NOT NULL REFERENCES public.emergency_alerts(id) ON DELETE CASCADE,
  caregiver_id uuid NOT NULL,
  kind text NOT NULL DEFAULT 'alarm',
  attempts integer NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'pending',
  devices_reached integer NOT NULL DEFAULT 0,
  last_error text,
  last_attempt_at timestamptz,
  delivered_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (alert_id, caregiver_id, kind)
);
GRANT ALL ON public.sos_deliveries TO service_role;
ALTER TABLE public.sos_deliveries ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.sos_location_updates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  alert_id uuid NOT NULL REFERENCES public.emergency_alerts(id) ON DELETE CASCADE,
  latitude double precision NOT NULL,
  longitude double precision NOT NULL,
  accuracy_m double precision,
  captured_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.sos_location_updates TO authenticated;
GRANT ALL ON public.sos_location_updates TO service_role;
ALTER TABLE public.sos_location_updates ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Senior or linked caregiver can view SOS locations" ON public.sos_location_updates
  FOR SELECT TO authenticated USING (EXISTS (
    SELECT 1 FROM public.emergency_alerts a WHERE a.id = alert_id AND (a.senior_id = auth.uid() OR EXISTS (
      SELECT 1 FROM public.caregiver_seniors cs WHERE cs.senior_id = a.senior_id AND cs.caregiver_id = auth.uid()))));

CREATE OR REPLACE FUNCTION public.trigger_sos(_request_id text, _lat double precision DEFAULT NULL, _lng double precision DEFAULT NULL,
  _accuracy double precision DEFAULT NULL, _captured_at timestamptz DEFAULT NULL)
RETURNS TABLE(alert_id uuid, is_new boolean)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE me uuid := auth.uid(); existing uuid; new_id uuid; valid_loc boolean;
BEGIN
  IF me IS NULL THEN RAISE EXCEPTION 'Please sign in first'; END IF;
  IF NOT EXISTS (SELECT 1 FROM profiles WHERE id = me AND role = 'senior') THEN RAISE EXCEPTION 'Only seniors can raise SOS'; END IF;
  PERFORM pg_advisory_xact_lock(hashtext('sos:' || me::text));
  -- Auto-close forgotten SOS events older than 12 hours.
  UPDATE emergency_alerts SET status = 'resolved', resolved_at = now()
    WHERE senior_id = me AND status IN ('active','partially_acknowledged','acknowledged') AND created_at < now() - interval '12 hours';
  SELECT id INTO existing FROM emergency_alerts
    WHERE senior_id = me AND (status IN ('active','partially_acknowledged','acknowledged')
      OR (_request_id IS NOT NULL AND client_request_id = left(_request_id, 80)))
    ORDER BY created_at DESC LIMIT 1;
  IF existing IS NOT NULL THEN RETURN QUERY SELECT existing, false; RETURN; END IF;
  valid_loc := _lat BETWEEN -90 AND 90 AND _lng BETWEEN -180 AND 180;
  INSERT INTO emergency_alerts (senior_id, client_request_id, latitude, longitude, accuracy_m, location_captured_at, status)
  VALUES (me, left(_request_id, 80), CASE WHEN valid_loc THEN _lat END, CASE WHEN valid_loc THEN _lng END,
    CASE WHEN valid_loc AND _accuracy >= 0 THEN _accuracy END, CASE WHEN valid_loc THEN COALESCE(LEAST(_captured_at, now()), now()) END, 'active')
  RETURNING id INTO new_id;
  IF valid_loc THEN
    INSERT INTO sos_location_updates (alert_id, latitude, longitude, accuracy_m, captured_at)
    VALUES (new_id, _lat, _lng, CASE WHEN _accuracy >= 0 THEN _accuracy END, COALESCE(LEAST(_captured_at, now()), now()));
  END IF;
  INSERT INTO senior_activity_log (senior_id, activity_type, activity_description) VALUES (me, 'emergency', 'SOS emergency alarm sent');
  RETURN QUERY SELECT new_id, true;
END $$;

CREATE OR REPLACE FUNCTION public.update_sos_location(_alert_id uuid, _lat double precision, _lng double precision,
  _accuracy double precision DEFAULT NULL, _captured_at timestamptz DEFAULT NULL)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE a emergency_alerts;
BEGIN
  SELECT * INTO a FROM emergency_alerts WHERE id = _alert_id;
  IF a.id IS NULL OR a.senior_id <> auth.uid() THEN RAISE EXCEPTION 'SOS not found'; END IF;
  IF a.status NOT IN ('active','partially_acknowledged','acknowledged') THEN RAISE EXCEPTION 'SOS is closed'; END IF;
  IF NOT (_lat BETWEEN -90 AND 90 AND _lng BETWEEN -180 AND 180) THEN RAISE EXCEPTION 'Invalid location'; END IF;
  INSERT INTO sos_location_updates (alert_id, latitude, longitude, accuracy_m, captured_at)
  VALUES (_alert_id, _lat, _lng, CASE WHEN _accuracy >= 0 THEN _accuracy END, COALESCE(LEAST(_captured_at, now()), now()));
  UPDATE emergency_alerts SET latitude = _lat, longitude = _lng, accuracy_m = CASE WHEN _accuracy >= 0 THEN _accuracy END,
    location_captured_at = COALESCE(LEAST(_captured_at, now()), now()) WHERE id = _alert_id;
END $$;

CREATE OR REPLACE FUNCTION public.acknowledge_sos(_alert_id uuid)
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE a emergency_alerts; me uuid := auth.uid(); total int; acked int; new_status text;
BEGIN
  SELECT * INTO a FROM emergency_alerts WHERE id = _alert_id FOR UPDATE;
  IF a.id IS NULL THEN RAISE EXCEPTION 'SOS not found'; END IF;
  IF NOT EXISTS (SELECT 1 FROM caregiver_seniors WHERE senior_id = a.senior_id AND caregiver_id = me) THEN RAISE EXCEPTION 'Not authorized'; END IF;
  IF a.status IN ('cancelled','resolved') THEN RETURN a.status; END IF;
  INSERT INTO sos_acknowledgements (alert_id, caregiver_id) VALUES (_alert_id, me) ON CONFLICT DO NOTHING;
  SELECT count(*) INTO total FROM caregiver_seniors WHERE senior_id = a.senior_id;
  SELECT count(*) INTO acked FROM sos_acknowledgements s JOIN caregiver_seniors cs ON cs.caregiver_id = s.caregiver_id AND cs.senior_id = a.senior_id WHERE s.alert_id = _alert_id;
  new_status := CASE WHEN acked >= total THEN 'acknowledged' ELSE 'partially_acknowledged' END;
  UPDATE emergency_alerts SET status = new_status, acknowledged = true,
    acknowledged_by = COALESCE(acknowledged_by, me), acknowledged_at = COALESCE(acknowledged_at, now()) WHERE id = _alert_id;
  RETURN new_status;
END $$;

CREATE OR REPLACE FUNCTION public.close_sos(_alert_id uuid, _outcome text DEFAULT 'cancelled')
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE a emergency_alerts; me uuid := auth.uid();
BEGIN
  IF _outcome NOT IN ('cancelled','resolved') THEN RAISE EXCEPTION 'Invalid outcome'; END IF;
  SELECT * INTO a FROM emergency_alerts WHERE id = _alert_id FOR UPDATE;
  IF a.id IS NULL THEN RAISE EXCEPTION 'SOS not found'; END IF;
  IF _outcome = 'cancelled' AND a.senior_id <> me THEN RAISE EXCEPTION 'Only the senior can cancel SOS'; END IF;
  IF _outcome = 'resolved' AND a.senior_id <> me AND NOT EXISTS (
    SELECT 1 FROM caregiver_seniors WHERE senior_id = a.senior_id AND caregiver_id = me) THEN RAISE EXCEPTION 'Not authorized'; END IF;
  IF a.status IN ('cancelled','resolved') THEN RETURN a.status; END IF;
  IF _outcome = 'cancelled' THEN
    UPDATE emergency_alerts SET status = 'cancelled', cancelled_by = me, cancelled_at = now() WHERE id = _alert_id;
  ELSE
    UPDATE emergency_alerts SET status = 'resolved', resolved_by = me, resolved_at = now() WHERE id = _alert_id;
  END IF;
  INSERT INTO senior_activity_log (senior_id, activity_type, activity_description)
  VALUES (a.senior_id, 'emergency', CASE WHEN _outcome = 'cancelled' THEN 'SOS cancelled' ELSE 'SOS marked resolved' END);
  RETURN _outcome;
END $$;

REVOKE EXECUTE ON FUNCTION public.trigger_sos(text,double precision,double precision,double precision,timestamptz) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.update_sos_location(uuid,double precision,double precision,double precision,timestamptz) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.acknowledge_sos(uuid) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.close_sos(uuid,text) FROM anon, public;
GRANT EXECUTE ON FUNCTION public.trigger_sos(text,double precision,double precision,double precision,timestamptz) TO authenticated;
GRANT EXECUTE ON FUNCTION public.update_sos_location(uuid,double precision,double precision,double precision,timestamptz) TO authenticated;
GRANT EXECUTE ON FUNCTION public.acknowledge_sos(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.close_sos(uuid,text) TO authenticated;

ALTER TABLE public.emergency_alerts REPLICA IDENTITY FULL;
DO $$ BEGIN
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.sos_acknowledgements; EXCEPTION WHEN duplicate_object THEN NULL; END;
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.sos_location_updates; EXCEPTION WHEN duplicate_object THEN NULL; END;
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.emergency_alerts; EXCEPTION WHEN duplicate_object THEN NULL; END;
END $$;