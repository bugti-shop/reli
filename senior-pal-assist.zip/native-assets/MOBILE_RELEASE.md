# Reli — Android & iOS release guide

Bundle / application id: `com.reli.care` · Store title: **Reli: Family Caregiver App**

The `android/` and `ios/` projects are committed and already configured
(permissions, SOS alarm channel + full-screen service, siren sound, deep
links, background modes, entitlements). Remaining steps need your accounts.

## Build
```
git pull && npm install && npm run build && npx cap sync
npx cap open android   # Android Studio
npx cap open ios       # Xcode
```
Live reload from the Lovable preview while developing: `CAP_LIVE_RELOAD=1 npx cap sync`
(never ship a build made this way).

## 1. Firebase (push + SOS alarm) — required
- Android: put `google-services.json` in `android/app/`.
- iOS: add `GoogleService-Info.plist` to the App target, then in Xcode
  File → Add Package Dependencies → `https://github.com/firebase/firebase-ios-sdk`
  → add **FirebaseMessaging** to the App target. AppDelegate already uses it.
- Upload your APNs auth key to Firebase.
- Connect Firebase Cloud Messaging in Lovable.

## 2. Subscriptions (RevenueCat)
1. Create the subscription products in App Store Connect and Google Play Console
   (monthly + annual for each paid plan).
2. Create one monthly auto-renewing product in both stores using the same ID:
   `com.reli.care.monthly`, priced at USD $34.99/month.
3. In RevenueCat: add both apps, attach only `com.reli.care.monthly` to an
   entitlement named **premium**, then add its monthly package to the *current* offering.
4. Set the public SDK keys as `VITE_REVENUECAT_IOS_KEY` and `VITE_REVENUECAT_ANDROID_KEY`.
5. RevenueCat → Integrations → Webhooks: URL
   `https://hwncdhbbqwelbhbzikqd.supabase.co/functions/v1/revenuecat-webhook`,
   Authorization header `Bearer <your secret>`; save the same secret in Lovable
   as `REVENUECAT_WEBHOOK_AUTH`.
Premium bought in the app, on the website, or by a linked senior/caregiver all
unlock the same features and member limits (enforced in the database).

## 3. Deep links (reli.care)
- iOS: host `https://reli.care/.well-known/apple-app-site-association` with your Team ID.
- Android: host `https://reli.care/.well-known/assetlinks.json` with your release SHA-256.

## 4. SOS platform notes
- Android 14+: caregivers must allow **Full-screen notifications** for Reli, and may
  allow **Do Not Disturb override** on the "SOS Emergency Alarm" channel.
  Play Console → App content → declare `USE_FULL_SCREEN_INTENT` as an alarm/emergency use.
- iOS: request the **Critical Alerts** entitlement from Apple; after approval
  uncomment it in `ios/App/App/App.entitlements`. iOS never opens a full screen
  from a locked phone — tapping the alert opens the full-screen SOS.
- Background location runs only while an SOS is open. Explain this in the
  App Store review notes and Play "Location permissions" declaration
  (feature: "share live location with caregivers during an emergency SOS").

## 5. Store listing checklist
App icons and splash screens are generated from the text-free Reli heart in
`assets/` by running `npm run assets:generate`. Privacy policy URL
(https://reli.care/privacy-policy), data-safety / privacy nutrition
labels (location, health info, contacts), a demo senior + caregiver login for
reviewers, account deletion path, screenshots.
