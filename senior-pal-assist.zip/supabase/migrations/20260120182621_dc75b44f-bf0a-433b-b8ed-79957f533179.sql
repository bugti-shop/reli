-- Add completed column to custom_trackers table
ALTER TABLE public.custom_trackers
ADD COLUMN completed boolean NOT NULL DEFAULT false;

-- Add completed_at timestamp to track when it was completed
ALTER TABLE public.custom_trackers
ADD COLUMN completed_at timestamp with time zone DEFAULT NULL;