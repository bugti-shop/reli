# Roadmap
- [x] Swap contact page footer email to julie@jpcreativellc.com
- [x] Deploy rewritten send-contact-email (contact form now uses managed email)
- [x] Add latest blood pressure, heart rate, and medication status to the senior dashboard header
- [x] Add voice navigation and fit the latest health summary within one mobile screen
- [x] Let seniors manually delete caregiver messages with confirmation
- [x] Senior + caregiver profile pages, details in health tiles, stay signed in after signup, newsletter confirmation flow
- [x] Stripe subscription webhook + fixed plan sync so Premium actually unlocks
- [x] Rebuild senior dashboard from approved reference with five dedicated destinations and preserve every feature
- [x] Match all five senior screens to reference image 2, including spacing and icon style

- [x] Replace the landing page with the approved Reli family illustration design

- [x] Compact the mobile landing hero and blend the optimized family illustration into the page
- [x] Pixel-match the mobile landing page spacing, type, controls, and illustration framing to the supplied reference
- [x] Match mobile store badge proportions, link alignment, and headline spacing to the supplied reference
- [x] Refine landing links, store badge text, speech bubbles, frame, and edge-to-edge illustration
- [x] Optimize landing artwork loading and refine illustration zoom and bubble placement

- [x] Family Circle invites (code/link), senior can remove members
- [x] Family Circle home flow: join by code, share code/link, and send invitation directly from Reli
- [x] Passwordless email joining with caregiver approval and Family Circle management lists
- [x] Add readable shadows to all mountain-card text and weather icons
- [x] SOS: no form, 5s countdown, full-screen ringing alarm for circle members, urgent push payloads
- [ ] Native SOS ringing on locked phones — blocked on Firebase connection + Apple Critical Alerts approval
- [ ] View-only family role and 2-minute SOS re-alert — not built yet
- [x] Prepare one monthly mobile Premium product (`com.reli.care.monthly`) and focused Reli Premium paywall
- [x] Require and bundle the iOS Firebase configuration in Codemagic releases
- [x] Prepare Google Play listing copy for Reli: Family Caregiver App
- [ ] Link Firebase Cloud Messaging to this project — blocked until the project owner is granted access to the existing workspace connection
