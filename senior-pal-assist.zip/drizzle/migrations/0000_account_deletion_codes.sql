CREATE TABLE public.account_deletion_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  code_hash text NOT NULL,
  attempts integer NOT NULL DEFAULT 0,
  expires_at timestamptz NOT NULL,
  used_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.account_deletion_codes TO service_role;
ALTER TABLE public.account_deletion_codes ENABLE ROW LEVEL SECURITY;
CREATE INDEX account_deletion_codes_email_idx ON public.account_deletion_codes (lower(email), created_at DESC);