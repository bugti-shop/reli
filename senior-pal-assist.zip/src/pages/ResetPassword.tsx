import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Eye, EyeOff, ArrowLeft, Loader2 } from "lucide-react";
import reliLogo from "@/assets/reli-logo.png";

type Status = "checking" | "ready" | "invalid" | "done";

const ResetPassword = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [status, setStatus] = useState<Status>("checking");
  const [errorMessage, setErrorMessage] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let cancelled = false;

    const finishReady = () => {
      if (cancelled) return;
      setStatus("ready");
      // Clean the sensitive tokens out of the address bar
      window.history.replaceState({}, "", "/reset-password");
    };

    const fail = (message: string) => {
      if (cancelled) return;
      setErrorMessage(message);
      setStatus("invalid");
    };

    const run = async () => {
      const search = new URLSearchParams(window.location.search);
      const hash = new URLSearchParams(window.location.hash.replace(/^#/, ""));

      const errorDescription =
        search.get("error_description") || hash.get("error_description");
      if (errorDescription) {
        fail(decodeURIComponent(errorDescription));
        return;
      }

      // 1. PKCE style link: ?code=...
      const code = search.get("code");
      if (code) {
        const { error } = await supabase.auth.exchangeCodeForSession(code);
        if (error) {
          fail("This reset link has expired or was already used.");
          return;
        }
        finishReady();
        return;
      }

      // 2. Token hash style link: ?token_hash=...&type=recovery
      const tokenHash = search.get("token_hash") || search.get("token");
      const type = search.get("type") || hash.get("type");
      if (tokenHash && (!type || type === "recovery")) {
        const { error } = await supabase.auth.verifyOtp({
          type: "recovery",
          token_hash: tokenHash,
        });
        if (error) {
          fail("This reset link has expired or was already used.");
          return;
        }
        finishReady();
        return;
      }

      // 3. Implicit style link: #access_token=...&refresh_token=...
      const accessToken = hash.get("access_token");
      const refreshToken = hash.get("refresh_token");
      if (accessToken && refreshToken) {
        const { error } = await supabase.auth.setSession({
          access_token: accessToken,
          refresh_token: refreshToken,
        });
        if (error) {
          fail("This reset link has expired or was already used.");
          return;
        }
        finishReady();
        return;
      }

      // 4. Supabase may already have picked the link up automatically
      const { data } = await supabase.auth.getSession();
      if (data.session) {
        finishReady();
        return;
      }

      fail(
        "This page needs a valid password reset link. Please request a new one.",
      );
    };

    const { data: listener } = supabase.auth.onAuthStateChange((event) => {
      if (event === "PASSWORD_RECOVERY" || event === "SIGNED_IN") {
        finishReady();
      }
    });

    run();

    return () => {
      cancelled = true;
      listener.subscription.unsubscribe();
    };
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (newPassword.length < 6) {
      toast({
        title: "Password too short",
        description: "Please use at least 6 characters.",
        variant: "destructive",
      });
      return;
    }
    if (newPassword !== confirmPassword) {
      toast({
        title: "Passwords don't match",
        description: "Please make sure both boxes are the same.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    setLoading(false);

    if (error) {
      toast({
        title: "Could not update password",
        description: error.message,
        variant: "destructive",
      });
      return;
    }

    setStatus("done");
    toast({
      title: "Password updated",
      description: "You're all set. You can sign in with your new password.",
    });
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-background to-muted/40 px-4 py-10">
      <div className="w-full max-w-md space-y-4">
        <Button
          variant="ghost"
          onClick={() => navigate("/auth")}
          className="gap-2"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to sign in
        </Button>

        <Card className="p-6 sm:p-8 space-y-6">
          <div className="text-center space-y-3">
            <img
              src={reliLogo}
              alt="Reli"
              className="h-12 w-auto mx-auto"
              loading="lazy"
            />
            <h1 className="text-2xl font-bold">Choose a new password</h1>
          </div>

          {status === "checking" && (
            <div className="flex flex-col items-center gap-3 py-6 text-muted-foreground">
              <Loader2 className="h-6 w-6 animate-spin" />
              <p>Checking your reset link…</p>
            </div>
          )}

          {status === "invalid" && (
            <div className="space-y-4 text-center">
              <p className="text-base text-muted-foreground">{errorMessage}</p>
              <Button className="w-full" onClick={() => navigate("/auth")}>
                Request a new reset link
              </Button>
            </div>
          )}

          {status === "ready" && (
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="new-password" className="text-base">
                  New password
                </Label>
                <div className="relative">
                  <Input
                    id="new-password"
                    type={showNew ? "text" : "password"}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="At least 6 characters"
                    autoComplete="new-password"
                    required
                    className="h-12 text-base pr-12"
                  />
                  <button
                    type="button"
                    onClick={() => setShowNew((v) => !v)}
                    aria-label={showNew ? "Hide password" : "Show password"}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
                  >
                    {showNew ? (
                      <EyeOff className="h-5 w-5" />
                    ) : (
                      <Eye className="h-5 w-5" />
                    )}
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirm-password" className="text-base">
                  Confirm new password
                </Label>
                <div className="relative">
                  <Input
                    id="confirm-password"
                    type={showConfirm ? "text" : "password"}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Type it again"
                    autoComplete="new-password"
                    required
                    className="h-12 text-base pr-12"
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirm((v) => !v)}
                    aria-label={showConfirm ? "Hide password" : "Show password"}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
                  >
                    {showConfirm ? (
                      <EyeOff className="h-5 w-5" />
                    ) : (
                      <Eye className="h-5 w-5" />
                    )}
                  </button>
                </div>
              </div>

              <Button
                type="submit"
                className="w-full h-12 text-base"
                disabled={loading}
              >
                {loading ? "Saving…" : "Save new password"}
              </Button>
            </form>
          )}

          {status === "done" && (
            <div className="space-y-4 text-center">
              <p className="text-base text-muted-foreground">
                Your password has been updated.
              </p>
              <Button
                className="w-full h-12 text-base"
                onClick={() => navigate("/dashboard")}
              >
                Continue to my dashboard
              </Button>
              <Button
                variant="outline"
                className="w-full"
                onClick={async () => {
                  await supabase.auth.signOut();
                  navigate("/auth");
                }}
              >
                Sign in again instead
              </Button>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
};

export default ResetPassword;
