import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Type } from "lucide-react";
import { useFontSize } from "@/hooks/use-font-size";

const sizes = [
  { key: "small", label: "A", className: "text-sm" },
  { key: "medium", label: "A", className: "text-base" },
  { key: "large", label: "A", className: "text-lg" },
] as const;

export const FontSizeControl = () => {
  const { fontSize, setFontSize } = useFontSize();

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="sm" className="px-2" aria-label="Change font size">
          <Type className="w-4 h-4" />
          <span className="hidden sm:inline ml-1.5 text-sm">Text size</span>
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-auto p-2">
        <div className="flex items-center gap-1.5">
          <span className="text-xs text-muted-foreground px-1 hidden sm:inline">Size</span>
          {sizes.map((s) => (
            <Button
              key={s.key}
              variant={fontSize === s.key ? "default" : "outline"}
              size="sm"
              onClick={() => setFontSize(s.key)}
              className={`${s.className} w-9 h-9 p-0 font-semibold`}
              aria-label={`${s.key} font size`}
              aria-pressed={fontSize === s.key}
            >
              {s.label}
            </Button>
          ))}
        </div>
      </PopoverContent>
    </Popover>
  );
};
