import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { User, Session } from "@supabase/supabase-js";
import { z } from "zod";
import { Eye, EyeOff, ArrowLeft } from "lucide-react";

const authSchema = z.object({
  email: z.string().trim().email({ message: "Invalid email address" }).max(255),
  password: z.string().min(6, { message: "Password must be at least 6 characters" }),
  fullName: z.string().trim().min(1, { message: "Name is required" }).max(100),
});

const Auth = () => {
  const [searchParams] = useSearchParams();
  const roleFromUrl = searchParams.get('role');
  const initialRole = roleFromUrl === 'caregiver' ? 'caregiver' : 'senior';
  const shouldStartWithSignup = roleFromUrl === 'senior' || roleFromUrl === 'caregiver';
  
  const [isLogin, setIsLogin] = useState(!shouldStartWithSignup);
  const [isForgotPassword, setIsForgotPassword] = useState(false);
  const [isResetPassword, setIsResetPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [role, setRole] = useState<"senior" | "caregiver">(initialRole);
  const [loading, setLoading] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const authenticatedDestination = (sessionUser: User) => {
    const pendingInvite = localStorage.getItem("reli-pending-invite")?.trim();
    if (pendingInvite) return `/join/${encodeURIComponent(pendingInvite)}`;
    // RoleGuard on each dashboard re-checks the stored role and redirects if needed.
    return sessionUser.user_metadata?.role === "caregiver" ? "/caregiver" : "/dashboard";
  };

  useEffect(() => {
    // Check if we're in password recovery mode
    const checkRecoveryMode = () => {
      const hashParams = new URLSearchParams(window.location.hash.substring(1));
      const type = hashParams.get('type');
      return type === 'recovery';
    };

    // Older reset links may still land here — forward them to the reset page
    const search = new URLSearchParams(window.location.search);
    const hashParams = new URLSearchParams(window.location.hash.replace(/^#/, ""));
    if (
      hashParams.get("type") === "recovery" ||
      search.get("type") === "recovery" ||
      search.get("token_hash") ||
      search.get("code")
    ) {
      window.location.replace(
        `/reset-password${window.location.search}${window.location.hash}`,
      );
      return;
    }

    const isRecoveryMode = checkRecoveryMode();
    if (isRecoveryMode) {
      setIsResetPassword(true);
      setIsLogin(false);
      setIsForgotPassword(false);
    }

    // Set up auth state listener FIRST
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        setSession(session);
        setUser(session?.user ?? null);
        
        // Check if we're in recovery mode via URL
        const isInRecovery = checkRecoveryMode();
        
        if (isInRecovery) {
          setIsResetPassword(true);
          setIsLogin(false);
          setIsForgotPassword(false);
          return; // Don't navigate away
        }
        
        if (session?.user && !isInRecovery) {
          // Defer navigation to avoid deadlock
          setTimeout(() => {
            navigate(authenticatedDestination(session.user));
          }, 0);
        }
      }
    );

    // THEN check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      // Don't auto-navigate if we're in password recovery mode
      if (session?.user && !checkRecoveryMode()) {
        navigate(authenticatedDestination(session.user));
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const validation = z.string().email().safeParse(email.trim());
      if (!validation.success) {
        toast({
          title: "Invalid Email",
          description: "Please enter a valid email address.",
          variant: "destructive",
        });
        setLoading(false);
        return;
      }

      const redirectUrl = `${window.location.origin}/reset-password`;
      const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), {
        redirectTo: redirectUrl,
      });

      if (error) {
        toast({
          title: "Error",
          description: error.message,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Check Your Email",
          description: "We've sent you a password reset link. Please check your email.",
        });
        setIsForgotPassword(false);
        setIsLogin(true);
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (newPassword.length < 6) {
        toast({
          title: "Password Too Short",
          description: "Password must be at least 6 characters long.",
          variant: "destructive",
        });
        setLoading(false);
        return;
      }

      if (newPassword !== confirmPassword) {
        toast({
          title: "Passwords Don't Match",
          description: "Please make sure both passwords match.",
          variant: "destructive",
        });
        setLoading(false);
        return;
      }

      const { error } = await supabase.auth.updateUser({
        password: newPassword,
      });

      if (error) {
        toast({
          title: "Error",
          description: error.message,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Password Updated",
          description: "Your password has been successfully updated. You can now log in.",
        });
        setIsResetPassword(false);
        setIsLogin(true);
        setNewPassword("");
        setConfirmPassword("");
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (isLogin) {
        const validation = authSchema.pick({ email: true, password: true }).safeParse({ email, password });
        if (!validation.success) {
          toast({
            title: "Validation Error",
            description: validation.error.errors[0].message,
            variant: "destructive",
          });
          setLoading(false);
          return;
        }

        const { data: signInData, error } = await supabase.auth.signInWithPassword({
          email: email.trim(),
          password,
        });
        if (!error && signInData.user && roleFromUrl) {
          const { data: prof } = await supabase.from("profiles").select("role").eq("id", signInData.user.id).maybeSingle();
          const actual = prof?.role ?? "senior";
          if (actual !== roleFromUrl) {
            await supabase.auth.signOut({ scope: "local" });
            toast({
              title: "Wrong dashboard",
              description: actual === "caregiver"
                ? "This email is registered as a Caregiver account. Please sign in from the Caregiver option."
                : "This email is registered as a Senior/Myself account. Please sign in from the Senior/Myself option.",
              variant: "destructive",
            });
            setLoading(false);
            return;
          }
        }

        if (!error && signInData.user) {
          void import("@/lib/activity").then((m) => m.logActivity("Signed in", "Signed in to Reli", { feature: "account" }));
        }

        if (error) {
          if (error.message.includes("Invalid login credentials")) {
            toast({
              title: "Login Failed",
              description: "Invalid email or password. Please try again.",
              variant: "destructive",
            });
          } else {
            toast({
              title: "Login Failed",
              description: error.message,
              variant: "destructive",
            });
          }
        } else {
          toast({
            title: "Welcome back!",
            description: "You have successfully logged in.",
          });
        }
      } else {
        const validation = authSchema.safeParse({ email, password, fullName });
        if (!validation.success) {
          toast({
            title: "Validation Error",
            description: validation.error.errors[0].message,
            variant: "destructive",
          });
          setLoading(false);
          return;
        }

        const pendingInvite = localStorage.getItem("reli-pending-invite")?.trim();
        const redirectUrl = pendingInvite
          ? `${window.location.origin}/join/${encodeURIComponent(pendingInvite)}`
          : `${window.location.origin}/`;
        const { error } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: {
            emailRedirectTo: redirectUrl,
            data: {
              full_name: fullName.trim(),
              role: role,
            },
          },
        });

        if (error) {
          if (error.message.includes("User already registered")) {
            toast({
              title: "Account Exists",
              description: "An account with this email already exists. Please login instead.",
              variant: "destructive",
            });
          } else {
            toast({
              title: "Signup Failed",
              description: error.message,
              variant: "destructive",
            });
          }
        } else {
          toast({
            title: "Account Created!",
            description: "Welcome to Reli. Your account has been created successfully.",
          });
        }
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/20 to-background flex items-center justify-center p-4">
      <Button
        variant="ghost"
        onClick={() => navigate('/')}
        className="absolute top-4 left-4 text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="mr-1" />
        Back to home
      </Button>
      <div className="w-full max-w-md">
        <Card className="w-full p-8 bg-card/90 backdrop-blur shadow-gentle border-2">
          <h1 className="text-4xl font-bold text-center mb-2 text-foreground">
            {isResetPassword
              ? "Reset Password"
              : isForgotPassword
              ? "Forgot Password"
              : isLogin
              ? "Welcome Back"
              : "Join Reli"}
          </h1>
          <p className="text-center text-muted-foreground mb-6">
            {isResetPassword
              ? "Enter your new password"
              : isForgotPassword
              ? "We'll send you a reset link"
              : isLogin
              ? "Sign in to continue"
              : "Create your account"}
          </p>

          {isResetPassword ? (
            <form onSubmit={handleResetPassword} className="space-y-4">
              <div>
                <Label htmlFor="newPassword" className="text-lg">New Password</Label>
                <div className="relative mt-1">
                  <Input
                    id="newPassword"
                    type={showNewPassword ? "text" : "password"}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Enter new password"
                    className="text-lg h-12 pr-12"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowNewPassword(!showNewPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showNewPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                  </button>
                </div>
              </div>

              <div>
                <Label htmlFor="confirmPassword" className="text-lg">Confirm Password</Label>
                <div className="relative mt-1">
                  <Input
                    id="confirmPassword"
                    type={showConfirmPassword ? "text" : "password"}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Confirm new password"
                    className="text-lg h-12 pr-12"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showConfirmPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                  </button>
                </div>
              </div>

              <Button
                type="submit"
                className="w-full h-12 text-lg"
                disabled={loading}
              >
                {loading ? "Updating..." : "Update Password"}
              </Button>
            </form>
          ) : isForgotPassword ? (
            <form onSubmit={handleForgotPassword} className="space-y-4">
              <div>
                <Label htmlFor="email" className="text-lg">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email"
                  className="mt-1 text-lg h-12"
                  required
                />
              </div>

              <Button
                type="submit"
                className="w-full h-12 text-lg"
                disabled={loading}
              >
                {loading ? "Sending..." : "Send Reset Link"}
              </Button>

              <div className="text-center">
                <button
                  onClick={() => {
                    setIsForgotPassword(false);
                    setIsLogin(true);
                  }}
                  className="text-primary hover:underline text-lg"
                  type="button"
                >
                  Back to Sign In
                </button>
              </div>
            </form>
          ) : (
            <form onSubmit={handleAuth} className="space-y-4">
              {!isLogin && (
                <>
                  <div>
                    <Label htmlFor="fullName" className="text-lg">Full Name</Label>
                    <Input
                      id="fullName"
                      type="text"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="Enter your full name"
                      className="mt-1 text-lg h-12"
                      required={!isLogin}
                    />
                  </div>
                  {shouldStartWithSignup ? (
                    <p className="text-muted-foreground">
                      Signing up as{" "}
                      <span className="font-semibold text-foreground">
                        {role === "caregiver" ? "a caregiver" : "a senior adult"}
                      </span>
                    </p>
                  ) : (
                    <div>
                      <Label htmlFor="role" className="text-lg">I am a...</Label>
                      <select
                        id="role"
                        value={role}
                        onChange={(e) => setRole(e.target.value as "senior" | "caregiver")}
                        className="mt-1 w-full h-12 px-3 rounded-md border border-input bg-background text-lg"
                      >
                        <option value="senior">Senior Adult</option>
                        <option value="caregiver">Caregiver</option>
                      </select>
                    </div>
                  )}
                </>
              )}

              <div>
                <Label htmlFor="email" className="text-lg">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email"
                  className="mt-1 text-lg h-12"
                  required
                />
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <Label htmlFor="password" className="text-lg">Password</Label>
                  {isLogin && (
                    <button
                      onClick={() => {
                        setIsForgotPassword(true);
                        setIsLogin(false);
                      }}
                      className="text-sm text-primary hover:underline"
                      type="button"
                    >
                      Forgot Password?
                    </button>
                  )}
                </div>
                <div className="relative mt-1">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter your password"
                    className="text-lg h-12 pr-12"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                  </button>
                </div>
              </div>

              <Button
                type="submit"
                className="w-full h-12 text-lg"
                disabled={loading}
              >
                {loading ? "Please wait..." : isLogin ? "Sign In" : "Sign Up"}
              </Button>
            </form>
          )}

          {!isResetPassword && !isForgotPassword && (
            <div className="mt-6 text-center">
              <button
                onClick={() => setIsLogin(!isLogin)}
                className="text-primary hover:underline text-lg"
              >
                {isLogin ? "Need an account? Sign up" : "Already have an account? Sign in"}
              </button>
            </div>
          )}
        </Card>
        
        {/* Footer */}
        <div className="text-center mt-6">
          <p className="text-muted-foreground text-sm">
            © {new Date().getFullYear()} Reli. All rights reserved.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Auth;
