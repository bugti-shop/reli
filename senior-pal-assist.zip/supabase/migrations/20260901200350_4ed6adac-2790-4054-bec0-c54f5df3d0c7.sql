CREATE TABLE public.vital_readings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  senior_id uuid NOT NULL,
  recorded_by uuid NOT NULL,
  created_by_role text NOT NULL CHECK (created_by_role IN ('senior','caregiver')),
  reading_type text NOT NULL CHECK (reading_type IN ('blood_pressure','heart_rate')),
  systolic integer,
  diastolic integer,
  bpm integer,
  notes text,
  recorded_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.vital_readings TO authenticated;
GRANT ALL ON public.vital_readings TO service_role;

ALTER TABLE public.vital_readings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Seniors can view their own vitals" ON public.vital_readings
FOR SELECT TO authenticated USING (senior_id = auth.uid());

CREATE POLICY "Seniors can add their own vitals" ON public.vital_readings
FOR INSERT TO authenticated WITH CHECK (senior_id = auth.uid() AND recorded_by = auth.uid() AND created_by_role = 'senior');

CREATE POLICY "Seniors can update their own vitals" ON public.vital_readings
FOR UPDATE TO authenticated USING (senior_id = auth.uid());

CREATE POLICY "Seniors can delete their own vitals" ON public.vital_readings
FOR DELETE TO authenticated USING (senior_id = auth.uid() AND created_by_role = 'senior');

CREATE POLICY "Caregivers can view their seniors vitals" ON public.vital_readings
FOR SELECT TO authenticated USING (EXISTS (SELECT 1 FROM public.caregiver_seniors cs WHERE cs.caregiver_id = auth.uid() AND cs.senior_id = vital_readings.senior_id));

CREATE POLICY "Caregivers can add vitals for their seniors" ON public.vital_readings
FOR INSERT TO authenticated WITH CHECK (recorded_by = auth.uid() AND created_by_role = 'caregiver' AND EXISTS (SELECT 1 FROM public.caregiver_seniors cs WHERE cs.caregiver_id = auth.uid() AND cs.senior_id = vital_readings.senior_id));

CREATE POLICY "Caregivers can update their seniors vitals" ON public.vital_readings
FOR UPDATE TO authenticated USING (EXISTS (SELECT 1 FROM public.caregiver_seniors cs WHERE cs.caregiver_id = auth.uid() AND cs.senior_id = vital_readings.senior_id));

CREATE POLICY "Caregivers can delete vitals they recorded" ON public.vital_readings
FOR DELETE TO authenticated USING (recorded_by = auth.uid() AND created_by_role = 'caregiver');

CREATE POLICY "deny_anon_access_vital_readings" ON public.vital_readings
AS RESTRICTIVE FOR ALL TO anon USING (false) WITH CHECK (false);

CREATE TRIGGER update_vital_readings_updated_at BEFORE UPDATE ON public.vital_readings
FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

CREATE INDEX idx_vital_readings_senior_time ON public.vital_readings (senior_id, reading_type, recorded_at DESC);