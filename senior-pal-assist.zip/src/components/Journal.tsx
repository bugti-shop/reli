import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { usePlan } from "@/hooks/use-plan";
import { VoiceInput } from "@/components/VoiceInput";
import { useToast } from "@/hooks/use-toast";
import {
  NotebookPen,
  Save,
  Trash2,
  Lock,
  Smile,
  Meh,
  Frown,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import { format, parseISO, subDays } from "date-fns";
import { enqueue, isOnline } from "@/lib/offlineQueue";
import { usePendingQueue } from "@/hooks/use-offline-sync";
import { CloudOff } from "lucide-react";

interface JournalProps {
  userId: string;
}

interface JournalRow {
  id: string;
  entry_date: string;
  title: string | null;
  content: string;
  mood: string | null;
  created_at: string;
}

const FREE_DAYS = 30;

const moods = [
  { key: "happy", label: "Good", icon: Smile, color: "text-green-500" },
  { key: "neutral", label: "Okay", icon: Meh, color: "text-yellow-500" },
  { key: "sad", label: "Low", icon: Frown, color: "text-blue-500" },
];

export const Journal = ({ userId }: JournalProps) => {
  const { toast } = useToast();
  const { plan, isPremium } = usePlan(userId);
  const [entries, setEntries] = useState<JournalRow[]>([]);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [mood, setMood] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(true);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const pending = usePendingQueue("journal_entries");

  const fetchEntries = async () => {
    if (!plan) return;
    let query = supabase
      .from("journal_entries")
      .select("*")
      .eq("senior_id", userId)
      .order("entry_date", { ascending: false })
      .order("created_at", { ascending: false })
      .limit(isPremium ? 2000 : 200);

    if (!isPremium) {
      query = query.gte("entry_date", format(subDays(new Date(), FREE_DAYS), "yyyy-MM-dd"));
    }

    const { data, error } = await query;
    if (error) {
      console.error("Error fetching journal entries:", error);
      return;
    }
    setEntries((data || []) as JournalRow[]);
  };

  useEffect(() => {
    fetchEntries();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId, plan]);

  const saveEntry = async () => {
    const text = content.trim();
    if (!text) {
      toast({ title: "Nothing to save", description: "Write a little something first." });
      return;
    }
    const row = {
      senior_id: userId,
      title: title.trim() || null,
      content: text,
      mood,
      entry_date: format(new Date(), "yyyy-MM-dd"),
    };

    if (!isOnline()) {
      enqueue({ table: "journal_entries", op: "insert", payload: row, label: "Journal entry" });
      setTitle("");
      setContent("");
      setMood(null);
      toast({
        title: "Saved on this device",
        description: "No internet right now — it will upload automatically later.",
      });
      return;
    }

    setSaving(true);
    const { error } = await supabase.from("journal_entries").insert(row);
    setSaving(false);

    if (error) {
      console.error("Error saving journal entry:", error);
      toast({ title: "Error", description: "Could not save your entry.", variant: "destructive" });
      return;
    }
    setTitle("");
    setContent("");
    setMood(null);
    toast({ title: "Saved", description: "Your journal entry has been saved." });
    fetchEntries();
  };

  const deleteEntry = async (id: string) => {
    const { error } = await supabase.from("journal_entries").delete().eq("id", id);
    if (error) {
      console.error("Error deleting journal entry:", error);
      toast({ title: "Error", description: "Could not delete that entry.", variant: "destructive" });
      return;
    }
    fetchEntries();
  };

  return (
    <div className="space-y-4">
      <Card className="p-6 bg-card/90 backdrop-blur border-2">
        <h2 className="text-2xl font-semibold flex items-center gap-2 mb-4">
          <NotebookPen className="w-6 h-6 text-primary" />
          My Journal
        </h2>

        <div className="space-y-3">
          <Input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Give today a title (optional)"
            className="text-lg h-12"
            maxLength={120}
          />

          <div className="relative">
            <Textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="How was your day? What's on your mind?"
              className="text-lg min-h-[160px] pr-14"
            />
            <div className="absolute top-2 right-2">
              <VoiceInput
                onTranscript={(t) => setContent((c) => (c ? `${c} ${t}` : t))}
              />
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <span className="text-base text-muted-foreground">How are you feeling?</span>
            {moods.map((m) => {
              const Icon = m.icon;
              const active = mood === m.key;
              return (
                <Button
                  key={m.key}
                  type="button"
                  variant={active ? "default" : "outline"}
                  size="lg"
                  onClick={() => setMood(active ? null : m.key)}
                  className="gap-2"
                >
                  <Icon className={`w-5 h-5 ${active ? "" : m.color}`} />
                  {m.label}
                </Button>
              );
            })}
          </div>

          <Button size="lg" onClick={saveEntry} disabled={saving} className="gap-2 text-lg">
            <Save className="w-5 h-5" />
            {saving ? "Saving..." : "Save entry"}
          </Button>
        </div>
      </Card>

      <Card className="p-6 bg-card/90 backdrop-blur border-2">
        <button
          onClick={() => setHistoryOpen((o) => !o)}
          className="w-full flex items-center justify-between text-left"
        >
          <h2 className="text-2xl font-semibold flex items-center gap-2">
            Past Entries
            <Badge variant="secondary" className="ml-1">{entries.length}</Badge>
          </h2>
          {historyOpen ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
        </button>

        {historyOpen && (
          <div className="mt-4 space-y-2">
            <p className="text-sm text-muted-foreground">
              {isPremium
                ? "Premium: showing your complete journal history."
                : `Free plan: showing the last ${FREE_DAYS} days.`}
            </p>

            {pending.map((p) => (
              <div
                key={p.id}
                className="border-2 border-dashed rounded-lg bg-muted/30 p-3 flex items-start gap-3"
              >
                <CloudOff className="w-5 h-5 text-amber-600 dark:text-amber-400 mt-1 flex-shrink-0" />
                <div>
                  <p className="font-medium text-lg">
                    Saved on this device · waiting to upload
                  </p>
                  <p className="text-base whitespace-pre-wrap">
                    {String((p.payload as { content?: string })?.content || "")}
                  </p>
                </div>
              </div>
            ))}

            {entries.length === 0 && pending.length === 0 ? (
              <p className="text-muted-foreground text-base py-4 text-center">
                No journal entries yet.
              </p>
            ) : (
              entries.map((entry) => {
                const m = moods.find((x) => x.key === entry.mood);
                const MoodIcon = m?.icon;
                const isOpen = expandedId === entry.id;
                return (
                  <div key={entry.id} className="border rounded-lg bg-background/50">
                    <div className="flex items-center justify-between gap-2 p-3">
                      <button
                        className="flex-1 flex items-center justify-between gap-3 text-left"
                        onClick={() => setExpandedId(isOpen ? null : entry.id)}
                      >
                        <span className="font-medium text-lg">
                          {format(parseISO(entry.entry_date), "EEE, MMM d, yyyy")}
                          {entry.title ? (
                            <span className="text-muted-foreground text-base"> · {entry.title}</span>
                          ) : null}
                        </span>
                        <span className="flex items-center gap-2">
                          {m && MoodIcon && (
                            <span className="flex items-center gap-1 text-sm text-muted-foreground">
                              <MoodIcon className={`w-4 h-4 ${m.color}`} />
                              {m.label}
                            </span>
                          )}
                          {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                        </span>
                      </button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-destructive hover:text-destructive"
                        onClick={() => deleteEntry(entry.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                    {isOpen && (
                      <p className="px-3 pb-3 text-base whitespace-pre-wrap">{entry.content}</p>
                    )}
                  </div>
                );
              })
            )}

            {!isPremium && (
              <div className="mt-4 p-4 rounded-lg border bg-muted/30 flex items-start gap-3">
                <Lock className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium text-sm">Free plan: last {FREE_DAYS} days shown</p>
                  <p className="text-sm text-muted-foreground">
                    Nothing is deleted — older entries unlock as soon as you upgrade to Premium.
                  </p>
                </div>
              </div>
            )}
          </div>
        )}
      </Card>
    </div>
  );
};

export default Journal;
