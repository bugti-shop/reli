-- Create a table for senior reminders (created by seniors themselves)
CREATE TABLE public.senior_reminders (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  senior_id UUID NOT NULL,
  message TEXT NOT NULL,
  reminder_time TIMESTAMP WITH TIME ZONE NOT NULL,
  completed BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.senior_reminders ENABLE ROW LEVEL SECURITY;

-- Seniors can create their own reminders
CREATE POLICY "Seniors can create their own reminders"
ON public.senior_reminders
FOR INSERT
WITH CHECK (auth.uid() = senior_id);

-- Seniors can view their own reminders
CREATE POLICY "Seniors can view their own reminders"
ON public.senior_reminders
FOR SELECT
USING (auth.uid() = senior_id);

-- Seniors can update their own reminders
CREATE POLICY "Seniors can update their own reminders"
ON public.senior_reminders
FOR UPDATE
USING (auth.uid() = senior_id);

-- Seniors can delete their own reminders
CREATE POLICY "Seniors can delete their own reminders"
ON public.senior_reminders
FOR DELETE
USING (auth.uid() = senior_id);

-- Caregivers can view their seniors' reminders
CREATE POLICY "Caregivers can view their seniors reminders"
ON public.senior_reminders
FOR SELECT
USING (EXISTS (
  SELECT 1 FROM caregiver_seniors
  WHERE caregiver_seniors.caregiver_id = auth.uid()
  AND caregiver_seniors.senior_id = senior_reminders.senior_id
));

-- Enable realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.senior_reminders;