import { useCallback, useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface Alert {
  id: string;
  senior_id: string;
  message: string | null;
  created_at: string;
}

interface EmergencyAlertsProps {
  caregiverId: string;
  seniors: { id: string; full_name: string }[];
}

export const EmergencyAlerts = ({ caregiverId, seniors }: EmergencyAlertsProps) => {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const { toast } = useToast();

  const seniorIds = seniors.map((s) => s.id);
  const nameFor = (id: string) => seniors.find((s) => s.id === id)?.full_name || "Your senior";

  const fetchAlerts = useCallback(async () => {
    if (seniorIds.length === 0) {
      setAlerts([]);
      return;
    }
    const { data, error } = await supabase
      .from("emergency_alerts")
      .select("id, senior_id, message, created_at")
      .in("status", ["active", "partially_acknowledged"])
      .in("senior_id", seniorIds)
      .order("created_at", { ascending: false });

    if (error) {
      console.error("Error fetching emergency alerts:", error);
      return;
    }
    const ids = (data || []).map((a) => a.id);
    const { data: mine } = ids.length
      ? await supabase.from("sos_acknowledgements").select("alert_id").eq("caregiver_id", caregiverId).in("alert_id", ids)
      : { data: [] as { alert_id: string }[] };
    const done = new Set((mine || []).map((m) => m.alert_id));
    setAlerts((data || []).filter((a) => !done.has(a.id)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [seniorIds.join(",")]);

  useEffect(() => {
    fetchAlerts();
  }, [fetchAlerts]);

  useEffect(() => {
    if (seniorIds.length === 0) return;

    const channel = supabase
      .channel("emergency-alerts")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "emergency_alerts" },
        (payload) => {
          const row = (payload.new || payload.old) as Alert | undefined;
          if (row && seniorIds.includes(row.senior_id)) {
            if (payload.eventType === "INSERT") {
              toast({
                title: `🚨 Emergency alert from ${nameFor(row.senior_id)}`,
                description: row.message || "They tapped the emergency button.",
                variant: "destructive",
              });
            }
            fetchAlerts();
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [seniorIds.join(","), fetchAlerts]);

  const acknowledge = async (id: string) => {
    const { error } = await supabase.rpc("acknowledge_sos", { _alert_id: id });

    if (error) {
      toast({ title: "Could not update", description: error.message, variant: "destructive" });
      return;
    }
    setAlerts((prev) => prev.filter((a) => a.id !== id));
  };

  if (alerts.length === 0) return null;

  return (
    <div className="space-y-3">
      {alerts.map((alert) => (
        <Card
          key={alert.id}
          className="p-4 border-2 border-destructive bg-destructive/10 flex items-start gap-3"
          role="alert"
        >
          <AlertTriangle className="w-6 h-6 text-destructive flex-shrink-0 mt-0.5" />
          <div className="flex-1 min-w-0">
            <p className="font-semibold text-destructive">
              Emergency alert from {nameFor(alert.senior_id)}
            </p>
            {alert.message && <p className="text-foreground mt-0.5">{alert.message}</p>}
            <p className="text-xs text-muted-foreground mt-1">
              {new Date(alert.created_at).toLocaleString([], {
                weekday: "short",
                month: "short",
                day: "numeric",
                hour: "2-digit",
                minute: "2-digit",
              })}
            </p>
          </div>
          <Button size="sm" variant="outline" className="gap-1.5 flex-shrink-0" onClick={() => acknowledge(alert.id)}>
            <Check className="w-4 h-4" /> Acknowledge SOS
          </Button>
        </Card>
      ))}
    </div>
  );
};
