# Compact mobile landing hero

## Goal
Make the Reli landing hero feel properly scaled on mobile so the logo, headline, actions, store badges, and complete family illustration are visible together with minimal scrolling, while preserving the current desktop design.

## What will change
- Reduce the mobile-only Reli logo, menu icon, headline, supporting text, buttons, links, store badges, labels, and vertical spacing in balanced proportions.
- Recompose the hero around the uploaded reference: keep the illustration large and visually prominent, but remove the separate card-like framing so its cream living-room background blends continuously into the page.
- Reposition the three live text bubbles over the matching areas shown in the reference: “How are you today?” on the left, medication centered above the family, and “You’re doing great!” on the right.
- Preserve the full illustration details—family, plants, frames, couch, hearts, and room setting—without embedding the reference screenshot itself.
- Keep all buttons, links, menu destinations, and newsletter behavior unchanged.

## Performance and verification
- Produce responsive WebP/AVIF variants of the family artwork and serve an appropriate mobile size, while retaining a reliable fallback.
- Give the illustration stable dimensions and prioritize its loading to prevent layout movement and make it appear quickly.
- Verify at the supplied narrow mobile width that there is no horizontal overflow, the artwork is not cropped incorrectly, text remains readable, and the composition closely matches the reference.
- Recheck desktop to ensure the mobile compaction does not make the computer layout cramped.
