import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Bell, BellRing, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { enablePush, pushIsConfigured } from "@/lib/push";

interface NotificationSettingsProps {
  userId?: string;
  role: "senior" | "caregiver";
}

interface Prefs {
  email: string;
  email_enabled: boolean;
  phone: string;
  sms_enabled: boolean;
  push_enabled: boolean;
  notify_emergency: boolean;
  notify_messages: boolean;
  notify_reminders: boolean;
  notify_daily_summary: boolean;
  daily_summary_time: string;
}

const defaults: Prefs = {
  email: "",
  email_enabled: true,
  phone: "",
  sms_enabled: false,
  push_enabled: false,
  notify_emergency: true,
  notify_messages: true,
  notify_reminders: true,
  notify_daily_summary: true,
  daily_summary_time: "19:00",
};

const phoneIsValid = (v: string) => v.replace(/\D/g, "").length >= 10;

const browserTimezone = () => {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone || "America/New_York";
  } catch {
    return "America/New_York";
  }
};

export const NotificationSettings = ({ userId, role }: NotificationSettingsProps) => {
  const { toast } = useToast();
  const [prefs, setPrefs] = useState<Prefs>(defaults);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [sendingSummary, setSendingSummary] = useState(false);
  const [enablingDevice, setEnablingDevice] = useState(false);
  const [deviceReady, setDeviceReady] = useState(false);

  const turnOnThisDevice = async () => {
    setEnablingDevice(true);
    const result = await enablePush(userId);
    setEnablingDevice(false);

    if (result.status === "registered") {
      setDeviceReady(true);
      setPrefs((p) => ({ ...p, push_enabled: true }));
      await supabase.from("notification_preferences").upsert(
        { user_id: userId!, push_enabled: true, daily_summary_timezone: browserTimezone() },
        { onConflict: "user_id" },
      );
      toast({
        title: "This device is set up",
        description: "Alerts will now pop up on this device the moment they happen.",
      });
      return;
    }

    const messages: Record<string, string> = {
      "not-configured":
        "Pop-up alerts aren't switched on for Reli yet. You'll still get emails and texts.",
      unsupported: "This browser can't show pop-up alerts. Try Chrome on Android, or the Reli app.",
      "open-in-new-tab":
        "Open Reli in its own browser tab (or use the installed app) and try again — the preview window can't ask for permission.",
      denied:
        "Your browser blocked alerts. Allow notifications for Reli in your browser's site settings, then try again.",
      failed: "Something went wrong setting up this device. Please try again in a moment.",
    };
    toast({
      title: "Not set up yet",
      description: messages[result.status] ?? messages.failed,
      variant: "destructive",
    });
  };

  const sendSummaryNow = async () => {
    setSendingSummary(true);
    const { data, error } = await supabase.functions.invoke("send-daily-summaries", { body: {} });
    setSendingSummary(false);
    if (error) {
      toast({ title: "Could not send", description: error.message, variant: "destructive" });
      return;
    }
    if (data && (data as any).sent === false) {
      toast({
        title: "Nothing sent",
        description: "Turn on email alerts and the daily summary, then save your settings first.",
      });
      return;
    }
    toast({ title: "Summary sent", description: "Check your inbox in a moment." });
  };

  useEffect(() => {
    if (!userId) return;
    const load = async () => {
      const [{ data: row }, { data: profile }] = await Promise.all([
        supabase
          .from("notification_preferences")
          .select(
            "email, email_enabled, phone, sms_enabled, push_enabled, notify_emergency, notify_messages, notify_reminders, notify_daily_summary, daily_summary_time",
          )
          .eq("user_id", userId)
          .maybeSingle(),
        supabase.from("profiles").select("email, phone").eq("id", userId).maybeSingle(),
      ]);
      setPrefs({
        email: row?.email || profile?.email || "",
        email_enabled: row?.email_enabled ?? true,
        phone: row?.phone || profile?.phone || "",
        sms_enabled: row?.sms_enabled ?? false,
        push_enabled: row?.push_enabled ?? false,
        notify_emergency: row?.notify_emergency ?? true,
        notify_messages: row?.notify_messages ?? true,
        notify_reminders: row?.notify_reminders ?? true,
        notify_daily_summary: row?.notify_daily_summary ?? true,
        daily_summary_time: (row?.daily_summary_time || "19:00").slice(0, 5),
      });
      setLoading(false);
    };
    load();
  }, [userId]);

  const save = async () => {
    if (!userId) return;
    const email = prefs.email.trim();
    if (prefs.email_enabled && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      toast({ title: "Check the email address", description: "Please enter a valid email address.", variant: "destructive" });
      return;
    }
    const phone = prefs.phone.trim();
    if (prefs.sms_enabled && !phoneIsValid(phone)) {
      toast({
        title: "Check the phone number",
        description: "Please enter a mobile number that can receive text messages.",
        variant: "destructive",
      });
      return;
    }
    setSaving(true);
    const { error } = await supabase
      .from("notification_preferences")
      .upsert(
        {
          user_id: userId,
          email,
          email_enabled: prefs.email_enabled,
          phone,
          sms_enabled: prefs.sms_enabled,
          push_enabled: prefs.push_enabled,
          notify_emergency: prefs.notify_emergency,
          notify_messages: prefs.notify_messages,
          notify_reminders: prefs.notify_reminders,
          notify_daily_summary: prefs.notify_daily_summary,
          daily_summary_time: prefs.daily_summary_time,
          daily_summary_timezone: browserTimezone(),
        },
        { onConflict: "user_id" },
      );
    setSaving(false);
    if (error) {
      toast({ title: "Could not save", description: error.message, variant: "destructive" });
      return;
    }
    toast({ title: "Saved", description: "Your alert settings are updated." });
  };

  if (loading) return null;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-xl">
          <Bell className="h-5 w-5 text-primary" />
          Alerts
        </CardTitle>
        <CardDescription>
          Choose where your alerts should go — email, text message, or both — and what you
          want to hear about.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="space-y-2">
          <Label htmlFor="notify-email">Send alerts to</Label>
          <Input
            id="notify-email"
            type="email"
            value={prefs.email}
            onChange={(e) => setPrefs({ ...prefs, email: e.target.value })}
            placeholder="you@example.com"
            className="text-base"
          />
        </div>

        <div className="flex items-center justify-between gap-4">
          <Label htmlFor="notify-email-enabled" className="text-base">Turn email alerts on</Label>
          <Switch
            id="notify-email-enabled"
            checked={prefs.email_enabled}
            onCheckedChange={(v) => setPrefs({ ...prefs, email_enabled: v })}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="notify-phone">Text alerts to (mobile number)</Label>
          <Input
            id="notify-phone"
            type="tel"
            value={prefs.phone}
            onChange={(e) => setPrefs({ ...prefs, phone: e.target.value })}
            placeholder="(555) 123-4567"
            className="text-base"
          />
        </div>

        <div className="flex items-center justify-between gap-4">
          <Label htmlFor="notify-sms-enabled" className="text-base">Turn text alerts on</Label>
          <Switch
            id="notify-sms-enabled"
            checked={prefs.sms_enabled}
            onCheckedChange={(v) => setPrefs({ ...prefs, sms_enabled: v })}
          />
        </div>

        <div className="space-y-3 rounded-lg border p-4">
          <div className="flex items-center justify-between gap-4">
            <Label htmlFor="notify-push-enabled" className="text-base">
              Pop-up alerts on my phone and computer
            </Label>
            <Switch
              id="notify-push-enabled"
              checked={prefs.push_enabled}
              onCheckedChange={(v) => setPrefs({ ...prefs, push_enabled: v })}
            />
          </div>
          <p className="text-sm text-muted-foreground">
            These arrive the second something happens, even when Reli is closed. Set this up on
            each device you want alerts on.
          </p>
          <Button
            type="button"
            variant="outline"
            onClick={turnOnThisDevice}
            disabled={enablingDevice || !pushIsConfigured()}
            className="w-full sm:w-auto"
          >
            {enablingDevice ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <BellRing className="mr-2 h-4 w-4" />
            )}
            {deviceReady ? "This device is set up" : "Turn on alerts on this device"}
          </Button>
          {!pushIsConfigured() && (
            <p className="text-sm text-muted-foreground">
              Pop-up alerts aren't switched on for Reli yet — email and text alerts still work.
            </p>
          )}
        </div>

        <div className="space-y-4 rounded-lg border p-4">
          <p className="text-sm text-muted-foreground">
            These choices apply to email, text and pop-up alerts.
          </p>
          <div className="flex items-center justify-between gap-4">
            <Label htmlFor="notify-emergency" className="text-base">
              {role === "caregiver" ? "Emergency alerts from your seniors" : "Emergency alerts"}
            </Label>
            <Switch
              id="notify-emergency"
              checked={prefs.notify_emergency}
              onCheckedChange={(v) => setPrefs({ ...prefs, notify_emergency: v })}
            />
          </div>
          <div className="flex items-center justify-between gap-4">
            <Label htmlFor="notify-messages" className="text-base">New messages</Label>
            <Switch
              id="notify-messages"
              checked={prefs.notify_messages}
              onCheckedChange={(v) => setPrefs({ ...prefs, notify_messages: v })}
            />
          </div>
          <div className="flex items-center justify-between gap-4">
            <Label htmlFor="notify-reminders" className="text-base">Medication and reading reminders</Label>
            <Switch
              id="notify-reminders"
              checked={prefs.notify_reminders}
              onCheckedChange={(v) => setPrefs({ ...prefs, notify_reminders: v })}
            />
          </div>
          <div className="flex items-center justify-between gap-4">
            <Label htmlFor="notify-daily-summary" className="text-base">
              Daily summary of the day
            </Label>
            <Switch
              id="notify-daily-summary"
              checked={prefs.notify_daily_summary}
              onCheckedChange={(v) => setPrefs({ ...prefs, notify_daily_summary: v })}
            />
          </div>
          {prefs.notify_daily_summary && (
            <div className="space-y-2">
              <Label htmlFor="daily-summary-time">Send the daily summary at</Label>
              <Input
                id="daily-summary-time"
                type="time"
                value={prefs.daily_summary_time}
                onChange={(e) => setPrefs({ ...prefs, daily_summary_time: e.target.value })}
                className="w-40 text-base"
              />
              <p className="text-sm text-muted-foreground">
                Your local time. The summary covers medications, blood pressure, heart rate,
                daily log and journal for that day.
              </p>
            </div>
          )}
        </div>

        <div className="flex flex-col gap-3 sm:flex-row">
          <Button onClick={save} disabled={saving} className="w-full sm:w-auto">
            {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            Save alert settings
          </Button>
          <Button
            variant="outline"
            onClick={sendSummaryNow}
            disabled={sendingSummary}
            className="w-full sm:w-auto"
          >
            {sendingSummary ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            Send me a summary now
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};
