CREATE TABLE public.store_entitlements (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  store text NOT NULL,
  product_id text,
  active boolean NOT NULL DEFAULT false,
  expires_at timestamptz,
  last_event_id text,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.store_entitlements TO authenticated;
GRANT ALL ON public.store_entitlements TO service_role;
ALTER TABLE public.store_entitlements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users view own store subscription" ON public.store_entitlements
  FOR SELECT TO authenticated USING (user_id = auth.uid());

CREATE OR REPLACE FUNCTION public.has_store_premium(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM store_entitlements WHERE user_id = _user_id AND active
    AND (expires_at IS NULL OR expires_at > now()))
$$;