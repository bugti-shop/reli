-- Add RESTRICTIVE policy to profiles to require authentication for viewing
-- This ensures anonymous users cannot read any profile data
CREATE POLICY "Require authentication for viewing profiles"
  ON public.profiles
  AS RESTRICTIVE
  FOR SELECT
  TO public
  USING (auth.uid() IS NOT NULL);

-- Add INSERT policy to profiles for defense-in-depth (alongside trigger)
CREATE POLICY "Users can insert their own profile"
  ON public.profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Add RESTRICTIVE policy to life_story_entries to require authentication
CREATE POLICY "Require authentication for viewing life stories"
  ON public.life_story_entries
  AS RESTRICTIVE
  FOR SELECT
  TO public
  USING (auth.uid() IS NOT NULL);

-- Add RESTRICTIVE policy to newsletter_subscribers for SELECT only
-- Note: INSERT remains open for anonymous newsletter signups
CREATE POLICY "Require authentication for viewing subscribers"
  ON public.newsletter_subscribers
  AS RESTRICTIVE
  FOR SELECT
  TO public
  USING (auth.uid() IS NOT NULL);