import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2, Edit2, Check, X, ClipboardList, Eye, EyeOff, CheckCircle2, Circle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface CustomTrackerItem {
  id: string;
  owner_id: string;
  name: string;
  value: string | null;
  tracker_type: string;
  shared_with_senior: boolean;
  created_by_role: string;
  created_at: string;
  updated_at: string;
  completed: boolean;
  completed_at: string | null;
}

interface CustomTrackerProps {
  userId: string;
  userRole: "senior" | "caregiver";
  seniorId?: string; // Only needed for caregivers
  seniorName?: string;
}

export const CustomTracker = ({ userId, userRole, seniorId, seniorName }: CustomTrackerProps) => {
  const [trackers, setTrackers] = useState<CustomTrackerItem[]>([]);
  const [newName, setNewName] = useState("");
  const [newValue, setNewValue] = useState("");
  const [newType, setNewType] = useState("text");
  const [shareWithSenior, setShareWithSenior] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState("");
  const [isAdding, setIsAdding] = useState(false);
  const { toast } = useToast();

  const targetSeniorId = userRole === "senior" ? userId : seniorId;

  useEffect(() => {
    if (targetSeniorId) {
      fetchTrackers();
    }
  }, [targetSeniorId, userId]);

  const fetchTrackers = async () => {
    if (!targetSeniorId) return;

    const { data, error } = await supabase
      .from("custom_trackers")
      .select("*")
      .eq("senior_id", targetSeniorId)
      .order("created_at", { ascending: false });

    if (error) {
      console.error("Error fetching trackers:", error);
      return;
    }

    setTrackers(data || []);
  };

  const handleAddTracker = async () => {
    if (!newName.trim() || !targetSeniorId) return;

    const { error } = await supabase.from("custom_trackers").insert({
      owner_id: userId,
      senior_id: targetSeniorId,
      name: newName.trim(),
      value: newValue.trim() || null,
      tracker_type: newType,
      shared_with_senior: userRole === "senior" ? true : shareWithSenior,
      created_by_role: userRole,
    });

    if (error) {
      console.error("Error adding tracker:", error);
      toast({
        title: "Error",
        description: "Failed to add tracker. Please try again.",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Tracker Added",
      description: `"${newName}" has been created.`,
    });

    setNewName("");
    setNewValue("");
    setNewType("text");
    setShareWithSenior(false);
    setIsAdding(false);
    fetchTrackers();
  };

  const handleUpdateValue = async (id: string, newValue?: string) => {
    const { error } = await supabase
      .from("custom_trackers")
      .update({ value: newValue !== undefined ? newValue : editValue })
      .eq("id", id);

    if (error) {
      console.error("Error updating tracker:", error);
      toast({
        title: "Error",
        description: "Failed to update. Please try again.",
        variant: "destructive",
      });
      return;
    }

    setEditingId(null);
    setEditValue("");
    fetchTrackers();
  };

  const handleToggleCheckbox = async (tracker: CustomTrackerItem) => {
    const currentValue = tracker.value === "true";
    await handleUpdateValue(tracker.id, (!currentValue).toString());
  };

  const handleToggleCompleted = async (tracker: CustomTrackerItem) => {
    const newCompleted = !tracker.completed;
    const { error } = await supabase
      .from("custom_trackers")
      .update({ 
        completed: newCompleted,
        completed_at: newCompleted ? new Date().toISOString() : null
      })
      .eq("id", tracker.id);

    if (error) {
      console.error("Error toggling completed:", error);
      toast({
        title: "Error",
        description: "Failed to update. Please try again.",
        variant: "destructive",
      });
      return;
    }

    fetchTrackers();
  };

  const handleToggleShare = async (id: string, currentShare: boolean) => {
    const { error } = await supabase
      .from("custom_trackers")
      .update({ shared_with_senior: !currentShare })
      .eq("id", id);

    if (error) {
      console.error("Error toggling share:", error);
      return;
    }

    fetchTrackers();
  };

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from("custom_trackers").delete().eq("id", id);

    if (error) {
      console.error("Error deleting tracker:", error);
      toast({
        title: "Error",
        description: "Failed to delete. Please try again.",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Deleted",
      description: "Tracker removed successfully.",
    });
    fetchTrackers();
  };

  const canEdit = (tracker: CustomTrackerItem) => {
    if (userRole === "senior") {
      return tracker.created_by_role === "senior";
    }
    return tracker.created_by_role === "caregiver" && tracker.owner_id === userId;
  };

  const canDelete = (tracker: CustomTrackerItem) => canEdit(tracker);

  // Filter trackers based on role and visibility
  const visibleTrackers = trackers.filter((tracker) => {
    if (userRole === "caregiver") return true; // Caregivers see all
    // Seniors see their own + shared ones
    return tracker.created_by_role === "senior" || tracker.shared_with_senior;
  });

  return (
    <Card className="rounded-xl border bg-card p-4 shadow-sm sm:p-5">
      <div className="mb-4 flex items-center justify-between gap-3">
        <h2 className="flex items-center gap-3 text-xl font-bold sm:text-2xl">
          <span className="flex h-11 w-11 items-center justify-center rounded-full bg-dashboard-sky text-primary"><ClipboardList className="h-6 w-6" /></span>
          Custom Trackers
        </h2>
        {!isAdding && (
          <Button onClick={() => setIsAdding(true)} size="sm" className="gap-2">
            <Plus className="w-4 h-4" />
            Add New
          </Button>
        )}
      </div>

      {/* Add New Tracker Form */}
      {isAdding && (
        <div className="mb-4 rounded-xl bg-dashboard-sky/45 p-4">
          <div className="space-y-4">
            <div>
              <Label htmlFor="trackerName" className="text-lg">
                Tracker Name
              </Label>
              <Input
                id="trackerName"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="e.g., Blood Pressure, Mood, Water Intake"
                className="text-lg h-12"
              />
            </div>

            <div>
              <Label htmlFor="trackerType" className="text-lg">
                Type
              </Label>
              <Select value={newType} onValueChange={setNewType}>
                <SelectTrigger className="text-lg h-12">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="text">Text</SelectItem>
                  <SelectItem value="number">Number</SelectItem>
                  <SelectItem value="note">Long Note</SelectItem>
                  <SelectItem value="checkbox">Checkbox</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="initialValue" className="text-lg">
                Initial Value (optional)
              </Label>
              {newType === "note" ? (
                <Textarea
                  id="initialValue"
                  value={newValue}
                  onChange={(e) => setNewValue(e.target.value)}
                  placeholder="Enter initial value..."
                  className="text-lg min-h-[100px]"
                />
              ) : (
                <Input
                  id="initialValue"
                  type={newType === "number" ? "number" : "text"}
                  value={newValue}
                  onChange={(e) => setNewValue(e.target.value)}
                  placeholder="Enter initial value..."
                  className="text-lg h-12"
                />
              )}
            </div>

            {userRole === "caregiver" && (
              <div className="flex items-center gap-3 p-3 bg-secondary/30 rounded-lg">
                <Switch
                  id="shareWithSenior"
                  checked={shareWithSenior}
                  onCheckedChange={setShareWithSenior}
                />
                <Label htmlFor="shareWithSenior" className="text-lg cursor-pointer">
                  {shareWithSenior ? (
                    <span className="flex items-center gap-2">
                      <Eye className="w-5 h-5 text-primary" />
                      Visible to {seniorName || "senior"}
                    </span>
                  ) : (
                    <span className="flex items-center gap-2">
                      <EyeOff className="w-5 h-5 text-muted-foreground" />
                      Only visible to you
                    </span>
                  )}
                </Label>
              </div>
            )}

            <div className="flex gap-2">
              <Button onClick={handleAddTracker} className="flex-1">
                <Check className="w-4 h-4 mr-2" />
                Save Tracker
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setIsAdding(false);
                  setNewName("");
                  setNewValue("");
                  setNewType("text");
                  setShareWithSenior(false);
                }}
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Trackers List */}
      <div className="space-y-3">
        {visibleTrackers.length === 0 ? (
          <p className="py-8 text-center text-base text-muted-foreground">
            No custom trackers yet. Add one to get started.
          </p>
        ) : (
          visibleTrackers.map((tracker) => (
            <div
              key={tracker.id}
              className={`border-t px-1 py-4 transition-opacity first:border-t-0 ${tracker.completed ? "opacity-70" : ""}`}
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                <div className="flex-1 flex items-start gap-3">
                  {/* Completion toggle */}
                  <button
                    onClick={() => handleToggleCompleted(tracker)}
                    className="mt-1 flex-shrink-0 transition-colors hover:text-primary"
                    aria-label={tracker.completed ? `Mark ${tracker.name} incomplete` : `Mark ${tracker.name} complete`}
                    title={tracker.completed ? "Mark as incomplete" : "Mark as complete"}
                  >
                    {tracker.completed ? (
                      <CheckCircle2 className="w-6 h-6 text-green-600 dark:text-green-500" />
                    ) : (
                      <Circle className="w-6 h-6 text-muted-foreground" />
                    )}
                  </button>
                  
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className={`text-xl font-semibold text-foreground ${tracker.completed ? "line-through text-muted-foreground" : ""}`}>
                        {tracker.name}
                      </h3>
                      {tracker.completed && (
                        <span className="text-xs px-2 py-0.5 rounded-full bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400">
                          Done
                        </span>
                      )}
                      {userRole === "caregiver" && tracker.created_by_role === "caregiver" && (
                        <span className="text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary">
                          {tracker.shared_with_senior ? "Shared" : "Private"}
                        </span>
                      )}
                      {tracker.created_by_role === "senior" && userRole === "caregiver" && (
                        <span className="text-xs px-2 py-0.5 rounded-full bg-accent/20 text-accent-foreground">
                          From {seniorName || "Senior"}
                        </span>
                      )}
                    </div>

                  {editingId === tracker.id ? (
                    <div className="flex items-center gap-2">
                      {tracker.tracker_type === "note" ? (
                        <Textarea
                          value={editValue}
                          onChange={(e) => setEditValue(e.target.value)}
                          className="text-lg min-h-[80px]"
                        />
                      ) : (
                        <Input
                          type={tracker.tracker_type === "number" ? "number" : "text"}
                          value={editValue}
                          onChange={(e) => setEditValue(e.target.value)}
                          className="text-lg h-10"
                        />
                      )}
                      <Button size="sm" onClick={() => handleUpdateValue(tracker.id)}>
                        <Check className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => {
                          setEditingId(null);
                          setEditValue("");
                        }}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  ) : tracker.tracker_type === "checkbox" ? (
                    <div className="flex items-center gap-3">
                      <Checkbox
                        id={`checkbox-${tracker.id}`}
                        checked={tracker.value === "true"}
                        onCheckedChange={() => handleToggleCheckbox(tracker)}
                        className="h-6 w-6"
                      />
                      <Label
                        htmlFor={`checkbox-${tracker.id}`}
                        className={`text-lg cursor-pointer ${
                          tracker.value === "true" ? "line-through text-muted-foreground" : ""
                        }`}
                      >
                        {tracker.value === "true" ? "Completed" : "Not completed"}
                      </Label>
                    </div>
                  ) : (
                    <p className="text-lg text-foreground/80">
                      {tracker.value || (
                        <span className="text-muted-foreground italic">No value set</span>
                      )}
                    </p>
                  )}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {userRole === "caregiver" &&
                    tracker.created_by_role === "caregiver" &&
                    tracker.owner_id === userId && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleToggleShare(tracker.id, tracker.shared_with_senior)}
                        title={tracker.shared_with_senior ? "Hide from senior" : "Share with senior"}
                      >
                        {tracker.shared_with_senior ? (
                          <Eye className="w-4 h-4 text-primary" />
                        ) : (
                          <EyeOff className="w-4 h-4 text-muted-foreground" />
                        )}
                      </Button>
                    )}

                  {canEdit(tracker) && editingId !== tracker.id && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setEditingId(tracker.id);
                        setEditValue(tracker.value || "");
                      }}
                    >
                      <Edit2 className="w-4 h-4" />
                    </Button>
                  )}

                  {canDelete(tracker) && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-destructive hover:text-destructive"
                      onClick={() => handleDelete(tracker.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              </div>

              <p className="text-xs text-muted-foreground mt-2">
                Last updated: {new Date(tracker.updated_at).toLocaleString()}
              </p>
            </div>
          ))
        )}
      </div>
    </Card>
  );
};
