import { useEffect } from "react";

const SCROLL_HIDE_DELAY = 1000;

export function useMobileScrollbar() {
  useEffect(() => {
    const isTouch = window.matchMedia("(hover: none) and (pointer: coarse)").matches;
    if (!isTouch) return;

    let scrollTimer: number | null = null;

    const showScrollbar = () => {
      document.documentElement.classList.add("mobile-scrollbar-visible");
      if (scrollTimer) window.clearTimeout(scrollTimer);
      scrollTimer = window.setTimeout(() => {
        document.documentElement.classList.remove("mobile-scrollbar-visible");
      }, SCROLL_HIDE_DELAY);
    };

    const events = ["scroll", "touchmove"] as const;
    events.forEach((event) => window.addEventListener(event, showScrollbar, { passive: true }));
    showScrollbar();

    return () => {
      events.forEach((event) => window.removeEventListener(event, showScrollbar));
      if (scrollTimer) window.clearTimeout(scrollTimer);
      document.documentElement.classList.remove("mobile-scrollbar-visible");
    };
  }, []);
}
