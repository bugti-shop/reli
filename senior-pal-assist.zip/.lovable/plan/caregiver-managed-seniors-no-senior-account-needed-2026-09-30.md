# Caregiver-managed seniors (no senior account needed)

## What changes for users
- On the caregiver dashboard, "Add Senior" gets a second option: **"Add someone without an account"**. The caregiver enters name, and optionally age, phone, address and emergency contacts.
- That senior then shows up in the senior switcher like any other. Every caregiver tool works for them: medications and reminders, BP/HR and history, custom trackers, daily log, doctor questions, shared reports, PDFs, the activity feed and health trends.
- A small "Managed by you" badge marks these seniors. Tools the senior would use themselves (messages to the senior, SOS, trivia, companion, journal, Life Story) are hidden or read "Senior has no app account yet".
- **Connect later:** the caregiver can hit "Invite senior to use the app" and enter the senior's email. The senior gets an email to set a password. After that it becomes a normal linked account, and all history, meds and messages stay in place.
- **Other family:** the managing caregiver can still share the Family Circle invite code, so a second caregiver can help manage the same senior.
- Normal senior accounts and linking by email or code keep working exactly as they do now.
- The free plan limit (2 seniors per caregiver) still applies. Premium removes the limit.

## Technical details
- New backend function `create-managed-senior`, which runs only for signed-in caregivers:
  - It creates a real sign-in user with a placeholder address (`managed+<uuid>@reli.care`), no password and the role `senior`, so `handle_new_user` creates the profile.
  - It then adds the `caregiver_seniors` link. Because this is a real user id, every existing access rule, foreign key, reminder sender and report works unchanged.
- Migration:
  - New columns on `profiles`: `managed boolean default false` and `managed_by uuid`.
  - `add_senior_by_email` and the email lookups skip rows marked `managed`.
- New backend function `claim-managed-senior`:
  - Checks that the caller is linked to the senior and that the email is unused.
  - Updates the sign-in email, sets `managed=false`, and sends a password-set (recovery) email through the existing Reli email templates.
- Reminder, daily summary and emergency email senders skip placeholder addresses (`managed=true`), so no mail is sent to fake addresses.
- UI changes:
  - `CaregiverDashboard.tsx`: the add dialog gets tabs, a badge, feature gating for managed seniors, and an "Invite to app" dialog.
  - The senior-only feature toggles are hidden for managed seniors.
- `AGENTS.md` gets a rule: managed seniors are placeholder sign-in users, so all access rules are reused.
