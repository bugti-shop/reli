import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  BookOpen,
  ChevronDown,
  ChevronUp,
  Download,
  ImagePlus,
  Loader2,
  Save,
  Share2,
  Sparkles,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { VoiceInput } from "@/components/VoiceInput";
import { jsPDF } from "jspdf";
import { LifeStoryMemories, LifeMemory, MEMORY_CONFIG, MemoryCategory } from "@/components/LifeStoryMemories";

const LIFE_STORY_PROMPTS = [
  "What is your earliest childhood memory?",
  "Who was your best friend growing up and what did you do together?",
  "What was your favorite family tradition?",
  "Tell me about a teacher who made a difference in your life.",
  "What was your first job and what did you learn from it?",
  "Describe the house you grew up in.",
  "What was your proudest moment?",
  "Tell me about a trip that changed your perspective.",
  "What advice would you give to your younger self?",
  "Who was the most influential person in your life and why?",
  "What was the happiest day of your life?",
  "Describe a challenge you overcame and how it shaped you.",
  "What family recipe has been passed down through generations?",
  "Tell me about your wedding day or a special celebration.",
  "Describe your favorite holiday memory.",
  "Tell me about a pet that was special to you.",
  "What song always brings back memories?",
  "Describe a family gathering you'll never forget.",
  "What lesson did your parents teach you that stuck with you?",
  "Tell me about a place that feels like home.",
  "What hobby or passion has brought you the most joy?",
  "Tell me about a moment that made you laugh until you cried.",
];

const getTodaysPrompt = () => {
  const today = new Date();
  const day = Math.floor((today.getTime() - new Date(today.getFullYear(), 0, 0).getTime()) / 86400000);
  return LIFE_STORY_PROMPTS[day % LIFE_STORY_PROMPTS.length];
};

interface LifeStoryEntry {
  id: string;
  prompt: string;
  response: string | null;
  prompt_date: string;
  image_path: string | null;
  imageUrl?: string | null;
}

const toDataUrl = async (url: string) => {
  const blob = await (await fetch(url)).blob();
  return await new Promise<string>((resolve) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.readAsDataURL(blob);
  });
};

const memoryText = (memory: LifeMemory) => MEMORY_CONFIG[memory.category].fields
  .filter((field) => memory.details?.[field.key])
  .map((field) => `${field.label}: ${memory.details[field.key]}`)
  .join("\n");

const addImageToPdf = async (doc: jsPDF, imageUrl: string | null | undefined, x: number, y: number) => {
  if (!imageUrl) return 0;
  try {
    const data = await toDataUrl(imageUrl);
    const props = doc.getImageProperties(data);
    const width = 80;
    const height = Math.min(90, (props.height / props.width) * width);
    doc.addImage(data, props.fileType || "JPEG", x, y, width, height);
    return height + 10;
  } catch (error) {
    console.error("Could not add Life Story image to PDF", error);
    return 0;
  }
};

export const LifeStoryPrompt = () => {
  const { toast } = useToast();
  const [todaysEntry, setTodaysEntry] = useState<LifeStoryEntry | null>(null);
  const [pastEntries, setPastEntries] = useState<LifeStoryEntry[]>([]);
  const [memories, setMemories] = useState<LifeMemory[]>([]);
  const [expanded, setExpanded] = useState<"today" | MemoryCategory | null>(null);
  const [todayEditorOpen, setTodayEditorOpen] = useState(false);
  const [response, setResponse] = useState("");
  const [todayImage, setTodayImage] = useState<File | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isExporting, setIsExporting] = useState(false);

  const todaysPrompt = getTodaysPrompt();
  const todayString = new Date().toISOString().split("T")[0];

  const signEntryImages = async (entries: LifeStoryEntry[]) => Promise.all(entries.map(async (entry) => {
    if (!entry.image_path) return { ...entry, imageUrl: null };
    const { data } = await supabase.storage.from("life-story-images").createSignedUrl(entry.image_path, 3600);
    return { ...entry, imageUrl: data?.signedUrl ?? null };
  }));

  const fetchEntries = async () => {
    setIsLoading(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { setIsLoading(false); return; }
    const { data } = await supabase
      .from("life_story_entries")
      .select("*")
      .eq("senior_id", user.id)
      .order("prompt_date", { ascending: false });
    const entries = await signEntryImages((data || []) as LifeStoryEntry[]);
    const today = entries.find((entry) => entry.prompt_date === todayString) || null;
    setTodaysEntry(today);
    setResponse(today?.response || "");
    setPastEntries(entries.filter((entry) => entry.prompt_date !== todayString && entry.response));
    setIsLoading(false);
  };

  useEffect(() => { void fetchEntries(); }, []);

  const openTodayEditor = () => {
    setExpanded("today");
    setTodayImage(null);
    setTodayEditorOpen(true);
  };

  const handleSave = async () => {
    if (!response.trim()) {
      toast({ title: "Please write something", description: "Share your story before saving.", variant: "destructive" });
      return;
    }
    setIsSaving(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      let imagePath = todaysEntry?.image_path ?? null;
      if (todayImage) {
        const ext = todayImage.name.split(".").pop() || "jpg";
        const path = `${user.id}/${crypto.randomUUID()}.${ext}`;
        const { error: uploadError } = await supabase.storage.from("life-story-images").upload(path, todayImage);
        if (uploadError) throw uploadError;
        if (imagePath) await supabase.storage.from("life-story-images").remove([imagePath]);
        imagePath = path;
      }
      const payload = { response: response.trim(), image_path: imagePath };
      const { error } = todaysEntry
        ? await supabase.from("life_story_entries").update(payload).eq("id", todaysEntry.id)
        : await supabase.from("life_story_entries").insert({ senior_id: user.id, prompt: todaysPrompt, prompt_date: todayString, ...payload });
      if (error) throw error;
      toast({ title: "Story saved!", description: "Your memory has been preserved." });
      setTodayEditorOpen(false);
      await fetchEntries();
    } catch (error) {
      console.error(error);
      toast({ title: "Could not save", description: "Please try again.", variant: "destructive" });
    } finally {
      setIsSaving(false);
    }
  };

  const allStories = [...pastEntries, ...(todaysEntry?.response ? [todaysEntry] : [])]
    .sort((a, b) => new Date(a.prompt_date).getTime() - new Date(b.prompt_date).getTime());
  const hasContent = allStories.length > 0 || memories.length > 0;

  const exportToPDF = async () => {
    if (!hasContent) {
      toast({ title: "No stories yet", description: "Add a story first, then export.", variant: "destructive" });
      return;
    }
    setIsExporting(true);
    try {
      const doc = new jsPDF();
      const width = doc.internal.pageSize.getWidth();
      const height = doc.internal.pageSize.getHeight();
      const margin = 20;
      const maxWidth = width - margin * 2;
      doc.setFont("helvetica", "bold");
      doc.setFontSize(28);
      doc.text("My Life Story", width / 2, height / 2 - 10, { align: "center" });
      doc.setFont("helvetica", "normal");
      doc.setFontSize(13);
      doc.text(`Created ${new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })}`, width / 2, height / 2 + 15, { align: "center" });

      for (const entry of allStories) {
        doc.addPage();
        let y = margin;
        doc.setFontSize(11);
        doc.setTextColor(100, 100, 100);
        doc.text(new Date(entry.prompt_date).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" }), margin, y);
        y += 12;
        doc.setFont("helvetica", "bold");
        doc.setFontSize(16);
        doc.setTextColor(38, 69, 105);
        const promptLines = doc.splitTextToSize(entry.prompt, maxWidth);
        doc.text(promptLines, margin, y);
        y += promptLines.length * 8 + 8;
        y += await addImageToPdf(doc, entry.imageUrl, margin, y);
        doc.setFont("helvetica", "normal");
        doc.setFontSize(12);
        doc.setTextColor(20, 20, 20);
        for (const line of doc.splitTextToSize(entry.response || "", maxWidth)) {
          if (y > height - margin) { doc.addPage(); y = margin; }
          doc.text(line, margin, y);
          y += 7;
        }
      }

      for (const memory of memories) {
        doc.addPage();
        let y = margin;
        doc.setFont("helvetica", "bold");
        doc.setFontSize(18);
        doc.setTextColor(38, 69, 105);
        doc.text(MEMORY_CONFIG[memory.category].title, margin, y);
        y += 12 + await addImageToPdf(doc, memory.imageUrl, margin, y + 2);
        doc.setFont("helvetica", "normal");
        doc.setFontSize(12);
        doc.setTextColor(20, 20, 20);
        for (const line of doc.splitTextToSize(memoryText(memory), maxWidth)) {
          if (y > height - margin) { doc.addPage(); y = margin; }
          doc.text(line, margin, y);
          y += 7;
        }
      }
      doc.save("My_Life_Story.pdf");
      toast({ title: "PDF exported", description: "Your complete Life Story has been downloaded." });
    } catch (error) {
      console.error(error);
      toast({ title: "Export failed", description: "Please try again.", variant: "destructive" });
    } finally {
      setIsExporting(false);
    }
  };

  const shareStories = async () => {
    if (!hasContent) return;
    const text = allStories
      .map((entry) => `${entry.prompt}\n${entry.response}`)
      .concat(memories.map((memory) => `${MEMORY_CONFIG[memory.category].title}\n${memoryText(memory)}`))
      .join("\n\n---\n\n");
    const shareData = { title: "My Life Story", text };
    if (navigator.share && navigator.canShare?.(shareData)) {
      try { await navigator.share(shareData); return; } catch (error) { if ((error as Error).name === "AbortError") return; }
    }
    try {
      await navigator.clipboard.writeText(text);
      toast({ title: "Copied!", description: "Your stories are ready to paste and share." });
    } catch {
      toast({ title: "Sharing not supported", description: "Please export the PDF instead.", variant: "destructive" });
    }
  };

  if (isLoading) return <div className="flex min-h-72 items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;

  return (
    <div className="mx-auto flex min-h-[calc(100dvh-15rem)] w-full max-w-2xl flex-col rounded-lg bg-background px-1 pb-2 sm:px-3">
      <div className="mb-3 text-center">
        <div className="flex items-center justify-center gap-3 text-primary"><span className="h-px w-12 bg-primary" /><BookOpen className="h-5 w-5" /><span className="h-px w-12 bg-primary" /></div>
        <h2 className="mt-1 text-2xl font-bold text-foreground sm:text-3xl">My Special Memories</h2>
      </div>

      <div className="space-y-2.5">
        <section className="overflow-hidden rounded-lg border bg-card shadow-sm">
          <Button variant="ghost" onClick={() => setExpanded(expanded === "today" ? null : "today")} className="h-16 w-full justify-start rounded-none px-4 hover:bg-muted/60">
            <Sparkles className="mr-3 h-6 w-6 shrink-0 text-primary" />
            <span className="min-w-0 flex-1 text-left text-base font-bold">Today's Story</span>
            {todaysEntry?.response && <span className="mr-2 flex h-7 min-w-7 items-center justify-center rounded-full bg-primary/10 px-2 text-sm font-bold text-primary">1</span>}
            {expanded === "today" ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
          </Button>
          {expanded === "today" && (
            <div className="border-t px-4 pb-4 pt-3">
              <p className="line-clamp-2 text-sm font-semibold text-foreground">{todaysPrompt}</p>
              {todaysEntry?.imageUrl && <img src={todaysEntry.imageUrl} alt="Today's memory" className="mt-3 h-20 w-20 rounded-full object-cover" />}
              {todaysEntry?.response && <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">{todaysEntry.response}</p>}
              <Button variant="outline" size="sm" onClick={openTodayEditor} className="mt-3 w-full border-primary/40 text-primary">
                <ImagePlus className="mr-2 h-4 w-4" /> {todaysEntry ? "Edit Today's Story" : "Add Today's Story"}
              </Button>
            </div>
          )}
        </section>

        <LifeStoryMemories onChange={setMemories} expanded={expanded} onExpandedChange={setExpanded} onAddToday={openTodayEditor} />
      </div>

      <div className="mt-auto grid grid-cols-2 gap-2 pt-3">
        <Button onClick={() => void exportToPDF()} disabled={isExporting || !hasContent} variant="outline" className="min-h-12 whitespace-normal border-primary text-sm font-bold text-primary">
          {isExporting ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : <Download className="mr-2 h-5 w-5" />} Export PDF
        </Button>
        <Button onClick={() => void shareStories()} disabled={!hasContent} className="min-h-12 whitespace-normal text-sm font-bold">
          <Share2 className="mr-2 h-5 w-5" /> Share Stories
        </Button>
      </div>

      <Dialog open={todayEditorOpen} onOpenChange={setTodayEditorOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader><DialogTitle>Today's Story</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="rounded-md bg-muted/60 p-3 text-base font-semibold">{todaysPrompt}</div>
            <div className="space-y-1">
              <Label className="flex items-center gap-2"><ImagePlus className="h-4 w-4" /> Add a photo</Label>
              <Input type="file" accept="image/*" onChange={(event) => setTodayImage(event.target.files?.[0] || null)} />
              {todaysEntry?.imageUrl && !todayImage && <img src={todaysEntry.imageUrl} alt="Current story" className="h-24 w-24 rounded-md object-cover" />}
            </div>
            <div className="space-y-1">
              <Label>Your story</Label>
              <div className="flex items-start gap-2">
                <Textarea value={response} onChange={(event) => setResponse(event.target.value)} placeholder="Share your memory..." className="min-h-32 flex-1 text-base" />
                <VoiceInput onTranscript={(text) => setResponse((current) => current ? `${current} ${text}` : text)} disabled={isSaving} />
              </div>
            </div>
          </div>
          <DialogFooter><Button onClick={() => void handleSave()} disabled={isSaving}>{isSaving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}Save Story</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};