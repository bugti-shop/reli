import * as React from 'npm:react@18.3.1'
import { Body, Container, Head, Heading, Html, Preview, Text } from 'npm:@react-email/components@0.0.22'
import type { TemplateEntry } from './registry.ts'

interface Props {
  code?: string
}

const Email = ({ code = '000000' }: Props) => (
  <Html lang="en" dir="ltr">
    <Head />
    <Preview>Your Reli verification code is {code}</Preview>
    <Body style={main}>
      <Container style={container}>
        <Heading style={h1}>Your verification code</Heading>
        <Text style={text}>
          Someone asked to delete a Reli account or some of its data using this email address.
          Enter this code in Reli to confirm:
        </Text>
        <Text style={codeStyle}>{code}</Text>
        <Text style={text}>
          The code expires in 10 minutes. If you did not request this, you can ignore this email —
          nothing will be deleted.
        </Text>
        <Text style={footer}>Sent from Reli</Text>
      </Container>
    </Body>
  </Html>
)

export const template = {
  component: Email,
  subject: (d: Record<string, any>) => `Your Reli verification code: ${d.code ?? ''}`,
  displayName: 'Account deletion code',
  previewData: { code: '482913' },
} satisfies TemplateEntry

const main = { backgroundColor: '#ffffff', fontFamily: 'Arial, sans-serif' }
const container = { padding: '20px 25px' }
const h1 = { fontSize: '22px', fontWeight: 'bold' as const, color: '#1f2937', margin: '0 0 20px' }
const text = { fontSize: '16px', color: '#4b5563', lineHeight: '1.6', margin: '0 0 18px' }
const codeStyle = {
  fontSize: '34px',
  fontWeight: 'bold' as const,
  letterSpacing: '8px',
  color: '#1d4ed8',
  margin: '10px 0 24px',
}
const footer = { fontSize: '12px', color: '#999999', margin: '30px 0 0' }
