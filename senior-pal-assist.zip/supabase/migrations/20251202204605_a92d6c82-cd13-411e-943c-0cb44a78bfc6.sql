-- Create table for feature visibility settings
CREATE TABLE public.senior_feature_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  senior_id UUID NOT NULL,
  caregiver_id UUID NOT NULL,
  show_trivia BOOLEAN NOT NULL DEFAULT true,
  show_medication_tracker BOOLEAN NOT NULL DEFAULT true,
  show_activity_tracker BOOLEAN NOT NULL DEFAULT true,
  show_life_story BOOLEAN NOT NULL DEFAULT true,
  show_ai_companion BOOLEAN NOT NULL DEFAULT true,
  show_doctor_report BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  CONSTRAINT unique_senior_caregiver_settings UNIQUE (senior_id, caregiver_id)
);

-- Enable Row Level Security
ALTER TABLE public.senior_feature_settings ENABLE ROW LEVEL SECURITY;

-- Caregivers can view settings for their seniors
CREATE POLICY "Caregivers can view their seniors settings"
ON public.senior_feature_settings
FOR SELECT
USING (caregiver_id = auth.uid());

-- Caregivers can create settings for their seniors
CREATE POLICY "Caregivers can create settings for their seniors"
ON public.senior_feature_settings
FOR INSERT
WITH CHECK (
  caregiver_id = auth.uid() AND
  EXISTS (
    SELECT 1 FROM caregiver_seniors
    WHERE caregiver_seniors.caregiver_id = auth.uid()
    AND caregiver_seniors.senior_id = senior_feature_settings.senior_id
  )
);

-- Caregivers can update settings for their seniors
CREATE POLICY "Caregivers can update their seniors settings"
ON public.senior_feature_settings
FOR UPDATE
USING (caregiver_id = auth.uid());

-- Seniors can view their own settings
CREATE POLICY "Seniors can view their own feature settings"
ON public.senior_feature_settings
FOR SELECT
USING (senior_id = auth.uid());

-- Create trigger for updated_at
CREATE TRIGGER update_senior_feature_settings_updated_at
BEFORE UPDATE ON public.senior_feature_settings
FOR EACH ROW
EXECUTE FUNCTION public.handle_updated_at();