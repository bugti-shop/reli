# Reli illustration landing page

## Goal
Replace the current public homepage with the selected warm, family-focused design while keeping every destination and sign-in flow available.

## What will change
- Build a mobile-first cream landing page using Reli blue `#3d6799` as the consistent action, link, and accent color.
- Use the attached Reli logo prominently in the top navigation and update the favicon from the same brand artwork.
- Add a working hamburger menu containing the existing public links: Pricing, Learn More/FAQ, Resources, Contact, Privacy, Terms, and Sign in.
- Create the requested editorial hero hierarchy: serif “Care for the people you love” headline, supporting copy, equal “For Myself” and “For Caregivers” actions, Pricing and Learn More links.
- Build professional black App Store and Google Play badges using the supplied platform logos. They will remain marked “Coming Soon” until real store URLs are provided.
- Create a new warm family-care illustration matching the reference composition: grandmother, family, blue clothing, cozy living room, plants, framed photo, floating hearts, and care-related message bubbles. Text bubbles will be placed in the page itself for crisp, exact wording.
- Preserve comfortable mobile spacing while scaling into a polished desktop composition without changing the requested visual language.

## Technical details
- Add the generated family illustration as a local app image.
- Store the uploaded Reli and store-logo images through the project asset flow, while keeping a real square favicon in `public/`.
- Update semantic color and typography tokens so the page uses the blue/cream/navy system consistently.
- Replace the current landing-page presentation only; dashboards, account flows, pricing, resources, and other existing pages remain unchanged.
- Verify the finished page at mobile and desktop sizes, including menu behavior, button navigation, text fit, image framing, and horizontal overflow.
