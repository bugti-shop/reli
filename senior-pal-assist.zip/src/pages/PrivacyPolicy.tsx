import { Card } from "@/components/ui/card";
import Header from "@/components/Header";
import Newsletter from "@/components/Newsletter";

const PrivacyPolicy = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="py-12 px-4">
        <div className="max-w-4xl mx-auto">
          <Card className="p-8">
          <h1 className="text-4xl font-bold text-foreground mb-2">Reli Privacy Notice</h1>
          <p className="text-muted-foreground mb-8">Effective: December 2025</p>

          <div className="space-y-6 text-foreground">
            <p className="text-muted-foreground leading-relaxed">
              At Reli, we build technology designed to support independence, connection, and well-being. Protecting your information is central to our mission. This Privacy Notice explains how we collect, use, disclose, and protect your information when you use our AI companion platform.
            </p>

            <p className="text-muted-foreground leading-relaxed">This policy is designed to be:</p>
            <ul className="list-disc pl-6 space-y-2 text-muted-foreground leading-relaxed">
              <li>HIPAA-friendly for users who track medication and health-related data</li>
              <li>GDPR-compliant for EU/EEA users</li>
              <li>Consistent with U.S. privacy laws, including CCPA/CPRA</li>
              <li>Aligned with industry standards used by major technology companies</li>
            </ul>

            <section>
              <h2 className="text-2xl font-semibold mb-3">1. Who We Are</h2>
              <p className="text-muted-foreground leading-relaxed mb-3">
                Reli ("we," "us," or "our") provides an AI-based companion and caregiver-support service. This Privacy Notice applies to all users of our platform.
              </p>
              <p className="text-muted-foreground leading-relaxed mb-3">
                For users in the EU/EEA, Reli is the data controller for your personal data.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                Contact: <a href="mailto:info@reli.care" className="text-primary hover:underline">info@reli.care</a>
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">2. Information We Collect</h2>
              <p className="text-muted-foreground leading-relaxed mb-4">
                We collect information to operate our service effectively and deliver personalized, safe experiences.
              </p>
              
              <h3 className="text-xl font-semibold mb-2">2.1 Information You Provide</h3>
              <ul className="list-disc pl-6 space-y-2 text-muted-foreground leading-relaxed mb-4">
                <li>Name, email address, and account credentials</li>
                <li>Profile details and preferences</li>
                <li>Senior/caregiver relationship settings</li>
                <li>Medication entries, reminders, and well-being notes</li>
                <li>Chat interactions with the AI companion</li>
                <li>Optional health-related inputs (processed with explicit consent under GDPR/HIPAA-friendly rules)</li>
              </ul>

              <h3 className="text-xl font-semibold mb-2">2.2 Information Collected Automatically</h3>
              <ul className="list-disc pl-6 space-y-2 text-muted-foreground leading-relaxed mb-4">
                <li>Device and browser identifiers</li>
                <li>IP address and general location</li>
                <li>Session data and usage logs</li>
                <li>Diagnostic, crash, and performance data</li>
                <li>Cookie and analytics information</li>
                <li>Voice inputs (processed in real time, not stored)</li>
              </ul>

              <h3 className="text-xl font-semibold mb-2">2.3 Information From Authorized Caregivers</h3>
              <p className="text-muted-foreground leading-relaxed">
                If you grant caregiver access, we collect and share information between senior and caregiver accounts as configured by you.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">3. How We Use Your Information</h2>
              <p className="text-muted-foreground leading-relaxed mb-3">We use information to:</p>
              <ul className="list-disc pl-6 space-y-2 text-muted-foreground leading-relaxed">
                <li>Provide and maintain the AI companion experience</li>
                <li>Personalize reminders, suggestions, and communication</li>
                <li>Support caregiver-senior connections</li>
                <li>Improve accuracy, safety, and functionality</li>
                <li>Detect and prevent fraud, abuse, or security issues</li>
                <li>Communicate changes, updates, and service messages</li>
                <li>Comply with legal obligations</li>
              </ul>
              <p className="text-muted-foreground leading-relaxed mt-3">
                We do not use personal information for advertising or profiling without your consent.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">4. Legal Bases for Processing (GDPR)</h2>
              <p className="text-muted-foreground leading-relaxed mb-3">
                For users in the EU/EEA, we process personal data under the following legal bases:
              </p>
              <ul className="list-disc pl-6 space-y-2 text-muted-foreground leading-relaxed">
                <li><span className="font-medium text-foreground">Contract:</span> operating and providing your account and service</li>
                <li><span className="font-medium text-foreground">Explicit Consent:</span> processing voice inputs, medication data, and caregiver-linked health information</li>
                <li><span className="font-medium text-foreground">Legitimate Interests:</span> analytics, service improvement, security monitoring, fraud prevention</li>
                <li><span className="font-medium text-foreground">Legal Obligation:</span> when required by law or regulatory authorities</li>
              </ul>
              <p className="text-muted-foreground leading-relaxed mt-3">
                For special category data (e.g., health-related notes), Reli uses explicit consent under Article 9(2)(a).
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">5. HIPAA-Friendly Notice Regarding Health Information</h2>
              <p className="text-muted-foreground leading-relaxed mb-3">
                If you track medication or well-being data, this may constitute health-related information. Reli implements administrative, physical, and technical safeguards consistent with HIPAA's security expectations.
              </p>
              <p className="text-muted-foreground leading-relaxed mb-2">Important clarifications:</p>
              <ul className="list-disc pl-6 space-y-2 text-muted-foreground leading-relaxed">
                <li>Reli may act as a Business Associate for certain health-related integrations if applicable.</li>
                <li>This Privacy Notice is structured to align with HIPAA principles, but Reli may not be a "covered entity" unless explicitly stated via contract.</li>
                <li>Regardless of classification, we treat health-related data with heightened protections.</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">6. Cookies and Tracking Technologies</h2>
              <p className="text-muted-foreground leading-relaxed mb-3">We use cookies and similar technologies to:</p>
              <ul className="list-disc pl-6 space-y-2 text-muted-foreground leading-relaxed">
                <li>Keep your session active</li>
                <li>Measure usage and performance</li>
                <li>Improve features and stability</li>
              </ul>
              <p className="text-muted-foreground leading-relaxed mt-3">
                You can control cookies through your browser settings.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">7. How We Share Information</h2>
              <p className="text-muted-foreground leading-relaxed mb-3">
                We do not sell your personal information.
              </p>
              <p className="text-muted-foreground leading-relaxed mb-3">We share information only:</p>
              
              <h3 className="text-xl font-semibold mb-2">7.1 With Your Authorized Caregivers</h3>
              <p className="text-muted-foreground leading-relaxed mb-4">
                Access is entirely controlled by you.
              </p>

              <h3 className="text-xl font-semibold mb-2">7.2 With Trusted Service Providers</h3>
              <p className="text-muted-foreground leading-relaxed mb-4">
                Examples include hosting providers, analytics partners, and customer support tools. These providers must comply with strict confidentiality and data-protection requirements.
              </p>

              <h3 className="text-xl font-semibold mb-2">7.3 For Legal or Safety Reasons</h3>
              <p className="text-muted-foreground leading-relaxed mb-4">
                Such as complying with court orders, preventing harm, or responding to lawful requests.
              </p>

              <h3 className="text-xl font-semibold mb-2">7.4 In Corporate Transactions</h3>
              <p className="text-muted-foreground leading-relaxed">
                Such as mergers, acquisitions, or financing. Your information will continue to be protected.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">8. International Data Transfers</h2>
              <p className="text-muted-foreground leading-relaxed mb-3">
                Your data may be processed in the United States or other countries. For EU/EEA residents, we use:
              </p>
              <ul className="list-disc pl-6 space-y-2 text-muted-foreground leading-relaxed">
                <li>Standard Contractual Clauses (SCCs)</li>
                <li>Technical and organizational safeguards (encryption, access controls)</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">9. Data Retention</h2>
              <p className="text-muted-foreground leading-relaxed mb-3">
                We retain information only as long as necessary to:
              </p>
              <ul className="list-disc pl-6 space-y-2 text-muted-foreground leading-relaxed">
                <li>Provide and improve the service</li>
                <li>Support your caregiver relationships</li>
                <li>Comply with laws and regulatory obligations</li>
                <li>Resolve disputes and enforce agreements</li>
              </ul>
              <p className="text-muted-foreground leading-relaxed mt-3">
                When information is no longer needed, we delete or anonymize it.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">10. Data Security</h2>
              <p className="text-muted-foreground leading-relaxed mb-3">
                We use industry-standard security measures to protect your information, including:
              </p>
              <ul className="list-disc pl-6 space-y-2 text-muted-foreground leading-relaxed">
                <li>Encryption in transit and at rest</li>
                <li>Access controls and authentication</li>
                <li>Regular security assessments</li>
                <li>Separation of user-role data (senior vs. caregiver)</li>
              </ul>
              <p className="text-muted-foreground leading-relaxed mt-3">
                However, no method of transmission over the Internet or electronic storage is 100% secure, and we cannot guarantee absolute security.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">11. Your Privacy Rights</h2>
              <p className="text-muted-foreground leading-relaxed mb-3">
                Depending on your jurisdiction (GDPR, CCPA/CPRA, or other privacy laws), you may have the right to:
              </p>
              <ul className="list-disc pl-6 space-y-2 text-muted-foreground leading-relaxed">
                <li>Access your personal data</li>
                <li>Request correction or updates</li>
                <li>Request deletion ("right to be forgotten")</li>
                <li>Restrict or object to processing</li>
                <li>Withdraw consent at any time</li>
                <li>Obtain a portable copy of your data</li>
                <li>Opt out of certain uses (e.g., data sharing)</li>
                <li>Lodge a complaint with a Data Protection Authority</li>
              </ul>
              <p className="text-muted-foreground leading-relaxed mt-3">
                To exercise rights: <a href="mailto:info@reli.care" className="text-primary hover:underline">info@reli.care</a>
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">12. Children's Privacy</h2>
              <p className="text-muted-foreground leading-relaxed mb-3">
                Reli is not intended for children under 13, or under the applicable age of digital consent in the EU/EEA (13–16 depending on country).
              </p>
              <p className="text-muted-foreground leading-relaxed">
                We do not knowingly collect information from children under these ages.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">13. Automated Decision-Making</h2>
              <p className="text-muted-foreground leading-relaxed">
                Reli uses automated processing to deliver reminders and suggestions. These processes:
              </p>
              <ul className="list-disc pl-6 space-y-2 text-muted-foreground leading-relaxed mt-3">
                <li>Do not produce decisions with legal or significant impact</li>
                <li>Are designed solely to enhance user experience</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">14. Changes to This Privacy Notice</h2>
              <p className="text-muted-foreground leading-relaxed mb-3">
                We may update this Privacy Notice periodically. When changes are made, we will:
              </p>
              <ul className="list-disc pl-6 space-y-2 text-muted-foreground leading-relaxed">
                <li>Post the updated version here</li>
                <li>Update the "Effective" date</li>
                <li>Provide additional notice when required by law</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">15. Contact Us</h2>
              <p className="text-muted-foreground leading-relaxed mb-3">
                If you have questions or requests regarding your privacy:
              </p>
              <p className="text-muted-foreground leading-relaxed mb-3">
                Email: <a href="mailto:info@reli.care" className="text-primary hover:underline">info@reli.care</a>
              </p>
              <p className="text-muted-foreground leading-relaxed">
                You may also contact your local Data Protection Authority if you are in the EU/EEA.
              </p>
            </section>
          </div>
          </Card>
        </div>
      </div>
      <Newsletter />
    </div>
  );
};

export default PrivacyPolicy;
