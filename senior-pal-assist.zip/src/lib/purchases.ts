import { isNativeApp, nativePlatform } from "@/lib/native";

// RevenueCat public SDK keys (safe to ship in the app). Fill these in from
// RevenueCat → Project → API keys after creating the store products.
const IOS_KEY = (import.meta.env.VITE_REVENUECAT_IOS_KEY as string | undefined) || "";
const ANDROID_KEY = (import.meta.env.VITE_REVENUECAT_ANDROID_KEY as string | undefined) || "";

/** Entitlement id configured in RevenueCat that unlocks Reli Premium. */
export const PREMIUM_ENTITLEMENT = "premium";
/** Shared App Store and Google Play monthly subscription product. */
export const PREMIUM_MONTHLY_PRODUCT_ID = "com.reli.care.monthly";

export const storePurchasesAvailable = () =>
  isNativeApp() && Boolean(nativePlatform() === "ios" ? IOS_KEY : ANDROID_KEY);

let configuredFor: string | null = null;

const sdk = async (userId: string) => {
  const { Purchases } = await import("@revenuecat/purchases-capacitor");
  if (configuredFor !== userId) {
    if (configuredFor === null) {
      await Purchases.configure({ apiKey: nativePlatform() === "ios" ? IOS_KEY : ANDROID_KEY, appUserID: userId });
    } else {
      await Purchases.logIn({ appUserID: userId });
    }
    configuredFor = userId;
  }
  return Purchases;
};

export interface StorePackage {
  id: string;
  productId: string;
  title: string;
  price: string;
  period: "monthly" | "annual" | "other";
  raw: unknown;
}

/** Packages from the current RevenueCat offering, with store-localised prices. */
export const loadStorePackages = async (userId: string): Promise<StorePackage[]> => {
  const Purchases = await sdk(userId);
  const offerings = await Purchases.getOfferings();
  const pkgs = offerings.current?.availablePackages ?? [];
  return pkgs
    .filter((p: any) =>
      p.product?.identifier === PREMIUM_MONTHLY_PRODUCT_ID && p.packageType === "MONTHLY",
    )
    .map((p: any) => ({
      id: p.identifier,
      productId: p.product.identifier,
      title: "Reli Premium",
      price: p.product?.priceString ?? "$34.99",
      period: "monthly" as const,
      raw: p,
    }));
};

/** Starts the Apple / Google purchase sheet. Returns true if Premium is active. */
export const buyStorePackage = async (userId: string, pkg: StorePackage) => {
  const Purchases = await sdk(userId);
  const { customerInfo } = await Purchases.purchasePackage({ aPackage: pkg.raw as any });
  return Boolean(customerInfo.entitlements.active[PREMIUM_ENTITLEMENT]);
};

export const restoreStorePurchases = async (userId: string) => {
  const Purchases = await sdk(userId);
  const { customerInfo } = await Purchases.restorePurchases();
  return Boolean(customerInfo.entitlements.active[PREMIUM_ENTITLEMENT]);
};

/** Store-managed subscriptions are changed in the phone's account settings. */
export const manageStoreSubscription = () => {
  const url = nativePlatform() === "ios"
    ? "https://apps.apple.com/account/subscriptions"
    : "https://play.google.com/store/account/subscriptions";
  window.open(url, "_system");
};
