-- Create table for life story prompts and entries
CREATE TABLE public.life_story_entries (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  senior_id UUID NOT NULL,
  prompt TEXT NOT NULL,
  response TEXT,
  prompt_date DATE NOT NULL DEFAULT CURRENT_DATE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Add unique constraint to ensure one prompt per day per senior
ALTER TABLE public.life_story_entries ADD CONSTRAINT unique_senior_prompt_date UNIQUE (senior_id, prompt_date);

-- Enable Row Level Security
ALTER TABLE public.life_story_entries ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Seniors can view their own life story entries"
ON public.life_story_entries
FOR SELECT
USING (auth.uid() = senior_id);

CREATE POLICY "Seniors can create their own life story entries"
ON public.life_story_entries
FOR INSERT
WITH CHECK (auth.uid() = senior_id);

CREATE POLICY "Seniors can update their own life story entries"
ON public.life_story_entries
FOR UPDATE
USING (auth.uid() = senior_id);

CREATE POLICY "Caregivers can view their seniors life story entries"
ON public.life_story_entries
FOR SELECT
USING (EXISTS (
  SELECT 1 FROM caregiver_seniors
  WHERE caregiver_seniors.caregiver_id = auth.uid()
  AND caregiver_seniors.senior_id = life_story_entries.senior_id
));

-- Create trigger for updated_at
CREATE TRIGGER update_life_story_entries_updated_at
BEFORE UPDATE ON public.life_story_entries
FOR EACH ROW
EXECUTE FUNCTION public.handle_updated_at();