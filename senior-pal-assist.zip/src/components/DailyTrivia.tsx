import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Brain, CheckCircle, XCircle, Trophy, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

type Difficulty = "easy" | "medium" | "hard";

interface TriviaQuestion {
  question: string;
  options: string[];
  correctAnswer: number;
}

interface DailyTriviaProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const DailyTrivia = ({ open, onOpenChange }: DailyTriviaProps) => {
  const [difficulty, setDifficulty] = useState<Difficulty | null>(null);
  const [currentQuestion, setCurrentQuestion] = useState<TriviaQuestion | null>(null);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [score, setScore] = useState(0);
  const [questionsAnswered, setQuestionsAnswered] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const fetchQuestion = async (level: Difficulty) => {
    setIsLoading(true);
    setSelectedAnswer(null);
    setIsCorrect(null);

    try {
      const { data, error } = await supabase.functions.invoke("trivia-generator", {
        body: { difficulty: level },
      });

      if (error) {
        console.error("Error fetching trivia:", error);
        toast({
          title: "Error",
          description: "Failed to load trivia question. Please try again.",
          variant: "destructive",
        });
        return;
      }

      setCurrentQuestion(data);
    } catch (err) {
      console.error("Trivia error:", err);
      toast({
        title: "Error",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const startGame = (level: Difficulty) => {
    setDifficulty(level);
    setScore(0);
    setQuestionsAnswered(0);
    fetchQuestion(level);
  };

  const handleAnswer = (index: number) => {
    if (selectedAnswer !== null || !currentQuestion) return;

    setSelectedAnswer(index);
    const correct = index === currentQuestion.correctAnswer;
    setIsCorrect(correct);

    if (correct) {
      setScore((prev) => prev + 1);
    }
    setQuestionsAnswered((prev) => prev + 1);
  };

  const nextQuestion = () => {
    if (difficulty) {
      fetchQuestion(difficulty);
    }
  };

  const resetGame = () => {
    setDifficulty(null);
    setCurrentQuestion(null);
    setSelectedAnswer(null);
    setIsCorrect(null);
    setScore(0);
    setQuestionsAnswered(0);
  };

  const handleClose = () => {
    onOpenChange(false);
    setTimeout(resetGame, 300);
  };

  const difficultyColors = {
    easy: "bg-green-500 hover:bg-green-600",
    medium: "bg-yellow-500 hover:bg-yellow-600",
    hard: "bg-red-500 hover:bg-red-600",
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-3xl flex items-center gap-3">
            <Brain className="w-10 h-10 text-primary" />
            Daily Trivia
          </DialogTitle>
        </DialogHeader>

        {!difficulty ? (
          <div className="space-y-6 py-4">
            <p className="text-xl text-muted-foreground text-center">
              Choose your difficulty level to start exercising your mind!
            </p>
            <div className="grid gap-4">
              <Button
                size="lg"
                className={`h-20 text-2xl ${difficultyColors.easy} text-white`}
                onClick={() => startGame("easy")}
              >
                🌱 Easy
              </Button>
              <Button
                size="lg"
                className={`h-20 text-2xl ${difficultyColors.medium} text-white`}
                onClick={() => startGame("medium")}
              >
                🌿 Medium
              </Button>
              <Button
                size="lg"
                className={`h-20 text-2xl ${difficultyColors.hard} text-white`}
                onClick={() => startGame("hard")}
              >
                🌳 Hard
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-6 py-4">
            {/* Score display */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xl">
                <Trophy className="w-6 h-6 text-yellow-500" />
                <span>
                  Score: {score}/{questionsAnswered}
                </span>
              </div>
              <span
                className={`px-3 py-1 rounded-full text-white capitalize ${difficultyColors[difficulty]}`}
              >
                {difficulty}
              </span>
            </div>

            {isLoading ? (
              <div className="flex flex-col items-center justify-center py-12 gap-4">
                <Loader2 className="w-12 h-12 animate-spin text-primary" />
                <p className="text-xl text-muted-foreground">Loading question...</p>
              </div>
            ) : currentQuestion ? (
              <>
                <Card className="p-6 bg-secondary/20">
                  <p className="text-2xl font-medium text-center">
                    {currentQuestion.question}
                  </p>
                </Card>

                <div className="grid gap-3">
                  {currentQuestion.options.map((option, index) => (
                    <Button
                      key={index}
                      size="lg"
                      variant="outline"
                      className={`h-auto py-4 px-6 text-xl text-left justify-start whitespace-normal ${
                        selectedAnswer === index
                          ? index === currentQuestion.correctAnswer
                            ? "bg-green-100 border-green-500 text-green-700"
                            : "bg-red-100 border-red-500 text-red-700"
                          : selectedAnswer !== null &&
                            index === currentQuestion.correctAnswer
                          ? "bg-green-100 border-green-500 text-green-700"
                          : ""
                      }`}
                      onClick={() => handleAnswer(index)}
                      disabled={selectedAnswer !== null}
                    >
                      {option}
                    </Button>
                  ))}
                </div>

                {selectedAnswer !== null && (
                  <div className="space-y-4">
                    <div
                      className={`flex items-center justify-center gap-3 text-2xl font-semibold ${
                        isCorrect ? "text-green-600" : "text-red-600"
                      }`}
                    >
                      {isCorrect ? (
                        <>
                          <CheckCircle className="w-8 h-8" />
                          Correct! Great job!
                        </>
                      ) : (
                        <>
                          <XCircle className="w-8 h-8" />
                          Not quite. Keep trying!
                        </>
                      )}
                    </div>

                    <div className="flex gap-4">
                      <Button
                        size="lg"
                        className="flex-1 h-16 text-xl"
                        onClick={nextQuestion}
                      >
                        Next Question
                      </Button>
                      <Button
                        size="lg"
                        variant="outline"
                        className="flex-1 h-16 text-xl"
                        onClick={resetGame}
                      >
                        Change Difficulty
                      </Button>
                    </div>
                  </div>
                )}
              </>
            ) : null}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};
