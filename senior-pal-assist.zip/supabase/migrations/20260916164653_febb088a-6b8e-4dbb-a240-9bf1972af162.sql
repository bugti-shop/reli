ALTER TABLE public.vital_readings ADD COLUMN IF NOT EXISTS deleted_at timestamptz;
ALTER TABLE public.medication_doses ADD COLUMN IF NOT EXISTS deleted_at timestamptz;

ALTER TABLE public.medication_doses ALTER COLUMN medication_id DROP NOT NULL;
ALTER TABLE public.medication_doses DROP CONSTRAINT medication_doses_medication_id_fkey;
ALTER TABLE public.medication_doses
  ADD CONSTRAINT medication_doses_medication_id_fkey
  FOREIGN KEY (medication_id) REFERENCES public.medications(id) ON DELETE SET NULL;

CREATE POLICY "Update medication doses"
ON public.medication_doses FOR UPDATE TO authenticated
USING (
  taken_by = auth.uid()
  OR senior_id = auth.uid()
  OR EXISTS (SELECT 1 FROM public.caregiver_seniors cs WHERE cs.senior_id = medication_doses.senior_id AND cs.caregiver_id = auth.uid())
)
WITH CHECK (
  taken_by = auth.uid()
  OR senior_id = auth.uid()
  OR EXISTS (SELECT 1 FROM public.caregiver_seniors cs WHERE cs.senior_id = medication_doses.senior_id AND cs.caregiver_id = auth.uid())
);

ALTER TABLE public.vital_readings REPLICA IDENTITY FULL;
ALTER TABLE public.medications REPLICA IDENTITY FULL;
ALTER TABLE public.medication_doses REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.vital_readings, public.medications, public.medication_doses;