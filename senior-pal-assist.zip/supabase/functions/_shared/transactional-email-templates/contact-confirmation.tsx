import * as React from 'npm:react@18.3.1'
import {
  Body,
  Container,
  Head,
  Heading,
  Html,
  Preview,
  Text,
} from 'npm:@react-email/components@0.0.22'
import type { TemplateEntry } from './registry.ts'

interface Props {
  senderName?: string
}

const Email = ({ senderName = 'there' }: Props) => (
  <Html lang="en" dir="ltr">
    <Head />
    <Preview>We received your message</Preview>
    <Body style={main}>
      <Container style={container}>
        <Heading style={h1}>Thank you for contacting us, {senderName}!</Heading>
        <Text style={text}>
          We have received your message and will get back to you as soon as
          possible.
        </Text>
        <Text style={text}>
          Best regards,
          <br />
          The Reli Team
        </Text>
        <Text style={footer}>Sent from Reli</Text>
      </Container>
    </Body>
  </Html>
)

export const template = {
  component: Email,
  subject: 'We received your message!',
  displayName: 'Contact form confirmation',
  previewData: { senderName: 'Jane' },
} satisfies TemplateEntry

const main = { backgroundColor: '#ffffff', fontFamily: 'Arial, sans-serif' }
const container = { padding: '20px 25px' }
const h1 = {
  fontSize: '22px',
  fontWeight: 'bold' as const,
  color: 'hsl(24, 20%, 15%)',
  margin: '0 0 20px',
}
const text = {
  fontSize: '16px',
  color: 'hsl(24, 15%, 35%)',
  lineHeight: '1.6',
  margin: '0 0 18px',
}
const footer = { fontSize: '12px', color: '#999999', margin: '30px 0 0' }
