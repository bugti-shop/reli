# Clean Trackers UI

## Goal
Implement the selected clean Trackers design across Meds, Vitals, Reminders, History, and Custom while preserving every existing tracker action and data rule.

## What will change
- Rebuild the Trackers header with the compact Reli identity, Caregiver/Senior role badge, clear title/subtitle, and one compact senior selector.
- Replace the current boxed tab buttons with the selected pale-blue five-tab strip and clear active indicator.
- Restyle Meds to match the reference: scheduled/taken summaries, clean daily medication rows, compact interaction checker, and coral add action that opens the existing medication form.
- Restyle Vitals with consistent summary tiles, readable latest values, streamlined reading forms, and uncluttered reading lists.
- Restyle Reminders with the same hierarchy: concise summary, schedule rows, notification state, and a focused add-reminder form.
- Restyle History into a clean, immediately visible timeline with medication, blood-pressure, and heart-rate filters; retain free/premium history limits and removed-record labels.
- Restyle Custom with simple tracker rows, clear completion/edit/share controls, and a focused add-tracker form.
- Apply the same shared tracker presentation on caregiver and senior dashboards, without changing the scenic home card or bottom navigation.

## Interaction details
- Coral floating add buttons open the relevant existing form rather than showing forms permanently.
- Existing create, edit, complete, delete, interaction checking, notification, offline-save, sharing, and Premium behavior remains intact.
- Layout will adapt cleanly to narrow phones and desktop widths without clipped labels or hidden actions.

## Technical details
- Add a small shared Trackers shell/tab component so both dashboards use one consistent layout.
- Update the five existing tracker components only at the presentation layer; database tables and policies remain unchanged.
- Use the app’s semantic color tokens and existing buttons/dialogs; the uploaded images remain visual references only.
- Verify all five tabs in the live caregiver flow at mobile width and confirm the latest preview build is clean.
