import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors'
import { createClient } from 'npm:@supabase/supabase-js@2'
import { z } from 'npm:zod@3'

const Body = z.object({
  full_name: z.string().trim().min(1).max(100),
  age: z.number().int().min(0).max(130).optional().nullable(),
  phone: z.string().trim().max(40).optional().nullable(),
  address: z.string().trim().max(300).optional().nullable(),
})

const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), { status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  try {
    const url = Deno.env.get('SUPABASE_URL')!
    const auth = req.headers.get('Authorization') ?? ''
    const userClient = createClient(url, Deno.env.get('SUPABASE_ANON_KEY')!, { global: { headers: { Authorization: auth } } })
    const { data: { user } } = await userClient.auth.getUser()
    if (!user) return json({ error: 'NOT_AUTHENTICATED' }, 401)

    const parsed = Body.safeParse(await req.json())
    if (!parsed.success) return json({ error: 'INVALID_INPUT', details: parsed.error.flatten().fieldErrors }, 400)

    const admin = createClient(url, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!)
    const { data: me } = await admin.from('profiles').select('role').eq('id', user.id).maybeSingle()
    if (me?.role !== 'caregiver') return json({ error: 'NOT_CAREGIVER' }, 403)

    // Enforce plan limit before creating anything.
    const [{ count }, { data: premium }] = await Promise.all([
      admin.from('caregiver_seniors').select('id', { count: 'exact', head: true }).eq('caregiver_id', user.id),
      admin.rpc('has_effective_premium', { _user_id: user.id }),
    ])
    if ((count ?? 0) >= 2 && !premium) return json({ error: 'SENIOR_LIMIT_REACHED' }, 400)

    const d = parsed.data
    const email = `senior-${crypto.randomUUID()}@managed.reli.care`
    const { data: created, error: cErr } = await admin.auth.admin.createUser({
      email,
      email_confirm: true,
      password: crypto.randomUUID() + crypto.randomUUID(),
      user_metadata: { full_name: d.full_name, role: 'senior', managed: true },
    })
    if (cErr || !created.user) { console.error(cErr); return json({ error: 'CREATE_FAILED' }, 500) }
    const sid = created.user.id

    await admin.from('profiles').update({
      managed: true, managed_by: user.id,
      age: d.age ?? null, phone: d.phone || null, address: d.address || null,
    }).eq('id', sid)

    const { error: lErr } = await admin.from('caregiver_seniors').insert({ caregiver_id: user.id, senior_id: sid, relationship: 'caregiver' })
    if (lErr) {
      await admin.auth.admin.deleteUser(sid)
      console.error(lErr)
      return json({ error: 'LINK_FAILED' }, 500)
    }
    return json({ senior_id: sid })
  } catch (e) {
    console.error(e)
    return json({ error: 'SERVER_ERROR' }, 500)
  }
})
