import * as React from 'npm:react@18.3.1'
import {
  Body,
  Container,
  Head,
  Heading,
  Html,
  Link,
  Preview,
  Text,
} from 'npm:@react-email/components@0.0.22'
import type { TemplateEntry } from './registry.ts'

const Email = () => (
  <Html lang="en" dir="ltr">
    <Head />
    <Preview>Welcome to the Reli newsletter</Preview>
    <Body style={main}>
      <Container style={container}>
        <Heading style={h1}>Welcome to the Reli newsletter!</Heading>
        <Text style={text}>
          Thank you for subscribing! You're now on the list to hear about new
          features, caregiving tips, and everything we're building to make
          caring for your loved ones a little easier.
        </Text>
        <Text style={text}>
          We're so glad to have you with us.
        </Text>
        <Text style={text}>
          Best regards,
          <br />
          The Reli Team
        </Text>
        <Text style={footer}>
          You're receiving this because you subscribed at{' '}
          <Link href="https://www.reli.care" style={link}>reli.care</Link>.
          To stop these emails, reply with "unsubscribe" or contact us at
          info@reli.care.
        </Text>
      </Container>
    </Body>
  </Html>
)

export const template = {
  component: Email,
  subject: 'Welcome to the Reli newsletter!',
  displayName: 'Newsletter welcome',
  previewData: {},
} satisfies TemplateEntry

const main = { backgroundColor: '#ffffff', fontFamily: 'Arial, sans-serif' }
const container = { padding: '20px 25px' }
const h1 = {
  fontSize: '22px',
  fontWeight: 'bold' as const,
  color: 'hsl(24, 20%, 15%)',
  margin: '0 0 20px',
}
const text = {
  fontSize: '16px',
  color: 'hsl(24, 15%, 35%)',
  lineHeight: '1.6',
  margin: '0 0 18px',
}
const footer = { fontSize: '12px', color: '#999999', margin: '30px 0 0' }
const link = { color: '#2563eb' }
