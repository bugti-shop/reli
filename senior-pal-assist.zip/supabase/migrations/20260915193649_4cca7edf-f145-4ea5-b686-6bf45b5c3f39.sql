ALTER TABLE public.notification_preferences
  ADD COLUMN IF NOT EXISTS daily_summary_timezone text NOT NULL DEFAULT 'America/New_York';

ALTER TABLE public.notification_preferences
  ALTER COLUMN daily_summary_time SET DEFAULT '19:00';