import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Bell, ChevronRight, Heart, Menu, Pill } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import Newsletter from "@/components/Newsletter";
import familyIllustration from "@/assets/reli-family-illustration.png";
import familyIllustration480 from "@/assets/reli-family-illustration-480.webp";
import familyIllustration640 from "@/assets/reli-family-illustration-640.webp";
import familyIllustration960 from "@/assets/reli-family-illustration-960.webp";
import familyIllustration1280 from "@/assets/reli-family-illustration-1280.webp";
import reliLogo from "@/assets/reli-logo-500.webp";
import appleLogo from "@/assets/apple-store-symbol.png";
import googlePlayLogo from "@/assets/google-play-symbol.png";

const menuItems = [
  { label: "Pricing", to: "/pricing" },
  { label: "Learn More", to: "/faq" },
  { label: "Resources", to: "/resources" },
  { label: "Contact", to: "/contact" },
  { label: "Privacy", to: "/privacy-policy" },
  { label: "Terms", to: "/terms-of-service" },
];

const StoreBadge = ({ store }: { store: "apple" | "google" }) => {
  const isApple = store === "apple";

  return (
    <div className={`flex min-w-0 flex-col ${isApple ? "items-start" : "items-end"}`}>
      <Button
        type="button"
        disabled
        aria-label={`${isApple ? "Apple App Store" : "Google Play"} — coming soon`}
        className={`${isApple ? "w-[132px] sm:w-[206px]" : "w-[136px] sm:w-[206px]"} h-11 justify-start gap-1.5 rounded-[5px] bg-store px-2 text-store-foreground shadow-sm hover:bg-store disabled:opacity-100 sm:h-[62px] sm:gap-2 sm:rounded-lg sm:px-4`}
      >
        <img
          src={isApple ? appleLogo : googlePlayLogo}
          alt=""
          aria-hidden="true"
          className={isApple ? "h-8 w-8 shrink-0 object-contain sm:h-10 sm:w-10" : "h-7 w-7 shrink-0 object-contain sm:h-9 sm:w-9"}
        />
        <span className="min-w-0 text-left leading-none">
          <span className="block whitespace-nowrap text-[8px] font-medium sm:text-[11px]">
            {isApple ? "Download on the" : "GET IT ON"}
          </span>
          <span className="mt-0.5 block whitespace-nowrap text-[15px] font-semibold sm:mt-1 sm:text-[22px]">
            {isApple ? "App Store" : "Google Play"}
          </span>
        </span>
      </Button>
    </div>
  );
};

const Landing = () => {
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div className="reli-landing min-h-screen overflow-x-hidden bg-background text-foreground">
      <main>
        <section className="mx-auto w-full max-w-5xl px-3 pb-0 pt-2 sm:px-8 sm:pt-7 lg:px-12">
          <header className="flex items-center justify-between">
            <Link to="/" aria-label="Reli home" className="inline-flex items-center">
              <img
                src={reliLogo}
                alt="Reli"
                className="h-auto w-[90px] object-contain sm:w-[166px]"
              />
            </Link>

            <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
              <SheetTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  aria-label="Open navigation menu"
                  className="h-9 w-9 rounded-full text-foreground hover:bg-primary/10 hover:text-primary sm:h-12 sm:w-12"
                >
                  <Menu className="!h-5 !w-5 sm:!h-8 sm:!w-8" strokeWidth={2.2} />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="reli-landing w-[86vw] max-w-sm bg-background px-7">
                <SheetHeader className="border-b border-border pb-6 text-left">
                  <SheetTitle>
                    <img src={reliLogo} alt="Reli" className="h-auto w-36" />
                  </SheetTitle>
                </SheetHeader>
                <nav aria-label="Main navigation" className="flex flex-col py-6">
                  {menuItems.map((item) => (
                    <Link
                      key={item.to}
                      to={item.to}
                      onClick={() => setMenuOpen(false)}
                      className="flex min-h-12 items-center justify-between border-b border-border py-3 text-lg font-semibold text-foreground transition-colors hover:text-primary"
                    >
                      {item.label}
                      <ChevronRight className="h-5 w-5 text-primary" />
                    </Link>
                  ))}
                  <Button asChild className="mt-7 h-12 rounded-full text-base">
                    <Link to="/auth" onClick={() => setMenuOpen(false)}>Sign in to Reli</Link>
                  </Button>
                </nav>
              </SheetContent>
            </Sheet>
          </header>

          <div className="mx-auto mt-3 max-w-[830px] text-left sm:mt-14">
            <h1 className="font-landing-serif text-[2.06rem] font-bold leading-[1.02] text-landing-navy sm:text-[5.35rem] sm:font-semibold sm:leading-[0.98] lg:text-[6.25rem]">
              Care for the<span className="sm:hidden"><br /></span><span className="hidden sm:inline"> </span>people you love
            </h1>
            <h2 className="mt-2 whitespace-nowrap text-[0.9rem] font-semibold leading-tight text-landing-navy sm:mt-8 sm:text-[2rem] sm:font-bold">
              Your Personal AI Companion for Everyday Living
            </h2>
            <p className="mt-1.5 max-w-3xl text-[0.82rem] leading-[1.4] text-muted-foreground sm:mt-3 sm:text-2xl sm:leading-relaxed">
              Health support, daily reminders, and peace of mind for you and the people who matter most.
            </p>

            <div className="mx-auto mt-3 grid w-full max-w-[350px] grid-cols-2 gap-2 sm:mt-10 sm:max-w-none sm:gap-5">
              <Button
                size="lg"
                onClick={() => navigate("/auth?role=senior")}
                className="h-10 min-w-0 rounded-full px-2 text-sm font-semibold shadow-sm sm:h-16 sm:px-3 sm:text-xl"
              >
                For Myself
              </Button>
              <Button
                size="lg"
                onClick={() => navigate("/auth?role=caregiver")}
                className="h-10 min-w-0 rounded-full bg-secondary px-2 text-sm font-semibold text-primary-foreground shadow-sm hover:bg-secondary/90 sm:h-16 sm:px-3 sm:text-xl"
              >
                For Caregivers
              </Button>
            </div>

            <div className="mx-auto mt-2 grid w-full max-w-[350px] grid-cols-2 gap-2 sm:mt-7 sm:max-w-none sm:gap-5">
              <Button asChild variant="link" className="h-auto min-w-0 justify-start gap-0.5 pl-[32%] pr-0 text-[12px] font-semibold sm:gap-1 sm:pl-[30%] sm:text-xl">
                <Link to="/pricing"><span className="underline decoration-primary underline-offset-[3px]">See Pricing</span> <ChevronRight className="!h-3 !w-3 sm:!h-4 sm:!w-4" /></Link>
              </Button>
              <Button asChild variant="link" className="h-auto min-w-0 justify-start gap-0.5 pl-[22%] pr-0 text-[12px] font-semibold sm:gap-1 sm:pl-[25%] sm:text-xl">
                <Link to="/faq"><span className="underline decoration-primary underline-offset-[3px]">Learn More</span> <ChevronRight className="!h-3 !w-3 sm:!h-4 sm:!w-4" /></Link>
              </Button>
            </div>

            <div className="relative z-20 mx-auto mt-3 grid w-full max-w-[284px] grid-cols-[132px_136px] justify-between gap-4 sm:mt-10 sm:max-w-[428px] sm:grid-cols-[206px_206px] sm:gap-4">
              <StoreBadge store="apple" />
              <StoreBadge store="google" />
            </div>
          </div>

          <div className="relative z-10 -mx-3 -mt-16 overflow-hidden sm:mx-auto sm:mt-10 sm:max-w-[900px]">
            <div className="absolute left-[5.5%] top-[26%] z-10 w-[22.5%] rounded-xl bg-landing-bubble/95 px-1 py-1.5 text-center text-[7px] font-semibold leading-tight text-landing-navy shadow-sm after:absolute after:-bottom-1.5 after:left-[22%] after:h-3 after:w-3 after:rotate-45 after:bg-landing-bubble/95 after:content-[''] sm:left-[3%] sm:top-[19%] sm:w-[31%] sm:rounded-2xl sm:px-4 sm:py-3 sm:text-sm sm:after:-bottom-2.5 sm:after:h-5 sm:after:w-5">
              <span className="relative z-10 mb-0.5 flex items-center justify-center gap-0.5 text-primary sm:mb-1 sm:gap-1">
                <Bell className="h-3 w-3 fill-current sm:h-5 sm:w-5" />
                <Pill className="h-3 w-3 sm:h-5 sm:w-5" />
              </span>
              <span className="relative z-10 block">Time for</span>
              <span className="relative z-10 block">Your Medication</span>
            </div>
            <div className="absolute right-[6.5%] top-[24%] z-[5] w-[14%] border-[3px] border-primary/20 bg-background/55 px-1 py-1 text-center text-[6px] font-medium leading-[1.08] text-muted-foreground/70 shadow-sm blur-[0.15px] sm:right-[5.8%] sm:top-[14%] sm:border-4 sm:px-2 sm:py-2 sm:text-xs">
              Brighter<br />days<br />together
              <Heart className="mx-auto mt-0.5 h-2 w-2 fill-primary/35 text-primary/35 sm:h-3 sm:w-3" />
            </div>
            <picture>
              <source
                type="image/webp"
                srcSet={`${familyIllustration480} 480w, ${familyIllustration640} 640w, ${familyIllustration960} 960w, ${familyIllustration1280} 1280w`}
                sizes="(max-width: 639px) 100vw, 900px"
              />
              <img
                src={familyIllustration}
                alt="A grandmother surrounded by her loving family in a cozy living room"
                width={1280}
                height={1280}
                loading="eager"
                decoding="async"
                className="block h-auto w-full object-contain sm:mx-auto sm:mt-0 sm:scale-100 sm:rounded-t-[2rem]"
              />
            </picture>
          </div>
        </section>

        <Newsletter />
      </main>

      <footer className="border-t border-border bg-background px-5 py-8 text-center">
        <img src={reliLogo} alt="Reli" className="mx-auto h-auto w-28" />
        <p className="mt-3 text-sm text-muted-foreground">© {new Date().getFullYear()} Reli. All rights reserved.</p>
        <div className="mt-4 flex flex-wrap justify-center gap-x-5 gap-y-2 text-sm">
          {menuItems.slice(2).map((item) => (
            <Link key={item.to} to={item.to} className="font-medium text-primary underline-offset-4 hover:underline">
              {item.label}
            </Link>
          ))}
        </div>
      </footer>
    </div>
  );
};

export default Landing;