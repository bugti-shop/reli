CREATE TABLE public.life_story_memories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  senior_id uuid NOT NULL,
  category text NOT NULL CHECK (category IN ('first_job','best_friend','first_pet')),
  details jsonb NOT NULL DEFAULT '{}'::jsonb,
  image_path text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.life_story_memories TO authenticated;
GRANT ALL ON public.life_story_memories TO service_role;
ALTER TABLE public.life_story_memories ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Seniors manage own memories" ON public.life_story_memories FOR ALL TO authenticated
  USING (senior_id = auth.uid()) WITH CHECK (senior_id = auth.uid());
CREATE POLICY "Caregivers view linked memories" ON public.life_story_memories FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.caregiver_seniors cs WHERE cs.senior_id = life_story_memories.senior_id AND cs.caregiver_id = auth.uid()));
CREATE TRIGGER life_story_memories_updated BEFORE UPDATE ON public.life_story_memories FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

CREATE POLICY "Seniors manage own life story images" ON storage.objects FOR ALL TO authenticated
  USING (bucket_id = 'life-story-images' AND (storage.foldername(name))[1] = auth.uid()::text)
  WITH CHECK (bucket_id = 'life-story-images' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "Caregivers view linked life story images" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'life-story-images' AND EXISTS (SELECT 1 FROM public.caregiver_seniors cs WHERE cs.senior_id::text = (storage.foldername(name))[1] AND cs.caregiver_id = auth.uid()));