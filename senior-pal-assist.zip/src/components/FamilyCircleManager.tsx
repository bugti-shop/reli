import { useCallback, useEffect, useState } from "react";
import { Check, Clock3, Mail, ShieldCheck, Trash2, UserRoundCheck, X } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface Invite {
  id: string;
  invitee_email: string | null;
  relationship: string;
  created_at: string;
  expires_at: string;
  requested_at: string | null;
  approved_at: string | null;
  declined_at: string | null;
}

interface Member {
  id: string;
  caregiver_id: string;
  relationship: string;
  created_at: string | null;
  profile: { full_name: string | null; email: string } | null;
}

const dateLabel = (value: string) => new Intl.DateTimeFormat("en-US", {
  month: "short",
  day: "numeric",
  year: "numeric",
}).format(new Date(value));

export const FamilyCircleManager = ({ seniorId, currentUserId }: { seniorId: string; currentUserId: string }) => {
  const [invites, setInvites] = useState<Invite[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [loading, setLoading] = useState(true);
  const [workingId, setWorkingId] = useState<string | null>(null);
  const { toast } = useToast();

  const load = useCallback(async () => {
    setLoading(true);
    const [inviteResult, memberResult] = await Promise.all([
      supabase.from("circle_invites")
        .select("id, invitee_email, relationship, created_at, expires_at, requested_at, approved_at, declined_at")
        .eq("senior_id", seniorId)
        .not("invitee_email", "is", null)
        .order("created_at", { ascending: false }),
      supabase.from("caregiver_seniors")
        .select("id, caregiver_id, relationship, created_at, profile:profiles!caregiver_seniors_caregiver_id_fkey(full_name, email)")
        .eq("senior_id", seniorId)
        .order("created_at", { ascending: false }),
    ]);
    if (inviteResult.error || memberResult.error) {
      toast({ title: "Could not load requests", variant: "destructive" });
    }
    setInvites((inviteResult.data as Invite[]) || []);
    setMembers((memberResult.data as unknown as Member[]) || []);
    setLoading(false);
  }, [seniorId, toast]);

  useEffect(() => { load(); }, [load]);

  const runInviteAction = async (id: string, action: "approve" | "decline" | "cancel") => {
    setWorkingId(id);
    const rpcName = action === "approve" ? "approve_circle_invite" : action === "decline" ? "decline_circle_invite" : "cancel_circle_invite";
    const { error } = await supabase.rpc(rpcName, { _invite_id: id });
    setWorkingId(null);
    if (error) {
      const limit = error.message.includes("LIMIT_REACHED");
      toast({
        title: action === "approve" ? "Could not approve request" : "Could not update invitation",
        description: limit ? "Free plan limit reached — Premium allows more family members." : error.message,
        variant: "destructive",
      });
      return;
    }
    toast({ title: action === "approve" ? "Family member approved" : action === "decline" ? "Request declined" : "Invitation cancelled" });
    await load();
  };

  const removeMember = async (member: Member) => {
    const name = member.profile?.full_name || member.profile?.email || "this family member";
    if (!window.confirm(`Remove ${name} from this senior's circle?`)) return;
    setWorkingId(member.id);
    const { error } = await supabase.rpc("remove_circle_member", { _link_id: member.id });
    setWorkingId(null);
    if (error) {
      toast({ title: "Could not remove access", description: error.message, variant: "destructive" });
      return;
    }
    toast({ title: "Access removed" });
    await load();
  };

  const requested = invites.filter((invite) => invite.requested_at && !invite.approved_at && !invite.declined_at);
  const invited = invites.filter((invite) => !invite.requested_at && !invite.approved_at && !invite.declined_at && new Date(invite.expires_at) > new Date());

  return (
    <Card className="border p-5">
      <div className="mb-4 flex items-start gap-3">
        <ShieldCheck className="mt-0.5 h-5 w-5 text-primary" />
        <div>
          <h3 className="font-semibold">Add Senior</h3>
          <p className="text-sm text-muted-foreground">Review requests and manage who can follow this senior.</p>
        </div>
      </div>

      {loading ? <p className="text-sm text-muted-foreground">Loading…</p> : (
        <div className="space-y-5">
          <section>
            <div className="mb-2 flex items-center gap-2"><Clock3 className="h-4 w-4 text-primary" /><h4 className="text-sm font-semibold">Requested</h4><Badge variant="secondary">{requested.length}</Badge></div>
            {requested.length === 0 ? <p className="text-sm text-muted-foreground">No requests waiting for approval.</p> : (
              <ul className="space-y-2">
                {requested.map((invite) => <li key={invite.id} className="flex flex-col gap-3 rounded-md border p-3 sm:flex-row sm:items-center sm:justify-between">
                  <div className="min-w-0"><p className="truncate font-medium">{invite.invitee_email}</p><p className="text-xs text-muted-foreground">Requested {dateLabel(invite.requested_at as string)}</p></div>
                  <div className="flex gap-2"><Button size="sm" disabled={workingId === invite.id} onClick={() => runInviteAction(invite.id, "approve")}><Check className="mr-1 h-4 w-4" />Approve</Button><Button size="sm" variant="outline" disabled={workingId === invite.id} onClick={() => runInviteAction(invite.id, "decline")}><X className="mr-1 h-4 w-4" />Decline</Button></div>
                </li>)}
              </ul>
            )}
          </section>

          <section>
            <div className="mb-2 flex items-center gap-2"><Mail className="h-4 w-4 text-primary" /><h4 className="text-sm font-semibold">Invited</h4><Badge variant="secondary">{invited.length}</Badge></div>
            {invited.length === 0 ? <p className="text-sm text-muted-foreground">No unopened email invitations.</p> : (
              <ul className="space-y-2">{invited.map((invite) => <li key={invite.id} className="flex items-center justify-between gap-3 rounded-md border p-3"><div className="min-w-0"><p className="truncate font-medium">{invite.invitee_email}</p><p className="text-xs text-muted-foreground">Expires {dateLabel(invite.expires_at)}</p></div><Button size="sm" variant="ghost" disabled={workingId === invite.id} onClick={() => runInviteAction(invite.id, "cancel")}>Cancel</Button></li>)}</ul>
            )}
          </section>

          <section>
            <div className="mb-2 flex items-center gap-2"><UserRoundCheck className="h-4 w-4 text-primary" /><h4 className="text-sm font-semibold">Accepted</h4><Badge variant="secondary">{members.length}</Badge></div>
            {members.length === 0 ? <p className="text-sm text-muted-foreground">No accepted family members yet.</p> : (
              <ul className="space-y-2">{members.map((member) => <li key={member.id} className="flex items-center justify-between gap-3 rounded-md border p-3"><div className="min-w-0"><p className="truncate font-medium">{member.profile?.full_name || member.profile?.email}</p><p className="text-xs capitalize text-muted-foreground">{member.relationship} · Accepted {member.created_at ? dateLabel(member.created_at) : "recently"}</p></div>{member.caregiver_id === currentUserId ? <Badge variant="outline">You</Badge> : <Button size="icon" variant="ghost" aria-label="Remove family member" disabled={workingId === member.id} onClick={() => removeMember(member)}><Trash2 className="h-4 w-4" /></Button>}</li>)}</ul>
            )}
          </section>
        </div>
      )}
    </Card>
  );
};