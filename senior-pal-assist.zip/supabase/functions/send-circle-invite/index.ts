import { createClient } from 'npm:@supabase/supabase-js@2'
import { z } from 'npm:zod@3.23.8'
import { sendTemplateEmail } from '../_shared/transactional-email-templates/send-email.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: { ...corsHeaders, 'Content-Type': 'application/json' },
})

const BodySchema = z.object({
  inviteId: z.string().uuid(),
  email: z.string().trim().email().max(255),
})

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405)

  try {
    const authHeader = req.headers.get('Authorization') ?? ''
    const userClient = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_ANON_KEY')!,
      { global: { headers: { Authorization: authHeader } } },
    )
    const { data: userData } = await userClient.auth.getUser()
    const user = userData?.user
    if (!user) return json({ error: 'Please sign in first.' }, 401)

    const parsed = BodySchema.safeParse(await req.json().catch(() => ({})))
    if (!parsed.success) return json({ error: 'Please enter a valid email address.' }, 400)

    const admin = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
    )
    const { data: invite } = await admin
      .from('circle_invites')
      .select('id, senior_id, created_by, code, expires_at, used_at')
      .eq('id', parsed.data.inviteId)
      .maybeSingle()

    if (!invite || invite.created_by !== user.id) return json({ error: 'Invitation not found.' }, 404)
    if (invite.used_at) return json({ error: 'This invitation was already used.' }, 409)
    if (new Date(invite.expires_at).getTime() <= Date.now()) return json({ error: 'This invitation has expired.' }, 410)

    const { data: inviter } = await admin
      .from('profiles')
      .select('full_name')
      .eq('id', user.id)
      .maybeSingle()

    const normalizedEmail = parsed.data.email.toLowerCase()
    const { error: bindError } = await admin
      .from('circle_invites')
      .update({ invitee_email: normalizedEmail })
      .eq('id', invite.id)
    if (bindError) return json({ error: 'The invitation could not be secured to this email.' }, 500)

    const inviteUrl = `https://reli.care/join/${encodeURIComponent(invite.code)}`
    const result = await sendTemplateEmail('family-circle-invite', parsed.data.email, {
      templateData: {
        inviterName: inviter?.full_name || 'Someone close to you',
        inviteCode: invite.code,
        inviteUrl,
      },
      idempotencyKey: `family-circle-${invite.id}-${parsed.data.email.toLowerCase()}`,
    })

    if (!result.sent) return json({ error: 'This email address cannot receive Reli invitations.' }, 409)
    return json({ sent: true })
  } catch (error) {
    console.error('send-circle-invite error', error)
    return json({ error: 'The invitation could not be sent. Please try again.' }, 500)
  }
})