REVOKE EXECUTE ON FUNCTION public.has_store_premium(uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.has_store_premium(uuid) TO service_role;