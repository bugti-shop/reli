
-- 1. Fix caregiver_seniors INSERT: require caller to actually have the caregiver role
DROP POLICY IF EXISTS "Caregivers can add seniors" ON public.caregiver_seniors;
CREATE POLICY "Caregivers can add seniors"
  ON public.caregiver_seniors FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = caregiver_id
    AND EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND role = 'caregiver'
    )
  );

-- 2. Prevent users from changing their own role via profiles UPDATE
DROP POLICY IF EXISTS "Users can update their own profile" ON public.profiles;
CREATE POLICY "Users can update their own profile"
  ON public.profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (
    auth.uid() = id
    AND role = (SELECT role FROM public.profiles WHERE id = auth.uid())
  );

-- 3. caregiver_messages INSERT: bind caregiver_id to auth.uid()
DROP POLICY IF EXISTS "Caregivers can create messages for their seniors" ON public.caregiver_messages;
CREATE POLICY "Caregivers can create messages for their seniors"
  ON public.caregiver_messages FOR INSERT
  TO authenticated
  WITH CHECK (
    caregiver_id = auth.uid()
    AND EXISTS (
      SELECT 1 FROM public.caregiver_seniors
      WHERE caregiver_seniors.caregiver_id = auth.uid()
        AND caregiver_seniors.senior_id = caregiver_messages.senior_id
    )
  );

-- 4. Fix ineffective deny-anon policies (PERMISSIVE false -> RESTRICTIVE for anon)
DROP POLICY IF EXISTS "deny_anon_access_medications" ON public.medications;
CREATE POLICY "deny_anon_access_medications"
  ON public.medications AS RESTRICTIVE FOR ALL
  TO anon
  USING (false)
  WITH CHECK (false);

DROP POLICY IF EXISTS "deny_anon_access_caregiver_daily_logs" ON public.caregiver_daily_logs;
CREATE POLICY "deny_anon_access_caregiver_daily_logs"
  ON public.caregiver_daily_logs AS RESTRICTIVE FOR ALL
  TO anon
  USING (false)
  WITH CHECK (false);

-- 5. Realtime authorization: only allow users to subscribe to topics they own
ALTER TABLE IF EXISTS realtime.messages ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can receive their own realtime messages" ON realtime.messages;
CREATE POLICY "Users can receive their own realtime messages"
  ON realtime.messages FOR SELECT
  TO authenticated
  USING (
    -- Topic format expected: "user:<uuid>" - users may only subscribe to their own topic,
    -- or topics for seniors they care for.
    (
      realtime.topic() = 'user:' || auth.uid()::text
    )
    OR EXISTS (
      SELECT 1 FROM public.caregiver_seniors
      WHERE caregiver_seniors.caregiver_id = auth.uid()
        AND realtime.topic() = 'user:' || caregiver_seniors.senior_id::text
    )
  );
