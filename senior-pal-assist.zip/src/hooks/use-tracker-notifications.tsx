import { useCallback, useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

type Permission = "default" | "granted" | "denied" | "unsupported";

interface ScheduleItem {
  key: string;
  time: string; // HH:MM
  title: string;
  body: string;
  days: number[]; // 0 = Sunday
  date?: string; // one-time reminders (toDateString)
}

const ALL_DAYS = [0, 1, 2, 3, 4, 5, 6];

const STORAGE_KEY = "reli-fired-reminders";

const hhmm = (d: Date) =>
  `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;

const normalizeTime = (t: string) => t.slice(0, 5);

const loadFired = (): Record<string, true> => {
  try {
    const raw = JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}");
    const today = new Date().toDateString();
    return raw.day === today ? raw.keys || {} : {};
  } catch {
    return {};
  }
};

// Short audible alarm (three rising beeps, repeated) + vibration so a
// reminder is hard to miss while the app is open.
export const playReminderAlarm = () => {
  try {
    const Ctx = (window as any).AudioContext || (window as any).webkitAudioContext;
    if (Ctx) {
      const ctx = new Ctx();
      const start = ctx.currentTime;
      for (let r = 0; r < 3; r++) {
        [880, 988, 1175].forEach((freq, i) => {
          const t = start + r * 1.2 + i * 0.25;
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = "square";
          osc.frequency.value = freq;
          gain.gain.setValueAtTime(0.0001, t);
          gain.gain.exponentialRampToValueAtTime(0.35, t + 0.02);
          gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.22);
          osc.connect(gain).connect(ctx.destination);
          osc.start(t);
          osc.stop(t + 0.24);
        });
      }
      window.setTimeout(() => ctx.close?.(), 4500);
    }
    navigator.vibrate?.([400, 200, 400, 200, 600]);
  } catch (e) {
    console.error("Reminder alarm failed:", e);
  }
};

const saveFired = (keys: Record<string, true>) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify({ day: new Date().toDateString(), keys }));
};

/**
 * Schedules in-app + browser notifications for medication times and
 * blood pressure / heart rate reading reminders for a senior.
 */
export const useTrackerNotifications = (
  seniorIdOrIds?: string | string[],
  enabled = true,
  seniorNames?: Record<string, string>,
) => {
  const ids = Array.isArray(seniorIdOrIds) ? seniorIdOrIds : seniorIdOrIds ? [seniorIdOrIds] : [];
  const idsKey = ids.join(",");
  const seniorId = idsKey || undefined;
  const namesRef = useRef(seniorNames);
  namesRef.current = seniorNames;
  const { toast } = useToast();
  const [permission, setPermission] = useState<Permission>(
    typeof window !== "undefined" && "Notification" in window
      ? (Notification.permission as Permission)
      : "unsupported",
  );
  const scheduleRef = useRef<ScheduleItem[]>([]);
  const firedRef = useRef<Record<string, true>>(loadFired());

  const requestPermission = useCallback(async () => {
    if (!("Notification" in window)) {
      setPermission("unsupported");
      return "unsupported" as Permission;
    }
    const result = await Notification.requestPermission();
    setPermission(result as Permission);
    return result as Permission;
  }, []);

  const loadSchedule = useCallback(async () => {
    if (!seniorId) return;

    const seniorIds = seniorId.split(",");
    const dayStart = new Date(); dayStart.setHours(0, 0, 0, 0);
    const dayEnd = new Date(dayStart); dayEnd.setDate(dayEnd.getDate() + 2);
    const [{ data: meds }, { data: reminders }, { data: oneTime }] = await Promise.all([
      supabase
        .from("medications")
        .select("id, senior_id, name, time, dosage, completed, days_of_week")
        .in("senior_id", seniorIds),
      supabase
        .from("tracker_reminders")
        .select("id, senior_id, kind, label, time, enabled, days_of_week")
        .in("senior_id", seniorIds)
        .eq("enabled", true),
      supabase
        .from("caregiver_messages")
        .select("id, senior_id, message, reminder_time")
        .in("senior_id", seniorIds)
        .eq("is_reminder", true)
        .gte("reminder_time", dayStart.toISOString())
        .lt("reminder_time", dayEnd.toISOString()),
    ]);
    const forName = (sid: string) => {
      const n = namesRef.current?.[sid];
      return n ? ` — ${n}` : "";
    };

    const items: ScheduleItem[] = [];

    // Group medications that share the same time and days into one
    // notification instead of one alert per pill.
    const medGroups = new Map<string, ScheduleItem>();
    (meds || []).forEach((m) => {
      if (!m.time || m.completed) return;
      const time = normalizeTime(m.time);
      const days = (m.days_of_week as number[]) ?? ALL_DAYS;
      const gKey = `medgroup-${m.senior_id}-${time}-${[...days].sort((a, b) => a - b).join("")}`;
      const label = `${m.name}${m.dosage ? ` — ${m.dosage}` : ""}`;
      const existing = medGroups.get(gKey);
      if (existing) {
        existing.body += `, ${label}`;
        existing.title = `Time for medications${forName(m.senior_id)}`;
      } else {
        medGroups.set(gKey, {
          key: gKey,
          time,
          title: `Time for medication${forName(m.senior_id)}`,
          body: label,
          days,
        });
      }
    });
    items.push(...medGroups.values());

    (reminders || []).forEach((r) => {
      const days = (r.days_of_week as number[]) ?? ALL_DAYS;
      if (r.kind === "custom") {
        items.push({
          key: `rem-${r.id}`,
          time: normalizeTime(r.time),
          title: `Reminder${forName(r.senior_id)}`,
          body: r.label || "You set a reminder for now.",
          days,
        });
        return;
      }
      const label =
        r.label ||
        (r.kind === "blood_pressure"
          ? "blood pressure"
          : r.kind === "heart_rate"
            ? "heart rate"
            : "medication");
      items.push({
        key: `rem-${r.id}`,
        time: normalizeTime(r.time),
        title: `${r.kind === "medication" ? "Medication reminder" : "Time to take a reading"}${forName(r.senior_id)}`,
        body: `Please record ${label}.`,
        days,
      });
    });

    (oneTime || []).forEach((m) => {
      if (!m.reminder_time) return;
      const at = new Date(m.reminder_time);
      items.push({
        key: `msg-${m.id}`,
        time: hhmm(at),
        title: `Reminder${forName(m.senior_id)}`,
        body: m.message,
        days: [],
        date: at.toDateString(),
      });
    });

    scheduleRef.current = items;
  }, [seniorId]);

  useEffect(() => {
    if (!seniorId || !enabled) return;
    loadSchedule();
    const refresh = window.setInterval(loadSchedule, 5 * 60 * 1000);
    window.addEventListener("reli:schedule-changed", loadSchedule);
    return () => {
      window.clearInterval(refresh);
      window.removeEventListener("reli:schedule-changed", loadSchedule);
    };
  }, [seniorId, enabled, loadSchedule]);

  useEffect(() => {
    if (!seniorId || !enabled) return;

    const check = () => {
      const nowDate = new Date();
      const now = hhmm(nowDate);
      const today = nowDate.getDay();
      scheduleRef.current.forEach((item) => {
        const firedKey = `${item.key}-${item.time}`;
        if (item.time !== now || firedRef.current[firedKey]) return;
        if (item.date && item.date !== nowDate.toDateString()) return;
        if (!item.date && item.days.length > 0 && !item.days.includes(today)) return;

        firedRef.current[firedKey] = true;
        saveFired(firedRef.current);

        toast({ title: `⏰ ${item.title}`, description: item.body, duration: 30000 });
        playReminderAlarm();

        // Emails and texts are sent by the scheduled send-tracker-reminders
        // function so they arrive even when the app is closed.



        if ("Notification" in window && Notification.permission === "granted") {
          try {
            new Notification(item.title, { body: item.body, tag: firedKey, requireInteraction: true } as NotificationOptions);
          } catch (e) {
            console.error("Notification failed:", e);
          }
        }
      });
    };

    check();
    const timer = window.setInterval(check, 30000);
    return () => window.clearInterval(timer);
  }, [seniorId, enabled, toast]);

  return { permission, requestPermission, reloadSchedule: loadSchedule };
};
