// Receives App Store / Google Play subscription events from RevenueCat and
// keeps store_entitlements + profiles.plan in sync. RevenueCat app_user_id is
// the Reli user id (set by Purchases.logIn in the app).
import { createClient } from 'npm:@supabase/supabase-js@2.57.2'

const ACTIVE = new Set(['INITIAL_PURCHASE', 'RENEWAL', 'UNCANCELLATION', 'PRODUCT_CHANGE', 'NON_RENEWING_PURCHASE', 'SUBSCRIPTION_EXTENDED', 'TEMPORARY_ENTITLEMENT_GRANT'])
const ENDED = new Set(['EXPIRATION', 'REFUND_REVERSED_NOT', 'SUBSCRIPTION_PAUSED'])
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i
const PREMIUM_PRODUCT_ID = 'com.reli.care.monthly'

Deno.serve(async (req) => {
  if (req.method !== 'POST') return new Response('Method not allowed', { status: 405 })
  const expected = Deno.env.get('REVENUECAT_WEBHOOK_AUTH')
  if (!expected || req.headers.get('authorization') !== `Bearer ${expected}`) {
    return new Response('Unauthorized', { status: 401 })
  }

  let body: any
  try { body = await req.json() } catch { return new Response('Bad JSON', { status: 400 }) }
  const ev = body?.event
  if (!ev || typeof ev.type !== 'string') return new Response('Bad event', { status: 400 })
  if (ev.product_id !== PREMIUM_PRODUCT_ID) {
    return new Response(JSON.stringify({ ignored: 'unrecognized product' }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    })
  }

  const userId: string | undefined = [ev.app_user_id, ...(ev.aliases || [])].find((v: unknown) => typeof v === 'string' && UUID.test(v))
  if (!userId) return new Response(JSON.stringify({ ignored: 'no reli user id' }), { status: 200 })

  const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!)
  const expiresAt = typeof ev.expiration_at_ms === 'number' ? new Date(ev.expiration_at_ms).toISOString() : null
  const store = ev.store === 'PLAY_STORE' ? 'google_play' : ev.store === 'APP_STORE' ? 'app_store' : String(ev.store || 'unknown').toLowerCase()

  let active: boolean | null = null
  if (ACTIVE.has(ev.type)) active = !expiresAt || new Date(expiresAt) > new Date()
  else if (ENDED.has(ev.type) || ev.type === 'REFUND') active = false
  // CANCELLATION / BILLING_ISSUE keep access until the paid period ends.
  if (active === null) return new Response(JSON.stringify({ ok: true, unchanged: ev.type }), { status: 200 })

  const { error } = await admin.from('store_entitlements').upsert({
    user_id: userId, store, product_id: ev.product_id ?? null, active, expires_at: expiresAt,
    last_event_id: String(ev.id ?? ''), updated_at: new Date().toISOString(),
  })
  if (error) {
    console.error('[revenuecat] upsert failed', error.message)
    return new Response('DB error', { status: 500 })
  }
  await admin.from('profiles').update({ plan: active ? 'premium' : 'free' }).eq('id', userId)
  return new Response(JSON.stringify({ ok: true, active }), { status: 200, headers: { 'Content-Type': 'application/json' } })
})
