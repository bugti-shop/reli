import { CloudOff, RefreshCw, UploadCloud } from "lucide-react";
import { useOfflineSync } from "@/hooks/use-offline-sync";
import { Button } from "@/components/ui/button";

/**
 * Shows a friendly, senior-readable notice when the device is offline
 * or still has entries waiting to upload.
 */
export const OfflineBanner = () => {
  const { online, pendingCount, syncing, sync } = useOfflineSync();

  if (online && pendingCount === 0) return null;

  const waiting =
    pendingCount === 1 ? "1 entry" : `${pendingCount} entries`;

  return (
    <div
      role="status"
      aria-live="polite"
      className={`rounded-xl border-2 p-4 flex flex-wrap items-center gap-3 ${
        online
          ? "border-primary/40 bg-primary/10"
          : "border-amber-500/50 bg-amber-500/10"
      }`}
    >
      {online ? (
        <UploadCloud className="w-6 h-6 text-primary flex-shrink-0" />
      ) : (
        <CloudOff className="w-6 h-6 text-amber-600 dark:text-amber-400 flex-shrink-0" />
      )}
      <div className="flex-1 min-w-[220px]">
        <p className="text-lg font-semibold">
          {online ? "Uploading your saved entries" : "No internet right now"}
        </p>
        <p className="text-base text-muted-foreground">
          {online
            ? `${waiting} saved on this device ${
                pendingCount === 1 ? "is" : "are"
              } being sent now.`
            : pendingCount > 0
            ? `${waiting} saved on this device. They will upload automatically when you're back online.`
            : "You can still write in your journal, tick off medications and add readings — everything saves on this device."}
        </p>
      </div>
      {online && pendingCount > 0 && (
        <Button size="lg" variant="outline" onClick={sync} disabled={syncing} className="gap-2">
          <RefreshCw className={`w-5 h-5 ${syncing ? "animate-spin" : ""}`} />
          {syncing ? "Sending..." : "Send now"}
        </Button>
      )}
    </div>
  );
};

export default OfflineBanner;
