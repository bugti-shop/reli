CREATE EXTENSION IF NOT EXISTS pg_cron WITH SCHEMA extensions;
CREATE EXTENSION IF NOT EXISTS pg_net WITH SCHEMA extensions;

SELECT cron.unschedule('reli-daily-summaries')
WHERE EXISTS (SELECT 1 FROM cron.job WHERE jobname = 'reli-daily-summaries');

SELECT cron.schedule(
  'reli-daily-summaries',
  '0 * * * *',
  $$
  SELECT net.http_post(
    url := 'https://hwncdhbbqwelbhbzikqd.supabase.co/functions/v1/send-daily-summaries',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'x-cron-key', '10083a469e8a43875534be1d10378eb46bfff2997d146d6f'
    ),
    body := '{}'::jsonb
  ) AS request_id;
  $$
);