import * as React from 'npm:react@18.3.1'
import {
  Body,
  Button,
  Container,
  Head,
  Heading,
  Html,
  Preview,
  Section,
  Text,
} from 'npm:@react-email/components@0.0.22'
import type { TemplateEntry } from './registry.ts'

interface Props {
  inviterName?: string
  inviteCode?: string
  inviteUrl?: string
}

const Email = ({ inviterName = 'Someone close to you', inviteCode = '', inviteUrl = '' }: Props) => (
  <Html lang="en" dir="ltr">
    <Head />
    <Preview>{inviterName} invited you to join their Reli Family Circle</Preview>
    <Body style={main}>
      <Container style={container}>
        <Heading style={heading}>Join my Family Circle</Heading>
        <Text style={text}>
          {inviterName} invited you to request access to their Reli Family Circle. Nothing is shared until an existing caregiver approves your request.
        </Text>
        <Section style={codeBox}>
          <Text style={codeLabel}>YOUR INVITATION CODE</Text>
          <Text style={codeText}>{inviteCode}</Text>
        </Section>
        <Button href={inviteUrl} style={button}>Request to join</Button>
        <Text style={smallText}>This secure invitation works only for this email address and expires after 7 days.</Text>
        <Text style={footer}>Care Today. A Brighter Tomorrow. — Reli</Text>
      </Container>
    </Body>
  </Html>
)

export const template = {
  component: Email,
  subject: (data: Record<string, any>) => `${data.inviterName || 'Someone'} invited you to their Reli Family Circle`,
  displayName: 'Family Circle invitation',
  previewData: {
    inviterName: 'Mary',
    inviteCode: 'AB12CD34',
    inviteUrl: 'https://reli.care/join/AB12CD34',
  },
} satisfies TemplateEntry

const main = { backgroundColor: '#ffffff', fontFamily: 'Arial, sans-serif' }
const container = { padding: '28px 25px', maxWidth: '560px' }
const heading = { color: 'hsl(211, 52%, 34%)', fontSize: '26px', margin: '0 0 18px' }
const text = { color: 'hsl(24, 20%, 15%)', fontSize: '16px', lineHeight: '1.6', margin: '0 0 20px' }
const codeBox = { backgroundColor: 'hsl(209, 68%, 95%)', borderRadius: '8px', padding: '18px', textAlign: 'center' as const, margin: '0 0 22px' }
const codeLabel = { color: 'hsl(24, 15%, 45%)', fontSize: '11px', fontWeight: 'bold' as const, margin: '0 0 6px' }
const codeText = { color: 'hsl(211, 52%, 34%)', fontSize: '28px', fontWeight: 'bold' as const, letterSpacing: '4px', margin: '0' }
const button = { backgroundColor: 'hsl(206, 55%, 38%)', borderRadius: '8px', color: '#ffffff', fontSize: '16px', fontWeight: 'bold' as const, padding: '13px 22px', textDecoration: 'none' }
const smallText = { color: 'hsl(24, 15%, 45%)', fontSize: '13px', lineHeight: '1.5', margin: '22px 0 0' }
const footer = { color: '#777777', fontSize: '12px', margin: '28px 0 0' }