import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

const allowedOrigins = [
  "https://1b7db766-f4d9-4f96-a0bc-d09948773d32.lovableproject.com",
  "https://senior-pal-assist.lovable.app",
  "https://reli.care",
  "https://www.reli.care",
  "https://hwncdhbbqwelbhbzikqd.supabase.co",
  "http://localhost:8080",
  "http://localhost:5173",
  "http://localhost:3000",
];

function getCorsHeaders(req: Request) {
  const origin = req.headers.get("origin") || "";
  const isAllowed = allowedOrigins.includes(origin) ||
    /^https:\/\/([a-z0-9-]+\.)*(lovable\.app|lovableproject\.com|reli\.care)$/i.test(origin) ||
    origin.startsWith('capacitor://') || origin === 'http://localhost';
  const allowedOrigin = isAllowed ? origin : allowedOrigins[0];
  return {
    "Access-Control-Allow-Origin": allowedOrigin,
    "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
    "Access-Control-Allow-Credentials": "true",
  };
}

const requestSchema = z.object({
  seniorId: z.string().uuid(),
  days: z.number().int().min(7).max(365).optional(),
});

serve(async (req) => {
  const corsHeaders = getCorsHeaders(req);

  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Authentication required." }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY");
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");

    if (!supabaseUrl || !supabaseAnonKey || !LOVABLE_API_KEY) {
      console.error("Missing configuration");
      return new Response(JSON.stringify({ error: "Service temporarily unavailable." }), {
        status: 503,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const parsed = requestSchema.safeParse(await req.json());
    if (!parsed.success) {
      return new Response(JSON.stringify({ error: parsed.error.flatten().fieldErrors }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const { seniorId, days = 90 } = parsed.data;

    // User-scoped client: RLS guarantees the caller may only read this senior's data
    const supabase = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: userData, error: userError } = await supabase.auth.getUser();
    if (userError || !userData?.user) {
      return new Response(JSON.stringify({ error: "Invalid session. Please log in again." }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const since = new Date(Date.now() - days * 86400000).toISOString();

    const [{ data: vitals }, { data: doses }, { data: meds }] = await Promise.all([
      supabase
        .from("vital_readings")
        .select("reading_type, systolic, diastolic, bpm, recorded_at, notes")
        .eq("senior_id", seniorId)
        .is("deleted_at", null)
        .gte("recorded_at", since)
        .order("recorded_at", { ascending: true })
        .limit(500),
      supabase
        .from("medication_doses")
        .select("medication_name, scheduled_time, taken_at")
        .eq("senior_id", seniorId)
        .is("deleted_at", null)
        .gte("taken_at", since)
        .order("taken_at", { ascending: true })
        .limit(500),
      supabase.from("medications").select("name, time, dosage").eq("senior_id", seniorId).limit(50),
    ]);

    const vitalCount = vitals?.length ?? 0;
    const doseCount = doses?.length ?? 0;

    if (vitalCount === 0 && doseCount === 0) {
      return new Response(
        JSON.stringify({
          insight:
            "There isn't enough recorded data yet to spot trends. Add a few blood pressure or heart rate readings and check off medications for a week or two, then come back for an analysis.",
          dataPoints: 0,
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const summary = {
      period_days: days,
      blood_pressure: (vitals || [])
        .filter((v) => v.reading_type === "blood_pressure")
        .map((v) => ({ date: v.recorded_at, systolic: v.systolic, diastolic: v.diastolic, notes: v.notes })),
      heart_rate: (vitals || [])
        .filter((v) => v.reading_type === "heart_rate")
        .map((v) => ({ date: v.recorded_at, bpm: v.bpm, notes: v.notes })),
      scheduled_medications: meds || [],
      medication_doses_taken: doses || [],
    };

    const systemPrompt = `You are a caregiving assistant that reviews home health tracking data for an older adult.
Analyze the provided blood pressure readings, heart rate readings, and medication adherence records.

Write a clear, warm, plain-language summary for a family caregiver, using these sections with these exact markdown headings:
## Overall
## Blood Pressure
## Heart Rate
## Medication Adherence
## What To Watch

Rules:
- Use short sentences and simple words. No medical jargon.
- Describe direction of change (rising, falling, steady) with actual numbers and averages.
- Point out missed medication patterns (e.g. evening doses often missed).
- Skip a section with one line if there is no data for it.
- Never diagnose, never suggest changing medications or doses.
- End "What To Watch" with a reminder to share this with their doctor and to call a doctor or emergency services about anything concerning.`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: `Here is the tracking data as JSON:\n${JSON.stringify(summary)}` },
        ],
        stream: false,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Too many requests right now. Please try again in a minute." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      return new Response(JSON.stringify({ error: "Could not analyze trends right now. Please try again." }), {
        status: 502,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const result = await response.json();
    const insight = result?.choices?.[0]?.message?.content ?? "No insight was generated. Please try again.";

    return new Response(
      JSON.stringify({ insight, dataPoints: vitalCount + doseCount }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (error) {
    console.error("analyze-health-trends error:", error);
    return new Response(JSON.stringify({ error: "An unexpected error occurred. Please try again." }), {
      status: 500,
      headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
    });
  }
});
