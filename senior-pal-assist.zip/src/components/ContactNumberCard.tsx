import { useEffect, useState } from "react";
import { Phone } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

/** Lets a caregiver save the phone number seniors can tap to call. */
export const ContactNumberCard = ({ userId }: { userId: string }) => {
  const [phone, setPhone] = useState("");
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const load = async () => {
      const { data } = await supabase.from("profiles").select("phone").eq("id", userId).maybeSingle();
      if (data?.phone) setPhone(data.phone);
    };
    load();
  }, [userId]);

  const save = async () => {
    setSaving(true);
    const { error } = await supabase.from("profiles").update({ phone: phone.trim() || null }).eq("id", userId);
    setSaving(false);
    if (error) {
      toast({ title: "Could not save", description: "Please try again.", variant: "destructive" });
      return;
    }
    toast({ title: "Saved", description: "Your seniors can now call you with one tap." });
  };

  return (
    <Card className="p-5 border">
      <h3 className="text-base font-semibold text-foreground mb-3 flex items-center gap-2">
        <Phone className="w-4 h-4 text-primary" /> Your Contact Number
      </h3>
      <div className="space-y-3">
        <div>
          <Label htmlFor="caregiver-phone" className="text-sm">Phone number</Label>
          <Input
            id="caregiver-phone"
            type="tel"
            inputMode="tel"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="(555) 123-4567"
            className="h-11 mt-1"
          />
        </div>
        <p className="text-xs text-muted-foreground">
          When you add a number, a “Call” button appears on your senior's dashboard.
        </p>
        <Button onClick={save} disabled={saving} className="min-h-[44px]">
          {saving ? "Saving…" : "Save number"}
        </Button>
      </div>
    </Card>
  );
};

export default ContactNumberCard;
