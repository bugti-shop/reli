import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Apple } from "lucide-react";
import reliLogo from "@/assets/reli-logo.png";



const Header = () => {
  return (
    <header className="bg-background border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center">
            <img src={reliLogo} alt="Reli" className="h-10 w-auto" />
          </Link>
          
          <nav className="hidden sm:flex items-center gap-6">
            <Link 
              to="/privacy-policy" 
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              Privacy
            </Link>
            <Link 
              to="/terms-of-service" 
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              Terms
            </Link>
            <Link 
              to="/resources" 
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              Resources
            </Link>
            <Link 
              to="/pricing" 
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              Pricing
            </Link>
            <Link 
              to="/contact" 
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              Contact
            </Link>
          </nav>

          <div className="flex items-center gap-2">
            <Button variant="outline" disabled className="hidden sm:inline-flex opacity-60 cursor-not-allowed">
              <Apple className="mr-1" />
              App Store — Coming Soon
            </Button>
            <Button asChild>
              <Link to="/auth">Try Reli</Link>
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
