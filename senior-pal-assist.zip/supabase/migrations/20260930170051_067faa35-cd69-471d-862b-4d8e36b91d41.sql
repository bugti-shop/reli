ALTER TABLE public.circle_invites
  ADD COLUMN IF NOT EXISTS invitee_email text,
  ADD COLUMN IF NOT EXISTS requested_at timestamptz,
  ADD COLUMN IF NOT EXISTS approved_at timestamptz,
  ADD COLUMN IF NOT EXISTS declined_at timestamptz;

CREATE INDEX IF NOT EXISTS circle_invites_senior_status_idx
  ON public.circle_invites (senior_id, requested_at, approved_at, declined_at);

CREATE OR REPLACE FUNCTION public.request_circle_invite(_code text)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  inv public.circle_invites;
  me uuid := auth.uid();
  my_email text := lower(trim(COALESCE(auth.jwt()->>'email', '')));
BEGIN
  IF me IS NULL THEN RAISE EXCEPTION 'Please open the invitation from your email'; END IF;

  SELECT * INTO inv
  FROM public.circle_invites
  WHERE code = upper(trim(_code))
  FOR UPDATE;

  IF inv.id IS NULL THEN RAISE EXCEPTION 'Invite code not found'; END IF;
  IF inv.invitee_email IS NULL THEN RAISE EXCEPTION 'This invitation uses the standard code flow'; END IF;
  IF inv.expires_at < now() THEN RAISE EXCEPTION 'This invite has expired'; END IF;
  IF inv.declined_at IS NOT NULL THEN RAISE EXCEPTION 'This request was declined'; END IF;
  IF inv.approved_at IS NOT NULL OR inv.used_at IS NOT NULL THEN RETURN inv.senior_id; END IF;
  IF my_email = '' OR lower(trim(inv.invitee_email)) <> my_email THEN
    RAISE EXCEPTION 'This invitation was sent to a different email address';
  END IF;
  IF inv.senior_id = me THEN RAISE EXCEPTION 'You cannot join your own circle'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.profiles WHERE id = me AND role = 'caregiver') THEN
    RAISE EXCEPTION 'Please join with a family/caregiver account';
  END IF;

  UPDATE public.circle_invites
  SET used_by = me,
      requested_at = COALESCE(requested_at, now())
  WHERE id = inv.id;

  RETURN inv.senior_id;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.request_circle_invite(text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.request_circle_invite(text) TO authenticated;

CREATE OR REPLACE FUNCTION public.approve_circle_invite(_invite_id uuid)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  inv public.circle_invites;
  me uuid := auth.uid();
BEGIN
  IF me IS NULL THEN RAISE EXCEPTION 'Please sign in first'; END IF;

  SELECT * INTO inv
  FROM public.circle_invites
  WHERE id = _invite_id
  FOR UPDATE;

  IF inv.id IS NULL THEN RAISE EXCEPTION 'Invitation not found'; END IF;
  IF NOT (
    inv.senior_id = me OR EXISTS (
      SELECT 1 FROM public.caregiver_seniors cs
      WHERE cs.senior_id = inv.senior_id AND cs.caregiver_id = me
    )
  ) THEN RAISE EXCEPTION 'You cannot manage this Family Circle'; END IF;
  IF inv.requested_at IS NULL OR inv.used_by IS NULL THEN RAISE EXCEPTION 'This invitation has not been requested'; END IF;
  IF inv.declined_at IS NOT NULL THEN RAISE EXCEPTION 'This request was declined'; END IF;
  IF inv.expires_at < now() THEN RAISE EXCEPTION 'This invite has expired'; END IF;

  IF NOT EXISTS (
    SELECT 1 FROM public.caregiver_seniors
    WHERE caregiver_id = inv.used_by AND senior_id = inv.senior_id
  ) THEN
    INSERT INTO public.caregiver_seniors (caregiver_id, senior_id, relationship)
    VALUES (inv.used_by, inv.senior_id, inv.relationship);
  END IF;

  UPDATE public.circle_invites
  SET approved_at = COALESCE(approved_at, now()),
      used_at = COALESCE(used_at, now())
  WHERE id = inv.id;

  RETURN inv.senior_id;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.approve_circle_invite(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.approve_circle_invite(uuid) TO authenticated;

CREATE OR REPLACE FUNCTION public.decline_circle_invite(_invite_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  inv public.circle_invites;
  me uuid := auth.uid();
BEGIN
  IF me IS NULL THEN RAISE EXCEPTION 'Please sign in first'; END IF;

  SELECT * INTO inv
  FROM public.circle_invites
  WHERE id = _invite_id
  FOR UPDATE;

  IF inv.id IS NULL THEN RAISE EXCEPTION 'Invitation not found'; END IF;
  IF NOT (
    inv.senior_id = me OR EXISTS (
      SELECT 1 FROM public.caregiver_seniors cs
      WHERE cs.senior_id = inv.senior_id AND cs.caregiver_id = me
    )
  ) THEN RAISE EXCEPTION 'You cannot manage this Family Circle'; END IF;
  IF inv.approved_at IS NOT NULL OR inv.used_at IS NOT NULL THEN RAISE EXCEPTION 'This request was already accepted'; END IF;

  UPDATE public.circle_invites
  SET declined_at = COALESCE(declined_at, now())
  WHERE id = inv.id;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.decline_circle_invite(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.decline_circle_invite(uuid) TO authenticated;

CREATE OR REPLACE FUNCTION public.remove_circle_member(_link_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  link public.caregiver_seniors;
  me uuid := auth.uid();
BEGIN
  IF me IS NULL THEN RAISE EXCEPTION 'Please sign in first'; END IF;

  SELECT * INTO link
  FROM public.caregiver_seniors
  WHERE id = _link_id
  FOR UPDATE;

  IF link.id IS NULL THEN RAISE EXCEPTION 'Family member not found'; END IF;
  IF link.caregiver_id = me THEN RAISE EXCEPTION 'You cannot remove your own access here'; END IF;
  IF NOT (
    link.senior_id = me OR EXISTS (
      SELECT 1 FROM public.caregiver_seniors manager
      WHERE manager.senior_id = link.senior_id AND manager.caregiver_id = me
    )
  ) THEN RAISE EXCEPTION 'You cannot manage this Family Circle'; END IF;

  DELETE FROM public.caregiver_seniors WHERE id = link.id;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.remove_circle_member(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.remove_circle_member(uuid) TO authenticated;

CREATE OR REPLACE FUNCTION public.accept_circle_invite(_code text)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE inv public.circle_invites; me uuid := auth.uid();
BEGIN
  IF me IS NULL THEN RAISE EXCEPTION 'Please sign in first'; END IF;
  SELECT * INTO inv FROM public.circle_invites WHERE code = upper(trim(_code)) FOR UPDATE;
  IF inv.id IS NULL THEN RAISE EXCEPTION 'Invite code not found'; END IF;
  IF inv.invitee_email IS NOT NULL THEN RAISE EXCEPTION 'Please open this invitation from the email address it was sent to'; END IF;
  IF inv.used_at IS NOT NULL THEN RAISE EXCEPTION 'This invite was already used'; END IF;
  IF inv.expires_at < now() THEN RAISE EXCEPTION 'This invite has expired'; END IF;
  IF inv.senior_id = me THEN RAISE EXCEPTION 'You cannot join your own circle'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.profiles WHERE id = me AND role = 'caregiver') THEN
    RAISE EXCEPTION 'Please join with a family/caregiver account';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM public.caregiver_seniors WHERE caregiver_id = me AND senior_id = inv.senior_id) THEN
    INSERT INTO public.caregiver_seniors (caregiver_id, senior_id, relationship) VALUES (me, inv.senior_id, inv.relationship);
  END IF;
  UPDATE public.circle_invites SET used_by = me, used_at = now(), approved_at = now() WHERE id = inv.id;
  RETURN inv.senior_id;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.accept_circle_invite(text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.accept_circle_invite(text) TO authenticated;