import { useState, useEffect } from "react";
import reliBrand from "@/assets/reli-logo.png";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { FontSizeControl } from "@/components/FontSizeControl";
import { OfflineBanner } from "@/components/OfflineBanner";
import { EmergencyAlerts } from "@/components/EmergencyAlerts";
import { LifeStoryViewer } from "@/components/LifeStoryViewer";
import { FeatureSettings } from "@/components/FeatureSettings";

import { CustomTracker } from "@/components/CustomTracker";
import { PremiumFeature } from "@/components/PremiumFeature";
import { SharedMedicationTracker } from "@/components/SharedMedicationTracker";
import { VitalsTracker } from "@/components/VitalsTracker";
import { TrackerReminders } from "@/components/TrackerReminders";
import { TrackerHistory } from "@/components/TrackerHistory";
import { HealthInsights } from "@/components/HealthInsights";
import { DashboardHealthSummary } from "@/components/DashboardHealthSummary";
import { SeniorLandscapeBackground } from "@/components/SeniorLandscapeBackground";
import { SeniorBottomNav, BottomNavItem } from "@/components/SeniorBottomNav";

import { CaregiverInbox } from "@/components/CaregiverInbox";
import { CaregiverDailyLog } from "@/components/CaregiverDailyLog";
import { DailyLogHistory } from "@/components/DailyLogHistory";
import { DoctorQuestions } from "@/components/DoctorQuestions";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { User } from "@supabase/supabase-js";
import { CarePatternJournal } from "@/components/CarePatternJournal";
import { SeniorActivityMonitor } from "@/components/SeniorActivityMonitor";
import { LogOut, Lightbulb, UserPlus, Send, Activity, Mail, Users, Settings, ClipboardList, Pill, BookOpen, LifeBuoy, Share2, HelpCircle, NotebookPen, Home, HeartHandshake, MoreHorizontal, Plus, MessageSquare, CalendarDays, ClipboardCheck, Footprints, Phone } from "lucide-react";
import { Resources } from "@/components/Resources";
import { BackToTop } from "@/components/BackToTop";
import { DashboardSkeleton } from "@/components/DashboardSkeleton";
import { EmptyState } from "@/components/EmptyState";
import { MotionPreference } from "@/components/MotionPreference";
import { ContactNumberCard } from "@/components/ContactNumberCard";
import { FamilyCircleManager } from "@/components/FamilyCircleManager";
import { HomeCalendar } from "@/components/HomeCalendar";
import { TrackerSectionTabs, TrackerSection } from "@/components/TrackerSectionTabs";
import { ShareReport } from "@/components/ShareReport";
import { usePlan } from "@/hooks/use-plan";
import { FREE_SENIOR_LIMIT, FREE_CAREGIVER_LIMIT } from "@/lib/plans";
import { logoutAndRedirect } from "@/lib/logout";
import { Link } from "react-router-dom";
import { SeniorRemindersOverview } from "@/components/SeniorRemindersOverview";
import { useTrackerNotifications } from "@/hooks/use-tracker-notifications";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface Senior {
  id: string;
  full_name: string;
  email: string;
  managed?: boolean;
}

async function readFnError(error: any): Promise<string> {
  try {
    const body = await error?.context?.json?.();
    return body?.error || "SERVER_ERROR";
  } catch { return "SERVER_ERROR"; }
}

interface ActivityLog {
  id: string;
  activity_type: string;
  activity_description: string;
  created_at: string;
}

const CaregiverDashboard = () => {
  const [user, setUser] = useState<User | null>(null);
  const [seniors, setSeniors] = useState<Senior[]>([]);
  const [selectedSenior, setSelectedSenior] = useState<Senior | null>(null);
  // Ring every linked senior's reminders on the caregiver's device too.
  useTrackerNotifications(seniors.map((s) => s.id), seniors.length > 0, Object.fromEntries(seniors.map((s) => [s.id, s.full_name])));
  const [seniorEmail, setSeniorEmail] = useState("");
  const [message, setMessage] = useState("");
  const [isReminder, setIsReminder] = useState(false);
  const [reminderTime, setReminderTime] = useState("");
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("home");
  const [activeFeature, setActiveFeature] = useState("messages");
  const [managedOpen, setManagedOpen] = useState(false);
  const [managedBusy, setManagedBusy] = useState(false);
  const [managedForm, setManagedForm] = useState({ full_name: "", age: "", phone: "", address: "" });
  const [claimOpen, setClaimOpen] = useState(false);
  const [claimBusy, setClaimBusy] = useState(false);
  const [claimEmail, setClaimEmail] = useState("");
  const [homeDialog, setHomeDialog] = useState<"add" | "network" | "messages" | null>(null);
  const [networkCounts, setNetworkCounts] = useState({ accepted: 0, requested: 0, invited: 0 });
  const [messagePreview, setMessagePreview] = useState<{ message: string; created_at: string } | null>(null);
  const [reminderPreview, setReminderPreview] = useState<{ message: string; reminder_time: string | null } | null>(null);
  const navigate = useNavigate();
  const { toast } = useToast();
  const { isPremium, refresh: refreshPlan } = usePlan(user?.id);
  const atSeniorLimit = !isPremium && seniors.length >= FREE_SENIOR_LIMIT;

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (_event, session) => { setUser(session?.user ?? null); }
    );
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      if (!session) navigate("/auth");
    });
    return () => subscription.unsubscribe();
  }, [navigate]);

  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: "instant" });
    const timer = setTimeout(() => { window.scrollTo({ top: 0, left: 0, behavior: "instant" }); }, 100);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => { if (user) fetchSeniors().finally(() => setLoading(false)); }, [user]);
  useEffect(() => { if (selectedSenior) fetchActivityLogs(); }, [selectedSenior]);
  useEffect(() => {
    if (!selectedSenior || !user) {
      setNetworkCounts({ accepted: 0, requested: 0, invited: 0 });
      setMessagePreview(null);
      setReminderPreview(null);
      return;
    }

    const loadHomeOverview = async () => {
      const now = new Date().toISOString();
      const [membersResult, invitesResult, messagesResult, remindersResult] = await Promise.all([
        supabase.from("caregiver_seniors").select("id", { count: "exact", head: true }).eq("senior_id", selectedSenior.id),
        supabase.from("circle_invites").select("requested_at, approved_at, declined_at, expires_at").eq("senior_id", selectedSenior.id).not("invitee_email", "is", null),
        supabase.from("caregiver_messages").select("message, created_at").eq("caregiver_id", user.id).eq("senior_id", selectedSenior.id).eq("sender_role", "senior").order("created_at", { ascending: false }).limit(1),
        supabase.from("caregiver_messages").select("message, reminder_time").eq("caregiver_id", user.id).eq("senior_id", selectedSenior.id).eq("is_reminder", true).gte("reminder_time", now).order("reminder_time", { ascending: true }).limit(1),
      ]);
      const invites = invitesResult.data || [];
      setNetworkCounts({
        accepted: membersResult.count || 0,
        requested: invites.filter((invite) => invite.requested_at && !invite.approved_at && !invite.declined_at).length,
        invited: invites.filter((invite) => !invite.requested_at && !invite.approved_at && !invite.declined_at && new Date(invite.expires_at) > new Date()).length,
      });
      setMessagePreview(messagesResult.data?.[0] || null);
      setReminderPreview(remindersResult.data?.[0] || null);
    };

    loadHomeOverview();
  }, [selectedSenior, user]);

  const fetchSeniors = async () => {
    const { data, error } = await supabase
      .from("caregiver_seniors")
      .select("senior_id, profiles!caregiver_seniors_senior_id_fkey(id, full_name, email, managed)")
      .eq("caregiver_id", user?.id);
    if (error) { console.error("Error fetching seniors:", error); return; }
    const seniorsList = data.map((item: any) => item.profiles).filter(Boolean);
    setSeniors(seniorsList);
    // Keep the first senior ready on Home so its overview is immediately useful.
    setSelectedSenior((prev) => {
      if (prev) return seniorsList.find((s: any) => s.id === prev.id) ?? seniorsList[0] ?? null;
      return seniorsList[0] ?? null;
    });
  };

  const fetchActivityLogs = async () => {
    if (!selectedSenior) return;
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const { data, error } = await supabase
      .from("senior_activity_log")
      .select("*")
      .eq("senior_id", selectedSenior.id)
      .gte("created_at", today.toISOString())
      .order("created_at", { ascending: false });
    if (error) { console.error("Error fetching activity logs:", error); return; }
    setActivityLogs(data || []);
  };

  const handleAddSenior = async () => {
    if (!seniorEmail.trim()) return;
    if (atSeniorLimit) {
      toast({
        title: "Free plan limit reached",
        description: `The free plan supports up to ${FREE_SENIOR_LIMIT} seniors. Upgrade to add more.`,
        variant: "destructive",
      });
      return;
    }
    const { error } = await supabase.rpc("add_senior_by_email" as any, { _email: seniorEmail.trim() });
    if (error) {
      if (error.message?.includes("NOT_A_SENIOR_ACCOUNT")) { toast({ title: "That's a family account", description: "This email is registered as a caregiver/family account, not a senior. The senior needs their own account signed up as \"Senior\" — or send them an invite code instead.", variant: "destructive" }); }
      else if (error.message?.includes("NOT_CAREGIVER")) { toast({ title: "Caregiver account needed", description: "You're signed in with a senior account. Sign in with a caregiver account to add seniors.", variant: "destructive" }); }
      else if (error.message?.includes("SENIOR_NOT_FOUND")) { toast({ title: "Senior Not Found", description: "No senior account uses this email. Check the spelling, or ask them to sign up as a Senior first.", variant: "destructive" }); }
      else if (error.code === "23505" || error.message?.includes("ALREADY_CONNECTED")) { toast({ title: "Already Connected", description: "This senior is already in your care list.", variant: "destructive" }); }
      else if (error.message?.includes("SENIOR_LIMIT_REACHED")) {
        toast({
          title: "Free plan limit reached",
          description: `The free plan supports up to ${FREE_SENIOR_LIMIT} seniors. Upgrade to add more.`,
          variant: "destructive",
        });
      }
      else if (error.message?.includes("CAREGIVER_LIMIT_REACHED")) {
        toast({
          title: "Free plan limit reached",
          description: `This senior already has ${FREE_CAREGIVER_LIMIT} caregivers. Premium allows unlimited caregivers.`,
          variant: "destructive",
        });
      }
      else { toast({ title: "Error", description: "Failed to add senior. Please try again.", variant: "destructive" }); }
      return;
    }
    toast({ title: "Success", description: "Senior has been added to your care list." });
    setSeniorEmail("");
    await fetchSeniors();
    // A newly linked senior may carry a membership that covers this caregiver.
    refreshPlan();
  };

  const handleCreateManaged = async () => {
    if (!managedForm.full_name.trim()) return;
    setManagedBusy(true);
    const ageNum = managedForm.age ? parseInt(managedForm.age, 10) : null;
    const { data, error } = await supabase.functions.invoke("create-managed-senior", {
      body: {
        full_name: managedForm.full_name.trim(),
        age: ageNum && !isNaN(ageNum) ? ageNum : null,
        phone: managedForm.phone.trim() || null,
        address: managedForm.address.trim() || null,
      },
    });
    setManagedBusy(false);
    const code = (data as any)?.error || (error ? await readFnError(error) : null);
    if (code) {
      toast({
        title: code === "SENIOR_LIMIT_REACHED" ? "Free plan limit reached" : "Couldn't add senior",
        description: code === "SENIOR_LIMIT_REACHED"
          ? `The free plan supports up to ${FREE_SENIOR_LIMIT} seniors. Upgrade to add more.`
          : code === "NOT_CAREGIVER" ? "Sign in with a caregiver account to add seniors." : "Please try again.",
        variant: "destructive",
      });
      return;
    }
    toast({ title: "Senior added", description: `${managedForm.full_name.trim()} is ready — you can start tracking right away.` });
    setManagedOpen(false);
    setManagedForm({ full_name: "", age: "", phone: "", address: "" });
    const newId = (data as any)?.senior_id;
    await fetchSeniors();
    if (newId) setSelectedSenior((prev) => prev && prev.id === newId ? prev : ({ id: newId, full_name: managedForm.full_name.trim(), email: "", managed: true }));
  };

  const handleClaim = async () => {
    if (!selectedSenior || !claimEmail.trim()) return;
    setClaimBusy(true);
    const { data, error } = await supabase.functions.invoke("claim-managed-senior", {
      body: { senior_id: selectedSenior.id, email: claimEmail.trim(), redirect_to: `${window.location.origin}/reset-password` },
    });
    setClaimBusy(false);
    const code = (data as any)?.error || (error ? await readFnError(error) : null);
    if (code) {
      toast({
        title: "Couldn't send invite",
        description: code === "EMAIL_IN_USE"
          ? "That email already has a Reli account. Ask them to share an invite code with you instead."
          : "Please check the email and try again.",
        variant: "destructive",
      });
      return;
    }
    toast({ title: "Invite sent", description: `${selectedSenior.full_name} will get an email to set their password. All their history stays in place.` });
    setClaimOpen(false);
    await fetchSeniors();
  };

  const handleSendMessage = async () => {
    if (!message.trim() || !selectedSenior) return;
    const { data: inserted, error } = await supabase.from("caregiver_messages").insert({
      caregiver_id: user?.id, senior_id: selectedSenior.id, message: message.trim(),
      sender_role: "caregiver",
      is_reminder: isReminder, reminder_time: isReminder && reminderTime ? new Date(reminderTime).toISOString() : null,
    }).select("id").single();
    if (error) { toast({ title: "Error", description: "Failed to send message. Please try again.", variant: "destructive" }); return; }
    if (inserted?.id) {
      supabase.functions
        .invoke("notify-message", { body: { messageId: inserted.id } })
        .catch((e) => console.error("message notification failed", e));
    }
    toast({ title: "Message Sent", description: isReminder ? "Reminder has been scheduled." : "Message sent successfully." });
    setMessage(""); setIsReminder(false); setReminderTime("");
  };

  const handleLogout = async () => {
    await logoutAndRedirect();
  };

  const caregiverName = user?.user_metadata?.full_name || "Caregiver";

  const navItems: BottomNavItem[] = [
    { value: "log", label: "Daily Log", icon: NotebookPen },
    { value: "trackers", label: "Trackers", icon: Pill },
    { value: "home", label: "Home", icon: Home },
    { value: "care", label: "Care", icon: HeartHandshake },
    { value: "more", label: "More", icon: MoreHorizontal },
  ];

  const changeDestination = (destination: string) => {
    setActiveTab(destination);
    if (destination === "trackers") setActiveFeature("meds");
    if (destination === "care") setActiveFeature("patterns");
    if (destination === "more") setActiveFeature("settings");
  };

  const sectionButton = (value: string, label: string, Icon: typeof Activity) => (
    <Button
      key={value}
      type="button"
      variant="ghost"
      onClick={() => setActiveFeature(value)}
      aria-pressed={activeFeature === value}
      className={`h-[4.25rem] min-w-0 flex-col gap-1 rounded-xl border px-1 text-[10px] leading-none md:h-[4.75rem] md:text-xs ${
        activeFeature === value
          ? "border-primary/35 bg-card font-semibold text-primary shadow-sm hover:bg-card"
          : "border-border/70 bg-card/65 font-medium text-nav-icon hover:bg-card"
      }`}
    >
      <Icon className="!h-[1.3rem] !w-[1.3rem] md:!h-6 md:!w-6" strokeWidth={1.9} />
      <span className="w-full truncate text-center">{label}</span>
    </Button>
  );

  const screenHeading = (title: string, description: string, Icon: typeof Activity) => (
    <div className="flex items-center gap-2.5 py-1 md:gap-3 md:py-2">
      <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-card text-nav-icon shadow-sm md:h-11 md:w-11">
        <Icon className="h-5 w-5 md:h-6 md:w-6" strokeWidth={1.9} />
      </span>
      <div className="min-w-0">
        <h1 className="text-xl font-bold leading-tight md:text-3xl">{title}</h1>
        <p className="text-[11px] text-muted-foreground md:text-sm">{description}</p>
      </div>
    </div>
  );

  if (loading) {
    return <div className="min-h-screen bg-dashboard-cream"><DashboardSkeleton /></div>;
  }

  const addSeniorPanel = (
    <div className="p-1">
      <div className="mb-3 flex items-center gap-2">
        <UserPlus className="h-5 w-5 text-primary" />
        <h2 className="text-lg font-bold md:text-xl">Add Senior</h2>
        <Button type="button" onClick={() => navigate("/join")} variant="link" size="sm" className="ml-auto h-auto px-0 text-xs">
          Have an invite code?
        </Button>
      </div>
      <div className="flex gap-2">
        <Input type="email" value={seniorEmail} onChange={(e) => setSeniorEmail(e.target.value)} placeholder="Senior's email" className="h-11" disabled={atSeniorLimit} />
        <Button onClick={handleAddSenior} className="h-11 px-5" disabled={atSeniorLimit}>Add</Button>
      </div>
      <Button type="button" onClick={() => setManagedOpen(true)} disabled={atSeniorLimit} variant="link" className="mt-1 h-auto whitespace-normal p-0 text-left text-xs">
        They don't have an account? Add them yourself
      </Button>
      {atSeniorLimit ? (
        <p className="mt-2 text-xs text-muted-foreground">Free plans cover up to {FREE_SENIOR_LIMIT} seniors. <Link to="/pricing" className="font-medium text-primary underline">Upgrade for unlimited</Link>.</p>
      ) : !isPremium ? (
        <p className="mt-2 text-xs text-muted-foreground">{seniors.length} of {FREE_SENIOR_LIMIT} seniors used on the free plan.</p>
      ) : null}
    </div>
  );

  const seniorPicker = (
    <section aria-label="Choose a senior" className="space-y-2">
      {activeTab !== "home" && seniors.length ? (
        <Select value={selectedSenior?.id} onValueChange={(id) => setSelectedSenior(seniors.find((senior) => senior.id === id) ?? null)}>
          <SelectTrigger className="h-16 rounded-xl border bg-card px-4 text-left text-base font-bold shadow-sm">
            <span className="mr-3 flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-dashboard-sky text-primary"><Users className="h-5 w-5" /></span>
            <SelectValue placeholder="Choose a senior" />
          </SelectTrigger>
          <SelectContent>
            {seniors.map((senior) => <SelectItem key={senior.id} value={senior.id}>{senior.full_name}{senior.managed ? " · No app" : ""}</SelectItem>)}
          </SelectContent>
        </Select>
      ) : seniors.length ? (
        <div className="grid auto-cols-[minmax(11rem,1fr)] grid-flow-col gap-2 overflow-x-auto pb-1">
          {seniors.map((senior) => (
            <Button key={senior.id} onClick={() => setSelectedSenior(senior)} variant={selectedSenior?.id === senior.id ? "default" : "outline"} className="h-12 min-w-0 rounded-full px-5 text-base shadow-sm">
              {senior.full_name}{senior.managed && <span className="ml-1.5 text-[10px] uppercase opacity-70">No app</span>}
            </Button>
          ))}
        </div>
      ) : <p className="px-1 text-sm text-muted-foreground">No seniors added yet.</p>}
    </section>
  );

  const messageForm = selectedSenior && !selectedSenior.managed ? <div className="space-y-3">
    {user && <CaregiverInbox caregiverId={user.id} seniorId={selectedSenior.id} seniorName={selectedSenior.full_name} />}
    <Card className="border p-4">
      <h3 className="mb-3 flex items-center gap-2 text-base font-semibold"><Send className="h-4 w-4 text-primary" />Send Message or Reminder</h3>
      <div className="space-y-3">
        <Textarea value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Type your message or reminder..." className="min-h-[100px]" />
        <div className="flex items-center gap-2"><input type="checkbox" id="isReminder" checked={isReminder} onChange={(e) => setIsReminder(e.target.checked)} className="h-4 w-4 rounded border-border" /><Label htmlFor="isReminder">This is a reminder</Label></div>
        {isReminder && <div><Label htmlFor="reminderTime">Reminder Time</Label><Input id="reminderTime" type="datetime-local" value={reminderTime} onChange={(e) => setReminderTime(e.target.value)} className="mt-1 h-10" /></div>}
        <Button onClick={handleSendMessage} className="w-full">Send</Button>
      </div>
    </Card>
  </div> : null;

  const homeOverview = selectedSenior ? (
    <div className="space-y-3">
      <Button type="button" variant="outline" onClick={() => setHomeDialog("add")} className="h-[4.9rem] w-full justify-between rounded-xl bg-card px-5 text-2xl font-bold shadow-sm hover:bg-card">
        Add Senior<span className="flex h-11 w-11 items-center justify-center rounded-full bg-dashboard-mint text-primary"><Plus className="h-7 w-7" /></span>
      </Button>

      <HomeCalendar seniorId={selectedSenior.id} role="caregiver" />

      {!selectedSenior.managed ? <>
        <Button type="button" variant="outline" onClick={() => setHomeDialog("network")} className="h-auto w-full flex-col items-stretch rounded-xl bg-card p-4 text-left shadow-sm hover:bg-card">
          <span className="text-xl font-bold text-foreground">Caregiving Network</span>
          <span className="mt-3 grid w-full grid-cols-3 gap-2 text-sm font-medium text-foreground">
            <span><strong className="rounded-full bg-dashboard-mint px-2 py-1 text-base">{networkCounts.accepted}</strong> Accepted</span>
            <span><strong className="rounded-full bg-dashboard-sky px-2 py-1 text-base">{networkCounts.requested}</strong> Requested</span>
            <span><strong className="rounded-full bg-dashboard-sky px-2 py-1 text-base">{networkCounts.invited}</strong> Invited</span>
          </span>
          <span className="mt-3 text-sm font-normal text-muted-foreground">{caregiverName} · You</span>
        </Button>

        <Button type="button" variant="outline" onClick={() => setHomeDialog("messages")} className="h-auto w-full flex-col items-stretch rounded-xl bg-card p-4 text-left shadow-sm hover:bg-card">
          <span className="text-xl font-bold text-foreground">Messages &amp; Reminders</span>
          <span className="mt-3 grid w-full grid-cols-2 gap-4 text-foreground">
            <span className="flex min-w-0 gap-2"><span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-dashboard-mint text-primary"><MessageSquare className="h-5 w-5" /></span><span className="min-w-0"><strong className="block truncate text-sm">{messagePreview ? "New message" : "Messages"}</strong><span className="line-clamp-2 text-xs font-normal text-muted-foreground">{messagePreview?.message || `Message ${selectedSenior.full_name}`}</span></span></span>
            <span className="flex min-w-0 gap-2"><span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-dashboard-blush text-destructive"><CalendarDays className="h-5 w-5" /></span><span className="min-w-0"><strong className="block truncate text-sm">{reminderPreview ? "Upcoming reminder" : "Add reminder"}</strong><span className="line-clamp-2 text-xs font-normal text-muted-foreground">{reminderPreview ? `${reminderPreview.message}${reminderPreview.reminder_time ? ` · ${new Date(reminderPreview.reminder_time).toLocaleString([], { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}` : ""}` : "Schedule for later"}</span></span></span>
          </span>
        </Button>
      </> : <Card className="border border-dashed p-4 text-sm text-muted-foreground">{selectedSenior.full_name} doesn't use the app yet, so messages are off. Everything else works.<Button size="sm" variant="outline" className="mt-3 w-full" onClick={() => { setClaimEmail(""); setClaimOpen(true); }}><Mail className="h-4 w-4" />Invite to app</Button></Card>}

<SeniorRemindersOverview seniorId={selectedSenior.id} seniorName={selectedSenior.full_name} onManage={() => { setActiveTab("trackers"); setActiveFeature("reminders"); }} />

<Card className="border p-4 shadow-sm">
        <h3 className="mb-3 text-xl font-bold">Quick Actions</h3>
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
          <Button type="button" variant="outline" className="h-12 justify-start text-base" onClick={() => { setActiveTab("trackers"); setActiveFeature("vitals"); }}><ClipboardCheck className="h-5 w-5" />Daily Vitals Log</Button>
          <Button type="button" variant="outline" className="h-12 justify-start text-base" onClick={() => setActiveTab("log")}><Footprints className="h-5 w-5" />Log Activity</Button>
          <Button type="button" variant="outline" className="h-12 justify-start text-base" onClick={() => { setActiveTab("care"); setActiveFeature("questions"); }}><Phone className="h-5 w-5" />Call Doctor</Button>
        </div>
      </Card>

      <SeniorActivityMonitor key={selectedSenior.id} seniorId={selectedSenior.id} seniorName={selectedSenior.full_name || "this senior"} />
    </div>
  ) : <><Button type="button" variant="outline" onClick={() => setHomeDialog("add")} className="h-[4.9rem] w-full justify-between rounded-xl bg-card px-5 text-2xl font-bold shadow-sm">Add Senior<span className="flex h-11 w-11 items-center justify-center rounded-full bg-dashboard-mint text-primary"><Plus className="h-7 w-7" /></span></Button><EmptyState icon={Users} title="Pick a senior to get started" description="Choose a name above to see their messages, activity, trackers and reports." /></>;

  return (
    <div className="relative min-h-screen overflow-x-hidden bg-dashboard-cream pb-20 md:pb-24">
      <header className="bg-dashboard-cream">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-2.5 md:px-8 md:py-5">
          <div><img src={reliBrand} alt="Reli" className="h-9 w-auto md:h-14" /><p className="mt-0.5 text-[10px] font-medium text-muted-foreground md:mt-1 md:text-sm">Care Today. A Brighter Tomorrow.</p></div>
          <span className="rounded-full bg-card px-3 py-2 text-xs font-bold text-primary shadow-sm md:text-sm">Caregiver</span>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-2.5 pb-4 md:px-8">
        <OfflineBanner />

        {activeTab === "home" && <div className="space-y-3 md:space-y-5">
          {user && <EmergencyAlerts caregiverId={user.id} seniors={seniors} />}
          <section className="scenery-readable relative isolate overflow-hidden rounded-[1.65rem] p-3 text-primary-foreground shadow-lg md:rounded-[2rem] md:p-8">
            <SeniorLandscapeBackground className="pointer-events-none absolute inset-0 -z-10 h-full w-full" />
            <div className="mb-3 flex items-start justify-between gap-3 md:mb-6">
              <div><p className="text-sm font-medium text-primary-foreground/90 md:text-2xl">Welcome back,</p><h1 className="text-2xl font-bold leading-tight text-primary-foreground md:mt-1 md:text-5xl">{caregiverName}</h1><p className="mt-1 text-xs font-medium text-primary-foreground/85 md:text-base">Managing {seniors.length} senior{seniors.length !== 1 ? "s" : ""}</p></div>
              <Button onClick={() => navigate("/caregiver-profile")} variant="secondary" size="sm" className="no-scenery-shadow shrink-0">My profile</Button>
            </div>
            {selectedSenior ? <div className="relative"><div className="mb-2 flex items-center justify-between gap-2"><p className="truncate text-xs font-bold uppercase text-primary-foreground/90 md:text-sm">{selectedSenior.full_name}'s latest</p><Button onClick={() => navigate(`/senior-profile/${selectedSenior.id}`)} variant="secondary" size="sm" className="no-scenery-shadow h-8">Edit profile</Button></div><DashboardHealthSummary seniorId={selectedSenior.id} variant="reference" /></div> : <p className="rounded-xl bg-dashboard-blue-deep/55 p-4 text-sm font-medium">Choose a senior below to see their latest health summary.</p>}
          </section>
          {seniorPicker}
          {homeOverview}
        </div>}

        {activeTab === "log" && <section className="space-y-3 pt-2 md:space-y-5 md:pt-4">
          {screenHeading("Daily Log", selectedSenior ? `Daily care notes for ${selectedSenior.full_name}.` : "Choose a senior to add care notes.", NotebookPen)}
          {selectedSenior && user ? <><CaregiverDailyLog caregiverId={user.id} seniorId={selectedSenior.id} seniorName={selectedSenior.full_name} /><DailyLogHistory caregiverId={user.id} seniorId={selectedSenior.id} seniorName={selectedSenior.full_name} /></> : <>{seniorPicker}<EmptyState icon={Users} title="Choose a senior" description="Select a senior to open their daily care log." /></>}
        </section>}

        {activeTab === "trackers" && <section className="space-y-3 pt-2 md:space-y-5 md:pt-4">
          <div className="px-1 py-2"><h1 className="text-3xl font-bold leading-tight md:text-5xl">Trackers</h1><p className="mt-1 text-sm text-muted-foreground md:text-lg">{selectedSenior ? `Health tracking for ${selectedSenior.full_name}` : "Choose a senior to view health tracking"}</p></div>
          {seniorPicker}
          {selectedSenior && user ? <>
            <TrackerSectionTabs active={activeFeature as TrackerSection} onChange={setActiveFeature} />
            {activeFeature === "meds" && <SharedMedicationTracker userId={user.id} userRole="caregiver" seniorId={selectedSenior.id} seniorName={selectedSenior.full_name} />}
            {activeFeature === "vitals" && <div className="space-y-4"><VitalsTracker type="blood_pressure" userId={user.id} userRole="caregiver" seniorId={selectedSenior.id} seniorName={selectedSenior.full_name} /><VitalsTracker type="heart_rate" userId={user.id} userRole="caregiver" seniorId={selectedSenior.id} seniorName={selectedSenior.full_name} /></div>}
            {activeFeature === "reminders" && <TrackerReminders userId={user.id} userRole="caregiver" seniorId={selectedSenior.id} seniorName={selectedSenior.full_name} />}
            {activeFeature === "history" && <div className="space-y-4"><TrackerHistory userId={user.id} userRole="caregiver" seniorId={selectedSenior.id} seniorName={selectedSenior.full_name} /><PremiumFeature name="Trends & Insights" description="AI-powered charts and insights from tracker history." userId={user.id}><HealthInsights userId={user.id} seniorId={selectedSenior.id} seniorName={selectedSenior.full_name} /></PremiumFeature></div>}
            {activeFeature === "custom" && <PremiumFeature name="Custom Trackers" description="Build your own trackers for anything you want to keep an eye on." userId={user.id}><CustomTracker userId={user.id} userRole="caregiver" seniorId={selectedSenior.id} seniorName={selectedSenior.full_name} /></PremiumFeature>}
          </> : <EmptyState icon={Users} title="Choose a senior" description="Select a senior to open their trackers." />}
        </section>}

        {activeTab === "care" && <section className="space-y-3 pt-2 md:space-y-5 md:pt-4">
          {screenHeading("Care", selectedSenior ? `Care planning for ${selectedSenior.full_name}.` : "Choose a senior to plan their care.", HeartHandshake)}
          {seniorPicker}
          {selectedSenior ? <><div className={`grid ${selectedSenior.managed ? "grid-cols-2" : "grid-cols-3"} gap-2`}>{sectionButton("patterns", "Patterns & Journal", Lightbulb)}{sectionButton("questions", "Doctor Questions", HelpCircle)}{!selectedSenior.managed && sectionButton("stories", "Life Story", BookOpen)}</div>{activeFeature === "patterns" && user && <CarePatternJournal userId={user.id} seniorId={selectedSenior.id} seniorName={selectedSenior.full_name} />}{activeFeature === "questions" && user && <DoctorQuestions userId={user.id} userRole="caregiver" seniorId={selectedSenior.id} seniorName={selectedSenior.full_name} />}{activeFeature === "stories" && !selectedSenior.managed && <LifeStoryViewer seniorId={selectedSenior.id} seniorName={selectedSenior.full_name} isCollapsed={false} onToggleCollapse={() => {}} />}</> : <EmptyState icon={Users} title="Choose a senior" description="Select a senior to open care planning." />}
        </section>}

        {activeTab === "more" && <section className="space-y-3 pt-2 md:space-y-5 md:pt-4">
          {screenHeading("More", "Reports, settings, resources and your account.", MoreHorizontal)}
          {seniorPicker}
          <div className="grid grid-cols-4 gap-1.5 md:gap-2">{sectionButton("settings", "Settings", Settings)}{sectionButton("share", "Share", Share2)}{sectionButton("resources", "Help", LifeBuoy)}{sectionButton("account", "Account", UserPlus)}</div>
          {activeFeature === "settings" && selectedSenior && <div className="space-y-4"><Card className="flex flex-col justify-between gap-3 p-4 sm:flex-row sm:items-center"><div><h3 className="font-semibold">Alert & notification settings</h3><p className="text-sm text-muted-foreground">Choose which alerts you receive and where they go.</p></div><Button variant="outline" onClick={() => navigate("/settings")}><Settings className="h-4 w-4" />Open settings</Button></Card>{user && <ContactNumberCard userId={user.id} />}{user && !selectedSenior.managed && <FeatureSettings seniorId={selectedSenior.id} seniorName={selectedSenior.full_name} caregiverId={user.id} />}</div>}
          {activeFeature === "share" && selectedSenior && user && <ShareReport userId={user.id} userRole="caregiver" seniorId={selectedSenior.id} seniorName={selectedSenior.full_name} />}
          {activeFeature === "resources" && <Resources audience="caregiver" />}
          {activeFeature === "account" && <div className="grid gap-3 sm:grid-cols-2"><Button variant="outline" className="min-h-16 justify-start" onClick={() => navigate("/caregiver-profile")}><UserPlus className="h-5 w-5" />My Profile</Button><Button variant="outline" className="min-h-16 justify-start" onClick={() => navigate("/settings")}><Settings className="h-5 w-5" />Settings & Alerts</Button><Button variant="outline" className="min-h-16 justify-start" onClick={() => navigate("/contact")}><Mail className="h-5 w-5" />Contact Reli</Button><div className="flex min-h-16 items-center justify-between gap-2 rounded-md border bg-background px-4"><FontSizeControl /><MotionPreference /></div><Button variant="outline" className="min-h-12 justify-start text-destructive hover:text-destructive" onClick={handleLogout}><LogOut className="h-5 w-5" />Logout</Button></div>}
          {(activeFeature === "settings" || activeFeature === "share") && !selectedSenior && <EmptyState icon={Users} title="Choose a senior" description="Select a senior to open these controls." />}
        </section>}
      </main>
      <BackToTop />
      <SeniorBottomNav items={navItems} active={activeTab} onChange={changeDestination} />

      <Dialog open={homeDialog !== null} onOpenChange={(open) => { if (!open) setHomeDialog(null); }}>
        <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-lg">
          {homeDialog === "add" && <><DialogHeader><DialogTitle>Add Senior</DialogTitle><DialogDescription>Connect a senior account or add someone you manage yourself.</DialogDescription></DialogHeader>{addSeniorPanel}</>}
          {homeDialog === "network" && selectedSenior && user && <><DialogHeader><DialogTitle>Caregiving Network</DialogTitle><DialogDescription>Review requests, invitations and accepted caregivers.</DialogDescription></DialogHeader><FamilyCircleManager seniorId={selectedSenior.id} currentUserId={user.id} /></>}
          {homeDialog === "messages" && <><DialogHeader><DialogTitle>Messages &amp; Reminders</DialogTitle><DialogDescription>Read messages or send a new message and reminder.</DialogDescription></DialogHeader>{messageForm}</>}
        </DialogContent>
      </Dialog>

      <Dialog open={managedOpen} onOpenChange={setManagedOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add a senior without an account</DialogTitle>
            <DialogDescription>
              You'll manage their medications, readings, reminders and reports. You can invite them to use the app later — nothing is lost.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <Label htmlFor="m-name">Full name *</Label>
              <Input id="m-name" value={managedForm.full_name} maxLength={100} onChange={(e) => setManagedForm({ ...managedForm, full_name: e.target.value })} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label htmlFor="m-age">Age</Label>
                <Input id="m-age" inputMode="numeric" value={managedForm.age} onChange={(e) => setManagedForm({ ...managedForm, age: e.target.value.replace(/\D/g, "").slice(0, 3) })} />
              </div>
              <div>
                <Label htmlFor="m-phone">Phone</Label>
                <Input id="m-phone" type="tel" value={managedForm.phone} maxLength={40} onChange={(e) => setManagedForm({ ...managedForm, phone: e.target.value })} />
              </div>
            </div>
            <div>
              <Label htmlFor="m-addr">Address</Label>
              <Input id="m-addr" value={managedForm.address} maxLength={300} onChange={(e) => setManagedForm({ ...managedForm, address: e.target.value })} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setManagedOpen(false)}>Cancel</Button>
            <Button onClick={handleCreateManaged} disabled={managedBusy || !managedForm.full_name.trim()}>
              {managedBusy ? "Adding…" : "Add senior"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={claimOpen} onOpenChange={setClaimOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Invite {selectedSenior?.full_name} to the app</DialogTitle>
            <DialogDescription>
              They'll get an email to set a password. Their meds, readings and history stay exactly as they are, and you'll be able to message each other.
            </DialogDescription>
          </DialogHeader>
          <div>
            <Label htmlFor="c-email">Their email</Label>
            <Input id="c-email" type="email" value={claimEmail} maxLength={255} onChange={(e) => setClaimEmail(e.target.value)} />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setClaimOpen(false)}>Cancel</Button>
            <Button onClick={handleClaim} disabled={claimBusy || !claimEmail.trim()}>
              {claimBusy ? "Sending…" : "Send invite"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default CaregiverDashboard;
