CREATE OR REPLACE FUNCTION public.validate_tracker_reminder()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  IF NEW.kind NOT IN ('medication', 'blood_pressure', 'heart_rate', 'custom') THEN
    RAISE EXCEPTION 'Invalid reminder kind: %', NEW.kind;
  END IF;
  IF NEW.time !~ '^([01][0-9]|2[0-3]):[0-5][0-9]$' THEN
    RAISE EXCEPTION 'Invalid reminder time: %', NEW.time;
  END IF;
  IF NEW.kind = 'custom' THEN
    NEW.label := NULLIF(TRIM(SUBSTRING(COALESCE(NEW.label, ''), 1, 100)), '');
    IF NEW.label IS NULL THEN
      RAISE EXCEPTION 'Custom reminders need a name';
    END IF;
  END IF;
  RETURN NEW;
END;
$function$;