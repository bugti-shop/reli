ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS age integer,
  ADD COLUMN IF NOT EXISTS address text,
  ADD COLUMN IF NOT EXISTS emergency_contacts jsonb NOT NULL DEFAULT '[]'::jsonb;

CREATE POLICY "Caregivers can update their seniors profiles"
ON public.profiles
FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.caregiver_seniors cs
    WHERE cs.senior_id = profiles.id AND cs.caregiver_id = auth.uid()
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.caregiver_seniors cs
    WHERE cs.senior_id = profiles.id AND cs.caregiver_id = auth.uid()
  )
  AND role = (SELECT p.role FROM public.profiles p WHERE p.id = profiles.id)
  AND plan = (SELECT p.plan FROM public.profiles p WHERE p.id = profiles.id)
);