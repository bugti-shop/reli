import { useCallback, useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle } from "@/components/ui/drawer";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { VoiceInput } from "@/components/VoiceInput";
import { toast } from "sonner";
import { AlertTriangle, Pill, Thermometer, Smile, Moon, Utensils, Footprints, Brain, Lamp, StickyNote, Trash2, Sparkles, Copy, Lightbulb, Loader2, Phone, ShieldCheck, MessageCircleQuestion, RotateCcw } from "lucide-react";
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip } from "recharts";
import { Obs, detectPatterns, careSummary, EPISODE_CATS } from "@/lib/carePatterns";

const CATS = [
  { id: "medication", label: "Medication", icon: Pill, options: ["Morning meds", "Evening meds", "As-needed med", "Missed dose"] },
  { id: "symptom", label: "Symptom", icon: Thermometer, options: ["Pain", "Dizziness", "Nausea", "Shortness of breath", "Fatigue", "Headache"], intensity: true },
  { id: "mood", label: "Mood", icon: Smile, options: ["Calm", "Happy", "Anxious", "Confused", "Angry", "Tired", "Sad"] },
  { id: "sleep", label: "Sleep", icon: Moon, options: ["Night sleep", "Nap"], hours: true },
  { id: "food", label: "Food & drink", icon: Utensils, options: ["Breakfast", "Lunch", "Dinner", "Snack", "Water", "Coffee/tea", "Sugary food", "Skipped meal"] },
  { id: "activity", label: "Activity", icon: Footprints, options: ["Walk", "Exercise", "Outing", "TV", "Social visit", "Resting all day"] },
  { id: "behavior", label: "Behavior", icon: Brain, options: ["Confusion", "Agitation", "Wandering", "Hallucination", "Fall", "Repeating questions", "Refused care"], intensity: true },
  { id: "environment", label: "Environment", icon: Lamp, options: ["Visitors", "Loud noise", "Change in routine", "Hot weather", "Storm"] },
  { id: "note", label: "Note", icon: StickyNote, options: ["General note"] },
] as const;
const LOCATIONS = ["Bedroom", "Living room", "Kitchen", "Bathroom", "Outside", "Car", "Doctor/clinic"];
const ENV = ["Dim lighting", "TV on", "Noisy", "Visitors", "Alone", "Sunset", "New place"];
const URGENT = ["Fall", "Shortness of breath", "Hallucination"];
const catOf = (id: string) => CATS.find((c) => c.id === id) ?? CATS[8];
const localNow = () => { const d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 16); };
const db = supabase as any;

export const CarePatternJournal = ({ userId, seniorId, seniorName, self = false }: { userId: string; seniorId: string; seniorName: string; self?: boolean }) => {
  const [doses, setDoses] = useState<Obs[]>([]);
  const [urgent, setUrgent] = useState<string | null>(null);
  const [fda, setFda] = useState<{ medication: string; symptom: string; quote: string }[] | null>(null);
  const [fdaLoading, setFdaLoading] = useState(false);
  const [asking, setAsking] = useState<number | null>(null);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [rows, setRows] = useState<Obs[]>([]);
  const [loading, setLoading] = useState(true);
  const [cat, setCat] = useState<(typeof CATS)[number] | null>(null);
  const [label, setLabel] = useState("");
  const [intensity, setIntensity] = useState<number | null>(null);
  const [hours, setHours] = useState("");
  const [location, setLocation] = useState<string | null>(null);
  const [env, setEnv] = useState<string[]>([]);
  const [notes, setNotes] = useState("");
  const [when, setWhen] = useState(localNow());
  const [saving, setSaving] = useState(false);
  const [days, setDays] = useState(14);

  const load = useCallback(async () => {
    const since = new Date(Date.now() - 90 * 864e5).toISOString();
    const { data } = await db.from("care_observations").select("*").eq("senior_id", seniorId).gte("observed_at", since).order("observed_at", { ascending: false }).limit(1000);
    setRows((data as Obs[]) || []);
    const { data: d } = await supabase.from("medication_doses").select("id, medication_name, dosage, taken_at").eq("senior_id", seniorId).is("deleted_at", null).gte("taken_at", since).limit(1000);
    setDoses((d || []).map((x: any) => ({ id: "dose-" + x.id, category: "medication", label: x.medication_name, intensity: null, value_num: null, location: null, environment: [], notes: x.dosage ? `Dose ${x.dosage} (from medication tracker)` : "From medication tracker", observed_at: x.taken_at })));
    setLoading(false);
  }, [seniorId]);
  useEffect(() => { setLoading(true); void load(); }, [load]);

  const open = (c: (typeof CATS)[number]) => {
    setCat(c); setLabel(c.options.length === 1 ? c.options[0] : ""); setIntensity(null); setHours(""); setLocation(null); setEnv([]); setNotes(""); setWhen(localNow());
  };
  const save = async () => {
    if (!cat || !label.trim()) { toast.error("Pick or type what happened"); return; }
    setSaving(true);
    const { error } = await db.from("care_observations").insert({
      senior_id: seniorId, caregiver_id: userId, category: cat.id, label: label.trim(), intensity,
      value_num: hours ? Number(hours) : null, location, environment: env, notes: notes.trim() || null,
      observed_at: new Date(when).toISOString(),
    });
    setSaving(false);
    if (error) { toast.error("Could not save", { description: error.message }); return; }
    toast.success("Recorded");
    if (URGENT.includes(label) || (intensity ?? 0) >= 4) setUrgent(label);
    setCat(null); void load();
  };
  const remove = async (id: string) => { await db.from("care_observations").delete().eq("id", id); setRows((r) => r.filter((x) => x.id !== id)); };

  const all = useMemo(() => [...rows, ...doses].sort((a, b) => Date.parse(b.observed_at) - Date.parse(a.observed_at)), [rows, doses]);
  const recentLabels = useMemo(() => { const seen = new Map<string, Obs>(); rows.forEach((r) => { const k = r.category + r.label; if (!seen.has(k) && seen.size < 6) seen.set(k, r); }); return [...seen.values()]; }, [rows]);
  const quickRepeat = async (r: Obs) => {
    const { error } = await db.from("care_observations").insert({ senior_id: seniorId, caregiver_id: userId, category: r.category, label: r.label, intensity: r.intensity, location: r.location, environment: r.environment });
    if (error) toast.error("Could not save"); else { toast.success(`${r.label} recorded`); if (URGENT.includes(r.label) || (r.intensity ?? 0) >= 4) setUrgent(r.label); void load(); }
  };
  const runFda = async () => {
    setFdaLoading(true);
    const symptoms = [...new Set(rows.filter((r) => EPISODE_CATS.includes(r.category) || r.category === "mood").map((r) => r.label))];
    const { data, error } = await supabase.functions.invoke("care-pattern-insights", { body: { action: "fda", senior_id: seniorId, symptoms } });
    setFdaLoading(false);
    if (error || data?.error) { toast.error("FDA check failed", { description: data?.error || error?.message }); return; }
    setFda(data.matches || []);
    if (!data.checked?.length) toast.info("Add medicines in the Medication tracker first.");
  };
  const ask = async (i: number, detail: string) => {
    setAsking(i);
    const context = all.slice(0, 60).map((r) => `${new Date(r.observed_at).toLocaleString()} | ${r.category} | ${r.label}${r.intensity ? ` (intensity ${r.intensity})` : ""}${r.value_num != null ? ` ${r.value_num}h` : ""}${r.location ? ` @ ${r.location}` : ""}${r.environment?.length ? ` [${r.environment.join(", ")}]` : ""}`).join("\n");
    const { data, error } = await supabase.functions.invoke("care-pattern-insights", { body: { action: "ask", senior_id: seniorId, pattern: detail, context } });
    setAsking(null);
    if (error || data?.error) { toast.error(data?.error || "Could not get an answer right now"); return; }
    setAnswers((a) => ({ ...a, [i]: data.answer }));
  };
  const patterns = useMemo(() => detectPatterns(all.filter((r) => Date.parse(r.observed_at) > Date.now() - 30 * 864e5)), [rows]);
  const episodes = all.filter((r) => EPISODE_CATS.includes(r.category));
  const byHour = useMemo(() => Array.from({ length: 24 }, (_, h) => ({ h: h % 12 === 0 ? (h ? "12p" : "12a") : h < 12 ? `${h}a` : `${h - 12}p`, n: episodes.filter((e) => new Date(e.observed_at).getHours() === h).length })), [episodes]);
  const byDay = useMemo(() => ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d, i) => ({ d, n: episodes.filter((e) => new Date(e.observed_at).getDay() === i).length })), [episodes]);
  const byLoc = useMemo(() => { const m = new Map<string, number>(); episodes.forEach((e) => e.location && m.set(e.location, (m.get(e.location) || 0) + 1)); return [...m.entries()].sort((a, b) => b[1] - a[1]); }, [episodes]);
  const byEnv = useMemo(() => { const m = new Map<string, number>(); episodes.forEach((e) => e.environment?.forEach((v) => m.set(v, (m.get(v) || 0) + 1))); return [...m.entries()].sort((a, b) => b[1] - a[1]); }, [episodes]);
  const grouped = useMemo(() => { const m = new Map<string, Obs[]>(); all.slice(0, 150).forEach((r) => { const k = new Date(r.observed_at).toDateString(); m.set(k, [...(m.get(k) || []), r]); }); return [...m.entries()]; }, [all]);
  const summary = useMemo(() => careSummary(all, days, seniorName) + (fda?.length ? `\n\nFDA label mentions (for discussion, not proof of cause):\n${fda.map((f) => `• ${f.symptom} is listed in the FDA label for ${f.medication}.`).join("\n")}` : ""), [all, days, seniorName, fda]);
  const todayCount = rows.filter((r) => new Date(r.observed_at).toDateString() === new Date().toDateString()).length;

  return (
    <div className="space-y-4">
      <Card className="flex gap-3 border-destructive/30 bg-destructive/5 p-3 text-sm">
        <AlertTriangle className="h-5 w-5 shrink-0 text-destructive" />
        <p>For sudden or severe symptoms (chest pain, trouble breathing, a fall with injury, sudden confusion or weakness) call emergency services right away. Patterns here are observations, not a diagnosis.</p>
      </Card>

      <Card className="p-4">
        <h3 className="font-semibold">{self ? "My health journal" : "Quick record"}</h3>
        <p className="mb-3 text-sm text-muted-foreground">{todayCount ? `${todayCount} record(s) today. ` : "Nothing recorded yet today. "}Tap what you noticed. The time is added automatically.</p>
        <div className="grid grid-cols-3 gap-2 sm:grid-cols-5">
          {CATS.map((c) => (
            <Button key={c.id} variant="outline" className="h-auto min-h-16 flex-col gap-1 py-2 text-xs" onClick={() => open(c)}>
              <c.icon className="h-5 w-5 text-primary" />{c.label}
            </Button>
          ))}
        </div>
        {recentLabels.length > 0 && <div className="mt-3"><p className="mb-1.5 flex items-center gap-1 text-xs font-medium text-muted-foreground"><RotateCcw className="h-3 w-3" />One-tap repeat (now)</p><div className="flex gap-2 overflow-x-auto pb-1">{recentLabels.map((r) => <Button key={r.id} size="sm" variant="secondary" className="shrink-0 min-h-10" onClick={() => quickRepeat(r)}>{r.label}</Button>)}</div></div>}
      </Card>

      <Tabs defaultValue="patterns">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="patterns">Patterns</TabsTrigger>
          <TabsTrigger value="timeline">Timeline</TabsTrigger>
          <TabsTrigger value="charts">Charts</TabsTrigger>
          <TabsTrigger value="summary">Summary</TabsTrigger>
        </TabsList>

        <TabsContent value="patterns" className="space-y-2">
          {loading ? <Loader2 className="mx-auto h-6 w-6 animate-spin" /> : patterns.length ? patterns.map((p, i) => (
            <Card key={i} className="space-y-2 p-3"><div className="flex gap-3"><Lightbulb className="h-5 w-5 shrink-0 text-accent" /><div><p className="font-medium">{p.title}</p><p className="text-sm text-muted-foreground">{p.detail}</p></div></div>
              {answers[i] ? <p className="whitespace-pre-wrap rounded-md bg-muted p-3 text-sm">{answers[i]}</p> : <Button size="sm" variant="outline" className="min-h-10" disabled={asking !== null} onClick={() => ask(i, p.detail)}>{asking === i ? <Loader2 className="h-4 w-4 animate-spin" /> : <MessageCircleQuestion className="h-4 w-4" />}Ask about this pattern</Button>}</Card>
          )) : <Card className="p-4 text-sm text-muted-foreground">No patterns yet. After a few records of the same symptom or behavior (3 or more), possible patterns from the last 30 days will appear here.</Card>}
          <Card className="space-y-2 p-3">
            <div className="flex items-center justify-between gap-2"><p className="flex items-center gap-2 font-medium"><ShieldCheck className="h-5 w-5 text-primary" />Medicines vs. symptoms (FDA)</p><Button size="sm" variant="outline" className="min-h-10" disabled={fdaLoading} onClick={runFda}>{fdaLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Check"}</Button></div>
            <p className="text-xs text-muted-foreground">Checks if recorded symptoms are listed as known side effects in the official FDA labels of medicines in the Medication tracker.</p>
            {fda && (fda.length ? fda.map((f, i) => <div key={i} className="rounded-md border p-2 text-sm"><p><span className="font-medium capitalize">{f.symptom}</span> is listed in the FDA label for <span className="font-medium">{f.medication}</span>. Worth discussing with the care team.</p><p className="mt-1 text-xs italic text-muted-foreground">"…{f.quote}…"</p></div>) : <p className="text-sm text-muted-foreground">No recorded symptoms were found in the FDA labels checked.</p>)}
            {fda && <p className="text-[11px] text-muted-foreground">Source: U.S. FDA drug labels (openFDA), names matched with NIH RxNorm. Not proof of cause. Don't stop or change medicines without the doctor.</p>}
          </Card>
          {patterns.length > 0 && <p className="text-xs text-muted-foreground">Possible patterns only. They show things that happened together, not what caused them. Worth discussing with the care team.</p>}
        </TabsContent>

        <TabsContent value="timeline" className="space-y-4">
          {!grouped.length && <Card className="p-4 text-sm text-muted-foreground">Your records will show here in time order.</Card>}
          {grouped.map(([day, list]) => (
            <div key={day}>
              <p className="mb-2 text-sm font-semibold text-muted-foreground">{day}</p>
              <div className="space-y-2 border-l-2 border-primary/30 pl-3">
                {list.map((r) => { const C = catOf(r.category); return (
                  <Card key={r.id} className={`flex items-start gap-3 p-3 ${EPISODE_CATS.includes(r.category) ? "border-accent/40" : ""}`}>
                    <C.icon className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                    <div className="min-w-0 flex-1 text-sm">
                      <p><span className="font-medium">{r.label}</span> <span className="text-muted-foreground">· {new Date(r.observed_at).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}</span></p>
                      <div className="mt-1 flex flex-wrap gap-1">
                        {r.intensity && <Badge variant="secondary">Intensity {r.intensity}/5</Badge>}
                        {r.value_num != null && <Badge variant="secondary">{r.value_num} h</Badge>}
                        {r.location && <Badge variant="outline">{r.location}</Badge>}
                        {r.environment?.map((e) => <Badge key={e} variant="outline">{e}</Badge>)}
                      </div>
                      {r.notes && <p className="mt-1 text-muted-foreground">{r.notes}</p>}
                    </div>
                    <Button size="icon" variant="ghost" aria-label="Delete record" onClick={() => remove(r.id)}><Trash2 className="h-4 w-4" /></Button>
                  </Card>
                ); })}
              </div>
            </div>
          ))}
        </TabsContent>

        <TabsContent value="charts" className="space-y-3">
          <Card className="p-3"><p className="mb-2 text-sm font-semibold">Symptoms & behaviors by time of day</p>
            <ResponsiveContainer width="100%" height={160}><BarChart data={byHour}><XAxis dataKey="h" fontSize={10} interval={2} /><YAxis allowDecimals={false} fontSize={10} width={20} /><Tooltip /><Bar dataKey="n" name="Records" fill="hsl(var(--primary))" radius={3} /></BarChart></ResponsiveContainer></Card>
          <Card className="p-3"><p className="mb-2 text-sm font-semibold">By day of week</p>
            <ResponsiveContainer width="100%" height={140}><BarChart data={byDay}><XAxis dataKey="d" fontSize={10} /><YAxis allowDecimals={false} fontSize={10} width={20} /><Tooltip /><Bar dataKey="n" name="Records" fill="hsl(var(--accent))" radius={3} /></BarChart></ResponsiveContainer></Card>
          <div className="grid gap-3 sm:grid-cols-2">
            <Card className="p-3"><p className="mb-2 text-sm font-semibold">Where they happened</p>{byLoc.length ? byLoc.map(([k, v]) => <p key={k} className="flex justify-between text-sm"><span>{k}</span><span className="font-medium">{v}</span></p>) : <p className="text-sm text-muted-foreground">No locations yet.</p>}</Card>
            <Card className="p-3"><p className="mb-2 text-sm font-semibold">Surroundings noted</p>{byEnv.length ? byEnv.map(([k, v]) => <p key={k} className="flex justify-between text-sm"><span>{k}</span><span className="font-medium">{v}</span></p>) : <p className="text-sm text-muted-foreground">No surroundings yet.</p>}</Card>
          </div>
        </TabsContent>

        <TabsContent value="summary" className="space-y-3">
          <div className="flex gap-2">{[7, 14, 30].map((d) => <Button key={d} size="sm" variant={days === d ? "default" : "outline"} onClick={() => setDays(d)}>Last {d} days</Button>)}</div>
          <Card className="whitespace-pre-wrap p-4 text-sm leading-relaxed"><Sparkles className="mb-2 h-5 w-5 text-primary" />{summary}</Card>
          <Button variant="outline" onClick={() => { void navigator.clipboard.writeText(summary); toast.success("Summary copied. Paste it into a message or email to the care team."); }}><Copy className="h-4 w-4" />Copy for doctor</Button>
        </TabsContent>
      </Tabs>

      <Drawer open={!!cat} onOpenChange={(o) => !o && setCat(null)}>
        <DrawerContent className="max-h-[92vh]">
          <DrawerHeader className="pb-0"><DrawerTitle>{cat?.label}</DrawerTitle></DrawerHeader>
          {cat && <div className="space-y-4 overflow-y-auto px-4 pb-6">
            <div className="flex flex-wrap gap-2">{cat.options.map((o) => <Button key={o} className="min-h-11" variant={label === o ? "default" : "outline"} onClick={() => setLabel(o)}>{o}</Button>)}</div>
            <Input placeholder="Or type something else" value={cat.options.includes(label as never) ? "" : label} onChange={(e) => setLabel(e.target.value)} />
            {"intensity" in cat && <div><p className="mb-1 text-sm font-medium">How strong? (1 mild – 5 severe)</p><div className="flex gap-2">{[1, 2, 3, 4, 5].map((n) => <Button key={n} className="min-h-11 flex-1" variant={intensity === n ? "default" : "outline"} onClick={() => setIntensity(n)}>{n}</Button>)}</div></div>}
            {"hours" in cat && <div><p className="mb-1 text-sm font-medium">Hours</p><Input type="number" inputMode="decimal" min={0} max={24} step={0.5} value={hours} onChange={(e) => setHours(e.target.value)} /></div>}
            {(cat.id === "symptom" || cat.id === "behavior" || cat.id === "mood") && <>
              <div><p className="mb-1 text-sm font-medium">Where?</p><div className="flex flex-wrap gap-2">{LOCATIONS.map((l) => <Button key={l} size="sm" variant={location === l ? "default" : "outline"} onClick={() => setLocation(location === l ? null : l)}>{l}</Button>)}</div></div>
              <div><p className="mb-1 text-sm font-medium">Surroundings</p><div className="flex flex-wrap gap-2">{ENV.map((l) => <Button key={l} size="sm" variant={env.includes(l) ? "default" : "outline"} onClick={() => setEnv(env.includes(l) ? env.filter((x) => x !== l) : [...env, l])}>{l}</Button>)}</div></div>
            </>}
            <div><div className="mb-1 flex items-center justify-between"><p className="text-sm font-medium">Notes (optional)</p><VoiceInput onTranscript={(t) => setNotes((n) => (n ? `${n} ${t}` : t))} /></div><Textarea rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Anything else you noticed" /></div>
            <div><p className="mb-1 text-sm font-medium">When</p><Input type="datetime-local" value={when} onChange={(e) => setWhen(e.target.value)} /></div>
            {(URGENT.includes(label) || (intensity ?? 0) >= 4) && <p className="rounded-md bg-destructive/10 p-2 text-sm text-destructive">If this is sudden, severe, or caused an injury, call emergency services or the doctor now.</p>}
            <Button className="w-full min-h-12" disabled={saving} onClick={save}>{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save"}</Button>
          </div>}
        </DrawerContent>
      </Drawer>

      <AlertDialog open={!!urgent} onOpenChange={(o) => !o && setUrgent(null)}>
        <AlertDialogContent className="border-destructive">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-destructive"><AlertTriangle className="h-6 w-6" />Serious symptom recorded</AlertDialogTitle>
            <AlertDialogDescription className="text-base">"{urgent}" was recorded. If it is sudden, severe, getting worse, or there is an injury, chest pain, trouble breathing, or sudden weakness or confusion, call emergency services now. Otherwise, contact the doctor today.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="gap-2">
            <AlertDialogAction asChild><a href="tel:911" className="bg-destructive text-destructive-foreground hover:bg-destructive/90"><Phone className="mr-2 h-4 w-4" />Call 911</a></AlertDialogAction>
            <AlertDialogCancel>It's under control</AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};
