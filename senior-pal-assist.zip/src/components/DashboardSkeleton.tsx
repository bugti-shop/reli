import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

/** Grey placeholder shapes shown while the dashboard data is loading. */
export const DashboardSkeleton = () => (
  <div className="max-w-7xl mx-auto px-4 md:px-8 py-6 space-y-6" aria-busy="true" aria-live="polite">
    <span className="sr-only">Loading your dashboard…</span>
    <Card className="p-6 md:p-8 border-0 shadow-lg">
      <Skeleton className="h-5 w-32 mb-3" />
      <Skeleton className="h-10 w-56 mb-4" />
      <Skeleton className="h-4 w-44" />
    </Card>
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
      {Array.from({ length: 4 }).map((_, i) => (
        <Skeleton key={i} className="h-16 rounded-2xl" />
      ))}
    </div>
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
      {Array.from({ length: 3 }).map((_, i) => (
        <Skeleton key={i} className="h-20 rounded-2xl" />
      ))}
    </div>
    <Skeleton className="h-12 w-full rounded-2xl" />
    <Skeleton className="h-64 w-full rounded-2xl" />
  </div>
);

export default DashboardSkeleton;
