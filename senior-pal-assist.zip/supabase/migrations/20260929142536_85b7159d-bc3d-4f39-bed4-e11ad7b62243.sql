CREATE OR REPLACE FUNCTION public.add_senior_by_email(_email text)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  me uuid := auth.uid();
  sid uuid;
BEGIN
  IF me IS NULL THEN RAISE EXCEPTION 'NOT_AUTHENTICATED'; END IF;
  IF NOT EXISTS (SELECT 1 FROM profiles WHERE id = me AND role = 'caregiver') THEN
    RAISE EXCEPTION 'NOT_CAREGIVER';
  END IF;
  SELECT id INTO sid FROM profiles WHERE lower(email) = lower(trim(_email)) AND role = 'senior' LIMIT 1;
  IF sid IS NULL THEN RAISE EXCEPTION 'SENIOR_NOT_FOUND'; END IF;
  IF EXISTS (SELECT 1 FROM caregiver_seniors WHERE caregiver_id = me AND senior_id = sid) THEN
    RAISE EXCEPTION 'ALREADY_CONNECTED';
  END IF;
  INSERT INTO caregiver_seniors (caregiver_id, senior_id, relationship) VALUES (me, sid, 'caregiver');
  RETURN sid;
END;
$$;
REVOKE ALL ON FUNCTION public.add_senior_by_email(text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.add_senior_by_email(text) TO authenticated;