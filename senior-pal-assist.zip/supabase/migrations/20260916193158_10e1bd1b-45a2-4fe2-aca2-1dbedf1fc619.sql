CREATE OR REPLACE FUNCTION public.protect_profile_role_plan()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  jwt_role text;
BEGIN
  jwt_role := COALESCE(current_setting('request.jwt.claims', true)::json->>'role', '');

  -- Trusted server-side contexts (billing sync, admin jobs) may change plan.
  IF jwt_role = 'service_role' OR jwt_role = '' THEN
    NEW.role := OLD.role;
    RETURN NEW;
  END IF;

  -- Regular users can never change their own role or plan.
  NEW.role := OLD.role;
  NEW.plan := OLD.plan;
  RETURN NEW;
END;
$function$;