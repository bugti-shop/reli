ALTER TABLE public.life_story_entries
ADD COLUMN IF NOT EXISTS image_path text;

ALTER TABLE public.life_story_memories
DROP CONSTRAINT IF EXISTS life_story_memories_category_check;

ALTER TABLE public.life_story_memories
ADD CONSTRAINT life_story_memories_category_check
CHECK (category IN ('best_days', 'first_job', 'best_friend', 'first_pet'));