import { useCallback, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Plus, KeyRound, Share2, Mail, ArrowLeft, Copy } from "lucide-react";
import { z } from "zod";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface Member { id: string; relationship: string; profile: { full_name: string | null; email: string } | null }
type Step = "menu" | "join" | "code" | "email";

const emailSchema = z.string().trim().email().max(255);
const codeSchema = z.string().trim().regex(/^[A-Za-z0-9]{6,12}$/);

/** Home-page Family Circle: avatars + a "+" that opens join / share code / email invite options. */
export const HomeFamilyCircle = ({ seniorId }: { seniorId: string }) => {
  const [members, setMembers] = useState<Member[]>([]);
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState<Step>("menu");
  const [code, setCode] = useState<string | null>(null);
  const [joinCode, setJoinCode] = useState("");
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();

  const load = useCallback(async () => {
    const { data } = await supabase
      .from("caregiver_seniors")
      .select("id, relationship, profile:profiles!caregiver_seniors_caregiver_id_fkey(full_name, email)")
      .eq("senior_id", seniorId);
    setMembers((data as unknown as Member[]) || []);
  }, [seniorId]);
  useEffect(() => { load(); }, [load]);

  const reset = (o: boolean) => { setOpen(o); if (!o) { setStep("menu"); setCode(null); setJoinCode(""); setEmail(""); } };

  const createCode = async () => {
    setBusy(true);
    const { data: auth } = await supabase.auth.getUser();
    if (!auth.user) {
      setBusy(false);
      toast({ title: "Please sign in again", variant: "destructive" });
      return null;
    }
    const { data, error } = await supabase.from("circle_invites")
      .insert({ senior_id: seniorId, created_by: auth.user.id, relationship: "family" })
      .select("id, code").single();
    setBusy(false);
    if (error) { toast({ title: "Could not create invite", description: error.message, variant: "destructive" }); return null; }
    setCode(data.code);
    return { id: data.id as string, code: data.code as string };
  };

  const inviteText = (c: string) => `Join my care circle on Reli so you get my SOS alerts and health updates: ${window.location.origin}/join/${c} (code ${c})`;

  const shareCode = async () => {
    if (!code) return;
    if (navigator.share) {
      try {
        await navigator.share({ title: "Join my Reli circle", text: inviteText(code) });
      } catch (error) {
        if (error instanceof DOMException && error.name === "AbortError") return;
        toast({ title: "Could not open sharing", description: "Please copy the code and send it manually.", variant: "destructive" });
      }
    } else {
      try {
        await navigator.clipboard.writeText(inviteText(code));
        toast({ title: "Invite copied" });
      } catch {
        toast({ title: "Could not copy invite", description: "Please copy the code shown above.", variant: "destructive" });
      }
    }
  };

  const sendEmail = async () => {
    const parsed = emailSchema.safeParse(email);
    if (!parsed.success) return toast({ title: "Please enter a valid email", variant: "destructive" });
    setBusy(true);
    const { data: auth } = await supabase.auth.getUser();
    if (!auth.user) {
      setBusy(false);
      toast({ title: "Please sign in again", variant: "destructive" });
      return;
    }
    const normalizedEmail = parsed.data.toLowerCase();
    const { data: invite, error: inviteError } = await supabase.from("circle_invites")
      .insert({ senior_id: seniorId, created_by: auth.user.id, relationship: "family", invitee_email: normalizedEmail })
      .select("id, code")
      .single();
    if (inviteError || !invite) {
      setBusy(false);
      toast({ title: "Could not prepare invitation", description: inviteError?.message, variant: "destructive" });
      return;
    }
    setCode(invite.code);
    const { data, error } = await supabase.functions.invoke("send-circle-invite", {
      body: { inviteId: invite.id, email: normalizedEmail },
    });
    setBusy(false);
    if (error || data?.error) {
      await supabase.from("circle_invites").delete().eq("id", invite.id);
      toast({ title: "Could not send invitation", description: data?.error || error?.message, variant: "destructive" });
      return;
    }
    toast({ title: "Invitation sent", description: `${parsed.data} can request access with one tap. You will approve them before anything is shared.` });
    reset(false);
  };

  const join = () => {
    const parsed = codeSchema.safeParse(joinCode);
    if (!parsed.success) return toast({ title: "Please enter a valid invite code", variant: "destructive" });
    navigate(`/join/${parsed.data.toUpperCase()}`);
  };

  const initial = (m: Member) => (m.profile?.full_name || m.profile?.email || "?").trim().charAt(0).toUpperCase();

  return (
    <section className="mt-5 px-1">
      <h2 className="text-xl font-bold md:text-2xl">Add Caregiver</h2>
      <div className="mt-3 flex gap-4 overflow-x-auto pb-1">
        {members.map((m) => (
          <div key={m.id} className="flex w-16 shrink-0 flex-col items-center gap-1">
            <span className="flex h-16 w-16 items-center justify-center rounded-full bg-accent text-xl font-bold text-accent-foreground">{initial(m)}</span>
            <span className="w-full truncate text-center text-xs capitalize text-muted-foreground">{m.profile?.full_name?.split(" ")[0] || m.relationship}</span>
          </div>
        ))}
        <Button type="button" variant="ghost" onClick={() => setOpen(true)} aria-label="Add caregiver" className="h-auto w-16 shrink-0 flex-col items-center gap-1 p-0 hover:bg-transparent">
          <span className="flex h-16 w-16 items-center justify-center rounded-full border-2 border-dashed border-muted-foreground/40 bg-card text-muted-foreground"><Plus className="h-7 w-7" /></span>
          <span className="text-xs text-muted-foreground">Add</span>
        </Button>
      </div>

      <Dialog open={open} onOpenChange={reset}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>{step === "menu" ? "Add Caregiver" : step === "join" ? "Join with a code" : step === "code" ? "Send invitation code" : "Invite by email"}</DialogTitle>
            <DialogDescription>{step === "menu" ? "What would you like to do?" : "Invites are single-use and valid for 7 days."}</DialogDescription>
          </DialogHeader>

          {step === "menu" && (
            <div className="grid gap-2">
              <Button variant="outline" className="min-h-14 justify-start gap-3" onClick={() => setStep("join")}><KeyRound className="h-5 w-5" />Join a family with a code</Button>
              <Button variant="outline" className="min-h-14 justify-start gap-3" disabled={busy} onClick={async () => { setStep("code"); await createCode(); }}><Share2 className="h-5 w-5" />Send an invitation code</Button>
              <Button variant="outline" className="min-h-14 justify-start gap-3" onClick={() => setStep("email")}><Mail className="h-5 w-5" />Send invitation by email</Button>
            </div>
          )}

          {step === "join" && (
            <div className="space-y-3">
              <Input value={joinCode} onChange={(e) => setJoinCode(e.target.value)} placeholder="Enter invite code" maxLength={12} className="text-center text-lg uppercase tracking-widest" />
              <Button className="w-full" disabled={busy || !joinCode.trim()} onClick={join}>Join</Button>
            </div>
          )}

          {step === "code" && (
            <div className="space-y-3 text-center">
              <p className="text-3xl font-bold tracking-widest">{busy ? "…" : code ?? "—"}</p>
              <Button className="w-full gap-2" disabled={!code} onClick={shareCode}><Copy className="h-4 w-4" />Share invite</Button>
            </div>
          )}

          {step === "email" && (
            <div className="space-y-3">
              <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="family@example.com" maxLength={255} />
              <Button className="w-full gap-2" disabled={busy || !email.trim()} onClick={sendEmail}><Mail className="h-4 w-4" />{busy ? "Sending…" : "Send invitation"}</Button>
            </div>
          )}

          {step !== "menu" && <Button variant="ghost" size="sm" className="gap-1" onClick={() => { setStep("menu"); setCode(null); }}><ArrowLeft className="h-4 w-4" />Back</Button>}
        </DialogContent>
      </Dialog>
    </section>
  );
};
