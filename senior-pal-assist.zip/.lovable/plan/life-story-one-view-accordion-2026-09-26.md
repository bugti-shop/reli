# Life Story one-view accordion

## Build
- Replace the long Life Story layout with the selected compact accordion design, optimized for one mobile view.
- Order sections as: Today's Story, My Best Days, My First Job, Childhood Best Friends, My First Pet.
- Keep only one section expanded at a time so the screen stays compact; tapping a row opens its relevant content.
- Add a circular plus button that opens a dropdown of all five memory types and launches the matching form.
- Require every form to offer image upload, including Today's Story and My Best Days.
- Preserve edit, delete, voice input, saved data, private images, PDF export, and sharing.
- Ensure the complete PDF includes every story, special-memory field, and available image.

## Technical details
- Extend the existing special-memory category model for My Best Days while retaining current Job, Friend, and Pet records.
- Add optional image storage to daily story entries so Today's Story can save a photo securely.
- Reuse the existing private Life Story image bucket and linked caregiver read access.
- Keep the caregiver viewer compatible with the expanded Life Story content.
- Verify the signed-in mobile flow at 393×852: open each accordion, launch every form, and confirm no horizontal overflow.
