import { useCallback, useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { CheckCircle2, MapPin, Phone, Siren, Volume2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { SosMap } from "@/components/SosMap";

interface AlertRow {
  id: string;
  senior_id: string;
  created_at: string;
  status: string;
  latitude: number | null;
  longitude: number | null;
  accuracy_m: number | null;
  location_captured_at: string | null;
  cancelled_at: string | null;
}

const OPEN = ["active", "partially_acknowledged", "acknowledged"];
const COLS = "id, senior_id, created_at, status, latitude, longitude, accuracy_m, location_captured_at, cancelled_at";

/** Loud looping two-tone siren built with Web Audio (no audio file needed). */
const createSiren = () => {
  const Ctx = window.AudioContext || (window as any).webkitAudioContext;
  if (!Ctx) return null;
  const ctx: AudioContext = new Ctx();
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = "square";
  gain.gain.value = 0.35;
  osc.connect(gain).connect(ctx.destination);
  osc.start();
  let high = false;
  const timer = window.setInterval(() => {
    high = !high;
    osc.frequency.setValueAtTime(high ? 960 : 640, ctx.currentTime);
  }, 450);
  return {
    ctx,
    stop: () => {
      window.clearInterval(timer);
      try { osc.stop(); } catch { /* already stopped */ }
      ctx.close();
    },
  };
};

/**
 * Full-screen SOS alarm for caregivers. One screen per SOS event id, no matter
 * how many times the push / realtime event arrives. Rings until THIS caregiver
 * acknowledges, or the senior cancels / the SOS is resolved.
 */
export const SosAlarm = () => {
  const [userId, setUserId] = useState<string | null>(null);
  const [alert, setAlert] = useState<AlertRow | null>(null);
  const [closedNotice, setClosedNotice] = useState<string | null>(null);
  const [senior, setSenior] = useState<{ full_name: string | null; phone: string | null } | null>(null);
  const [mineAcked, setMineAcked] = useState(false);
  const [needsTap, setNeedsTap] = useState(false);
  const siren = useRef<ReturnType<typeof createSiren>>(null);
  const vibrateTimer = useRef<number | null>(null);
  const currentId = useRef<string | null>(null);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setUserId(data.user?.id ?? null));
    const { data } = supabase.auth.onAuthStateChange((_e, s) => setUserId(s?.user?.id ?? null));
    return () => data.subscription.unsubscribe();
  }, []);

  const stopSound = useCallback(() => {
    siren.current?.stop();
    siren.current = null;
    if (vibrateTimer.current) window.clearInterval(vibrateTimer.current);
    vibrateTimer.current = null;
    navigator.vibrate?.(0);
  }, []);

  const startSound = useCallback(() => {
    if (siren.current) return;
    siren.current = createSiren();
    if (siren.current?.ctx.state === "suspended") {
      siren.current.ctx.resume().catch(() => undefined);
      setNeedsTap(true);
    } else setNeedsTap(false);
    void import("@/lib/native").then((m) => m.buzz("alarm"));
    vibrateTimer.current = window.setInterval(() => void import("@/lib/native").then((m) => m.buzz("alarm")), 1200);
  }, []);

  const showAlert = useCallback(
    async (row: AlertRow) => {
      if (!userId || row.senior_id === userId || !OPEN.includes(row.status)) return;
      if (currentId.current === row.id) {
        setAlert((a) => (a ? { ...a, ...row } : a));
        return; // de-duplicate repeated deliveries of the same SOS
      }
      const { data: ack } = await supabase
        .from("sos_acknowledgements")
        .select("id")
        .eq("alert_id", row.id)
        .eq("caregiver_id", userId)
        .maybeSingle();
      if (ack) return;
      currentId.current = row.id;
      setClosedNotice(null);
      setMineAcked(false);
      setAlert(row);
      const { data } = await supabase.from("profiles").select("full_name, phone").eq("id", row.senior_id).maybeSingle();
      setSenior(data ?? null);
      startSound();
    },
    [userId, startSound],
  );

  const loadById = useCallback(
    async (id: string) => {
      const { data } = await supabase.from("emergency_alerts").select(COLS).eq("id", id).maybeSingle();
      if (data) showAlert(data as AlertRow);
    },
    [showAlert],
  );

  // On open: any SOS still open for my seniors (e.g. launched from the notification).
  useEffect(() => {
    if (!userId) return;
    const fromUrl = new URLSearchParams(window.location.search).get("sos");
    if (fromUrl && /^[0-9a-f-]{36}$/i.test(fromUrl)) loadById(fromUrl);
    supabase
      .from("emergency_alerts")
      .select(COLS)
      .in("status", OPEN)
      .neq("senior_id", userId)
      .order("created_at", { ascending: false })
      .limit(5)
      .then(async ({ data }) => {
        for (const row of data || []) {
          await showAlert(row as AlertRow);
          if (currentId.current) break;
        }
      });
  }, [userId, showAlert, loadById]);

  // Native app: notification tap → open that SOS.
  useEffect(() => {
    if (!(window as any).Capacitor?.isNativePlatform?.()) return;
    let remove: (() => void) | undefined;
    import("@capacitor/push-notifications")
      .then(async ({ PushNotifications }) => {
        const a = await PushNotifications.addListener("pushNotificationActionPerformed", (e) => {
          const id = e.notification?.data?.alert_id;
          if (typeof id === "string") loadById(id);
        });
        const b = await PushNotifications.addListener("pushNotificationReceived", (n) => {
          const id = n.data?.alert_id;
          if (typeof id === "string") loadById(id);
        });
        remove = () => { a.remove(); b.remove(); };
      })
      .catch(() => undefined);
    return () => remove?.();
  }, [loadById]);

  useEffect(() => {
    if (!userId) return;
    const channel = supabase
      .channel(`sos-alarm-${userId}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "emergency_alerts" }, (p) => showAlert(p.new as AlertRow))
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "emergency_alerts" }, (p) => {
        const row = p.new as AlertRow;
        if (currentId.current !== row.id) return;
        if (!OPEN.includes(row.status)) {
          stopSound();
          currentId.current = null;
          setAlert(null);
          setClosedNotice(row.status === "cancelled" ? "The senior cancelled the SOS. They said they are okay." : "The SOS was marked resolved.");
          return;
        }
        setAlert((a) => (a ? { ...a, ...row } : a));
      })
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [userId, showAlert, stopSound]);

  useEffect(() => stopSound, [stopSound]);

  if (closedNotice && !alert) {
    return (
      <div role="status" className="fixed inset-x-3 top-3 z-[100] flex items-center gap-3 rounded-2xl bg-primary p-4 text-primary-foreground shadow-lg">
        <CheckCircle2 className="h-6 w-6 shrink-0" />
        <p className="flex-1 font-semibold">{closedNotice}</p>
        <Button size="sm" variant="secondary" onClick={() => setClosedNotice(null)}>OK</Button>
      </div>
    );
  }

  if (!alert) return null;

  const name = senior?.full_name || "Your family member";
  const time = new Date(alert.created_at).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });

  const acknowledge = async () => {
    stopSound();
    setMineAcked(true);
    await supabase.rpc("acknowledge_sos", { _alert_id: alert.id });
  };

  const resolve = async () => {
    await supabase.rpc("close_sos", { _alert_id: alert.id, _outcome: "resolved" });
    supabase.functions.invoke("notify-emergency", { body: { alertId: alert.id, action: "cancel" } }).catch(() => undefined);
    stopSound();
    currentId.current = null;
    setAlert(null);
  };

  return (
    <div
      role="alertdialog"
      aria-live="assertive"
      aria-label={`Emergency SOS from ${name}`}
      className="fixed inset-0 z-[100] flex flex-col items-center gap-4 overflow-y-auto bg-destructive p-5 text-destructive-foreground"
    >
      <div className="mt-4 flex flex-col items-center gap-2 text-center">
        <div className={`flex h-20 w-20 items-center justify-center rounded-full bg-destructive-foreground/15 ${mineAcked ? "" : "animate-pulse"}`}>
          <Siren className="h-10 w-10" />
        </div>
        <p className="text-base font-semibold uppercase tracking-widest">Senior Emergency SOS</p>
        <h1 className="text-3xl font-bold leading-tight">{name} needs help</h1>
        <p className="opacity-90">SOS pressed at {time}</p>
        {mineAcked && <p className="rounded-full bg-destructive-foreground/15 px-4 py-1.5 font-semibold">You acknowledged — {name.split(" ")[0]} can see it</p>}
        {needsTap && !mineAcked && (
          <Button variant="secondary" onClick={() => { siren.current?.ctx.resume(); setNeedsTap(false); }} className="gap-2">
            <Volume2 className="h-5 w-5" /> Tap to turn sound on
          </Button>
        )}
      </div>

      <div className="w-full max-w-md">
        {alert.latitude != null && alert.longitude != null ? (
          <>
          <p className="mb-2 flex items-center gap-2 text-sm font-semibold"><span className="h-2.5 w-2.5 animate-pulse rounded-full bg-destructive-foreground" /> Live location — updates automatically</p>
          <SosMap latitude={alert.latitude} longitude={alert.longitude} accuracy={alert.accuracy_m} capturedAt={alert.location_captured_at} />
          </>
        ) : (
          <div className="flex items-center gap-2 rounded-2xl bg-destructive-foreground/15 p-4">
            <MapPin className="h-5 w-5 shrink-0" />
            <p>Waiting for the senior's location… It will appear here automatically if their phone shares it.</p>
          </div>
        )}
      </div>

      <div className="grid w-full max-w-md gap-3 pb-6">
        {!mineAcked && (
          <Button size="lg" variant="secondary" className="h-16 text-lg font-bold" onClick={acknowledge}>
            Acknowledge SOS
          </Button>
        )}
        {senior?.phone && (
          <Button asChild size="lg" variant="secondary" className="h-14 gap-2 text-lg">
            <a href={`tel:${senior.phone}`}><Phone className="h-5 w-5" /> Call {name.split(" ")[0]}</a>
          </Button>
        )}
        {mineAcked && (
          <>
            <Button size="lg" variant="secondary" onClick={resolve}>Mark emergency resolved</Button>
            <Button
              size="lg"
              variant="ghost"
              className="text-destructive-foreground hover:bg-destructive-foreground/10 hover:text-destructive-foreground"
              onClick={() => { currentId.current = alert.id; setAlert(null); }}
            >
              Close
            </Button>
          </>
        )}
      </div>
    </div>
  );
};
