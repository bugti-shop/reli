import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const url = new URL(req.url);
    const token = url.searchParams.get("token");
    if (!token || token.length < 16) {
      return new Response(JSON.stringify({ error: "Invalid token" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const { data: report, error } = await supabase
      .from("shared_reports")
      .select("*")
      .eq("share_token", token)
      .maybeSingle();

    if (error || !report) {
      return new Response(JSON.stringify({ error: "Report not found" }), {
        status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (report.revoked) {
      return new Response(JSON.stringify({ error: "This link has been revoked" }), {
        status: 410, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (new Date(report.expires_at) < new Date()) {
      return new Response(JSON.stringify({ error: "This link has expired" }), {
        status: 410, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Senior info
    const { data: senior } = await supabase
      .from("profiles")
      .select("full_name")
      .eq("id", report.senior_id)
      .maybeSingle();

    // Owner (sharer) info
    const { data: owner } = await supabase
      .from("profiles")
      .select("full_name, role")
      .eq("id", report.owner_id)
      .maybeSingle();

    const sinceDate = new Date();
    sinceDate.setDate(sinceDate.getDate() - (report.date_range_days || 14));
    const sinceIso = sinceDate.toISOString();
    const sinceDateOnly = sinceIso.slice(0, 10);

    let medications: any[] = [];
    let wellness: any[] = [];
    let activity: any[] = [];
    let customTrackers: any[] = [];

    if (report.include_medications) {
      const { data } = await supabase
        .from("medications")
        .select("name, dosage, time, notes, completed, completed_at, updated_at")
        .eq("senior_id", report.senior_id)
        .order("time", { ascending: true });
      medications = data || [];
    }

    if (report.include_wellness) {
      const { data } = await supabase
        .from("caregiver_daily_logs")
        .select("log_date, mood, took_medications, slept_well, ate_well, confusion_noted, had_fall, notes")
        .eq("senior_id", report.senior_id)
        .gte("log_date", sinceDateOnly)
        .order("log_date", { ascending: false });
      wellness = data || [];
    }

    if (report.include_activity) {
      const { data: act } = await supabase
        .from("senior_activity_log")
        .select("activity_type, activity_description, created_at")
        .eq("senior_id", report.senior_id)
        .gte("created_at", sinceIso)
        .order("created_at", { ascending: false })
        .limit(100);
      activity = act || [];

      const { data: ct } = await supabase
        .from("custom_trackers")
        .select("name, value, tracker_type, completed, completed_at, updated_at")
        .eq("senior_id", report.senior_id)
        .gte("updated_at", sinceIso)
        .order("updated_at", { ascending: false });
      customTrackers = ct || [];
    }

    return new Response(JSON.stringify({
      report: {
        title: report.title,
        notes: report.notes,
        recipient_name: report.recipient_name,
        date_range_days: report.date_range_days,
        created_at: report.created_at,
        expires_at: report.expires_at,
        include_medications: report.include_medications,
        include_wellness: report.include_wellness,
        include_activity: report.include_activity,
      },
      senior: { full_name: senior?.full_name || "Senior" },
      owner: { full_name: owner?.full_name || "Reli user", role: owner?.role || "senior" },
      data: { medications, wellness, activity, customTrackers },
    }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e) {
    console.error("get-shared-report error:", e);
    return new Response(JSON.stringify({ error: "Server error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
