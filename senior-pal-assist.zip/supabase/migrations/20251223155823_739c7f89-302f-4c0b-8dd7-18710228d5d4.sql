-- Drop the overly permissive RESTRICTIVE policies that allow any authenticated user to read data
-- The existing owner-based policies already properly restrict access

DROP POLICY IF EXISTS "Require authentication for viewing profiles" ON public.profiles;
DROP POLICY IF EXISTS "Require authentication for viewing life stories" ON public.life_story_entries;
DROP POLICY IF EXISTS "Require authentication for viewing subscribers" ON public.newsletter_subscribers;