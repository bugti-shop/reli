import { useEffect, useRef, useState } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

interface SosMapProps {
  latitude: number;
  longitude: number;
  /** GPS accuracy radius in metres, drawn as a circle. Null = unknown. */
  accuracy: number | null;
  capturedAt: string | null;
}

/** Zoom that roughly fits the accuracy circle; street level for good fixes. */
const zoomFor = (acc: number | null) => {
  if (acc == null) return 16;
  if (acc <= 25) return 18;
  if (acc <= 100) return 17;
  if (acc <= 400) return 15;
  if (acc <= 1500) return 13;
  return 11;
};

/**
 * Map of the senior's SOS location. Uses OpenStreetMap tiles (zoomable to
 * street / building level) and shows the real GPS accuracy radius — never a
 * guessed point. The readable address comes from OpenStreetMap reverse lookup.
 */
export const SosMap = ({ latitude, longitude, accuracy, capturedAt }: SosMapProps) => {
  const el = useRef<HTMLDivElement>(null);
  const map = useRef<L.Map | null>(null);
  const layer = useRef<L.LayerGroup | null>(null);
  const [address, setAddress] = useState<string | null>(null);

  useEffect(() => {
    if (!el.current || map.current) return;
    map.current = L.map(el.current, { zoomControl: true, attributionControl: true });
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      maxZoom: 19,
      attribution: "© OpenStreetMap",
    }).addTo(map.current);
    layer.current = L.layerGroup().addTo(map.current);
    return () => {
      map.current?.remove();
      map.current = null;
    };
  }, []);

  useEffect(() => {
    if (!map.current || !layer.current) return;
    layer.current.clearLayers();
    const point: L.LatLngExpression = [latitude, longitude];
    if (accuracy != null) {
      L.circle(point, { radius: accuracy, color: "hsl(0 72% 51%)", weight: 2, fillOpacity: 0.15 }).addTo(layer.current);
    }
    L.circleMarker(point, { radius: 9, color: "#fff", weight: 3, fillColor: "hsl(0 72% 51%)", fillOpacity: 1 }).addTo(layer.current);
    map.current.setView(point, zoomFor(accuracy));
    setTimeout(() => map.current?.invalidateSize(), 50);
  }, [latitude, longitude, accuracy]);

  useEffect(() => {
    const ctrl = new AbortController();
    setAddress(null);
    fetch(
      `https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=18&addressdetails=1&lat=${latitude}&lon=${longitude}`,
      { signal: ctrl.signal, headers: { Accept: "application/json" } },
    )
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => d?.display_name && setAddress(String(d.display_name)))
      .catch(() => undefined);
    return () => ctrl.abort();
  }, [latitude, longitude]);

  const coarse = accuracy != null && accuracy > 100;

  return (
    <div className="w-full overflow-hidden rounded-2xl bg-background text-foreground">
      <div ref={el} className="h-56 w-full sm:h-72" aria-label="Map of SOS location" />
      <div className="space-y-1 p-3 text-left text-sm">
        <p className="font-semibold leading-snug">{address ?? "Looking up street address…"}</p>
        <p className="text-muted-foreground">
          {latitude.toFixed(6)}, {longitude.toFixed(6)}
          {accuracy != null ? ` · accurate to ±${Math.round(accuracy)} m` : " · accuracy unknown"}
        </p>
        {coarse && <p className="font-medium text-destructive">Approximate location — the senior is somewhere inside the red circle.</p>}
        {capturedAt && (
          <p className="text-muted-foreground">
            Location captured {new Date(capturedAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit", second: "2-digit" })}
          </p>
        )}
        <a
          className="inline-block font-semibold text-primary underline"
          href={`https://www.google.com/maps/search/?api=1&query=${latitude},${longitude}`}
          target="_blank"
          rel="noreferrer"
        >
          Open in maps for directions
        </a>
      </div>
    </div>
  );
};
