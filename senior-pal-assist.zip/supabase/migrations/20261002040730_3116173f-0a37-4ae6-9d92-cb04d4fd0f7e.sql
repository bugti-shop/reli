CREATE TABLE public.care_observations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  senior_id uuid NOT NULL,
  caregiver_id uuid NOT NULL DEFAULT auth.uid(),
  category text NOT NULL,
  label text NOT NULL,
  intensity smallint,
  value_num numeric,
  location text,
  environment text[] NOT NULL DEFAULT '{}',
  notes text,
  observed_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.care_observations TO authenticated;
GRANT ALL ON public.care_observations TO service_role;
ALTER TABLE public.care_observations ENABLE ROW LEVEL SECURITY;
CREATE INDEX care_observations_senior_time ON public.care_observations (senior_id, observed_at DESC);
CREATE POLICY "Linked caregivers read observations" ON public.care_observations FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.caregiver_seniors cs WHERE cs.senior_id = care_observations.senior_id AND cs.caregiver_id = auth.uid()));
CREATE POLICY "Linked caregivers add observations" ON public.care_observations FOR INSERT TO authenticated
  WITH CHECK (caregiver_id = auth.uid() AND EXISTS (SELECT 1 FROM public.caregiver_seniors cs WHERE cs.senior_id = care_observations.senior_id AND cs.caregiver_id = auth.uid()));
CREATE POLICY "Authors update observations" ON public.care_observations FOR UPDATE TO authenticated
  USING (caregiver_id = auth.uid()) WITH CHECK (caregiver_id = auth.uid());
CREATE POLICY "Authors delete observations" ON public.care_observations FOR DELETE TO authenticated
  USING (caregiver_id = auth.uid());
CREATE OR REPLACE FUNCTION public.validate_care_observation() RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF NEW.category NOT IN ('medication','symptom','mood','sleep','food','activity','behavior','environment','note') THEN
    RAISE EXCEPTION 'Invalid category';
  END IF;
  NEW.label := left(trim(NEW.label), 120);
  NEW.notes := left(NEW.notes, 2000);
  IF NEW.intensity IS NOT NULL AND (NEW.intensity < 1 OR NEW.intensity > 5) THEN RAISE EXCEPTION 'Intensity 1-5'; END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER validate_care_observation BEFORE INSERT OR UPDATE ON public.care_observations
  FOR EACH ROW EXECUTE FUNCTION public.validate_care_observation();