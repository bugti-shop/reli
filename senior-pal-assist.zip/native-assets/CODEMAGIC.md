# Reli — GitHub + Codemagic build guide (no Mac, no Android Studio)

## 1. Get the code on GitHub
In Lovable: **+ menu → GitHub → Connect project** → create the repository.
Lovable syncs every change both ways. `android/`, `ios/`, `codemagic.yaml` and all source are included.
Signing files, `google-services.json` and `GoogleService-Info.plist` are git-ignored on purpose.

## 2. Connect Codemagic
Codemagic → Add application → GitHub → pick the repo → it detects `codemagic.yaml`.

## 3. Environment variable groups (Codemagic → Teams/App → Environment variables, mark Secure)
| Group | Variable | Value |
|---|---|---|
| reli_app | VITE_REVENUECAT_IOS_KEY / VITE_REVENUECAT_ANDROID_KEY | RevenueCat public SDK keys |
| reli_app | APP_VERSION (optional) | e.g. 1.0.0 |
| reli_firebase | GOOGLE_SERVICES_JSON_B64 | `base64 -i google-services.json` (can do on any PC / online at Firebase download) |
| reli_firebase | GOOGLE_SERVICE_INFO_PLIST_B64 | `base64 -i GoogleService-Info.plist` |
| google_play | GCLOUD_SERVICE_ACCOUNT_CREDENTIALS | Google Play service account JSON |

## 4. Signing — all in the cloud
- **Android:** Codemagic → Code signing identities → Android keystores → *Generate* (or upload) with reference name `reli_upload_keystore`. Download a backup and keep it safe — losing it blocks Play updates (Play App Signing recommended).
- **iOS:** Codemagic → Code signing identities → add an **App Store Connect API key** (named `Reli App Store Connect API key`), then let Codemagic *generate* the Distribution certificate and fetch the App Store profile for `com.reli.care`. No Mac or Xcode needed.
- Set `APP_STORE_APPLE_ID` in `codemagic.yaml` to the app's numeric Apple ID.

### Create an Android keystore without Android Studio
The simplest method is **Codemagic → Teams → Code signing identities → Android keystores → Generate keystore**. Use reference name `reli_upload_keystore`, then download its backup and store the file, alias and passwords securely. The existing `codemagic.yaml` reuses this same identity for every signed APK and AAB.

You can also create one locally on Windows, macOS or Linux after installing a Java JDK (Android Studio is not required):

```bash
keytool -genkeypair -v -keystore reli-upload-key.jks -alias reli-upload -keyalg RSA -keysize 2048 -validity 10000
```

Upload `reli-upload-key.jks` to Codemagic under Android keystores with reference name `reli_upload_keystore`. Never commit the `.jks`, alias password or keystore password to GitHub. Keep at least two encrypted backups; the same upload key must sign future updates.

## 5. Build
- Push to `main` → `android-main` makes a signed AAB + APK (same keystore, auto-incremented versionCode). Tags `v*` also publish to Play internal.
- Create a Git tag `v1.0.0` (GitHub → Releases → new release) → `android-release` (AAB → Play internal track as draft) and `ios-release` (IPA → TestFlight).
Each build runs `npm run build` → `npx cap sync` so web code, plugins and native config are always fresh.

## 6. Adding/removing Capacitor plugins
Install/remove the npm package, then `npx cap sync` (done automatically in every Codemagic build). Commit `android/` and `ios/` changes the sync produces (e.g. `ios/App/CapApp-SPM/Package.swift`, `android/capacitor.settings.gradle`). iOS uses Swift Package Manager, so no CocoaPods step.

## What still genuinely needs Apple/Google consoles (web, not Xcode/Android Studio)
- App records in App Store Connect and Google Play Console; first Play upload of the AAB must be done manually once in the Play Console.
- APNs key (.p8) uploaded to Firebase; Push + Critical Alerts capabilities on the App ID in developer.apple.com. Critical Alerts needs Apple's approval.
- Store listings, screenshots, privacy forms, reviewer demo accounts.
- Debugging on a real iPhone: no Xcode needed — install via TestFlight. Android: install the APK artifact directly.
