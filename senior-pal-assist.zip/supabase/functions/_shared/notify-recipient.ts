// Shared helper: resolves where a user's notifications should go, based on
// their saved notification preferences with a fallback to their account email.

export type NotifyEvent =
  | 'notify_emergency'
  | 'notify_messages'
  | 'notify_reminders'
  | 'notify_daily_summary'

export interface Recipient {
  email: string
  name: string | null
}

export async function resolveEmailRecipient(
  admin: any,
  userId: string,
  event: NotifyEvent
): Promise<Recipient | null> {
  const [{ data: profile }, { data: prefs }] = await Promise.all([
    admin.from('profiles').select('email, full_name').eq('id', userId).maybeSingle(),
    admin
      .from('notification_preferences')
      .select('email, email_enabled, notify_emergency, notify_messages, notify_reminders, notify_daily_summary')
      .eq('user_id', userId)
      .maybeSingle(),
  ])

  const name = profile?.full_name ?? null

  if (prefs) {
    if (prefs.email_enabled === false) return null
    if (prefs[event] === false) return null
    const email = (prefs.email || profile?.email || '').trim()
    return email && !isManagedEmail(email) ? { email, name } : null
  }

  const email = (profile?.email || '').trim()
  return email && !isManagedEmail(email) ? { email, name } : null
}

export interface SmsRecipient {
  phone: string
  name: string | null
}

/**
 * Resolves the phone number a user's text alerts should go to, honoring their
 * saved SMS preferences with a fallback to the phone on their profile.
 */
export async function resolveSmsRecipient(
  admin: any,
  userId: string,
  event: NotifyEvent
): Promise<SmsRecipient | null> {
  const [{ data: profile }, { data: prefs }] = await Promise.all([
    admin.from('profiles').select('phone, full_name').eq('id', userId).maybeSingle(),
    admin
      .from('notification_preferences')
      .select('phone, sms_enabled, notify_emergency, notify_messages, notify_reminders, notify_daily_summary')
      .eq('user_id', userId)
      .maybeSingle(),
  ])

  const name = profile?.full_name ?? null

  // Texts are opt-in: without saved preferences we do not send.
  if (!prefs) return null
  if (prefs.sms_enabled !== true) return null
  if (prefs[event] === false) return null

  const phone = (prefs.phone || profile?.phone || '').trim()
  return phone ? { phone, name } : null
}

/** Placeholder addresses for caregiver-managed seniors who have no app login. */
export function isManagedEmail(email: string): boolean {
  return /@managed\.reli\.care$/i.test(email.trim())
}
