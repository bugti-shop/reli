import { supabase } from "@/integrations/supabase/client";

const STORAGE_KEY = "reli.offline.queue.v1";
const EVENT = "reli-offline-queue-changed";

export type QueueOp = "insert" | "update" | "upsert" | "delete";

export interface QueueItem {
  id: string;
  table: string;
  op: QueueOp;
  /** Row data for insert/update/upsert */
  payload?: Record<string, unknown>;
  /** Row id to match for update/delete */
  matchId?: string;
  /** Comma separated conflict columns for upsert */
  onConflict?: string;
  /** Human friendly description shown to the user */
  label: string;
  createdAt: string;
  attempts: number;
}

const isBrowser = () => typeof window !== "undefined";

export const getQueue = (): QueueItem[] => {
  if (!isBrowser()) return [];
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as QueueItem[]) : [];
  } catch {
    return [];
  }
};

const setQueue = (items: QueueItem[]) => {
  if (!isBrowser()) return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  } catch (e) {
    console.error("Could not save offline queue", e);
  }
  window.dispatchEvent(new CustomEvent(EVENT));
};

export const subscribeToQueue = (cb: () => void) => {
  if (!isBrowser()) return () => {};
  window.addEventListener(EVENT, cb);
  window.addEventListener("storage", cb);
  return () => {
    window.removeEventListener(EVENT, cb);
    window.removeEventListener("storage", cb);
  };
};

export const enqueue = (
  item: Omit<QueueItem, "id" | "createdAt" | "attempts">
): QueueItem => {
  const full: QueueItem = {
    ...item,
    id:
      typeof crypto !== "undefined" && "randomUUID" in crypto
        ? crypto.randomUUID()
        : `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    createdAt: new Date().toISOString(),
    attempts: 0,
  };
  setQueue([...getQueue(), full]);
  return full;
};

export const removeFromQueue = (id: string) => {
  setQueue(getQueue().filter((i) => i.id !== id));
};

export const queueForTable = (table: string) =>
  getQueue().filter((i) => i.table === table);

export const isOnline = () => (isBrowser() ? window.navigator.onLine !== false : true);

let flushing = false;

export interface FlushResult {
  synced: number;
  failed: number;
  remaining: number;
}

const runItem = async (item: QueueItem) => {
  // Table names are validated by the caller (only known app tables are queued).
  const table = supabase.from(item.table as never);
  if (item.op === "insert") {
    return await (table as never as { insert: (v: unknown) => Promise<{ error: unknown }> }).insert(
      item.payload
    );
  }
  if (item.op === "upsert") {
    return await (
      table as never as {
        upsert: (v: unknown, o?: { onConflict?: string }) => Promise<{ error: unknown }>;
      }
    ).upsert(item.payload, item.onConflict ? { onConflict: item.onConflict } : undefined);
  }
  if (item.op === "update") {
    return await (
      table as never as {
        update: (v: unknown) => { eq: (c: string, v: string) => Promise<{ error: unknown }> };
      }
    )
      .update(item.payload)
      .eq("id", item.matchId as string);
  }
  return await (
    table as never as {
      delete: () => { eq: (c: string, v: string) => Promise<{ error: unknown }> };
    }
  )
    .delete()
    .eq("id", item.matchId as string);
};

/** Sends everything saved on the device. Stops early if the connection drops again. */
export const flushQueue = async (): Promise<FlushResult> => {
  if (flushing) return { synced: 0, failed: 0, remaining: getQueue().length };
  flushing = true;
  let synced = 0;
  let failed = 0;

  try {
    for (const item of getQueue()) {
      if (!isOnline()) break;
      let result: { error: unknown } | undefined;
      try {
        result = (await runItem(item)) as { error: unknown };
      } catch (e) {
        // Almost always a lost connection — keep the item for the next attempt.
        console.warn("Offline sync attempt failed", e);
        break;
      }

      const error = result?.error as { message?: string; code?: string } | null;
      if (!error) {
        synced += 1;
        removeFromQueue(item.id);
        continue;
      }

      const message = (error.message || "").toLowerCase();
      const networky =
        message.includes("failed to fetch") ||
        message.includes("network") ||
        message.includes("timeout");
      if (networky) break;

      // The server rejected it (duplicate, permissions, bad data) — retrying won't help.
      console.error("Dropping unsyncable offline entry", item.table, error);
      failed += 1;
      removeFromQueue(item.id);
    }
  } finally {
    flushing = false;
  }

  return { synced, failed, remaining: getQueue().length };
};
