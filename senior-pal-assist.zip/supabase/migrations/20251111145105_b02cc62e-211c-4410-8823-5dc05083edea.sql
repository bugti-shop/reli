-- Add foreign key constraints to link caregiver_messages to profiles table
ALTER TABLE caregiver_messages
  DROP CONSTRAINT IF EXISTS caregiver_messages_caregiver_id_fkey,
  DROP CONSTRAINT IF EXISTS caregiver_messages_senior_id_fkey;

ALTER TABLE caregiver_messages
  ADD CONSTRAINT caregiver_messages_caregiver_id_fkey 
    FOREIGN KEY (caregiver_id) 
    REFERENCES profiles(id) 
    ON DELETE CASCADE,
  ADD CONSTRAINT caregiver_messages_senior_id_fkey 
    FOREIGN KEY (senior_id) 
    REFERENCES profiles(id) 
    ON DELETE CASCADE;

-- Add foreign key constraints to caregiver_seniors table
ALTER TABLE caregiver_seniors
  DROP CONSTRAINT IF EXISTS caregiver_seniors_caregiver_id_fkey,
  DROP CONSTRAINT IF EXISTS caregiver_seniors_senior_id_fkey;

ALTER TABLE caregiver_seniors
  ADD CONSTRAINT caregiver_seniors_caregiver_id_fkey 
    FOREIGN KEY (caregiver_id) 
    REFERENCES profiles(id) 
    ON DELETE CASCADE,
  ADD CONSTRAINT caregiver_seniors_senior_id_fkey 
    FOREIGN KEY (senior_id) 
    REFERENCES profiles(id) 
    ON DELETE CASCADE;