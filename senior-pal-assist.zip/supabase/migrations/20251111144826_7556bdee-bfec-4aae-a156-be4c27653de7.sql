-- Enable realtime for caregiver_messages table
ALTER PUBLICATION supabase_realtime ADD TABLE public.caregiver_messages;