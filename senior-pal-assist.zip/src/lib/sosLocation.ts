import { Capacitor, registerPlugin } from "@capacitor/core";
import type { BackgroundGeolocationPlugin } from "@capacitor-community/background-geolocation";

export interface SosFix {
  latitude: number;
  longitude: number;
  accuracy: number | null;
  capturedAt: string;
}

const BackgroundGeolocation = registerPlugin<BackgroundGeolocationPlugin>("BackgroundGeolocation");
const native = () => Capacitor.isNativePlatform();

const fromPosition = (p: GeolocationPosition): SosFix => ({
  latitude: p.coords.latitude,
  longitude: p.coords.longitude,
  accuracy: Number.isFinite(p.coords.accuracy) ? p.coords.accuracy : null,
  capturedAt: new Date(p.timestamp || Date.now()).toISOString(),
});

/** One high-accuracy GPS fix (null if denied/unavailable). Never invents a location. */
export const getSosFix = async (timeoutMs = 15000): Promise<SosFix | null> => {
  if (native()) {
    try {
      const { Geolocation } = await import("@capacitor/geolocation");
      let perm = await Geolocation.checkPermissions();
      if (perm.location !== "granted") perm = await Geolocation.requestPermissions({ permissions: ["location"] });
      if (perm.location !== "granted" && perm.coarseLocation !== "granted") return null;
      const p = await Geolocation.getCurrentPosition({ enableHighAccuracy: true, timeout: timeoutMs, maximumAge: 0 });
      return fromPosition(p as unknown as GeolocationPosition);
    } catch {
      return null;
    }
  }
  return new Promise<SosFix | null>((resolve) => {
    if (!("geolocation" in navigator)) return resolve(null);
    navigator.geolocation.getCurrentPosition(
      (p) => resolve(fromPosition(p)),
      () => resolve(null),
      { enableHighAccuracy: true, timeout: timeoutMs, maximumAge: 0 },
    );
  });
};

/**
 * Live updates during an active SOS only. On the phone app this keeps running
 * while the screen is locked (Android shows a persistent "sharing location"
 * notification; iOS shows the blue location indicator). Returns a stop function.
 */
export const watchSosFix = (onFix: (f: SosFix) => void) => {
  if (native()) {
    let watcherId: string | null = null;
    let stopped = false;
    BackgroundGeolocation.addWatcher(
      {
        backgroundTitle: "Reli SOS — sharing your location",
        backgroundMessage: "Your caregivers can see where you are until the SOS ends.",
        requestPermissions: true,
        stale: false,
        distanceFilter: 5,
      },
      (loc, err) => {
        if (err || !loc) return;
        onFix({
          latitude: loc.latitude,
          longitude: loc.longitude,
          accuracy: Number.isFinite(loc.accuracy) ? loc.accuracy : null,
          capturedAt: new Date(loc.time || Date.now()).toISOString(),
        });
      },
    ).then((id) => {
      if (stopped) BackgroundGeolocation.removeWatcher({ id });
      else watcherId = id;
    }).catch(() => undefined);
    return () => {
      stopped = true;
      if (watcherId) BackgroundGeolocation.removeWatcher({ id: watcherId }).catch(() => undefined);
    };
  }
  if (!("geolocation" in navigator)) return () => {};
  const id = navigator.geolocation.watchPosition((p) => onFix(fromPosition(p)), () => undefined, {
    enableHighAccuracy: true,
    maximumAge: 5000,
    timeout: 30000,
  });
  return () => navigator.geolocation.clearWatch(id);
};
