import { StorePlans } from "@/components/StorePlans";
import { isNativeApp } from "@/lib/native";
import { manageStoreSubscription } from "@/lib/purchases";
import { useEffect, useState, useCallback } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Check, Loader2, Sparkles, ArrowLeft, RefreshCw, CreditCard } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { usePlan } from "@/hooks/use-plan";
import { PAID_PLANS } from "@/lib/plans";
import Header from "@/components/Header";

const FREE_FEATURES = [
  "Medication, blood pressure & heart rate trackers",
  "Reminders & notifications",
  "Journal & daily log (last 30 days)",
  "AI companion & life story",
  "Shared reports & doctor reports",
  "Up to 2 seniors per caregiver",
];

const Pricing = () => {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const { toast } = useToast();
  const [userId, setUserId] = useState<string | null>(null);
  const [role, setRole] = useState<"senior" | "caregiver">("senior");
  const [annual, setAnnual] = useState(false);
  const [busyPrice, setBusyPrice] = useState<string | null>(null);
  const [managing, setManaging] = useState(false);
  const [checking, setChecking] = useState(false);
  const { plan, isPremium, refresh } = usePlan(userId ?? undefined);

  useEffect(() => {
    const load = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        setUserId(user.id);
        const { data: profile } = await supabase
          .from("profiles")
          .select("role")
          .eq("id", user.id)
          .maybeSingle();
        if (profile?.role === "caregiver") setRole("caregiver");
      }
    };
    load();
  }, []);

  // After returning from Stripe checkout, poll until the plan flips to premium.
  useEffect(() => {
    if (searchParams.get("subscribed") === "1") {
      toast({ title: "Thank you!", description: "Confirming your subscription…" });
      let attempts = 0;
      const timer = setInterval(async () => {
        attempts += 1;
        await refresh();
        if (attempts >= 12) {
          clearInterval(timer);
          setSearchParams({}, { replace: true });
        }
      }, 5000);
      return () => clearInterval(timer);
    }
    if (searchParams.get("cancelled") === "1") {
      toast({ title: "Checkout cancelled", description: "No charge was made." });
      setSearchParams({}, { replace: true });
    }
  }, [searchParams, setSearchParams, refresh, toast]);

  useEffect(() => {
    if (isPremium && searchParams.get("subscribed") === "1") {
      setSearchParams({}, { replace: true });
      toast({ title: "You're Premium!", description: "All premium features are now unlocked." });
    }
  }, [isPremium, searchParams, setSearchParams, toast]);

  const startCheckout = async (priceId: string) => {
    if (!userId) {
      navigate("/auth");
      return;
    }
    setBusyPrice(priceId);
    try {
      const { data, error } = await supabase.functions.invoke("create-checkout", {
        body: { priceId },
      });
      if (error) throw error;
      if (data?.url) window.open(data.url, "_blank");
      else throw new Error("No checkout link returned");
    } catch (e) {
      console.error("Checkout error:", e);
      toast({ title: "Error", description: "Could not start checkout. Please try again.", variant: "destructive" });
    } finally {
      setBusyPrice(null);
    }
  };

  const openPortal = async () => {
    setManaging(true);
    try {
      const { data, error } = await supabase.functions.invoke("customer-portal");
      if (error) throw error;
      if (data?.url) window.open(data.url, "_blank");
      else throw new Error("No portal link returned");
    } catch (e) {
      console.error("Portal error:", e);
      toast({ title: "Error", description: "Could not open subscription management.", variant: "destructive" });
    } finally {
      setManaging(false);
    }
  };

  const refreshStatus = useCallback(async () => {
    setChecking(true);
    await refresh();
    setChecking(false);
    toast({ title: "Status refreshed" });
  }, [refresh, toast]);

  const price = (monthly: number, annualAmt: number) =>
    annual ? `$${annualAmt.toFixed(2)}/yr` : `$${monthly.toFixed(2)}/mo`;

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-10 max-w-4xl">
        {userId && (
          <Button
            variant="ghost"
            className="mb-6 -ml-2"
            onClick={() => navigate(role === "caregiver" ? "/caregiver" : "/dashboard")}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to dashboard
          </Button>
        )}

        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-3">Choose your plan</h1>
          <p className="text-lg text-muted-foreground max-w-xl mx-auto">
            Reli's core care tools are always free. Premium unlocks unlimited history,
            custom trackers &amp; reminders, and AI trends &amp; insights.
          </p>
          <p className="text-base text-foreground font-medium mt-4 max-w-xl mx-auto">
            One membership covers everyone. If either the senior or their caregiver
            subscribes, the premium features unlock for both of them.
          </p>
        </div>

        {isPremium && (
          <Card className="p-5 mb-8 border-2 border-primary bg-primary/5 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <Sparkles className="w-6 h-6 text-primary" />
              <div>
                <p className="text-lg font-semibold">You're on Premium</p>
                <p className="text-sm text-muted-foreground">Thank you for supporting Reli.</p>
              </div>
            </div>
            <Button variant="outline" onClick={isNativeApp() ? manageStoreSubscription : openPortal} disabled={managing}>
              {managing ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <CreditCard className="w-4 h-4 mr-2" />}
              Manage subscription
            </Button>
          </Card>
        )}

        {isNativeApp() ? (
          <StorePlans userId={userId} onActive={refresh} />
        ) : (
        <>
        <div className="flex items-center justify-center gap-3 mb-8">
          <Label htmlFor="billing-toggle" className={!annual ? "font-semibold" : "text-muted-foreground"}>
            Monthly
          </Label>
          <Switch id="billing-toggle" checked={annual} onCheckedChange={setAnnual} />
          <Label htmlFor="billing-toggle" className={annual ? "font-semibold" : "text-muted-foreground"}>
            Annual <Badge variant="secondary" className="ml-1">Save 15%</Badge>
          </Label>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          <Card className="p-6 border-2 flex flex-col">
            <h2 className="text-2xl font-semibold mb-1">Free</h2>
            <p className="text-3xl font-bold mb-4">$0</p>
            <ul className="space-y-2 mb-6 flex-1">
              {FREE_FEATURES.map((f) => (
                <li key={f} className="flex items-start gap-2 text-sm">
                  <Check className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                  {f}
                </li>
              ))}
            </ul>
            {!isPremium && (
              <Badge variant="outline" className="self-center">Your current plan</Badge>
            )}
          </Card>

          {PAID_PLANS.map((p, i) => (
            <Card
              key={p.id}
              className={`p-6 border-2 flex flex-col ${
                p.comingSoon ? "opacity-75 bg-muted/30" : i === 0 ? "border-primary shadow-lg" : ""
              }`}
            >
              <div className="flex items-center gap-2 mb-1 flex-wrap">
                <h2 className="text-2xl font-semibold">{p.name}</h2>
                {p.comingSoon ? (
                  <Badge variant="secondary">Coming soon</Badge>
                ) : (
                  i === 0 && <Badge className="bg-primary text-primary-foreground">Popular</Badge>
                )}
              </div>
              {p.comingSoon ? (
                <p className="text-3xl font-bold mb-1 text-muted-foreground">—</p>
              ) : (
                <p className="text-3xl font-bold mb-1">{price(p.monthlyAmount, p.annualAmount)}</p>
              )}
              <p className="text-sm text-muted-foreground mb-4">{p.blurb}</p>
              <ul className="space-y-2 mb-6 flex-1">
                {p.features.map((f) => (
                  <li key={f} className="flex items-start gap-2 text-sm">
                    <Check className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                    {f}
                  </li>
                ))}
              </ul>
              {p.comingSoon ? (
                <Button variant="outline" disabled className="w-full">
                  Coming soon
                </Button>
              ) : isPremium ? (
                <Badge variant="outline" className="self-center">Included in your plan</Badge>
              ) : (
                <Button
                  onClick={() => startCheckout(annual ? p.annualPriceId : p.monthlyPriceId)}
                  disabled={busyPrice !== null}
                >
                  {busyPrice === (annual ? p.annualPriceId : p.monthlyPriceId) && (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  )}
                  {userId ? "Upgrade" : "Sign in to upgrade"}
                </Button>
              )}
            </Card>
          ))}
        </div>

        </>
        )}

        {userId && !isPremium && (
          <div className="text-center mt-8">
            <Button variant="ghost" size="sm" onClick={refreshStatus} disabled={checking}>
              {checking ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <RefreshCw className="w-4 h-4 mr-2" />}
              Already subscribed? Refresh status
            </Button>
          </div>
        )}
      </main>
    </div>
  );
};

export default Pricing;
