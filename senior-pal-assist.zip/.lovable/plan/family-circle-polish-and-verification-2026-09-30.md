# Family Circle polish and verification

## Changes
- Add a consistent readable shadow behind every piece of text and each weather icon shown over the mountain/sky card.
- Keep the date and time at matching sizes.
- Make the Family Circle `+` control use the app’s standard accessible button.
- Complete all three Family Circle paths: joining by code, sharing a generated code/link, and sending an invitation email directly from Reli.
- Add clear loading, success, cancellation, and error feedback without changing the existing seven-day, single-use invite rules.

## Verification
- Check the mountain card at mobile and desktop sizes for text clarity and overlap.
- Exercise invite creation, email delivery request, and code validation.
- Confirm the join page preserves the code through sign-in and links the family account successfully.

## Technical details
- Reuse the current `circle_invites` records and `accept_circle_invite` secure action.
- Send invitation email through Reli’s existing managed email delivery pattern; no email queue or extra table.
