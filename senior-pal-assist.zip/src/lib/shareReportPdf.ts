import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

export interface SharedReportData {
  report: {
    title: string;
    notes: string | null;
    recipient_name: string | null;
    date_range_days: number;
    created_at: string;
    expires_at: string;
    include_medications: boolean;
    include_wellness: boolean;
    include_activity: boolean;
  };
  senior: { full_name: string };
  owner: { full_name: string; role: string };
  data: {
    medications: any[];
    wellness: any[];
    activity: any[];
    customTrackers: any[];
  };
}

export function generateSharedReportPdf(d: SharedReportData): jsPDF {
  const doc = new jsPDF({ unit: "pt", format: "letter" });
  const left = 48;
  let y = 56;

  doc.setFont("helvetica", "bold");
  doc.setFontSize(22);
  doc.text(d.report.title, left, y);
  y += 24;

  doc.setFont("helvetica", "normal");
  doc.setFontSize(11);
  doc.setTextColor(90);
  doc.text(`About: ${d.senior.full_name}`, left, y); y += 14;
  doc.text(`Shared by: ${d.owner.full_name} (${d.owner.role})`, left, y); y += 14;
  if (d.report.recipient_name) {
    doc.text(`Prepared for: ${d.report.recipient_name}`, left, y); y += 14;
  }
  doc.text(
    `Period: last ${d.report.date_range_days} days — Generated ${new Date(d.report.created_at).toLocaleDateString()}`,
    left, y
  );
  y += 20;
  doc.setTextColor(0);

  if (d.report.notes) {
    doc.setFont("helvetica", "bold"); doc.setFontSize(13);
    doc.text("Notes", left, y); y += 16;
    doc.setFont("helvetica", "normal"); doc.setFontSize(11);
    const lines = doc.splitTextToSize(d.report.notes, 500);
    doc.text(lines, left, y);
    y += lines.length * 14 + 10;
  }

  const addSection = (title: string, head: string[], body: any[][]) => {
    if (y > 700) { doc.addPage(); y = 56; }
    doc.setFont("helvetica", "bold"); doc.setFontSize(14);
    doc.text(title, left, y); y += 8;
    autoTable(doc, {
      startY: y + 4,
      head: [head],
      body: body.length ? body : [["No entries for this period"]],
      styles: { fontSize: 9, cellPadding: 5 },
      headStyles: { fillColor: [60, 90, 150] },
      margin: { left, right: left },
    });
    y = (doc as any).lastAutoTable.finalY + 20;
  };

  if (d.report.include_medications) {
    addSection(
      "Medications",
      ["Name", "Dosage", "Time", "Status", "Notes"],
      d.data.medications.map((m: any) => [
        m.name || "",
        m.dosage || "",
        m.time || "",
        m.completed ? `Taken${m.completed_at ? " " + new Date(m.completed_at).toLocaleString() : ""}` : "Not taken",
        m.notes || "",
      ])
    );
  }

  if (d.report.include_wellness) {
    addSection(
      "Daily Wellness Logs",
      ["Date", "Mood", "Meds", "Sleep", "Eating", "Confusion", "Fall", "Notes"],
      d.data.wellness.map((w: any) => [
        w.log_date,
        w.mood || "—",
        w.took_medications ? "Yes" : "No",
        w.slept_well ? "Yes" : "No",
        w.ate_well ? "Yes" : "No",
        w.confusion_noted ? "Yes" : "No",
        w.had_fall ? "Yes" : "No",
        w.notes || "",
      ])
    );
  }

  if (d.report.include_activity) {
    addSection(
      "Recent Activity",
      ["When", "Type", "Description"],
      d.data.activity.map((a: any) => [
        new Date(a.created_at).toLocaleString(),
        a.activity_type || "",
        a.activity_description || "",
      ])
    );
    addSection(
      "Custom Trackers",
      ["Name", "Type", "Value", "Status", "Updated"],
      d.data.customTrackers.map((t: any) => [
        t.name || "",
        t.tracker_type || "",
        t.value || "",
        t.completed ? "Completed" : "Active",
        t.updated_at ? new Date(t.updated_at).toLocaleString() : "",
      ])
    );
  }

  const total = doc.getNumberOfPages();
  for (let i = 1; i <= total; i++) {
    doc.setPage(i);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    doc.setTextColor(140);
    doc.text(`Reli wellness summary · Page ${i} of ${total}`, left, 780);
  }
  return doc;
}
