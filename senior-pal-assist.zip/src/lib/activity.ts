import { supabase } from "@/integrations/supabase/client";

export type ActivityStatus = "completed" | "pending" | "missed" | "skipped" | "cancelled" | "info";

/**
 * Records a senior's in-app action (feature opened, sign in/out, settings…).
 * Data changes (doses, readings, journal, SOS…) are captured by the backend
 * automatically, so call this only for actions that don't save data.
 * `eventId` makes retries safe: the same id is stored once.
 */
export const logActivity = async (
  type: string,
  description: string,
  opts: { feature?: string; status?: ActivityStatus; meta?: Record<string, unknown>; eventId?: string } = {},
) => {
  const eventId = opts.eventId ?? crypto.randomUUID();
  for (let attempt = 0; attempt < 3; attempt++) {
    const { error } = await supabase.rpc("log_my_activity" as any, {
      _event_id: eventId,
      _type: type,
      _desc: description,
      _feature: opts.feature ?? "general",
      _status: opts.status ?? "info",
      _meta: opts.meta ?? {},
    });
    if (!error) return;
    if (!/fetch|network/i.test(error.message)) return;
    await new Promise((r) => setTimeout(r, 1000 * (attempt + 1)));
  }
};

/** Logs a feature being opened at most once per 10 minutes per feature. */
export const logFeatureOpen = (feature: string, label: string) => {
  const bucket = Math.floor(Date.now() / 600000);
  const key = `open:${feature}:${bucket}`;
  try {
    if (sessionStorage.getItem(key)) return;
    sessionStorage.setItem(key, "1");
  } catch { /* storage blocked */ }
  void logActivity("Opened " + label, `Opened ${label}`, { feature, status: "info", eventId: `${key}:${crypto.randomUUID()}` });
};
