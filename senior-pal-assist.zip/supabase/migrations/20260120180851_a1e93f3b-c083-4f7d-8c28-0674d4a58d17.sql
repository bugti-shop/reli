-- Add RESTRICTIVE policy for newsletter_subscribers to ensure only site admins can SELECT
-- This is defense-in-depth since authenticated non-admin users should not be able to read subscriber emails

CREATE POLICY "Only authenticated site admins can read newsletter"
  ON public.newsletter_subscribers
  AS RESTRICTIVE
  FOR SELECT
  TO authenticated
  USING (is_site_admin(auth.uid()));