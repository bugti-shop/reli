import { createClient } from 'npm:@supabase/supabase-js@2'
import { z } from 'npm:zod@3.23.8'
import { sendTemplateEmail } from '../_shared/transactional-email-templates/send-email.ts'

// Public account / data deletion. Identity is proven ONLY by a 6-digit code
// emailed to the account address (no links). Responses never reveal whether
// an email has an account.

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })

export const CATEGORIES = [
  'messages', 'medications', 'vitals', 'journal', 'life_story', 'trackers', 'doctor', 'sos', 'activity',
] as const

const Body = z.discriminatedUnion('action', [
  z.object({ action: z.literal('send_code'), email: z.string().trim().email().max(255) }),
  z.object({
    action: z.literal('delete'),
    email: z.string().trim().email().max(255),
    code: z.string().trim().regex(/^\d{6}$/),
    scope: z.enum(['account', 'data']),
    categories: z.array(z.enum(CATEGORIES)).max(CATEGORIES.length).optional(),
  }),
])

const sha256 = async (s: string) => {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s))
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, '0')).join('')
}

const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!)

async function findUser(email: string) {
  const { data } = await admin.from('profiles').select('id, email').ilike('email', email).maybeSingle()
  return data
}

async function del(table: string, column: string, id: string) {
  const { error } = await admin.from(table).delete().eq(column, id)
  if (error) throw new Error(`${table}: ${error.message}`)
}

async function deleteCategory(cat: string, uid: string) {
  switch (cat) {
    case 'messages':
      await del('caregiver_messages', 'caregiver_id', uid)
      await del('caregiver_messages', 'senior_id', uid)
      break
    case 'medications':
      await del('medication_doses', 'senior_id', uid)
      await del('medication_doses', 'taken_by', uid)
      await del('medications', 'senior_id', uid)
      await del('medications', 'owner_id', uid)
      break
    case 'vitals':
      await del('vital_readings', 'senior_id', uid)
      await del('vital_readings', 'recorded_by', uid)
      break
    case 'journal':
      await del('journal_entries', 'senior_id', uid)
      await del('care_observations', 'senior_id', uid)
      await del('care_observations', 'caregiver_id', uid)
      await del('caregiver_daily_logs', 'senior_id', uid)
      await del('caregiver_daily_logs', 'caregiver_id', uid)
      break
    case 'life_story': {
      const { data: files } = await admin.storage.from('life-story-images').list(uid, { limit: 1000 })
      if (files?.length) {
        await admin.storage.from('life-story-images').remove(files.map((f) => `${uid}/${f.name}`))
      }
      await del('life_story_entries', 'senior_id', uid)
      await del('life_story_memories', 'senior_id', uid)
      break
    }
    case 'trackers':
      await del('custom_trackers', 'senior_id', uid)
      await del('custom_trackers', 'owner_id', uid)
      await del('tracker_reminders', 'senior_id', uid)
      await del('tracker_reminders', 'owner_id', uid)
      await del('senior_reminders', 'senior_id', uid)
      break
    case 'doctor':
      await del('doctor_questions', 'senior_id', uid)
      await del('doctor_questions', 'owner_id', uid)
      await del('shared_reports', 'senior_id', uid)
      await del('shared_reports', 'owner_id', uid)
      break
    case 'sos':
      await del('emergency_alerts', 'senior_id', uid)
      break
    case 'activity':
      await del('senior_activity_log', 'senior_id', uid)
      break
  }
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405)

  const parsed = Body.safeParse(await req.json().catch(() => ({})))
  if (!parsed.success) return json({ error: 'Please check the details you entered.' }, 400)
  const input = parsed.data
  const email = input.email.toLowerCase()

  try {
    if (input.action === 'send_code') {
      const { data: recent } = await admin
        .from('account_deletion_codes')
        .select('created_at')
        .eq('email', email)
        .gte('created_at', new Date(Date.now() - 60_000).toISOString())
        .limit(1)
      if (recent?.length) return json({ error: 'Please wait a minute before asking for a new code.' }, 429)

      const user = await findUser(email)
      if (user && !user.email.endsWith('@managed.reli.care')) {
        const code = String(crypto.getRandomValues(new Uint32Array(1))[0] % 1_000_000).padStart(6, '0')
        await admin.from('account_deletion_codes').insert({
          email,
          code_hash: await sha256(`${email}:${code}`),
          expires_at: new Date(Date.now() + 10 * 60_000).toISOString(),
        })
        await sendTemplateEmail('account-deletion-code', user.email, { templateData: { code } })
      }
      return json({ ok: true })
    }

    // delete
    const { data: row } = await admin
      .from('account_deletion_codes')
      .select('id, code_hash, attempts, expires_at, used_at')
      .eq('email', email)
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle()
    const invalid = () => json({ error: 'That code is wrong or has expired. Please ask for a new one.' }, 400)
    if (!row || row.used_at || row.attempts >= 5 || new Date(row.expires_at).getTime() < Date.now()) return invalid()
    if ((await sha256(`${email}:${input.code}`)) !== row.code_hash) {
      await admin.from('account_deletion_codes').update({ attempts: row.attempts + 1 }).eq('id', row.id)
      return invalid()
    }
    await admin.from('account_deletion_codes').update({ used_at: new Date().toISOString() }).eq('id', row.id)

    const user = await findUser(email)
    if (!user) return invalid()

    if (input.scope === 'data') {
      const cats = input.categories ?? []
      if (!cats.length) return json({ error: 'Please choose what to delete.' }, 400)
      for (const c of cats.filter((c) => c !== 'activity')) await deleteCategory(c, user.id)
      if (cats.includes('activity')) await deleteCategory('activity', user.id)
      return json({ ok: true, deleted: cats })
    }

    for (const c of CATEGORIES) await deleteCategory(c, user.id)
    await del('senior_feature_settings', 'senior_id', user.id)
    await del('senior_feature_settings', 'caregiver_id', user.id)
    const { error } = await admin.auth.admin.deleteUser(user.id)
    if (error) throw error
    await admin.from('account_deletion_codes').delete().eq('email', email)
    return json({ ok: true, deleted: 'account' })
  } catch (e) {
    console.error('account-deletion failed', e)
    return json({ error: 'Something went wrong. Please try again or email info@reli.care.' }, 500)
  }
})
