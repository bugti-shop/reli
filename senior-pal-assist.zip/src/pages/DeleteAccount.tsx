import { useEffect, useState } from "react";
import Header from "@/components/Header";
import { AccountDeletion } from "@/components/AccountDeletion";
import { supabase } from "@/integrations/supabase/client";

const DeleteAccount = () => {
  const [email, setEmail] = useState<string | null>(null);
  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setEmail(data.user?.email ?? ""));
    document.title = "Delete your Reli account or data";
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-8 max-w-2xl space-y-6">
        <h1 className="text-3xl font-bold">Delete your Reli account or data</h1>
        <div className="text-muted-foreground space-y-2 text-sm">
          <p>Reli (by Reli, app ID com.reli.care) lets you delete your whole account, or only parts of your data, at any time.</p>
          <ol className="list-decimal pl-5 space-y-1">
            <li>Enter the email of your Reli account.</li>
            <li>Enter the 6-digit code we email you.</li>
            <li>Choose which data to delete, or delete the whole account.</li>
          </ol>
          <p>Deletion happens immediately and permanently. Nothing is kept after an account is deleted, except anonymous billing records required by law. Questions: info@reli.care</p>
        </div>
        {email !== null && <AccountDeletion defaultEmail={email} />}
      </main>
    </div>
  );
};

export default DeleteAccount;
